#!/usr/bin/env python3
"""
RRV analysis for biosignals/bio_eventrelated_100hz.csv.

Loads the RSP signal, cleans it, extracts inhalation peaks and respiratory-rate
signal, computes respiratory-rate-variability indices in time, frequency, and
nonlinear domains, and saves results to:
    pred_results/rrv_analysis_pred.csv
"""
import os
import json
import math
import warnings
import importlib.util

import numpy as np
import pandas as pd

from scipy import signal, interpolate, stats


INPUT = "biosignals/bio_eventrelated_100hz.csv"
OUTDIR = "pred_results"
OUTPUT = os.path.join(OUTDIR, "rrv_analysis_pred.csv")
FS = 100.0


def finite_array(x):
    x = np.asarray(x, dtype=float)
    if np.any(~np.isfinite(x)):
        s = pd.Series(x)
        x = s.interpolate(limit_direction="both").bfill().ffill().to_numpy(dtype=float)
    return x


def clean_rsp_fallback(rsp, fs=100.0):
    """Bandpass clean respiration; typical adult breathing 0.05-1.0 Hz."""
    x = finite_array(rsp)
    x = signal.detrend(x, type="linear")
    nyq = fs / 2.0
    low = 0.05 / nyq
    high = 1.0 / nyq
    b, a = signal.butter(4, [low, high], btype="bandpass")
    try:
        y = signal.filtfilt(b, a, x)
    except ValueError:
        y = signal.lfilter(b, a, x)
    return y


def find_inhalation_peaks_fallback(cleaned, fs=100.0):
    """Find inhalation peaks in cleaned RSP."""
    x = np.asarray(cleaned, dtype=float)
    # Minimum distance 1.5 s -> up to 40 breaths/min; prominence adaptive.
    min_distance = int(round(1.5 * fs))
    prom = max(np.nanstd(x) * 0.15, np.ptp(x) * 0.02, 1e-12)
    peaks, props = signal.find_peaks(x, distance=min_distance, prominence=prom)

    # If too few peaks, relax prominence. If too many, increase distance/prominence.
    if len(peaks) < 3:
        peaks, props = signal.find_peaks(x, distance=int(round(1.0 * fs)), prominence=max(np.nanstd(x) * 0.05, 1e-12))
    if len(peaks) > 0:
        # Reject extreme inter-peak intervals by physiological range 1.5-15 s if possible.
        return peaks.astype(int), props
    return np.array([], dtype=int), props


def compute_rate_from_peaks(peaks, n_samples, fs=100.0):
    """Create sample-wise respiratory-rate signal in breaths/min from inhalation peaks."""
    rate = np.full(n_samples, np.nan, dtype=float)
    peaks = np.asarray(peaks, dtype=int)
    if len(peaks) < 2:
        return rate
    t_peaks = peaks / fs
    intervals = np.diff(t_peaks)
    inst_rate = 60.0 / intervals
    # Associate interval rate with midpoint between adjacent peaks.
    t_mid = (t_peaks[:-1] + t_peaks[1:]) / 2.0
    valid = np.isfinite(inst_rate) & (inst_rate > 0) & (inst_rate < 80)
    if valid.sum() == 0:
        return rate
    t_all = np.arange(n_samples) / fs
    f = interpolate.interp1d(
        t_mid[valid],
        inst_rate[valid],
        kind="linear",
        bounds_error=False,
        fill_value=(inst_rate[valid][0], inst_rate[valid][-1]),
        assume_sorted=False,
    )
    rate = f(t_all)
    return rate


def triangular_index(intervals):
    intervals = np.asarray(intervals, dtype=float)
    intervals = intervals[np.isfinite(intervals)]
    if len(intervals) < 3:
        return np.nan
    bin_width = 1.0 / 128.0  # seconds, analogous to HRV triangular index convention
    bins = np.arange(np.nanmin(intervals), np.nanmax(intervals) + bin_width, bin_width)
    if len(bins) < 2:
        return np.nan
    hist, _ = np.histogram(intervals, bins=bins)
    max_count = np.max(hist) if len(hist) else 0
    return float(len(intervals) / max_count) if max_count > 0 else np.nan


def tinn(intervals):
    """Approximate TINN as width of central 90% of interval distribution."""
    intervals = np.asarray(intervals, dtype=float)
    intervals = intervals[np.isfinite(intervals)]
    if len(intervals) < 4:
        return np.nan
    return float(np.percentile(intervals, 95) - np.percentile(intervals, 5))


def sample_entropy(x, m=2, r=None):
    """Simple sample entropy implementation."""
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n <= m + 2:
        return np.nan
    if r is None:
        sd = np.std(x, ddof=0)
        if sd <= 0 or not np.isfinite(sd):
            return np.nan
        r = 0.2 * sd

    def count_matches(mm):
        count = 0
        templates = np.array([x[i:i + mm] for i in range(n - mm + 1)])
        for i in range(len(templates) - 1):
            dist = np.max(np.abs(templates[i + 1:] - templates[i]), axis=1)
            count += np.sum(dist <= r)
        return count

    b = count_matches(m)
    a = count_matches(m + 1)
    if b == 0:
        return np.nan
    if a == 0:
        return np.inf
    return float(-np.log(a / b))


def approximate_entropy(x, m=2, r=None):
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n <= m + 2:
        return np.nan
    if r is None:
        sd = np.std(x, ddof=0)
        if sd <= 0 or not np.isfinite(sd):
            return np.nan
        r = 0.2 * sd

    def phi(mm):
        templates = np.array([x[i:i + mm] for i in range(n - mm + 1)])
        c = []
        for tmpl in templates:
            dist = np.max(np.abs(templates - tmpl), axis=1)
            c.append(np.mean(dist <= r))
        c = np.asarray(c)
        c = c[c > 0]
        if len(c) == 0:
            return np.nan
        return np.mean(np.log(c))

    p1 = phi(m)
    p2 = phi(m + 1)
    if not np.isfinite(p1) or not np.isfinite(p2):
        return np.nan
    return float(p1 - p2)


def poincare_features(intervals):
    x = np.asarray(intervals, dtype=float)
    x = x[np.isfinite(x)]
    if len(x) < 3:
        return {"SD1": np.nan, "SD2": np.nan, "SD1SD2": np.nan, "EllipseArea": np.nan}
    diff = np.diff(x)
    sd1 = np.sqrt(0.5) * np.std(diff, ddof=1)
    sdnn = np.std(x, ddof=1)
    sd2_sq = max(0.0, 2 * sdnn**2 - 0.5 * np.std(diff, ddof=1)**2)
    sd2 = np.sqrt(sd2_sq)
    return {
        "SD1": float(sd1),
        "SD2": float(sd2),
        "SD1SD2": float(sd1 / sd2) if sd2 > 0 else np.nan,
        "EllipseArea": float(np.pi * sd1 * sd2) if np.isfinite(sd1) and np.isfinite(sd2) else np.nan,
    }


def dfa_alpha(x):
    """Basic DFA alpha over feasible scales."""
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n < 16:
        return np.nan
    y = np.cumsum(x - np.mean(x))
    scales = np.unique(np.floor(np.logspace(np.log10(4), np.log10(max(5, n // 4)), 10)).astype(int))
    flucts = []
    used_scales = []
    for s in scales:
        if s < 4 or n // s < 2:
            continue
        rms = []
        for start in range(0, n - s + 1, s):
            seg = y[start:start + s]
            t = np.arange(s)
            coef = np.polyfit(t, seg, 1)
            trend = np.polyval(coef, t)
            rms.append(np.sqrt(np.mean((seg - trend) ** 2)))
        if len(rms) > 0 and np.mean(rms) > 0:
            used_scales.append(s)
            flucts.append(np.mean(rms))
    if len(flucts) < 2:
        return np.nan
    slope, _, _, _, _ = stats.linregress(np.log(used_scales), np.log(flucts))
    return float(slope)


def frequency_features_from_intervals(peaks, intervals, fs_resample=4.0):
    """
    Frequency-domain RRV from uneven breath intervals resampled at 4 Hz.
    Frequency bands adapted for respiration interval variability:
    VLF 0.00-0.04 Hz, LF 0.04-0.15 Hz, HF 0.15-0.40 Hz.
    """
    out = {
        "VLF_Power": np.nan, "LF_Power": np.nan, "HF_Power": np.nan,
        "Total_Power": np.nan, "LFHF": np.nan, "LF_Norm": np.nan, "HF_Norm": np.nan,
        "Peak_Frequency": np.nan
    }
    peaks = np.asarray(peaks, dtype=float)
    intervals = np.asarray(intervals, dtype=float)
    good = np.isfinite(intervals) & (intervals > 0)
    intervals = intervals[good]
    if len(intervals) < 4 or len(peaks) < 5:
        return out

    t_mid = (peaks[:-1] + peaks[1:]) / 2.0
    t_mid = t_mid[good]
    if len(np.unique(t_mid)) < 4:
        return out
    duration = t_mid[-1] - t_mid[0]
    if duration <= 10:
        return out

    t_grid = np.arange(t_mid[0], t_mid[-1], 1.0 / fs_resample)
    if len(t_grid) < 16:
        return out
    interp = interpolate.interp1d(t_mid, intervals, kind="linear", bounds_error=False, fill_value="extrapolate")
    y = interp(t_grid)
    y = signal.detrend(y)

    nperseg = min(256, len(y))
    if nperseg < 16:
        return out
    freqs, psd = signal.welch(y, fs=fs_resample, nperseg=nperseg, noverlap=nperseg // 2)

    def bandpower(lo, hi):
        mask = (freqs >= lo) & (freqs < hi)
        if mask.sum() < 1:
            return 0.0
        return float(np.trapz(psd[mask], freqs[mask]))

    vlf = bandpower(0.0033, 0.04)
    lf = bandpower(0.04, 0.15)
    hf = bandpower(0.15, 0.40)
    total = bandpower(0.0033, 0.40)
    valid_band = (freqs >= 0.0033) & (freqs <= 0.40)
    peakf = float(freqs[valid_band][np.argmax(psd[valid_band])]) if np.any(valid_band) else np.nan
    out.update({
        "VLF_Power": vlf,
        "LF_Power": lf,
        "HF_Power": hf,
        "Total_Power": total,
        "LFHF": float(lf / hf) if hf > 0 else np.nan,
        "LF_Norm": float(100 * lf / (total - vlf)) if (total - vlf) > 0 else np.nan,
        "HF_Norm": float(100 * hf / (total - vlf)) if (total - vlf) > 0 else np.nan,
        "Peak_Frequency": peakf,
    })
    return out


def compute_features(peaks_samples, cleaned, rate_signal, fs=100.0):
    n = len(cleaned)
    peaks_samples = np.asarray(peaks_samples, dtype=int)
    peak_times = peaks_samples / fs
    intervals = np.diff(peak_times)
    # Keep physiologically plausible breath intervals: 1.5-15 s (4-40 br/min)
    plausible = np.isfinite(intervals) & (intervals >= 1.5) & (intervals <= 15.0)
    if plausible.sum() >= max(3, int(0.5 * len(intervals))):
        # Keep peak pairs by rebuilding intervals only; features use filtered intervals.
        intervals_clean = intervals[plausible]
    else:
        intervals_clean = intervals[np.isfinite(intervals) & (intervals > 0)]

    rates = 60.0 / intervals_clean if len(intervals_clean) else np.array([], dtype=float)
    rate_valid = np.asarray(rate_signal, dtype=float)
    rate_valid = rate_valid[np.isfinite(rate_valid)]

    feats = {
        "Sampling_Rate_Hz": fs,
        "Duration_s": n / fs,
        "N_Samples": n,
        "N_Inhalation_Peaks": int(len(peaks_samples)),
        "N_Breath_Intervals": int(len(intervals_clean)),
        "First_Peak_s": float(peak_times[0]) if len(peak_times) else np.nan,
        "Last_Peak_s": float(peak_times[-1]) if len(peak_times) else np.nan,
    }

    # Time domain: intervals in seconds and rates in breaths/min.
    if len(intervals_clean):
        diff_intervals = np.diff(intervals_clean)
        feats.update({
            "Mean_Breath_Interval_s": float(np.mean(intervals_clean)),
            "Median_Breath_Interval_s": float(np.median(intervals_clean)),
            "SD_Breath_Interval_s": float(np.std(intervals_clean, ddof=1)) if len(intervals_clean) > 1 else np.nan,
            "RMSSD_Breath_Interval_s": float(np.sqrt(np.mean(diff_intervals**2))) if len(diff_intervals) else np.nan,
            "SDSD_Breath_Interval_s": float(np.std(diff_intervals, ddof=1)) if len(diff_intervals) > 1 else np.nan,
            "CV_Breath_Interval": float(np.std(intervals_clean, ddof=1) / np.mean(intervals_clean)) if len(intervals_clean) > 1 and np.mean(intervals_clean) != 0 else np.nan,
            "IQR_Breath_Interval_s": float(np.percentile(intervals_clean, 75) - np.percentile(intervals_clean, 25)),
            "MAD_Breath_Interval_s": float(stats.median_abs_deviation(intervals_clean, scale=1.0)),
            "Min_Breath_Interval_s": float(np.min(intervals_clean)),
            "Max_Breath_Interval_s": float(np.max(intervals_clean)),
            "Mean_Respiratory_Rate_bpm": float(np.mean(rates)) if len(rates) else np.nan,
            "Median_Respiratory_Rate_bpm": float(np.median(rates)) if len(rates) else np.nan,
            "SD_Respiratory_Rate_bpm": float(np.std(rates, ddof=1)) if len(rates) > 1 else np.nan,
            "Min_Respiratory_Rate_bpm": float(np.min(rates)) if len(rates) else np.nan,
            "Max_Respiratory_Rate_bpm": float(np.max(rates)) if len(rates) else np.nan,
            "pNN50_Breath_Interval_pct": float(100 * np.mean(np.abs(diff_intervals) > 0.050)) if len(diff_intervals) else np.nan,
            "pNN100_Breath_Interval_pct": float(100 * np.mean(np.abs(diff_intervals) > 0.100)) if len(diff_intervals) else np.nan,
            "Triangular_Index": triangular_index(intervals_clean),
            "TINN_s": tinn(intervals_clean),
        })
    else:
        feats.update({k: np.nan for k in [
            "Mean_Breath_Interval_s", "Median_Breath_Interval_s", "SD_Breath_Interval_s",
            "RMSSD_Breath_Interval_s", "SDSD_Breath_Interval_s", "CV_Breath_Interval",
            "IQR_Breath_Interval_s", "MAD_Breath_Interval_s", "Min_Breath_Interval_s",
            "Max_Breath_Interval_s", "Mean_Respiratory_Rate_bpm", "Median_Respiratory_Rate_bpm",
            "SD_Respiratory_Rate_bpm", "Min_Respiratory_Rate_bpm", "Max_Respiratory_Rate_bpm",
            "pNN50_Breath_Interval_pct", "pNN100_Breath_Interval_pct", "Triangular_Index", "TINN_s"
        ]})

    if len(rate_valid):
        feats.update({
            "RateSignal_Mean_bpm": float(np.mean(rate_valid)),
            "RateSignal_SD_bpm": float(np.std(rate_valid, ddof=1)) if len(rate_valid) > 1 else np.nan,
            "RateSignal_Min_bpm": float(np.min(rate_valid)),
            "RateSignal_Max_bpm": float(np.max(rate_valid)),
        })
    else:
        feats.update({
            "RateSignal_Mean_bpm": np.nan,
            "RateSignal_SD_bpm": np.nan,
            "RateSignal_Min_bpm": np.nan,
            "RateSignal_Max_bpm": np.nan,
        })

    # Frequency domain.
    feats.update(frequency_features_from_intervals(peak_times, intervals_clean))

    # Nonlinear.
    pc = poincare_features(intervals_clean)
    feats.update({
        "Poincare_SD1_s": pc["SD1"],
        "Poincare_SD2_s": pc["SD2"],
        "Poincare_SD1SD2": pc["SD1SD2"],
        "Poincare_EllipseArea_s2": pc["EllipseArea"],
        "Sample_Entropy": sample_entropy(intervals_clean),
        "Approximate_Entropy": approximate_entropy(intervals_clean),
        "DFA_Alpha": dfa_alpha(intervals_clean),
    })

    # Signal/amplitude features at inhalation peaks.
    if len(peaks_samples):
        peak_vals = cleaned[peaks_samples]
        feats.update({
            "InhalationPeak_Amplitude_Mean": float(np.mean(peak_vals)),
            "InhalationPeak_Amplitude_SD": float(np.std(peak_vals, ddof=1)) if len(peak_vals) > 1 else np.nan,
            "InhalationPeak_Amplitude_Min": float(np.min(peak_vals)),
            "InhalationPeak_Amplitude_Max": float(np.max(peak_vals)),
        })
    else:
        feats.update({
            "InhalationPeak_Amplitude_Mean": np.nan,
            "InhalationPeak_Amplitude_SD": np.nan,
            "InhalationPeak_Amplitude_Min": np.nan,
            "InhalationPeak_Amplitude_Max": np.nan,
        })
    return feats


def use_neurokit_if_available(rsp, fs=100.0):
    """Try NeuroKit2 processing; return cleaned, peaks, rate, metadata."""
    if importlib.util.find_spec("neurokit2") is None:
        return None
    try:
        import neurokit2 as nk
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            signals, info = nk.rsp_process(rsp, sampling_rate=fs)
        cleaned = signals["RSP_Clean"].to_numpy(dtype=float) if "RSP_Clean" in signals else clean_rsp_fallback(rsp, fs)
        if "RSP_Peaks" in signals:
            peaks = np.flatnonzero(signals["RSP_Peaks"].to_numpy() > 0).astype(int)
        else:
            peaks = np.asarray(info.get("RSP_Peaks", []), dtype=int)
        if len(peaks) < 3:
            peaks, _ = find_inhalation_peaks_fallback(cleaned, fs)
        if "RSP_Rate" in signals:
            rate = signals["RSP_Rate"].to_numpy(dtype=float)
        else:
            rate = compute_rate_from_peaks(peaks, len(rsp), fs)
        return cleaned, peaks, rate, {"method": "neurokit2_rsp_process"}
    except Exception as e:
        print("NeuroKit2 processing failed; using fallback. Error:", repr(e))
        return None


def main():
    os.makedirs(OUTDIR, exist_ok=True)

    print("Loading:", INPUT)
    df = pd.read_csv(INPUT)
    print("Columns:", list(df.columns))
    print("Shape:", df.shape)
    if "RSP" not in df.columns:
        raise ValueError("Input CSV does not contain an RSP column.")

    rsp = finite_array(df["RSP"].to_numpy(dtype=float))
    print("RSP summary:", json.dumps({
        "n": int(len(rsp)),
        "duration_s": len(rsp) / FS,
        "mean": float(np.mean(rsp)),
        "std": float(np.std(rsp)),
        "min": float(np.min(rsp)),
        "max": float(np.max(rsp)),
    }, indent=2))

    nk_result = use_neurokit_if_available(rsp, FS)
    if nk_result is not None:
        cleaned, peaks, rate_signal, meta = nk_result
    else:
        cleaned = clean_rsp_fallback(rsp, FS)
        peaks, _ = find_inhalation_peaks_fallback(cleaned, FS)
        rate_signal = compute_rate_from_peaks(peaks, len(rsp), FS)
        meta = {"method": "scipy_fallback_bandpass_find_peaks"}

    # Final sanity filter: remove peaks creating implausible local intervals only if numerous.
    if len(peaks) >= 3:
        peak_times = peaks / FS
        intervals = np.diff(peak_times)
        plausible = (intervals >= 1.5) & (intervals <= 15.0)
        print("Initial peaks:", len(peaks), "plausible intervals:", int(plausible.sum()), "/", len(intervals))
    else:
        print("Initial peaks:", len(peaks))

    features = compute_features(peaks, cleaned, rate_signal, FS)
    features["Processing_Method"] = meta["method"]

    out = pd.DataFrame([features])
    # Stable column order: metadata first, then alphabetical rest.
    first_cols = [
        "Processing_Method", "Sampling_Rate_Hz", "Duration_s", "N_Samples",
        "N_Inhalation_Peaks", "N_Breath_Intervals", "Mean_Respiratory_Rate_bpm",
        "Mean_Breath_Interval_s"
    ]
    cols = [c for c in first_cols if c in out.columns] + sorted([c for c in out.columns if c not in first_cols])
    out = out[cols]
    out.to_csv(OUTPUT, index=False)

    print("Saved:", OUTPUT)
    print("Output shape:", out.shape)
    print("Key results:")
    for k in [
        "Processing_Method", "Duration_s", "N_Inhalation_Peaks", "N_Breath_Intervals",
        "Mean_Respiratory_Rate_bpm", "SD_Respiratory_Rate_bpm",
        "Mean_Breath_Interval_s", "SD_Breath_Interval_s",
        "RMSSD_Breath_Interval_s", "LF_Power", "HF_Power", "LFHF",
        "Poincare_SD1_s", "Poincare_SD2_s", "Sample_Entropy", "DFA_Alpha"
    ]:
        if k in out.columns:
            print(f"  {k}: {out.loc[0, k]}")
    print("All columns:", list(out.columns))


if __name__ == "__main__":
    main()