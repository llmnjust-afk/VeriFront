#!/usr/bin/env python3
"""
RRV analysis for biosignals/bio_eventrelated_100hz.csv.

Outputs:
  pred_results/rrv_analysis_pred.csv

The script cleans the RSP signal, detects inhalation peaks, derives breath-to-breath
intervals and a respiratory-rate time series, then computes time-domain,
frequency-domain, and nonlinear RRV features.
"""

import os
import math
import warnings
from pathlib import Path

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore", category=RuntimeWarning)

FS = 100.0
INPUT = Path("biosignals/bio_eventrelated_100hz.csv")
OUTDIR = Path("pred_results")
OUTFILE = OUTDIR / "rrv_analysis_pred.csv"


def _safe_float(x):
    try:
        if x is None:
            return np.nan
        x = float(x)
        if np.isfinite(x):
            return x
        return np.nan
    except Exception:
        return np.nan


def clean_rsp_fallback(rsp, fs):
    """Bandpass-clean respiration signal without requiring NeuroKit2."""
    from scipy import signal

    x = np.asarray(rsp, dtype=float)
    s = pd.Series(x).interpolate(limit_direction="both").bfill().ffill().to_numpy(dtype=float)

    # Remove slow drift and high-frequency noise. Respiration is commonly 0.05-1 Hz.
    nyq = fs / 2.0
    low = 0.05 / nyq
    high = 1.0 / nyq
    if len(s) > int(fs * 6):
        b, a = signal.butter(2, [low, high], btype="bandpass")
        cleaned = signal.filtfilt(b, a, s, method="pad")
    else:
        cleaned = signal.detrend(s)

    # Robust centering
    cleaned = cleaned - np.nanmedian(cleaned)
    return cleaned


def process_with_neurokit_or_fallback(rsp, fs):
    """
    Try NeuroKit2 for RSP cleaning/peak detection. Fall back to scipy detector.
    Returns cleaned signal, peak indices, respiration-rate signal, method string.
    """
    method = "scipy_fallback"
    cleaned = None
    peaks = None
    rate_signal = None

    try:
        import neurokit2 as nk  # noqa: F401

        signals, info = nk.rsp_process(rsp, sampling_rate=fs)
        method = "neurokit2_rsp_process"

        if "RSP_Clean" in signals:
            cleaned = signals["RSP_Clean"].to_numpy(dtype=float)
        else:
            cleaned = clean_rsp_fallback(rsp, fs)

        peak_col = None
        for col in ["RSP_Peaks", "RSP_Inspiration_Onsets"]:
            if col in signals.columns:
                peak_col = col
                break
        if peak_col is not None:
            peaks = np.flatnonzero(signals[peak_col].to_numpy() == 1)

        if peaks is None or len(peaks) < 3:
            if isinstance(info, dict):
                for key in ["RSP_Peaks", "Peaks"]:
                    if key in info:
                        tmp = np.asarray(info[key], dtype=int)
                        if len(tmp) >= 3:
                            peaks = tmp
                            break

        if "RSP_Rate" in signals:
            rate_signal = signals["RSP_Rate"].to_numpy(dtype=float)

    except Exception as exc:
        method = f"scipy_fallback_neurokit_unavailable_or_failed:{type(exc).__name__}"
        cleaned = None
        peaks = None
        rate_signal = None

    if cleaned is None or not np.all(np.isfinite(cleaned)):
        cleaned = clean_rsp_fallback(rsp, fs)

    if peaks is None or len(peaks) < 3:
        from scipy.signal import find_peaks

        finite_clean = cleaned[np.isfinite(cleaned)]
        scale = np.nanpercentile(finite_clean, 95) - np.nanpercentile(finite_clean, 5)
        prom = max(0.05 * scale, 0.10 * np.nanstd(finite_clean), 1e-9)

        # Physiological lower bound: do not allow peaks closer than 0.8 s (75 br/min).
        peaks, props = find_peaks(
            cleaned,
            distance=int(round(0.8 * fs)),
            prominence=prom,
        )

        # If too few peaks, relax prominence.
        if len(peaks) < 3:
            peaks, props = find_peaks(
                cleaned,
                distance=int(round(0.8 * fs)),
                prominence=max(0.02 * scale, 1e-9),
            )

    # Sort and keep in-bounds unique peaks.
    peaks = np.unique(np.asarray(peaks, dtype=int))
    peaks = peaks[(peaks >= 0) & (peaks < len(cleaned))]

    # Build respiratory-rate signal if NeuroKit did not provide one.
    if rate_signal is None or len(rate_signal) != len(cleaned) or np.sum(np.isfinite(rate_signal)) < 10:
        rate_signal = np.full(len(cleaned), np.nan, dtype=float)
        if len(peaks) >= 2:
            intervals = np.diff(peaks) / fs
            rr = 60.0 / intervals
            times_for_rr = peaks[1:] / fs
            valid = np.isfinite(rr) & (intervals >= 0.8) & (intervals <= 12.0) & (rr >= 5) & (rr <= 75)
            if np.sum(valid) >= 2:
                t = np.arange(len(cleaned)) / fs
                rate_signal = np.interp(t, times_for_rr[valid], rr[valid], left=rr[valid][0], right=rr[valid][-1])

    return cleaned, peaks, rate_signal, method


def derive_valid_breath_intervals(peaks, fs):
    """Return peak times, valid breath-to-breath intervals, and interval times."""
    peaks = np.asarray(peaks, dtype=int)
    if len(peaks) < 2:
        return peaks / fs, np.array([]), np.array([]), np.array([], dtype=bool)

    intervals = np.diff(peaks) / fs
    interval_times = peaks[1:] / fs

    # Conservative artifact rejection for respiration: 0.8-12 s = 5-75 breaths/min.
    valid = np.isfinite(intervals) & (intervals >= 0.8) & (intervals <= 12.0)

    if np.sum(valid) >= 5:
        med = np.nanmedian(intervals[valid])
        mad = np.nanmedian(np.abs(intervals[valid] - med))
        if np.isfinite(mad) and mad > 0:
            robust_z = 0.6745 * np.abs(intervals - med) / mad
            valid = valid & (robust_z <= 5.0)

    return peaks / fs, intervals[valid], interval_times[valid], valid


def time_domain_features(bbi):
    """Time-domain RRV features from breath-to-breath intervals in seconds."""
    bbi = np.asarray(bbi, dtype=float)
    bbi = bbi[np.isfinite(bbi)]
    out = {}

    out["RRV_Breaths_Used"] = int(len(bbi))
    if len(bbi) == 0:
        keys = [
            "RRV_MeanBB_s", "RRV_MedianBB_s", "RRV_MinBB_s", "RRV_MaxBB_s",
            "RRV_SDNN_s", "RRV_RMSSD_s", "RRV_SDSD_s", "RRV_CVBB",
            "RRV_MeanRate_bpm", "RRV_MedianRate_bpm", "RRV_SDRate_bpm",
            "RRV_pNN25_pct", "RRV_pNN50_pct", "RRV_TINN_s", "RRV_TriangularIndex"
        ]
        out.update({k: np.nan for k in keys})
        return out

    diff = np.diff(bbi)
    rate = 60.0 / bbi

    out["RRV_MeanBB_s"] = np.mean(bbi)
    out["RRV_MedianBB_s"] = np.median(bbi)
    out["RRV_MinBB_s"] = np.min(bbi)
    out["RRV_MaxBB_s"] = np.max(bbi)
    out["RRV_SDNN_s"] = np.std(bbi, ddof=1) if len(bbi) > 1 else np.nan
    out["RRV_RMSSD_s"] = np.sqrt(np.mean(diff ** 2)) if len(diff) > 0 else np.nan
    out["RRV_SDSD_s"] = np.std(diff, ddof=1) if len(diff) > 1 else np.nan
    out["RRV_CVBB"] = out["RRV_SDNN_s"] / out["RRV_MeanBB_s"] if out["RRV_MeanBB_s"] else np.nan
    out["RRV_MeanRate_bpm"] = np.mean(rate)
    out["RRV_MedianRate_bpm"] = np.median(rate)
    out["RRV_SDRate_bpm"] = np.std(rate, ddof=1) if len(rate) > 1 else np.nan
    out["RRV_pNN25_pct"] = 100.0 * np.mean(np.abs(diff) > 0.025) if len(diff) else np.nan
    out["RRV_pNN50_pct"] = 100.0 * np.mean(np.abs(diff) > 0.050) if len(diff) else np.nan

    if len(bbi) >= 5:
        counts, edges = np.histogram(bbi, bins="auto")
        if len(counts) and np.max(counts) > 0:
            out["RRV_TriangularIndex"] = len(bbi) / np.max(counts)
            nonzero = np.flatnonzero(counts)
            out["RRV_TINN_s"] = edges[nonzero[-1] + 1] - edges[nonzero[0]] if len(nonzero) else np.nan
        else:
            out["RRV_TriangularIndex"] = np.nan
            out["RRV_TINN_s"] = np.nan
    else:
        out["RRV_TriangularIndex"] = np.nan
        out["RRV_TINN_s"] = np.nan

    return out


def bandpower(freqs, psd, lo, hi):
    mask = np.isfinite(freqs) & np.isfinite(psd) & (freqs >= lo) & (freqs < hi)
    if np.sum(mask) < 2:
        return np.nan
    return float(np.trapz(psd[mask], freqs[mask]))


def frequency_domain_features(bbi, bbi_times, cleaned_rsp, fs):
    """
    Frequency-domain RRV features.

    HRV-style bands are used for interval variability:
      VLF: 0.0033-0.04 Hz, LF: 0.04-0.15 Hz, HF: 0.15-0.40 Hz.
    Also compute dominant breathing frequency directly from the cleaned RSP signal.
    """
    from scipy import signal

    out = {}
    for k in [
        "RRV_VLF_power_s2", "RRV_LF_power_s2", "RRV_HF_power_s2",
        "RRV_TotalPower_s2", "RRV_LFHF", "RRV_LFn_pct", "RRV_HFn_pct",
        "RRV_PeakFreq_VLF_Hz", "RRV_PeakFreq_LF_Hz", "RRV_PeakFreq_HF_Hz",
        "RSP_DominantFreq_Hz", "RSP_DominantRate_bpm"
    ]:
        out[k] = np.nan

    bbi = np.asarray(bbi, dtype=float)
    bbi_times = np.asarray(bbi_times, dtype=float)
    valid = np.isfinite(bbi) & np.isfinite(bbi_times)
    bbi = bbi[valid]
    bbi_times = bbi_times[valid]

    if len(bbi) >= 4 and (bbi_times[-1] - bbi_times[0]) >= 10:
        fs_interp = 4.0
        t_grid = np.arange(bbi_times[0], bbi_times[-1], 1.0 / fs_interp)
        if len(t_grid) >= 16:
            x = np.interp(t_grid, bbi_times, bbi)
            x = signal.detrend(x)

            nperseg = min(256, len(x))
            if nperseg >= 16:
                freqs, psd = signal.welch(x, fs=fs_interp, nperseg=nperseg, noverlap=nperseg // 2)
                out["RRV_VLF_power_s2"] = bandpower(freqs, psd, 0.0033, 0.04)
                out["RRV_LF_power_s2"] = bandpower(freqs, psd, 0.04, 0.15)
                out["RRV_HF_power_s2"] = bandpower(freqs, psd, 0.15, 0.40)
                out["RRV_TotalPower_s2"] = bandpower(freqs, psd, 0.0033, 0.40)

                lf = out["RRV_LF_power_s2"]
                hf = out["RRV_HF_power_s2"]
                vlf = out["RRV_VLF_power_s2"]
                if np.isfinite(lf) and np.isfinite(hf) and hf > 0:
                    out["RRV_LFHF"] = lf / hf
                if np.isfinite(lf) and np.isfinite(hf) and (lf + hf) > 0:
                    out["RRV_LFn_pct"] = 100.0 * lf / (lf + hf)
                    out["RRV_HFn_pct"] = 100.0 * hf / (lf + hf)

                for label, lo, hi in [
                    ("VLF", 0.0033, 0.04),
                    ("LF", 0.04, 0.15),
                    ("HF", 0.15, 0.40),
                ]:
                    m = (freqs >= lo) & (freqs < hi)
                    if np.sum(m) >= 1:
                        idx = np.argmax(psd[m])
                        out[f"RRV_PeakFreq_{label}_Hz"] = freqs[m][idx]

    # Dominant respiratory frequency from cleaned waveform.
    x = np.asarray(cleaned_rsp, dtype=float)
    x = x[np.isfinite(x)]
    if len(x) >= int(10 * fs):
        x = signal.detrend(x)
        nperseg = min(int(60 * fs), len(x))
        if nperseg >= int(8 * fs):
            freqs, psd = signal.welch(x, fs=fs, nperseg=nperseg, noverlap=nperseg // 2)
            m = (freqs >= 0.05) & (freqs <= 1.0)
            if np.sum(m) > 0:
                peak_freq = freqs[m][np.argmax(psd[m])]
                out["RSP_DominantFreq_Hz"] = peak_freq
                out["RSP_DominantRate_bpm"] = 60.0 * peak_freq

    return out


def sample_entropy(x, m=2, r=None):
    """Sample entropy using Chebyshev-distance template matching."""
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n < m + 3:
        return np.nan
    if r is None:
        sd = np.std(x, ddof=0)
        if not np.isfinite(sd) or sd == 0:
            return np.nan
        r = 0.2 * sd

    try:
        from scipy.spatial import cKDTree

        def embed(mm):
            return np.array([x[i:i + mm] for i in range(n - mm + 1)])

        xm = embed(m)
        xm1 = embed(m + 1)
        tree_m = cKDTree(xm)
        tree_m1 = cKDTree(xm1)

        # count_neighbors includes self and double-counts; convert to unordered non-self pairs.
        cm = (tree_m.count_neighbors(tree_m, r, p=np.inf) - len(xm)) / 2.0
        cm1 = (tree_m1.count_neighbors(tree_m1, r, p=np.inf) - len(xm1)) / 2.0

        if cm <= 0 or cm1 <= 0:
            return np.nan
        return -np.log(cm1 / cm)
    except Exception:
        return np.nan


def approximate_entropy(x, m=2, r=None):
    """Approximate entropy with Chebyshev distance; suitable for short BBI series."""
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n < m + 3:
        return np.nan
    if r is None:
        sd = np.std(x, ddof=0)
        if not np.isfinite(sd) or sd == 0:
            return np.nan
        r = 0.2 * sd

    def _phi(mm):
        emb = np.array([x[i:i + mm] for i in range(n - mm + 1)])
        counts = []
        for row in emb:
            d = np.max(np.abs(emb - row), axis=1)
            counts.append(np.mean(d <= r))
        counts = np.asarray(counts)
        counts = counts[counts > 0]
        if len(counts) == 0:
            return np.nan
        return np.mean(np.log(counts))

    p1 = _phi(m)
    p2 = _phi(m + 1)
    if not np.isfinite(p1) or not np.isfinite(p2):
        return np.nan
    return p1 - p2


def dfa_alpha(x):
    """Detrended fluctuation analysis alpha over available scales."""
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n < 16:
        return np.nan

    y = np.cumsum(x - np.mean(x))
    min_scale = 4
    max_scale = max(5, n // 4)
    if max_scale <= min_scale:
        return np.nan

    scales = np.unique(np.floor(np.logspace(np.log10(min_scale), np.log10(max_scale), 10)).astype(int))
    flucts = []

    for s in scales:
        if s < 4:
            continue
        nseg = n // s
        if nseg < 2:
            continue
        rms = []
        for i in range(nseg):
            seg = y[i * s:(i + 1) * s]
            t = np.arange(s)
            coef = np.polyfit(t, seg, 1)
            trend = np.polyval(coef, t)
            rms.append(np.sqrt(np.mean((seg - trend) ** 2)))
        f = np.mean(rms)
        if np.isfinite(f) and f > 0:
            flucts.append((s, f))

    if len(flucts) < 3:
        return np.nan

    scales2 = np.array([p[0] for p in flucts], dtype=float)
    fluc2 = np.array([p[1] for p in flucts], dtype=float)
    alpha = np.polyfit(np.log(scales2), np.log(fluc2), 1)[0]
    return alpha


def nonlinear_features(bbi):
    """Nonlinear RRV features."""
    bbi = np.asarray(bbi, dtype=float)
    bbi = bbi[np.isfinite(bbi)]
    out = {
        "RRV_SD1_s": np.nan,
        "RRV_SD2_s": np.nan,
        "RRV_SD1SD2": np.nan,
        "RRV_PoincareArea_s2": np.nan,
        "RRV_SampEn": np.nan,
        "RRV_ApEn": np.nan,
        "RRV_DFA_alpha": np.nan,
    }
    if len(bbi) < 3:
        return out

    diff = np.diff(bbi)
    sdnn = np.std(bbi, ddof=1) if len(bbi) > 1 else np.nan
    sdsd = np.std(diff, ddof=1) if len(diff) > 1 else np.nan

    if np.isfinite(sdsd):
        out["RRV_SD1_s"] = math.sqrt(0.5) * sdsd
    if np.isfinite(sdnn) and np.isfinite(sdsd):
        val = 2 * sdnn ** 2 - 0.5 * sdsd ** 2
        out["RRV_SD2_s"] = math.sqrt(val) if val > 0 else np.nan

    if np.isfinite(out["RRV_SD1_s"]) and np.isfinite(out["RRV_SD2_s"]) and out["RRV_SD2_s"] > 0:
        out["RRV_SD1SD2"] = out["RRV_SD1_s"] / out["RRV_SD2_s"]
        out["RRV_PoincareArea_s2"] = math.pi * out["RRV_SD1_s"] * out["RRV_SD2_s"]

    out["RRV_SampEn"] = sample_entropy(bbi, m=2)
    out["RRV_ApEn"] = approximate_entropy(bbi, m=2)
    out["RRV_DFA_alpha"] = dfa_alpha(bbi)
    return out


def main():
    if not INPUT.exists():
        raise FileNotFoundError(f"Input file not found: {INPUT}")

    df = pd.read_csv(INPUT)
    print(f"Loaded {INPUT} with shape {df.shape} and columns {list(df.columns)}")

    if "RSP" not in df.columns:
        raise ValueError("Required RSP column not present in input CSV.")

    rsp = pd.to_numeric(df["RSP"], errors="coerce").interpolate(limit_direction="both").bfill().ffill().to_numpy(dtype=float)
    duration_s = len(rsp) / FS
    print(f"RSP samples: {len(rsp)}, sampling rate: {FS:g} Hz, duration: {duration_s:.2f} s")

    cleaned, peaks, rate_signal, method = process_with_neurokit_or_fallback(rsp, FS)
    peak_times, bbi, bbi_times, valid_interval_mask = derive_valid_breath_intervals(peaks, FS)

    results = {
        "SourceFile": str(INPUT),
        "SamplingRate_Hz": FS,
        "Duration_s": duration_s,
        "ProcessingMethod": method,
        "RSP_Samples": int(len(rsp)),
        "RSP_InhalationPeaks_Detected": int(len(peaks)),
        "RSP_InhalationPeaks_ValidIntervals": int(len(bbi)),
        "RSP_FirstPeak_s": _safe_float(peak_times[0]) if len(peak_times) else np.nan,
        "RSP_LastPeak_s": _safe_float(peak_times[-1]) if len(peak_times) else np.nan,
        "RSP_Clean_Mean": _safe_float(np.nanmean(cleaned)),
        "RSP_Clean_SD": _safe_float(np.nanstd(cleaned, ddof=1)) if len(cleaned) > 1 else np.nan,
        "RSP_RateSignal_Mean_bpm": _safe_float(np.nanmean(rate_signal)),
        "RSP_RateSignal_SD_bpm": _safe_float(np.nanstd(rate_signal, ddof=1)) if np.sum(np.isfinite(rate_signal)) > 1 else np.nan,
    }

    results.update(time_domain_features(bbi))
    results.update(frequency_domain_features(bbi, bbi_times, cleaned, FS))
    results.update(nonlinear_features(bbi))

    # Save a compact representation of peak locations for traceability without making the file huge.
    max_store = 100
    results["RSP_InhalationPeakTimes_s_First100"] = ";".join([f"{t:.3f}" for t in peak_times[:max_store]])
    results["RSP_ValidBBI_s_First100"] = ";".join([f"{v:.3f}" for v in bbi[:max_store]])

    OUTDIR.mkdir(parents=True, exist_ok=True)
    out_df = pd.DataFrame([results])

    # Stable column ordering: identifiers, time, frequency, nonlinear, trace columns.
    out_df.to_csv(OUTFILE, index=False)

    print(f"Detected inhalation peaks: {len(peaks)}")
    print(f"Valid breath-to-breath intervals used for RRV: {len(bbi)}")
    print(f"Mean respiratory rate from intervals: {results.get('RRV_MeanRate_bpm', np.nan):.4f} bpm")
    print(f"SDNN: {results.get('RRV_SDNN_s', np.nan):.6f} s")
    print(f"RMSSD: {results.get('RRV_RMSSD_s', np.nan):.6f} s")
    print(f"LF power: {results.get('RRV_LF_power_s2', np.nan):.6g} s^2")
    print(f"HF power: {results.get('RRV_HF_power_s2', np.nan):.6g} s^2")
    print(f"Sample entropy: {results.get('RRV_SampEn', np.nan):.6f}")
    print(f"Saved RRV analysis to {OUTFILE}")
    print("Output preview:")
    print(out_df.T.head(35).to_string(header=False))


if __name__ == "__main__":
    main()