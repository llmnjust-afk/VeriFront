#!/usr/bin/env python3
"""
Third pass: inspect exact NeuroKit RRV output columns and test HRV nonlinear
functions on respiratory interval data for additional nonlinear RRV features.
"""
from pathlib import Path
import inspect
import numpy as np
import pandas as pd
import neurokit2 as nk

Path("pred_results").mkdir(exist_ok=True)

fs = 100
rsp = pd.read_csv("biosignals/bio_eventrelated_100hz.csv")["RSP"].astype(float).to_numpy()
signals, info = nk.rsp_process(rsp, sampling_rate=fs)
rrv_nk = nk.rsp_rrv(signals["RSP_Rate"].to_numpy(), troughs=info, sampling_rate=fs, show=False, silent=False)

print("NeuroKit rsp_rrv columns/count:", len(rrv_nk.columns))
print(rrv_nk.T.to_string())
rrv_nk.to_csv("pred_results/rrv_neurokit_exact.csv", index=False)

print("\nAvailable HRV functions:")
for name in ["hrv_time", "hrv_frequency", "hrv_nonlinear", "hrv"]:
    if hasattr(nk, name):
        print(name, inspect.signature(getattr(nk, name)))
        doc = inspect.getdoc(getattr(nk, name))
        print("\n".join(doc.splitlines()[:6]) if doc else "No doc")

# Construct respiratory "R-peaks" from troughs and try HRV functions as interval variability analogues.
troughs = np.asarray(info["RSP_Troughs"], dtype=int)
peaks_dict = {"RRI": np.diff(troughs) / fs * 1000.0, "RRI_Time": troughs[1:] / fs}
fake_peaks = {"ECG_R_Peaks": troughs}

print("\nBreath trough count:", len(troughs))
print("Resp intervals ms first10:", peaks_dict["RRI"][:10])
print("Resp intervals ms summary:", pd.Series(peaks_dict["RRI"]).describe().to_string())

for name in ["hrv_time", "hrv_frequency", "hrv_nonlinear", "hrv"]:
    try:
        out = getattr(nk, name)(fake_peaks, sampling_rate=fs, show=False)
        print(f"\n{name} on fake peaks success shape {out.shape}, columns {len(out.columns)}")
        print(out.T.head(80).to_string())
        out.to_csv(f"pred_results/{name}_resp_intervals_debug.csv", index=False)
    except Exception as e:
        print(f"\n{name} on fake peaks failed:", repr(e))

# Try interval dict input
for name in ["hrv_time", "hrv_frequency", "hrv_nonlinear", "hrv"]:
    try:
        out = getattr(nk, name)(peaks_dict, sampling_rate=fs, show=False)
        print(f"\n{name} on RRI dict success shape {out.shape}, columns {len(out.columns)}")
        print(out.T.head(80).to_string())
        out.to_csv(f"pred_results/{name}_rri_dict_debug.csv", index=False)
    except Exception as e:
        print(f"\n{name} on RRI dict failed:", repr(e))