#!/usr/bin/env python3
"""
First pass: inspect the available biosignal data and check package availability
for RRV analysis.
"""
import os
import sys
import json
import importlib.util
from pathlib import Path

import numpy as np
import pandas as pd

print("Python:", sys.version)
print("Working directory:", os.getcwd())

data_path = Path("biosignals/bio_eventrelated_100hz.csv")
print("Target data exists:", data_path.exists(), data_path)

packages = ["numpy", "pandas", "scipy", "neurokit2"]
for pkg in packages:
    spec = importlib.util.find_spec(pkg)
    print(f"Package {pkg}: {'FOUND' if spec is not None else 'MISSING'}")

if data_path.exists():
    df = pd.read_csv(data_path)
    print("Shape:", df.shape)
    print("Columns:", df.columns.tolist())
    print("Head:")
    print(df.head().to_string())
    print("Dtypes:")
    print(df.dtypes.to_string())
    print("Missing values:")
    print(df.isna().sum().to_string())
    print("Basic RSP stats:")
    print(df["RSP"].describe().to_string())
    print("Approx duration seconds @100Hz:", len(df) / 100.0)

    # Save a small inspection summary for continuity.
    summary = {
        "path": str(data_path),
        "shape": df.shape,
        "columns": df.columns.tolist(),
        "missing": df.isna().sum().to_dict(),
        "rsp_describe": df["RSP"].describe().to_dict(),
        "duration_sec_at_100hz": len(df) / 100.0,
    }
    Path("pred_results").mkdir(exist_ok=True)
    with open("pred_results/inspection_summary.json", "w") as f:
        json.dump(summary, f, indent=2)
    print("Saved inspection summary to pred_results/inspection_summary.json")