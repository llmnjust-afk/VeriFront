#!/usr/bin/env python3
"""
Final RRV analysis script.

Loads biosignals/bio_eventrelated_100hz.csv, cleans RSP, extracts inhalation
onsets (NeuroKit RSP_Troughs) and peaks in the respiratory-rate signal, computes
RRV time/frequency/nonlinear features, and saves a one-row feature table to:
pred_results/rrv_analysis_pred.csv
"""
from pathlib import Path
import warnings

import numpy as np
import pandas as pd
from scipy.signal import find_peaks
import neurokit2 as nk

warnings.filterwarnings("ignore", category=RuntimeWarning)

INPUT = Path("biosignals/bio_eventrelated_100hz.csv")
OUTPUT = Path("pred_results/rrv_analysis_pred.csv")
FS = 100

OUTPUT.parent.mkdir(parents=True, exist_ok=True)

# -----------------------------
# Load and preprocess RSP signal
# -----------------------------
df = pd.read_csv(INPUT)
rsp_raw = df["RSP"].astype(float).to_numpy()
duration_sec = len(rsp_raw) / FS

signals, info = nk.rsp_process(rsp_raw, sampling_rate=FS, method="khodadad2018")
rsp_clean = signals["RSP_Clean"].astype(float).to_numpy()
rsp_rate = signals["RSP_Rate"].astype(float).to_numpy()

# NeuroKit terminology: RSP_Troughs are inhalation onsets.
inhalation_onsets = np.asarray(info["RSP_Troughs"], dtype=int)
rsp_signal_peaks = np.asarray(info["RSP_Peaks"], dtype=int)
breath_intervals_ms = np.diff(inhalation_onsets) / FS * 1000.0

# -------------------------------------------------
# Extract peaks in the respiratory-rate time series
# -------------------------------------------------
finite_rate = rsp_rate[np.isfinite(rsp_rate)]
if len(finite_rate) > 0:
    # Conservative peak detection: local maxima at least ~2 s apart and above
    # a small prominence relative to rate variability.
    rate_prominence = max(float(np.nanstd(rsp_rate) * 0.20), 0.01)
    rate_peaks, rate_peak_props = find_peaks(
        rsp_rate,
        distance=int(2.0 * FS),
        prominence=rate_prominence,
    )
else:
    rate_peaks = np.array([], dtype=int)
    rate_peak_props = {"prominences": np.array([], dtype=float)}

# -------------------------
# Core NeuroKit RRV metrics
# -------------------------
rrv_core = nk.rsp_rrv(
    rsp_rate,
    troughs=info,
    sampling_rate=FS,
    show=False,
    silent=True,
)

# ---------------------------------------------------------
# Additional interval-variability features via HRV routines
# applied to respiratory intervals / inhalation-onset events
# ---------------------------------------------------------
fake_resp_events = {"ECG_R_Peaks": inhalation_onsets}

extra_frames = []
for func in [nk.hrv_time, nk.hrv_frequency, nk.hrv_nonlinear]:
    try:
        extra = func(fake_resp_events, sampling_rate=FS, show=False)
        # Rename HRV_* interval metrics to RRV_Interval_* to make provenance clear
        extra = extra.rename(columns={c: c.replace("HRV_", "RRV_Interval_") for c in extra.columns})
        extra_frames.append(extra)
    except Exception as exc:
        print(f"Warning: {func.__name__} failed and was skipped: {exc}")

# ---------------------
# Manual summary metrics
# ---------------------
def safe_stat(x, fun, default=np.nan):
    arr = np.asarray(x, dtype=float)
    arr = arr[np.isfinite(arr)]
    if arr.size == 0:
        return default
    return float(fun(arr))

manual = {
    "RSP_Sampling_Rate_Hz": FS,
    "RSP_Duration_sec": duration_sec,
    "RSP_Samples": len(rsp_raw),
    "RSP_Raw_Mean": safe_stat(rsp_raw, np.mean),
    "RSP_Raw_SD": safe_stat(rsp_raw, np.std),
    "RSP_Clean_Mean": safe_stat(rsp_clean, np.mean),
    "RSP_Clean_SD": safe_stat(rsp_clean, np.std),
    "RSP_Signal_Peaks_N": int(len(rsp_signal_peaks)),
    "RSP_Inhalation_Onsets_N": int(len(inhalation_onsets)),
    "RSP_Breath_Intervals_N": int(len(breath_intervals_ms)),
    "RSP_First_Inhalation_Onset_sec": float(inhalation_onsets[0] / FS) if len(inhalation_onsets) else np.nan,
    "RSP_Last_Inhalation_Onset_sec": float(inhalation_onsets[-1] / FS) if len(inhalation_onsets) else np.nan,
    "RSP_Mean_Breath_Rate_bpm_from_intervals": float(60000.0 / np.mean(breath_intervals_ms)) if len(breath_intervals_ms) else np.nan,
    "RSP_Rate_Mean_bpm": safe_stat(rsp_rate, np.mean),
    "RSP_Rate_Median_bpm": safe_stat(rsp_rate, np.median),
    "RSP_Rate_SD_bpm": safe_stat(rsp_rate, np.std),
    "RSP_Rate_Min_bpm": safe_stat(rsp_rate, np.min),
    "RSP_Rate_Max_bpm": safe_stat(rsp_rate, np.max),
    "RSP_Rate_Peaks_N": int(len(rate_peaks)),
    "RSP_Rate_Peaks_Mean_bpm": safe_stat(rsp_rate[rate_peaks] if len(rate_peaks) else [], np.mean),
    "RSP_Rate_Peaks_Mean_Prominence": safe_stat(rate_peak_props.get("prominences", []), np.mean),
}
manual_df = pd.DataFrame([manual])

# --------------------------
# Combine and save one row
# --------------------------
frames = [manual_df, rrv_core.reset_index(drop=True)] + [f.reset_index(drop=True) for f in extra_frames]
result = pd.concat(frames, axis=1)

# Remove duplicate columns while preserving the first occurrence.
result = result.loc[:, ~result.columns.duplicated()]

# Replace inf with NaN for CSV compatibility.
result = result.replace([np.inf, -np.inf], np.nan)

result.to_csv(OUTPUT, index=False)

print(f"Saved RRV analysis to {OUTPUT}")
print("Output shape:", result.shape)
print("Inhalation onsets detected:", len(inhalation_onsets))
print("Respiratory-rate peaks detected:", len(rate_peaks))
print("Mean breath interval ms:", safe_stat(breath_intervals_ms, np.mean))
print("Mean respiratory rate bpm:", manual["RSP_Rate_Mean_bpm"])
print("First 20 columns:", result.columns[:20].tolist())
print("Core RRV metrics:")
print(rrv_core.T.to_string())