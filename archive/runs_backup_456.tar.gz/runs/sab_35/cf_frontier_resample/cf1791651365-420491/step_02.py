#!/usr/bin/env python3
"""
Second pass: run NeuroKit2 respiration processing/interval analysis if possible,
inspect outputs and available RRV functions/signatures.
"""
import os
import inspect
from pathlib import Path

import numpy as np
import pandas as pd
import scipy.signal as signal
import neurokit2 as nk

Path("pred_results").mkdir(exist_ok=True)

df = pd.read_csv("biosignals/bio_eventrelated_100hz.csv")
rsp = df["RSP"].astype(float).to_numpy()
fs = 100

print("NeuroKit2 version:", getattr(nk, "__version__", "unknown"))
print("Signal length:", len(rsp), "duration_sec:", len(rsp)/fs)

# List respiratory-related functions
resp_funcs = [name for name in dir(nk) if name.startswith("rsp_") or name.startswith("rrv")]
print("Resp/RRV functions:", resp_funcs)

for func_name in ["rsp_clean", "rsp_process", "rsp_peaks", "rsp_rate", "rsp_rrv"]:
    if hasattr(nk, func_name):
        func = getattr(nk, func_name)
        print(f"\nSignature {func_name}: {inspect.signature(func)}")
        doc = inspect.getdoc(func)
        print(f"Doc first lines {func_name}:")
        print("\n".join(doc.splitlines()[:12]) if doc else "No doc")

# Try processing
try:
    signals, info = nk.rsp_process(rsp, sampling_rate=fs)
    print("\nrsp_process success")
    print("signals columns:", signals.columns.tolist())
    print("signals shape:", signals.shape)
    print("info keys:", list(info.keys()))
    for k, v in info.items():
        if isinstance(v, (list, np.ndarray, pd.Series)):
            arr = np.asarray(v)
            print(f"info[{k}] length={len(arr)} first10={arr[:10]}")
        else:
            print(f"info[{k}]={v}")

    print("signals head:")
    print(signals.head().to_string())
    print("signals describe:")
    print(signals.describe().to_string())

    signals.to_csv("pred_results/rsp_process_signals_debug.csv", index=False)
    pd.DataFrame({k: pd.Series(v) for k, v in info.items() if isinstance(v, (list, np.ndarray, pd.Series))}).to_csv(
        "pred_results/rsp_process_info_debug.csv", index=False
    )
    print("Saved debug process outputs.")
except Exception as e:
    print("rsp_process failed:", repr(e))

# Try direct rrv from process info
try:
    signals, info = nk.rsp_process(rsp, sampling_rate=fs)
    rrv = nk.rsp_rrv(signals, sampling_rate=fs, show=False)
    print("\nrsp_rrv(signals) success")
    print("rrv type:", type(rrv), "shape:", getattr(rrv, "shape", None))
    print(rrv.to_string())
    rrv.to_csv("pred_results/rrv_neurokit_debug.csv", index=False)
    print("Saved pred_results/rrv_neurokit_debug.csv")
except Exception as e:
    print("rsp_rrv failed:", repr(e))

# Also perform basic peak detection on cleaned signal for sanity.
try:
    clean = nk.rsp_clean(rsp, sampling_rate=fs)
    peaks_info = nk.rsp_peaks(clean, sampling_rate=fs)
    print("\nrsp_peaks return type:", type(peaks_info))
    print("rsp_peaks repr:", repr(peaks_info)[:1000])
except Exception as e:
    print("rsp_peaks failed:", repr(e))