import os
import warnings
import numpy as np
import pandas as pd
import scipy
from scipy import signal, interpolate, stats
import neurokit2 as nk

warnings.filterwarnings("ignore")

DATA_PATH = "biosignals/bio_eventrelated_100hz.csv"
OUT_DIR = "pred_results"
OUT_PATH = os.path.join(OUT_DIR, "rrv_analysis_pred.csv")
FS = 100

os.makedirs(OUT_DIR, exist_ok=True)

df = pd.read_csv(DATA_PATH)
rsp_raw = pd.to_numeric(df["RSP"], errors="coerce").to_numpy(dtype=float)
print("Loaded RSP samples:", len(rsp_raw), "duration_s:", len(rsp_raw)/FS)

# Fill possible missing values robustly.
if np.isnan(rsp_raw).any():
    s = pd.Series(rsp_raw).interpolate(limit_direction="both").ffill().bfill()
    rsp_raw = s.to_numpy(dtype=float)
print("NaNs after fill:", int(np.isnan(rsp_raw).sum()))

# Clean RSP using NeuroKit2; fall back to Butterworth bandpass if needed.
try:
    rsp_clean = nk.rsp_clean(rsp_raw, sampling_rate=FS, method="khodadad2018")
    method_clean = "neurokit2_khodadad2018"
except Exception as e:
    print("nk.rsp_clean failed; fallback:", repr(e))
    nyq = FS / 2
    b, a = signal.butter(2, [0.05/nyq, 1.0/nyq], btype="bandpass")
    rsp_clean = signal.filtfilt(b, a, rsp_raw)
    method_clean = "scipy_butter_bandpass_0.05_1.0Hz"

print("Clean method:", method_clean)
print("Clean RSP summary:", pd.Series(rsp_clean).describe().to_string())

# Detect inhalation peaks and troughs with NeuroKit2.
peaks = None
info = None
for method in ["khodadad2018", "biosppy"]:
    try:
        signals, info_candidate = nk.rsp_peaks(rsp_clean, sampling_rate=FS, method=method)
        p = np.asarray(info_candidate.get("RSP_Peaks", []), dtype=int)
        t = np.asarray(info_candidate.get("RSP_Troughs", []), dtype=int)
        if len(p) >= 3:
            peaks, troughs, info = p, t, info_candidate
            peak_method = method
            break
        print("Peak method", method, "found too few peaks:", len(p))
    except Exception as e:
        print("Peak method failed:", method, repr(e))

# Fallback peak detection if NK fails.
if peaks is None:
    min_distance = int(1.5 * FS)
    prominence = max(np.nanstd(rsp_clean) * 0.15, 1e-6)
    peaks, props = signal.find_peaks(rsp_clean, distance=min_distance, prominence=prominence)
    troughs, _ = signal.find_peaks(-rsp_clean, distance=min_distance, prominence=prominence)
    peak_method = "scipy_find_peaks"
    print("Fallback scipy peaks used.")

peaks = np.asarray(peaks, dtype=int)
troughs = np.asarray(troughs, dtype=int)
peaks = peaks[(peaks >= 0) & (peaks < len(rsp_clean))]
troughs = troughs[(troughs >= 0) & (troughs < len(rsp_clean))]
print("Peak method:", peak_method)
print("Num inhalation peaks:", len(peaks))
print("Num troughs:", len(troughs))
print("First 10 peak samples:", peaks[:10].tolist())
print("First 10 peak times:", (peaks[:10]/FS).round(3).tolist())

# Respiratory rate signal via NeuroKit2 if possible; otherwise peak interval interpolation.
try:
    rsp_rate = nk.rsp_rate(peaks, sampling_rate=FS, desired_length=len(rsp_clean))
    rate_method = "neurokit2_rsp_rate_from_peaks"
except Exception as e:
    print("nk.rsp_rate failed; fallback:", repr(e))
    rsp_rate = np.full(len(rsp_clean), np.nan)
    if len(peaks) >= 2:
        peak_times = peaks / FS
        ibi = np.diff(peak_times)
        bpm = 60.0 / ibi
        mid_times = (peak_times[:-1] + peak_times[1:]) / 2
        if len(mid_times) >= 2:
            f = interpolate.interp1d(mid_times, bpm, bounds_error=False, fill_value=(bpm[0], bpm[-1]))
            rsp_rate = f(np.arange(len(rsp_clean))/FS)
        elif len(bpm) == 1:
            rsp_rate[:] = bpm[0]
    rate_method = "interpolated_peak_intervals"

print("Rate method:", rate_method)
print("RSP rate valid samples:", int(np.isfinite(rsp_rate).sum()))
print("RSP rate summary bpm:")
print(pd.Series(rsp_rate).replace([np.inf, -np.inf], np.nan).dropna().describe().to_string())

# Compute RRV indices using NeuroKit2.
rrv_df = None
try:
    rrv_df = nk.rsp_rrv(rsp_rate, peaks, sampling_rate=FS, show=False)
    print("nk.rsp_rrv succeeded. Shape:", rrv_df.shape)
    print("nk.rsp_rrv columns:", rrv_df.columns.tolist())
except Exception as e:
    print("nk.rsp_rrv failed:", repr(e))

# Manual robust RRV features based on breath-to-breath intervals (BBI).
peak_times = peaks / FS
bbi = np.diff(peak_times)  # seconds, peak-to-peak respiratory cycles
bbi_ms = bbi * 1000.0
inst_rate = 60.0 / bbi if len(bbi) else np.array([])

features = {}
features["Sampling_Rate_Hz"] = FS
features["Signal_Duration_s"] = len(rsp_clean) / FS
features["RSP_Clean_Method"] = method_clean
features["RSP_Peak_Method"] = peak_method
features["RSP_Rate_Method"] = rate_method
features["RSP_Peaks_N"] = len(peaks)
features["RSP_Troughs_N"] = len(troughs)
features["Breath_Intervals_N"] = len(bbi)

def finite_arr(x):
    x = np.asarray(x, dtype=float)
    return x[np.isfinite(x)]

bbi_f = finite_arr(bbi)
bbi_ms_f = finite_arr(bbi_ms)
rate_f = finite_arr(inst_rate)
rsp_rate_f = finite_arr(rsp_rate)

if len(bbi_f) > 0:
    diff_bbi = np.diff(bbi_f)
    diff_bbi_ms = diff_bbi * 1000
    features.update({
        "RRV_MeanBB_s": np.mean(bbi_f),
        "RRV_MedianBB_s": np.median(bbi_f),
        "RRV_MinBB_s": np.min(bbi_f),
        "RRV_MaxBB_s": np.max(bbi_f),
        "RRV_RangeBB_s": np.ptp(bbi_f),
        "RRV_SDBB_s": np.std(bbi_f, ddof=1) if len(bbi_f) > 1 else 0.0,
        "RRV_CVBB": (np.std(bbi_f, ddof=1) / np.mean(bbi_f)) if len(bbi_f) > 1 and np.mean(bbi_f) else np.nan,
        "RRV_RMSSD_s": np.sqrt(np.mean(diff_bbi**2)) if len(diff_bbi) else np.nan,
        "RRV_SDSD_s": np.std(diff_bbi, ddof=1) if len(diff_bbi) > 1 else np.nan,
        "RRV_MeanBB_ms": np.mean(bbi_ms_f),
        "RRV_SDBB_ms": np.std(bbi_ms_f, ddof=1) if len(bbi_ms_f) > 1 else 0.0,
        "RRV_RMSSD_ms": np.sqrt(np.mean(diff_bbi_ms**2)) if len(diff_bbi_ms) else np.nan,
        "RRV_MeanRate_bpm": np.mean(rate_f) if len(rate_f) else np.nan,
        "RRV_MedianRate_bpm": np.median(rate_f) if len(rate_f) else np.nan,
        "RRV_SDRate_bpm": np.std(rate_f, ddof=1) if len(rate_f) > 1 else 0.0,
        "RSP_Rate_Mean_bpm": np.mean(rsp_rate_f) if len(rsp_rate_f) else np.nan,
        "RSP_Rate_SD_bpm": np.std(rsp_rate_f, ddof=1) if len(rsp_rate_f) > 1 else np.nan,
    })
    # pNN analogues (successive interval differences exceeding thresholds)
    for thr_ms in [50, 100, 200, 500]:
        features[f"RRV_pBBdiff_gt_{thr_ms}ms"] = np.mean(np.abs(diff_bbi_ms) > thr_ms) * 100 if len(diff_bbi_ms) else np.nan

# Frequency-domain on interpolated BBI tachogram.
if len(bbi_f) >= 4:
    times_bbi = peak_times[1:]  # assign interval to second peak
    # ensure strict and finite
    mask = np.isfinite(times_bbi) & np.isfinite(bbi)
    times_bbi = times_bbi[mask]
    bbi_series = bbi[mask]
    if len(times_bbi) >= 4 and np.ptp(times_bbi) > 0:
        fs_interp = 4.0
        t_uniform = np.arange(times_bbi[0], times_bbi[-1], 1/fs_interp)
        if len(t_uniform) >= 8:
            interp_fun = interpolate.interp1d(times_bbi, bbi_series, kind="linear", bounds_error=False, fill_value="extrapolate")
            bbi_uniform = interp_fun(t_uniform)
            bbi_uniform = signal.detrend(bbi_uniform)
            nperseg = min(256, len(bbi_uniform))
            freqs, psd = signal.welch(bbi_uniform, fs=fs_interp, nperseg=nperseg)
            def bandpower(lo, hi):
                idx = (freqs >= lo) & (freqs < hi)
                if not np.any(idx):
                    return 0.0
                return float(np.trapz(psd[idx], freqs[idx]))
            # Common RRV/HRV-like bands; respiratory rhythms are low in this short recording.
            vlf = bandpower(0.0033, 0.04)
            lf = bandpower(0.04, 0.15)
            hf = bandpower(0.15, 0.40)
            total = bandpower(0.0033, 0.40)
            features.update({
                "RRV_Freq_VLF_s2": vlf,
                "RRV_Freq_LF_s2": lf,
                "RRV_Freq_HF_s2": hf,
                "RRV_Freq_TotalPower_s2": total,
                "RRV_Freq_LFHF": lf/hf if hf > 0 else np.nan,
                "RRV_Freq_LFnu": 100*lf/(lf+hf) if (lf+hf) > 0 else np.nan,
                "RRV_Freq_HFnu": 100*hf/(lf+hf) if (lf+hf) > 0 else np.nan,
                "RRV_Freq_Peak_Hz": float(freqs[np.argmax(psd)]) if len(psd) else np.nan,
            })

# Nonlinear features.
if len(bbi_f) >= 3:
    x1 = bbi_f[:-1]
    x2 = bbi_f[1:]
    diff = x2 - x1
    summ = x2 + x1
    sd1 = np.sqrt(np.var(diff, ddof=1) / 2) if len(diff) > 1 else np.nan
    sd2 = np.sqrt(np.var(summ, ddof=1) / 2) if len(summ) > 1 else np.nan
    features.update({
        "RRV_Nonlinear_SD1_s": sd1,
        "RRV_Nonlinear_SD2_s": sd2,
        "RRV_Nonlinear_SD1SD2": sd1/sd2 if sd2 and np.isfinite(sd2) else np.nan,
        "RRV_Nonlinear_CSI": sd2/sd1 if sd1 and np.isfinite(sd1) else np.nan,
        "RRV_Nonlinear_CVI": np.log10(sd1*sd2) if sd1 > 0 and sd2 > 0 else np.nan,
    })
    # Approximate entropy / sample entropy if enough data
    try:
        features["RRV_Nonlinear_SampEn"] = float(nk.entropy_sample(bbi_f)[0])
    except Exception as e:
        print("SampEn failed:", repr(e))
        features["RRV_Nonlinear_SampEn"] = np.nan
    try:
        features["RRV_Nonlinear_ApEn"] = float(nk.entropy_approximate(bbi_f)[0])
    except Exception as e:
        print("ApEn failed:", repr(e))
        features["RRV_Nonlinear_ApEn"] = np.nan

# Add NeuroKit RRV results with namespaced columns.
if rrv_df is not None and len(rrv_df) > 0:
    for col in rrv_df.columns:
        val = rrv_df.iloc[0][col]
        # Convert numpy scalar/strings safely
        features[f"NK_{col}"] = val

# Add peak timing summaries useful for validation.
features["First_Peak_Time_s"] = float(peaks[0]/FS) if len(peaks) else np.nan
features["Last_Peak_Time_s"] = float(peaks[-1]/FS) if len(peaks) else np.nan

out = pd.DataFrame([features])
# Put method/object columns first, then numeric.
first_cols = [c for c in ["Sampling_Rate_Hz","Signal_Duration_s","RSP_Clean_Method","RSP_Peak_Method","RSP_Rate_Method","RSP_Peaks_N","RSP_Troughs_N","Breath_Intervals_N"] if c in out.columns]
other_cols = [c for c in out.columns if c not in first_cols]
out = out[first_cols + sorted(other_cols)]

out.to_csv(OUT_PATH, index=False)
print("Saved:", OUT_PATH)
print("Output shape:", out.shape)
print("Output columns:")
print(out.columns.tolist())
print("Output row preview:")
with pd.option_context("display.max_columns", 200, "display.width", 240):
    print(out.to_string(index=False))

# Also save extracted series/peaks for reproducibility (not required but useful).
aux = pd.DataFrame({
    "RSP_Raw": rsp_raw,
    "RSP_Clean": rsp_clean,
    "RSP_Rate_bpm": rsp_rate,
    "RSP_Inhalation_Peak": np.isin(np.arange(len(rsp_clean)), peaks).astype(int),
    "RSP_Trough": np.isin(np.arange(len(rsp_clean)), troughs).astype(int),
})
aux_path = os.path.join(OUT_DIR, "rrv_extracted_signals_pred.csv")
aux.to_csv(aux_path, index=False)
print("Saved auxiliary:", aux_path, "shape:", aux.shape)