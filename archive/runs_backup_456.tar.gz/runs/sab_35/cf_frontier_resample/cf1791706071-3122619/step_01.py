import os
import sys
import importlib.util
import pandas as pd
import numpy as np

print("Working directory:", os.getcwd())
print("Python:", sys.version)

data_path = "biosignals/bio_eventrelated_100hz.csv"
print("Data exists:", os.path.exists(data_path), data_path)

df = pd.read_csv(data_path)
print("Shape:", df.shape)
print("Columns:", df.columns.tolist())
print("Head:")
print(df.head().to_string())
print("Describe RSP:")
print(df["RSP"].describe().to_string())
print("Missing values:")
print(df.isna().sum().to_string())

for pkg in ["neurokit2", "scipy", "numpy", "pandas", "sklearn"]:
    spec = importlib.util.find_spec(pkg)
    print(f"Package {pkg}: {'available' if spec else 'NOT available'}")

if importlib.util.find_spec("neurokit2"):
    import neurokit2 as nk
    print("NeuroKit2 version:", getattr(nk, "__version__", "unknown"))
    print("Has rsp_process:", hasattr(nk, "rsp_process"))
    print("Has rsp_analyze:", hasattr(nk, "rsp_analyze"))
    print("Has rsp_peaks:", hasattr(nk, "rsp_peaks"))
    print("Has rsp_rrv:", hasattr(nk, "rsp_rrv"))

print("Inspection complete.")