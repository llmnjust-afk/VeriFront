import os
import inspect
import numpy as np
import pandas as pd
import neurokit2 as nk

# Inspect NeuroKit2 RSP/RRV APIs and try the canonical processing pipeline.
infile = "biosignals/bio_eventrelated_100hz.csv"
sampling_rate = 100
df = pd.read_csv(infile)
rsp = df["RSP"].astype(float).to_numpy()

print("rsp_process signature:", inspect.signature(nk.rsp_process))
print("rsp_rrv signature:", inspect.signature(nk.rsp_rrv))
print("rsp_intervalrelated signature:", inspect.signature(nk.rsp_intervalrelated))

# Run NeuroKit2 processing
signals, info = nk.rsp_process(rsp, sampling_rate=sampling_rate)
print("Processed signals shape:", signals.shape)
print("Processed signals columns:", list(signals.columns))
print("Info keys:", info.keys())
for k, v in info.items():
    if isinstance(v, (list, tuple, np.ndarray, pd.Series)):
        arr = np.asarray(v)
        print(k, "len", len(arr), "first10", arr[:10])
    else:
        print(k, v)

# Try RRV computation from processed peaks.
try:
    rrv = nk.rsp_rrv(signals, sampling_rate=sampling_rate, show=False)
    print("RRV type:", type(rrv), "shape:", getattr(rrv, "shape", None))
    print(rrv)
except Exception as e:
    print("rsp_rrv on signals failed:", repr(e))

try:
    interval = nk.rsp_intervalrelated(signals, sampling_rate=sampling_rate)
    print("Intervalrelated type:", type(interval), "shape:", getattr(interval, "shape", None))
    print(interval)
except Exception as e:
    print("rsp_intervalrelated failed:", repr(e))

# Also extract peaks and respiratory rate summary
for col in ["RSP_Peaks", "RSP_Troughs", "RSP_Rate", "RSP_Clean"]:
    if col in signals:
        vals = signals[col].to_numpy()
        if col in ["RSP_Peaks", "RSP_Troughs"]:
            idx = np.where(vals == 1)[0]
            print(col, "count", len(idx), "first idx", idx[:10], "first sec", idx[:10]/sampling_rate)
        else:
            print(col, "finite count", np.isfinite(vals).sum(), "mean", np.nanmean(vals), "std", np.nanstd(vals), "min", np.nanmin(vals), "max", np.nanmax(vals))