import os
import json
import warnings
import numpy as np
import pandas as pd
import neurokit2 as nk
from scipy import signal, interpolate, stats

warnings.filterwarnings("ignore")

infile = "biosignals/bio_eventrelated_100hz.csv"
outdir = "pred_results"
outfile = os.path.join(outdir, "rrv_analysis_pred.csv")
sampling_rate = 100

os.makedirs(outdir, exist_ok=True)

# ----------------------------
# Load data
# ----------------------------
df = pd.read_csv(infile)
if "RSP" not in df.columns:
    raise ValueError("Input file must contain an RSP column.")
rsp_raw = df["RSP"].astype(float).to_numpy()
duration_s = len(rsp_raw) / sampling_rate

# Fill possible missing samples by linear interpolation before processing
if np.isnan(rsp_raw).any():
    s = pd.Series(rsp_raw)
    rsp_raw = s.interpolate(limit_direction="both").to_numpy()

# ----------------------------
# Clean RSP and identify inhalation peaks / respiratory rate
# ----------------------------
signals, info = nk.rsp_process(rsp_raw, sampling_rate=sampling_rate, method="khodadad2018")
rsp_clean = signals["RSP_Clean"].to_numpy()
rsp_rate = signals["RSP_Rate"].to_numpy()

rsp_peak_idx = np.asarray(info.get("RSP_Peaks", np.where(signals["RSP_Peaks"].to_numpy() == 1)[0]), dtype=int)
rsp_trough_idx = np.asarray(info.get("RSP_Troughs", np.where(signals["RSP_Troughs"].to_numpy() == 1)[0]), dtype=int)

# Extract peaks of the respiratory rate signal too (local maxima in breaths/min)
finite_rate = np.nan_to_num(rsp_rate, nan=np.nanmedian(rsp_rate))
min_rate_peak_distance = int(1.0 * sampling_rate)
rate_prominence = max(0.01, 0.10 * np.nanstd(finite_rate))
rate_peak_idx, rate_peak_props = signal.find_peaks(
    finite_rate,
    distance=min_rate_peak_distance,
    prominence=rate_prominence
)

# ----------------------------
# NeuroKit2 RRV indices (time, frequency, nonlinear where available)
# ----------------------------
rrv_nk = nk.rsp_rrv(signals, sampling_rate=sampling_rate, show=False, silent=True)
interval_nk = nk.rsp_intervalrelated(signals, sampling_rate=sampling_rate)

# ----------------------------
# Additional transparent/custom features
# ----------------------------
features = {}

# General metadata
features["Duration_s"] = duration_s
features["Sampling_Rate_Hz"] = sampling_rate
features["RSP_Samples"] = len(rsp_raw)

# Cleaned RSP summary
features["RSP_Raw_Mean"] = float(np.mean(rsp_raw))
features["RSP_Raw_SD"] = float(np.std(rsp_raw, ddof=1))
features["RSP_Clean_Mean"] = float(np.mean(rsp_clean))
features["RSP_Clean_SD"] = float(np.std(rsp_clean, ddof=1))
features["RSP_Clean_Min"] = float(np.min(rsp_clean))
features["RSP_Clean_Max"] = float(np.max(rsp_clean))

# Inhalation peaks of RSP
features["RSP_Inhalation_Peaks_N"] = int(len(rsp_peak_idx))
features["RSP_Troughs_N"] = int(len(rsp_trough_idx))
features["RSP_Inhalation_Peak_Amplitude_Mean"] = float(np.mean(rsp_clean[rsp_peak_idx])) if len(rsp_peak_idx) else np.nan
features["RSP_Inhalation_Peak_Amplitude_SD"] = float(np.std(rsp_clean[rsp_peak_idx], ddof=1)) if len(rsp_peak_idx) > 1 else np.nan
features["RSP_First_Inhalation_Peak_s"] = float(rsp_peak_idx[0] / sampling_rate) if len(rsp_peak_idx) else np.nan
features["RSP_Last_Inhalation_Peak_s"] = float(rsp_peak_idx[-1] / sampling_rate) if len(rsp_peak_idx) else np.nan

# Respiratory rate signal peak features
features["RSP_Rate_Mean_Custom"] = float(np.nanmean(rsp_rate))
features["RSP_Rate_SD_Custom"] = float(np.nanstd(rsp_rate, ddof=1))
features["RSP_Rate_Min_Custom"] = float(np.nanmin(rsp_rate))
features["RSP_Rate_Max_Custom"] = float(np.nanmax(rsp_rate))
features["RSP_Rate_Peaks_N"] = int(len(rate_peak_idx))
features["RSP_Rate_Peak_Value_Mean"] = float(np.mean(rsp_rate[rate_peak_idx])) if len(rate_peak_idx) else np.nan
features["RSP_Rate_Peak_Value_SD"] = float(np.std(rsp_rate[rate_peak_idx], ddof=1)) if len(rate_peak_idx) > 1 else np.nan
features["RSP_Rate_First_Peak_s"] = float(rate_peak_idx[0] / sampling_rate) if len(rate_peak_idx) else np.nan
features["RSP_Rate_Last_Peak_s"] = float(rate_peak_idx[-1] / sampling_rate) if len(rate_peak_idx) else np.nan

# Breath-to-breath intervals from inhalation peaks
bb_s = np.diff(rsp_peak_idx) / sampling_rate
bb_ms = bb_s * 1000.0
if len(bb_ms) > 0:
    diff_bb = np.diff(bb_ms)
    features["Custom_MeanBB_ms"] = float(np.mean(bb_ms))
    features["Custom_MedianBB_ms"] = float(np.median(bb_ms))
    features["Custom_SDBB_ms"] = float(np.std(bb_ms, ddof=1)) if len(bb_ms) > 1 else np.nan
    features["Custom_RMSSD_ms"] = float(np.sqrt(np.mean(diff_bb**2))) if len(diff_bb) else np.nan
    features["Custom_SDSD_ms"] = float(np.std(diff_bb, ddof=1)) if len(diff_bb) > 1 else np.nan
    features["Custom_CVBB"] = float(np.std(bb_ms, ddof=1) / np.mean(bb_ms)) if len(bb_ms) > 1 and np.mean(bb_ms) != 0 else np.nan
    features["Custom_Breathing_Rate_From_Peaks_bpm"] = float(60.0 / np.mean(bb_s))
    features["Custom_pBB50"] = float(100.0 * np.mean(np.abs(diff_bb) > 50.0)) if len(diff_bb) else np.nan
    features["Custom_pBB100"] = float(100.0 * np.mean(np.abs(diff_bb) > 100.0)) if len(diff_bb) else np.nan
else:
    for k in ["Custom_MeanBB_ms", "Custom_MedianBB_ms", "Custom_SDBB_ms", "Custom_RMSSD_ms",
              "Custom_SDSD_ms", "Custom_CVBB", "Custom_Breathing_Rate_From_Peaks_bpm",
              "Custom_pBB50", "Custom_pBB100"]:
        features[k] = np.nan

# Poincare geometry from intervals
if len(bb_ms) >= 3:
    x1 = bb_ms[:-1]
    x2 = bb_ms[1:]
    sd1 = np.sqrt(np.var((x2 - x1) / np.sqrt(2), ddof=1))
    sd2 = np.sqrt(np.var((x2 + x1) / np.sqrt(2), ddof=1))
    features["Custom_SD1_ms"] = float(sd1)
    features["Custom_SD2_ms"] = float(sd2)
    features["Custom_SD2SD1"] = float(sd2 / sd1) if sd1 != 0 else np.nan
else:
    features["Custom_SD1_ms"] = np.nan
    features["Custom_SD2_ms"] = np.nan
    features["Custom_SD2SD1"] = np.nan

# Frequency-domain features from uneven BB interval series interpolated at 4 Hz
# Use standard HRV-like bands as an interpretable RRV spectrum summary.
for k in ["Custom_VLF_Power", "Custom_LF_Power", "Custom_HF_Power", "Custom_Total_Power",
          "Custom_LFHF", "Custom_LFnu", "Custom_HFnu"]:
    features[k] = np.nan

if len(bb_ms) >= 8:
    peak_times_s = rsp_peak_idx / sampling_rate
    interval_times_s = (peak_times_s[:-1] + peak_times_s[1:]) / 2.0
    ibi_centered = bb_ms - np.mean(bb_ms)
    fs_interp = 4.0
    t_grid = np.arange(interval_times_s[0], interval_times_s[-1], 1.0 / fs_interp)
    if len(t_grid) > 8 and len(np.unique(interval_times_s)) == len(interval_times_s):
        f_interp = interpolate.interp1d(interval_times_s, ibi_centered, kind="linear", fill_value="extrapolate")
        y = signal.detrend(f_interp(t_grid))
        nperseg = min(256, len(y))
        freqs, psd = signal.welch(y, fs=fs_interp, nperseg=nperseg, noverlap=nperseg // 2)
        def bandpower(lo, hi):
            mask = (freqs >= lo) & (freqs < hi)
            return float(np.trapz(psd[mask], freqs[mask])) if np.any(mask) else np.nan
        vlf = bandpower(0.0033, 0.04)
        lf = bandpower(0.04, 0.15)
        hf = bandpower(0.15, 0.40)
        total = bandpower(0.0033, 0.40)
        features["Custom_VLF_Power"] = vlf
        features["Custom_LF_Power"] = lf
        features["Custom_HF_Power"] = hf
        features["Custom_Total_Power"] = total
        features["Custom_LFHF"] = float(lf / hf) if np.isfinite(lf) and np.isfinite(hf) and hf > 0 else np.nan
        denom = lf + hf if np.isfinite(lf) and np.isfinite(hf) else np.nan
        features["Custom_LFnu"] = float(100 * lf / denom) if np.isfinite(denom) and denom > 0 else np.nan
        features["Custom_HFnu"] = float(100 * hf / denom) if np.isfinite(denom) and denom > 0 else np.nan

# ----------------------------
# Assemble one-row output
# ----------------------------
out = pd.concat(
    [
        pd.DataFrame([features]),
        rrv_nk.reset_index(drop=True).add_prefix("NK_"),
        interval_nk.reset_index(drop=True).add_prefix("NK_Interval_"),
    ],
    axis=1
)

# Avoid duplicate column names and ensure numeric output where possible
out = out.loc[:, ~out.columns.duplicated()]
out.to_csv(outfile, index=False)

# Save extracted peak locations for reproducibility (auxiliary, not required)
peak_info = {
    "rsp_inhalation_peak_indices": rsp_peak_idx.astype(int).tolist(),
    "rsp_inhalation_peak_times_s": (rsp_peak_idx / sampling_rate).round(6).tolist(),
    "rsp_rate_peak_indices": rate_peak_idx.astype(int).tolist(),
    "rsp_rate_peak_times_s": (rate_peak_idx / sampling_rate).round(6).tolist(),
}
with open(os.path.join(outdir, "rrv_extracted_peaks.json"), "w") as f:
    json.dump(peak_info, f, indent=2)

print("Saved RRV analysis to:", outfile)
print("Output shape:", out.shape)
print("Number of inhalation peaks:", len(rsp_peak_idx))
print("Number of respiratory-rate peaks:", len(rate_peak_idx))
print("Key rate stats: mean bpm =", features["RSP_Rate_Mean_Custom"], "sd bpm =", features["RSP_Rate_SD_Custom"])
print("NeuroKit RRV columns:", list(rrv_nk.columns))
print("First 10 output columns:", list(out.columns[:10]))
print("Preview:")
print(out.T.head(60))