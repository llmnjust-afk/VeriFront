import os
import sys
import importlib.util
import numpy as np
import pandas as pd

print("Python:", sys.version)
for pkg in ["neurokit2", "scipy", "numpy", "pandas"]:
    spec = importlib.util.find_spec(pkg)
    print(pkg, "available:", spec is not None)

# If NeuroKit2 exists, inspect relevant functions enough to choose robust workflow.
if importlib.util.find_spec("neurokit2") is not None:
    import neurokit2 as nk
    funcs = [name for name in dir(nk) if name.startswith("rsp_") or name.startswith("hrv_")]
    print("NeuroKit2 version:", getattr(nk, "__version__", "unknown"))
    print("Relevant functions:", funcs[:200])
else:
    print("NeuroKit2 not available; will implement RRV features with scipy/numpy.")