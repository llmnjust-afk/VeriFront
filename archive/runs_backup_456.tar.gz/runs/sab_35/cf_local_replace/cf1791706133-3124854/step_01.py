import os
import numpy as np
import pandas as pd

# Check available files and basic dataset characteristics
base_dir = "biosignals"
infile = os.path.join(base_dir, "bio_eventrelated_100hz.csv")
outdir = "pred_results"
outfile = os.path.join(outdir, "rrv_analysis_pred.csv")

os.makedirs(outdir, exist_ok=True)

df = pd.read_csv(infile)
print("Loaded:", infile)
print("Shape:", df.shape)
print("Columns:", list(df.columns))
print(df.head())

# Basic RSP summary
if "RSP" not in df.columns:
    raise ValueError("RSP column not found in input data.")

rsp = df["RSP"].astype(float).to_numpy()
print("RSP stats:")
print("  min:", np.nanmin(rsp))
print("  max:", np.nanmax(rsp))
print("  mean:", np.nanmean(rsp))
print("  std:", np.nanstd(rsp))

# Save a small inspection file for sanity if needed
summary = pd.DataFrame({
    "signal": ["RSP"],
    "n_samples": [len(rsp)],
    "min": [np.nanmin(rsp)],
    "max": [np.nanmax(rsp)],
    "mean": [np.nanmean(rsp)],
    "std": [np.nanstd(rsp)],
})
summary_path = os.path.join(outdir, "initial_rsp_summary.csv")
summary.to_csv(summary_path, index=False)
print("Saved initial summary to:", summary_path)