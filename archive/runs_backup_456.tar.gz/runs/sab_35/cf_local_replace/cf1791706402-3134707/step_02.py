import os
os.environ.setdefault("MPLCONFIGDIR", os.path.abspath("pred_results/.mplconfig"))
os.makedirs(os.environ["MPLCONFIGDIR"], exist_ok=True)

import inspect
import neurokit2 as nk

for name in ["rsp_process", "rsp_clean", "rsp_peaks", "rsp_rate", "rsp_rrv", "rsp_intervalrelated"]:
    obj = getattr(nk, name, None)
    print("\n==", name, "==")
    print(obj)
    if obj is not None:
        try:
            print(inspect.signature(obj))
            doc = inspect.getdoc(obj) or ""
            print(doc[:1200])
        except Exception as e:
            print("inspect error", e)