import os
os.environ.setdefault("MPLCONFIGDIR", os.path.abspath("pred_results/.mplconfig"))
os.makedirs(os.environ["MPLCONFIGDIR"], exist_ok=True)

import neurokit2 as nk
import inspect

for name in ["rsp_rrv", "rsp_intervalrelated", "rsp_eventrelated", "rsp_findpeaks", "signal_rate", "entropy_sample", "fractal_dfa"]:
    obj = getattr(nk, name, None)
    print("\n==", name, "==")
    if obj is None:
        print("missing")
        continue
    print(inspect.signature(obj))
    doc = inspect.getdoc(obj) or ""
    print(doc[:4000])