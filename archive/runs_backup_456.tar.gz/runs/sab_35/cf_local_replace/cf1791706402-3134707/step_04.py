import os
os.environ.setdefault("MPLCONFIGDIR", os.path.abspath("pred_results/.mplconfig"))
os.makedirs(os.environ["MPLCONFIGDIR"], exist_ok=True)

import numpy as np
import pandas as pd
import neurokit2 as nk
from scipy import signal, interpolate, stats

SAMPLING_RATE = 100
INPUT = "biosignals/bio_eventrelated_100hz.csv"
OUTDIR = "pred_results"
OUTFILE = os.path.join(OUTDIR, "rrv_analysis_pred.csv")
os.makedirs(OUTDIR, exist_ok=True)

df = pd.read_csv(INPUT)
rsp_raw = pd.to_numeric(df["RSP"], errors="coerce").interpolate().bfill().ffill().to_numpy(dtype=float)
n = len(rsp_raw)
duration_s = n / SAMPLING_RATE
print(f"Loaded {INPUT}: {n} samples, duration={duration_s:.2f}s, fs={SAMPLING_RATE}Hz")

# Clean RSP and extract peaks/troughs using NeuroKit2.
methods_to_try = ["khodadad2018", "biosppy"]
chosen = None
for method in methods_to_try:
    try:
        cleaned = nk.rsp_clean(rsp_raw, sampling_rate=SAMPLING_RATE, method=method)
        peaks_signals, info = nk.rsp_peaks(cleaned, sampling_rate=SAMPLING_RATE, method=method)
        peaks = np.asarray(info.get("RSP_Peaks", []), dtype=int)
        troughs = np.asarray(info.get("RSP_Troughs", []), dtype=int)
        print(f"Method {method}: peaks={len(peaks)}, troughs(inhalation onsets)={len(troughs)}")
        if len(troughs) >= 5 and len(peaks) >= 5:
            chosen = (method, cleaned, peaks_signals, info, peaks, troughs)
            break
    except Exception as e:
        print(f"Method {method} failed: {repr(e)}")

if chosen is None:
    # Fallback: bandpass + scipy peak/trough detection with conservative respiratory constraints.
    method = "scipy_fallback"
    cleaned = nk.rsp_clean(rsp_raw, sampling_rate=SAMPLING_RATE, method="khodadad2018")
    min_distance = int(1.5 * SAMPLING_RATE)
    prominence = max(np.nanstd(cleaned) * 0.15, 1e-6)
    peaks, _ = signal.find_peaks(cleaned, distance=min_distance, prominence=prominence)
    troughs, _ = signal.find_peaks(-cleaned, distance=min_distance, prominence=prominence)
    peaks_signals = pd.DataFrame({
        "RSP_Peaks": np.isin(np.arange(n), peaks).astype(int),
        "RSP_Troughs": np.isin(np.arange(n), troughs).astype(int),
    })
    info = {"RSP_Peaks": peaks, "RSP_Troughs": troughs}
    chosen = (method, cleaned, peaks_signals, info, peaks, troughs)
    print(f"Fallback: peaks={len(peaks)}, troughs(inhalation onsets)={len(troughs)}")

method, rsp_cleaned, peaks_signals, info, peaks, troughs = chosen

# Respiratory rate signal. Prefer inhalation onsets (troughs), as requested.
try:
    rsp_rate = nk.signal_rate(troughs, sampling_rate=SAMPLING_RATE, desired_length=n)
except Exception as e:
    print("signal_rate from troughs failed, trying peaks:", repr(e))
    rsp_rate = nk.signal_rate(peaks, sampling_rate=SAMPLING_RATE, desired_length=n)

rsp_rate = np.asarray(rsp_rate, dtype=float)
valid_rate = rsp_rate[np.isfinite(rsp_rate)]
print(f"Chosen method: {method}")
print(f"Rate signal finite samples={len(valid_rate)}, mean={np.nanmean(rsp_rate):.4f} bpm, sd={np.nanstd(rsp_rate, ddof=1):.4f} bpm")

# NeuroKit2 RRV features.
rrv_nk = pd.DataFrame()
try:
    rrv_nk = nk.rsp_rrv(rsp_rate, troughs=troughs, sampling_rate=SAMPLING_RATE, show=False, silent=False)
    print("NeuroKit RRV columns:", list(rrv_nk.columns))
    print(rrv_nk.T.to_string())
except Exception as e:
    print("nk.rsp_rrv failed:", repr(e))

# Custom robust RRV features based on breath-to-breath intervals from inhalation onsets.
features = {
    "Sampling_Rate": SAMPLING_RATE,
    "Duration_s": duration_s,
    "RSP_Cleaning_Method": method,
    "RSP_Raw_Mean": float(np.mean(rsp_raw)),
    "RSP_Raw_SD": float(np.std(rsp_raw, ddof=1)),
    "RSP_Clean_Mean": float(np.mean(rsp_cleaned)),
    "RSP_Clean_SD": float(np.std(rsp_cleaned, ddof=1)),
    "RSP_Peaks_N": int(len(peaks)),
    "RSP_Troughs_Inhalation_N": int(len(troughs)),
    "RSP_Peaks_per_min": float(len(peaks) / duration_s * 60),
    "RSP_Troughs_per_min": float(len(troughs) / duration_s * 60),
    "RSP_Rate_Mean": float(np.nanmean(rsp_rate)),
    "RSP_Rate_SD": float(np.nanstd(rsp_rate, ddof=1)),
    "RSP_Rate_Min": float(np.nanmin(rsp_rate)),
    "RSP_Rate_Max": float(np.nanmax(rsp_rate)),
    "RSP_Rate_Median": float(np.nanmedian(rsp_rate)),
}

troughs = np.sort(np.asarray(troughs, dtype=int))
bbi = np.diff(troughs) / SAMPLING_RATE  # breath-to-breath intervals in seconds
features["BBI_N"] = int(len(bbi))
if len(bbi) > 0:
    diff_bbi = np.diff(bbi)
    features.update({
        "BBI_Mean": float(np.mean(bbi)),
        "BBI_Median": float(np.median(bbi)),
        "BBI_SD": float(np.std(bbi, ddof=1)) if len(bbi) > 1 else np.nan,
        "BBI_CV": float(np.std(bbi, ddof=1) / np.mean(bbi)) if len(bbi) > 1 and np.mean(bbi) != 0 else np.nan,
        "Breathing_Rate_BBI_Mean": float(60 / np.mean(bbi)),
        "RRV_RMSSD_custom": float(np.sqrt(np.mean(diff_bbi ** 2))) if len(diff_bbi) > 0 else np.nan,
        "RRV_SDSD_custom": float(np.std(diff_bbi, ddof=1)) if len(diff_bbi) > 1 else np.nan,
        "RRV_BB50_custom": int(np.sum(np.abs(diff_bbi) > 0.05)) if len(diff_bbi) > 0 else 0,
        "RRV_pBB50_custom": float(np.mean(np.abs(diff_bbi) > 0.05) * 100) if len(diff_bbi) > 0 else np.nan,
        "RRV_BB100_custom": int(np.sum(np.abs(diff_bbi) > 0.10)) if len(diff_bbi) > 0 else 0,
        "RRV_pBB100_custom": float(np.mean(np.abs(diff_bbi) > 0.10) * 100) if len(diff_bbi) > 0 else np.nan,
    })
    if len(bbi) > 2:
        sd1 = np.sqrt(np.var(diff_bbi, ddof=1) / 2)
        sd2_sq = 2 * np.var(bbi, ddof=1) - 0.5 * np.var(diff_bbi, ddof=1)
        sd2 = np.sqrt(sd2_sq) if sd2_sq >= 0 else np.nan
        features["RRV_SD1_custom"] = float(sd1)
        features["RRV_SD2_custom"] = float(sd2)
        features["RRV_SD2SD1_custom"] = float(sd2 / sd1) if sd1 not in [0, np.nan] and np.isfinite(sd1) else np.nan
    # Entropy if enough intervals.
    try:
        features["RRV_SampEn_custom"] = float(nk.entropy_sample(bbi)[0]) if len(bbi) >= 5 else np.nan
    except Exception as e:
        print("custom SampEn failed:", repr(e))
        features["RRV_SampEn_custom"] = np.nan
    try:
        features["RRV_ApEn_custom"] = float(nk.entropy_approximate(bbi)[0]) if len(bbi) >= 5 else np.nan
    except Exception as e:
        print("custom ApEn failed:", repr(e))
        features["RRV_ApEn_custom"] = np.nan

# Frequency domain from interpolated BBI tachogram at 4 Hz, if possible.
if len(bbi) >= 4:
    interval_times = troughs[1:] / SAMPLING_RATE
    fs_interp = 4.0
    t_grid = np.arange(interval_times[0], interval_times[-1], 1 / fs_interp)
    if len(t_grid) > 8:
        bbi_interp = interpolate.interp1d(interval_times, bbi, kind="linear", fill_value="extrapolate")(t_grid)
        bbi_interp = signal.detrend(bbi_interp)
        freqs, psd = signal.welch(bbi_interp, fs=fs_interp, nperseg=min(256, len(bbi_interp)))
        def band_power(lo, hi):
            mask = (freqs >= lo) & (freqs < hi)
            return float(np.trapz(psd[mask], freqs[mask])) if np.any(mask) else np.nan
        vlf = band_power(0.0033, 0.04)
        lf = band_power(0.04, 0.15)
        hf = band_power(0.15, 0.40)
        total = band_power(0.0033, 0.40)
        features.update({
            "RRV_VLF_custom": vlf,
            "RRV_LF_custom": lf,
            "RRV_HF_custom": hf,
            "RRV_TotalPower_custom": total,
            "RRV_LFHF_custom": float(lf / hf) if hf and np.isfinite(hf) and hf != 0 else np.nan,
            "RRV_LFn_custom": float(lf / total) if total and np.isfinite(total) and total != 0 else np.nan,
            "RRV_HFn_custom": float(hf / total) if total and np.isfinite(total) and total != 0 else np.nan,
        })

# Merge NK RRV and custom/metadata features.
if len(rrv_nk) == 1:
    for col, val in rrv_nk.iloc[0].items():
        features[col] = val

out = pd.DataFrame([features])
# Keep strings as strings; convert numpy scalars; blank for unavailable.
out.to_csv(OUTFILE, index=False)
print(f"Saved {OUTFILE} with shape {out.shape}")
print("Columns:")
print(out.columns.tolist())
print("Output preview:")
print(out.T.to_string())