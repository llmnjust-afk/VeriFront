import numpy as np
import pandas as pd
import os

print("CWD:", os.getcwd())
print(os.listdir("."))
print(os.listdir("biosignals"))

df = pd.read_csv("biosignals/bio_eventrelated_100hz.csv")
print(df.head())
print(df.shape)
print(df.columns.tolist())
print(df.describe())

# check neurokit
try:
    import neurokit2 as nk
    print("nk version", nk.__version__)
except Exception as e:
    print("no nk", e)