import os
import numpy as np
import pandas as pd
import neurokit2 as nk
from scipy import signal

fs = 100
df = pd.read_csv("biosignals/bio_eventrelated_100hz.csv")
rsp_raw = pd.to_numeric(df["RSP"], errors="coerce").interpolate().bfill().ffill().to_numpy()

for method in ["khodadad2018", "biosppy"]:
    try:
        cleaned = nk.rsp_clean(rsp_raw, sampling_rate=fs, method=method)
        signals, info = nk.rsp_process(rsp_raw, sampling_rate=fs, method=method)
        print("\nMETHOD", method)
        print("signals shape", signals.shape)
        print("signals columns", list(signals.columns))
        print("info keys", sorted(info.keys()))
        for k, v in info.items():
            if isinstance(v, (list, np.ndarray, pd.Series)):
                arr = np.asarray(v)
                print(k, "len", len(arr), "first10", arr[:10])
            else:
                print(k, type(v), v if isinstance(v, (int, float, str)) else "")
        troughs = np.asarray(info.get("RSP_Troughs", []), dtype=int)
        peaks = np.asarray(info.get("RSP_Peaks", []), dtype=int)
        print("num peaks(exhalation extrema)", len(peaks), "num troughs(inhalation onsets)", len(troughs))
        if len(troughs) > 1:
            intervals = np.diff(troughs) / fs
            print("trough intervals sec: mean", intervals.mean(), "std", intervals.std(ddof=1), "min", intervals.min(), "max", intervals.max(), "rate bpm mean", 60/intervals.mean())
        rrv = nk.rsp_rrv(signals["RSP_Rate"].to_numpy(), troughs=info, sampling_rate=fs, silent=False)
        print("rrv shape", rrv.shape)
        print(rrv.T.to_string(header=False))
    except Exception as e:
        print("\nMETHOD", method, "FAILED", repr(e))