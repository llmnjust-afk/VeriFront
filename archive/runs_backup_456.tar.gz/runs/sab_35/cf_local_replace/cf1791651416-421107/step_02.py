import os
import sys
import importlib
import numpy as np
import pandas as pd

print("Python", sys.version)
for pkg in ["numpy", "pandas", "scipy", "neurokit2"]:
    try:
        mod = importlib.import_module(pkg)
        print(pkg, "version", getattr(mod, "__version__", "unknown"), "available")
    except Exception as e:
        print(pkg, "NOT available:", repr(e))

df = pd.read_csv("biosignals/bio_eventrelated_100hz.csv")
rsp = pd.to_numeric(df["RSP"], errors="coerce").to_numpy()
print("RSP length", len(rsp), "nan", np.isnan(rsp).sum(), "min", np.nanmin(rsp), "max", np.nanmax(rsp), "mean", np.nanmean(rsp), "std", np.nanstd(rsp))
print("Duration seconds @100Hz:", len(rsp)/100)