import neurokit2 as nk
import inspect

names = [n for n in dir(nk) if "rsp" in n.lower() or "rrv" in n.lower()]
print("Resp/RRV-related names:")
print("\n".join(names))

for fn_name in ["rsp_process", "rsp_peaks", "rsp_rate", "rsp_rrv", "rsp_intervalrelated", "hrv_time", "hrv_frequency", "hrv_nonlinear"]:
    if hasattr(nk, fn_name):
        fn = getattr(nk, fn_name)
        print("\n==", fn_name, "==")
        try:
            print(inspect.signature(fn))
        except Exception as e:
            print("signature err", e)
        doc = inspect.getdoc(fn) or ""
        print(doc[:1200])