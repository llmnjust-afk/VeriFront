import inspect
import neurokit2 as nk

for fn_name in ["rsp_rrv", "rsp_intervalrelated", "rsp_analyze", "rsp_clean", "rsp_findpeaks", "rsp_fixpeaks"]:
    fn = getattr(nk, fn_name)
    print("\n" + "="*80)
    print(fn_name, inspect.signature(fn))
    doc = inspect.getdoc(fn) or ""
    print(doc[:5000])