import os
import warnings
import numpy as np
import pandas as pd
import neurokit2 as nk

warnings.filterwarnings("ignore", category=RuntimeWarning)

# Paths and constants
INPUT = "biosignals/bio_eventrelated_100hz.csv"
OUTPUT = "pred_results/rrv_analysis_pred.csv"
FS = 100
os.makedirs(os.path.dirname(OUTPUT), exist_ok=True)

# Load and clean input data
df = pd.read_csv(INPUT)
rsp_raw = pd.to_numeric(df["RSP"], errors="coerce").interpolate(limit_direction="both").bfill().ffill().to_numpy(dtype=float)

# Process respiration signal with NeuroKit2.
# Khodadad2018 is NeuroKit2's default validated RSP processing pipeline.
signals, info = nk.rsp_process(rsp_raw, sampling_rate=FS, method="khodadad2018")
rsp_clean = signals["RSP_Clean"].to_numpy(dtype=float)
rsp_rate = signals["RSP_Rate"].to_numpy(dtype=float)

# NeuroKit2 terminology:
# RSP_Troughs = inhalation onsets; RSP_Peaks = exhalation onsets/end-inspiration extrema.
troughs = np.asarray(info["RSP_Troughs"], dtype=int)
peaks = np.asarray(info["RSP_Peaks"], dtype=int)

# Compute RRV metrics: time-domain, frequency-domain, and nonlinear indices.
rrv = nk.rsp_rrv(rsp_rate, troughs=info, sampling_rate=FS, show=False, silent=True).reset_index(drop=True)

# Additional scalar respiratory features to document the extracted cleaned signal,
# inhalation/exhalation extrema, and respiratory-rate signal used for RRV.
breath_intervals_s = np.diff(troughs) / FS if len(troughs) > 1 else np.array([], dtype=float)
feature_row = {
    "Sampling_Rate_Hz": FS,
    "Duration_s": len(rsp_raw) / FS,
    "RSP_Raw_Mean": float(np.nanmean(rsp_raw)),
    "RSP_Raw_SD": float(np.nanstd(rsp_raw, ddof=1)),
    "RSP_Clean_Mean": float(np.nanmean(rsp_clean)),
    "RSP_Clean_SD": float(np.nanstd(rsp_clean, ddof=1)),
    "RSP_Inhalation_Onsets_N": int(len(troughs)),
    "RSP_Exhalation_Peaks_N": int(len(peaks)),
    "RSP_First_Inhalation_Onset_s": float(troughs[0] / FS) if len(troughs) else np.nan,
    "RSP_Last_Inhalation_Onset_s": float(troughs[-1] / FS) if len(troughs) else np.nan,
    "RSP_BreathInterval_Mean_s": float(np.nanmean(breath_intervals_s)) if len(breath_intervals_s) else np.nan,
    "RSP_BreathInterval_SD_s": float(np.nanstd(breath_intervals_s, ddof=1)) if len(breath_intervals_s) > 1 else np.nan,
    "RSP_BreathInterval_Min_s": float(np.nanmin(breath_intervals_s)) if len(breath_intervals_s) else np.nan,
    "RSP_BreathInterval_Max_s": float(np.nanmax(breath_intervals_s)) if len(breath_intervals_s) else np.nan,
    "RSP_Rate_Mean_bpm": float(np.nanmean(rsp_rate)),
    "RSP_Rate_SD_bpm": float(np.nanstd(rsp_rate, ddof=1)),
    "RSP_Rate_Min_bpm": float(np.nanmin(rsp_rate)),
    "RSP_Rate_Max_bpm": float(np.nanmax(rsp_rate)),
}

# Compactly store the detected event locations as semicolon-separated seconds/samples
# so the required CSV contains both indices and the extracted inhalation features.
feature_row["RSP_Inhalation_Onsets_Samples"] = ";".join(map(str, troughs.tolist()))
feature_row["RSP_Inhalation_Onsets_s"] = ";".join(f"{x/FS:.3f}" for x in troughs)
feature_row["RSP_Exhalation_Peaks_Samples"] = ";".join(map(str, peaks.tolist()))
feature_row["RSP_Exhalation_Peaks_s"] = ";".join(f"{x/FS:.3f}" for x in peaks)

features = pd.DataFrame([feature_row])
out = pd.concat([features, rrv], axis=1)

# Put RRV metrics first after core metadata, while keeping all extracted feature columns.
core_cols = ["Sampling_Rate_Hz", "Duration_s"]
rrv_cols = [c for c in out.columns if c.startswith("RRV_")]
other_cols = [c for c in out.columns if c not in core_cols + rrv_cols]
out = out[core_cols + rrv_cols + other_cols]

out.to_csv(OUTPUT, index=False)

print("Saved RRV analysis to", OUTPUT)
print("Output shape:", out.shape)
print("Detected inhalation onsets/troughs:", len(troughs))
print("Detected exhalation peaks:", len(peaks))
print("Mean respiratory rate (bpm):", feature_row["RSP_Rate_Mean_bpm"])
print("RRV columns:", rrv_cols)
print(out.drop(columns=[c for c in out.columns if c.endswith("_Samples") or c.endswith("_s") and "Onsets" in c or c.endswith("Peaks_s")], errors="ignore").T.to_string(header=False))