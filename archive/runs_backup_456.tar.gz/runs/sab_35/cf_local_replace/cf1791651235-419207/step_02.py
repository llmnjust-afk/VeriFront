import os
import numpy as np
import pandas as pd
from scipy import signal, stats, interpolate
from scipy.signal import find_peaks, welch

# ============================================================
# RRV analysis for biosignals/bio_eventrelated_100hz.csv
# Produces pred_results/rrv_analysis_pred.csv
# ============================================================

INFILE = "biosignals/bio_eventrelated_100hz.csv"
OUTDIR = "pred_results"
OUTFILE = os.path.join(OUTDIR, "rrv_analysis_pred.csv")
FS = 100.0
os.makedirs(OUTDIR, exist_ok=True)

# ----------------------------
# Utility functions
# ----------------------------
def sanitize_series(x):
    s = pd.to_numeric(x, errors="coerce").astype(float)
    s = s.replace([np.inf, -np.inf], np.nan)
    s = s.interpolate(limit_direction="both").bfill().ffill()
    return s.to_numpy(dtype=float)

def butter_filter(x, fs, low=None, high=None, order=4, btype="bandpass"):
    nyq = fs / 2.0
    if btype == "bandpass":
        wn = [max(low / nyq, 1e-6), min(high / nyq, 0.999999)]
    elif btype == "lowpass":
        wn = min(high / nyq, 0.999999)
    elif btype == "highpass":
        wn = max(low / nyq, 1e-6)
    else:
        raise ValueError("Unsupported filter type")
    b, a = signal.butter(order, wn, btype=btype)
    return signal.filtfilt(b, a, x)

def moving_average(x, seconds, fs):
    win = max(1, int(round(seconds * fs)))
    return np.convolve(x, np.ones(win) / win, mode="same")

def robust_standardize(x):
    med = np.median(x)
    mad = np.median(np.abs(x - med))
    if mad <= 1e-12:
        return (x - med) / (np.std(x) + 1e-12)
    return 0.67448975 * (x - med) / mad

def sample_entropy(x, m=2, r=None):
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n <= m + 2:
        return np.nan
    if r is None:
        sd = np.std(x, ddof=1)
        if sd <= 0:
            return np.nan
        r = 0.2 * sd

    def count_matches(mm):
        cnt = 0
        for i in range(n - mm):
            xi = x[i:i + mm]
            for j in range(i + 1, n - mm + 1):
                if np.max(np.abs(xi - x[j:j + mm])) <= r:
                    cnt += 1
        return cnt

    b = count_matches(m)
    a = count_matches(m + 1)
    if a == 0 or b == 0:
        return np.nan
    return -np.log(a / b)

def approximate_entropy(x, m=2, r=None):
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n <= m + 2:
        return np.nan
    if r is None:
        sd = np.std(x, ddof=1)
        if sd <= 0:
            return np.nan
        r = 0.2 * sd

    def phi(mm):
        vals = []
        for i in range(n - mm + 1):
            xi = x[i:i + mm]
            c = 0
            for j in range(n - mm + 1):
                if np.max(np.abs(xi - x[j:j + mm])) <= r:
                    c += 1
            vals.append(c / (n - mm + 1))
        vals = np.asarray(vals)
        vals = vals[vals > 0]
        if len(vals) == 0:
            return np.nan
        return np.mean(np.log(vals))

    p1 = phi(m)
    p2 = phi(m + 1)
    if not np.isfinite(p1) or not np.isfinite(p2):
        return np.nan
    return p1 - p2

def dfa_alpha(x):
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n < 20:
        return np.nan
    y = np.cumsum(x - np.mean(x))
    max_scale = max(5, n // 4)
    scales = np.unique(np.floor(np.logspace(np.log10(4), np.log10(max_scale), 8)).astype(int))
    used_scales, fluct = [], []
    for scale in scales:
        if scale < 4 or n // scale < 2:
            continue
        rms = []
        for start in range(0, n - scale + 1, scale):
            seg = y[start:start + scale]
            tt = np.arange(scale)
            coeff = np.polyfit(tt, seg, 1)
            detrended = seg - np.polyval(coeff, tt)
            rms.append(np.sqrt(np.mean(detrended ** 2)))
        if rms and np.mean(rms) > 0:
            used_scales.append(scale)
            fluct.append(np.mean(rms))
    if len(fluct) < 2:
        return np.nan
    slope, *_ = stats.linregress(np.log(used_scales), np.log(fluct))
    return slope

def band_power(freq, psd, lo, hi):
    mask = (freq >= lo) & (freq < hi)
    if np.sum(mask) < 2:
        return 0.0
    return float(np.trapz(psd[mask], freq[mask]))

def safe_float(x):
    try:
        x = float(x)
        return x if np.isfinite(x) else np.nan
    except Exception:
        return np.nan

# ----------------------------
# Load and clean RSP
# ----------------------------
df = pd.read_csv(INFILE)
print("Loaded file:", INFILE)
print("Shape:", df.shape)
print("Columns:", list(df.columns))

if "RSP" not in df.columns:
    raise ValueError("RSP column is required for RRV analysis.")

rsp_raw = sanitize_series(df["RSP"])
n = len(rsp_raw)
duration_s = n / FS
time = np.arange(n) / FS

# Respiration is slow; filter broadly around plausible adult breathing.
rsp_detrended = signal.detrend(rsp_raw, type="linear")
rsp_clean = butter_filter(rsp_detrended, FS, low=0.05, high=1.0, order=4, btype="bandpass")
rsp_clean = moving_average(rsp_clean, 0.20, FS)
rsp_clean_z = robust_standardize(rsp_clean)

# ----------------------------
# Inhalation peak extraction
# ----------------------------
# Peaks in cleaned RSP correspond to inhalation maxima. Enforce plausible refractory period.
min_peak_distance_s = 1.5  # max 40 breaths/min
min_peak_distance = int(round(min_peak_distance_s * FS))
prominence = max(0.20 * np.std(rsp_clean_z), 0.08)
height_min = np.percentile(rsp_clean_z, 35)

peaks, peak_props = find_peaks(
    rsp_clean_z,
    distance=min_peak_distance,
    prominence=prominence,
    height=height_min
)

# If overly strict, relax height criterion.
if len(peaks) < 5:
    peaks, peak_props = find_peaks(
        rsp_clean_z,
        distance=min_peak_distance,
        prominence=max(0.12 * np.std(rsp_clean_z), 0.05)
    )

peak_times = peaks / FS
rri_s = np.diff(peak_times)  # respiratory cycle intervals in seconds
rate_bpm = 60.0 / rri_s if len(rri_s) else np.array([])
rate_times = (peak_times[:-1] + peak_times[1:]) / 2.0 if len(rri_s) else np.array([])

# Remove physiologically implausible interval outliers for variability features only.
valid = (rri_s >= 1.25) & (rri_s <= 12.0)
rri_valid = rri_s[valid]
rate_valid = 60.0 / rri_valid if len(rri_valid) else np.array([])
rate_times_valid = rate_times[valid] if len(rate_times) else np.array([])

# ----------------------------
# Continuous respiratory-rate signal and its peaks
# ----------------------------
# Use low-rate interpolation for respiratory-rate variability spectral analysis.
interp_fs = 4.0
uniform_t = np.arange(0, duration_s, 1.0 / interp_fs)

if len(rate_times_valid) >= 2:
    f_interp = interpolate.interp1d(
        rate_times_valid,
        rate_valid,
        kind="linear",
        bounds_error=False,
        fill_value=(rate_valid[0], rate_valid[-1])
    )
    rr_rate_signal = f_interp(uniform_t)
    rr_rate_signal = signal.detrend(rr_rate_signal, type="linear") + np.mean(rr_rate_signal)
    rr_rate_signal_smooth = moving_average(rr_rate_signal, 1.0, interp_fs)
    rr_rate_peak_distance = int(round(3.0 * interp_fs))
    rr_rate_peaks, _ = find_peaks(
        robust_standardize(rr_rate_signal_smooth),
        distance=max(1, rr_rate_peak_distance),
        prominence=max(0.10 * np.std(robust_standardize(rr_rate_signal_smooth)), 0.05)
    )
else:
    rr_rate_signal = np.array([])
    rr_rate_signal_smooth = np.array([])
    rr_rate_peaks = np.array([])

# ----------------------------
# Time-domain RRV indices
# ----------------------------
rri = rri_valid
diff_rri = np.diff(rri) if len(rri) > 1 else np.array([])
metrics = {}

metrics["duration_s"] = duration_s
metrics["rsp_raw_mean"] = np.mean(rsp_raw)
metrics["rsp_raw_sd"] = np.std(rsp_raw, ddof=1)
metrics["rsp_clean_mean"] = np.mean(rsp_clean_z)
metrics["rsp_clean_sd"] = np.std(rsp_clean_z, ddof=1)

metrics["n_inhalation_peaks"] = len(peaks)
metrics["n_resp_intervals"] = len(rri)
metrics["n_resp_rate_signal_peaks"] = len(rr_rate_peaks)

metrics["mean_breath_interval_s"] = np.mean(rri) if len(rri) else np.nan
metrics["median_breath_interval_s"] = np.median(rri) if len(rri) else np.nan
metrics["sd_breath_interval_s"] = np.std(rri, ddof=1) if len(rri) > 1 else np.nan
metrics["var_breath_interval_s2"] = np.var(rri, ddof=1) if len(rri) > 1 else np.nan
metrics["min_breath_interval_s"] = np.min(rri) if len(rri) else np.nan
metrics["max_breath_interval_s"] = np.max(rri) if len(rri) else np.nan
metrics["iqr_breath_interval_s"] = stats.iqr(rri) if len(rri) else np.nan
metrics["mad_breath_interval_s"] = stats.median_abs_deviation(rri, scale=1.0) if len(rri) else np.nan
metrics["cv_breath_interval"] = np.std(rri, ddof=1) / np.mean(rri) if len(rri) > 1 and np.mean(rri) != 0 else np.nan

metrics["mean_resp_rate_bpm"] = np.mean(rate_valid) if len(rate_valid) else np.nan
metrics["median_resp_rate_bpm"] = np.median(rate_valid) if len(rate_valid) else np.nan
metrics["sd_resp_rate_bpm"] = np.std(rate_valid, ddof=1) if len(rate_valid) > 1 else np.nan
metrics["min_resp_rate_bpm"] = np.min(rate_valid) if len(rate_valid) else np.nan
metrics["max_resp_rate_bpm"] = np.max(rate_valid) if len(rate_valid) else np.nan

metrics["rmssd_breath_interval_s"] = np.sqrt(np.mean(diff_rri ** 2)) if len(diff_rri) else np.nan
metrics["sdsd_breath_interval_s"] = np.std(diff_rri, ddof=1) if len(diff_rri) > 1 else np.nan
metrics["mean_abs_successive_diff_s"] = np.mean(np.abs(diff_rri)) if len(diff_rri) else np.nan
metrics["pnn20"] = np.mean(np.abs(diff_rri) > 0.20) if len(diff_rri) else np.nan
metrics["pnn50"] = np.mean(np.abs(diff_rri) > 0.50) if len(diff_rri) else np.nan

# ----------------------------
# Frequency-domain RRV indices on interpolated respiratory-rate signal
# Bands adapted to variability frequencies, not the breathing carrier.
# VLF 0.0033-0.04 Hz, LF 0.04-0.15 Hz, HF 0.15-0.40 Hz.
# ----------------------------
if len(rr_rate_signal) >= 32:
    x = rr_rate_signal - np.mean(rr_rate_signal)
    nperseg = min(len(x), 512)
    if nperseg < 64:
        nperseg = len(x)
    freq, psd = welch(x, fs=interp_fs, nperseg=nperseg, noverlap=nperseg // 2 if nperseg >= 16 else None)
    vlf = band_power(freq, psd, 0.0033, 0.04)
    lf = band_power(freq, psd, 0.04, 0.15)
    hf = band_power(freq, psd, 0.15, 0.40)
    total = band_power(freq, psd, 0.0033, 0.40)
    mask_total = (freq >= 0.0033) & (freq <= 0.40)
    peak_freq = freq[mask_total][np.argmax(psd[mask_total])] if np.any(mask_total) else np.nan
else:
    vlf = lf = hf = total = peak_freq = np.nan

metrics["vlf_power_bpm2"] = vlf
metrics["lf_power_bpm2"] = lf
metrics["hf_power_bpm2"] = hf
metrics["total_power_bpm2"] = total
metrics["lf_hf_ratio"] = lf / hf if np.isfinite(hf) and hf > 0 else np.nan
metrics["lf_norm_percent"] = 100 * lf / (lf + hf) if np.isfinite(lf + hf) and (lf + hf) > 0 else np.nan
metrics["hf_norm_percent"] = 100 * hf / (lf + hf) if np.isfinite(lf + hf) and (lf + hf) > 0 else np.nan
metrics["rrv_peak_frequency_hz"] = peak_freq

# ----------------------------
# Nonlinear RRV indices
# ----------------------------
if len(rri) > 2:
    rr1, rr2 = rri[:-1], rri[1:]
    sd1 = np.sqrt(np.var((rr2 - rr1) / np.sqrt(2), ddof=1))
    sd2 = np.sqrt(np.var((rr2 + rr1) / np.sqrt(2), ddof=1))
else:
    sd1 = sd2 = np.nan

metrics["poincare_sd1_s"] = sd1
metrics["poincare_sd2_s"] = sd2
metrics["poincare_sd1_sd2_ratio"] = sd1 / sd2 if np.isfinite(sd1) and np.isfinite(sd2) and sd2 > 0 else np.nan
metrics["sample_entropy"] = sample_entropy(rri) if len(rri) >= 8 else np.nan
metrics["approximate_entropy"] = approximate_entropy(rri) if len(rri) >= 8 else np.nan
metrics["dfa_alpha"] = dfa_alpha(rri) if len(rri) >= 20 else np.nan
metrics["skew_breath_interval"] = stats.skew(rri, bias=False) if len(rri) > 2 else np.nan
metrics["kurtosis_breath_interval"] = stats.kurtosis(rri, bias=False) if len(rri) > 3 else np.nan

# Clean numeric types and save
metrics = {k: safe_float(v) for k, v in metrics.items()}
out = pd.DataFrame([metrics])
out.to_csv(OUTFILE, index=False)

print("Detected inhalation peaks:", int(metrics["n_inhalation_peaks"]))
print("Valid respiratory intervals:", int(metrics["n_resp_intervals"]))
print("Respiratory-rate signal peaks:", int(metrics["n_resp_rate_signal_peaks"]))
print("Mean breath interval (s):", round(metrics["mean_breath_interval_s"], 6))
print("Mean respiratory rate (bpm):", round(metrics["mean_resp_rate_bpm"], 6))
print("SDNN/RRV interval SD (s):", round(metrics["sd_breath_interval_s"], 6))
print("RMSSD (s):", round(metrics["rmssd_breath_interval_s"], 6))
print("LF power:", round(metrics["lf_power_bpm2"], 6))
print("HF power:", round(metrics["hf_power_bpm2"], 6))
print("Sample entropy:", round(metrics["sample_entropy"], 6) if np.isfinite(metrics["sample_entropy"]) else "nan")
print("Saved:", OUTFILE)
print(out.round(6).to_string(index=False))