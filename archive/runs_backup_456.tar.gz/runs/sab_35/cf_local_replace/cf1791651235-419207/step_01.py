import os
import numpy as np
import pandas as pd
from scipy import signal, stats, interpolate
from scipy.signal import find_peaks, welch

# ----------------------------
# Config
# ----------------------------
infile = "biosignals/bio_eventrelated_100hz.csv"
outdir = "pred_results"
outfile = os.path.join(outdir, "rrv_analysis_pred.csv")
fs = 100.0

os.makedirs(outdir, exist_ok=True)

# ----------------------------
# Helpers
# ----------------------------
def sanitize_series(x):
    x = pd.to_numeric(x, errors="coerce").astype(float)
    x = x.replace([np.inf, -np.inf], np.nan).interpolate(limit_direction="both")
    return x.fillna(method="bfill").fillna(method="ffill").to_numpy()

def bandpass_filter(x, fs, low=0.05, high=2.0, order=4):
    nyq = 0.5 * fs
    lowc = max(low / nyq, 1e-6)
    highc = min(high / nyq, 0.999999)
    b, a = signal.butter(order, [lowc, highc], btype="bandpass")
    return signal.filtfilt(b, a, x)

def moving_average(x, win):
    win = int(max(1, win))
    kernel = np.ones(win) / win
    return np.convolve(x, kernel, mode="same")

def robust_zscore(x):
    med = np.nanmedian(x)
    mad = np.nanmedian(np.abs(x - med))
    if mad == 0:
        return (x - med) / (np.nanstd(x) + 1e-12)
    return 0.6745 * (x - med) / (mad + 1e-12)

def compute_rr_intervals(peaks, fs):
    if len(peaks) < 2:
        return np.array([])
    return np.diff(peaks) / fs

def rr_to_inst_rate(rr):
    rr = np.asarray(rr)
    rr = rr[rr > 0]
    if len(rr) == 0:
        return np.array([])
    return 60.0 / rr

def interpolate_series(t, y, t_new):
    if len(t) < 2:
        return np.full_like(t_new, np.nan, dtype=float)
    f = interpolate.interp1d(t, y, kind="linear", bounds_error=False, fill_value="extrapolate")
    return f(t_new)

def sample_entropy(x, m=2, r=None):
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n <= m + 2:
        return np.nan
    if r is None:
        r = 0.2 * np.std(x, ddof=1)
    def _phi(mm):
        count = 0
        total = 0
        for i in range(n - mm):
            template = x[i:i+mm]
            for j in range(i+1, n - mm + 1):
                total += 1
                if np.max(np.abs(template - x[j:j+mm])) <= r:
                    count += 1
        return count, total
    c1, t1 = _phi(m)
    c2, t2 = _phi(m + 1)
    if c1 == 0 or c2 == 0:
        return np.nan
    return -np.log((c2 / t2) / (c1 / t1) + 1e-12)

def detrended_fluctuation_analysis(x):
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n < 20:
        return np.nan
    y = np.cumsum(x - np.mean(x))
    scales = np.unique(np.floor(np.logspace(np.log10(4), np.log10(max(5, n // 4)), 8)).astype(int))
    F = []
    S = []
    for s in scales:
        if s < 4 or n // s < 2:
            continue
        rms = []
        for start in range(0, n - s + 1, s):
            seg = y[start:start+s]
            t = np.arange(s)
            p = np.polyfit(t, seg, 1)
            trend = np.polyval(p, t)
            rms.append(np.sqrt(np.mean((seg - trend) ** 2)))
        if len(rms) > 0:
            F.append(np.mean(rms))
            S.append(s)
    if len(F) < 2:
        return np.nan
    slope, _, _, _, _ = stats.linregress(np.log(S), np.log(F))
    return slope

def power_in_band(f, pxx, lo, hi):
    mask = (f >= lo) & (f < hi)
    if not np.any(mask):
        return np.nan
    return np.trapz(pxx[mask], f[mask])

# ----------------------------
# Load data
# ----------------------------
df = pd.read_csv(infile)
print("Loaded:", infile, "shape=", df.shape)
print("Columns:", list(df.columns))

if "RSP" not in df.columns:
    raise ValueError("Expected RSP column not found.")

rsp_raw = sanitize_series(df["RSP"])
n = len(rsp_raw)
t = np.arange(n) / fs

# ----------------------------
# Clean RSP signal
# ----------------------------
rsp_detrended = signal.detrend(rsp_raw, type="linear")
rsp_bp = bandpass_filter(rsp_detrended, fs, low=0.05, high=2.0, order=4)
rsp_smooth = moving_average(rsp_bp, int(fs * 0.25))
rsp_clean = robust_zscore(rsp_smooth)

print(f"RSP raw stats: mean={np.mean(rsp_raw):.4f}, std={np.std(rsp_raw):.4f}")
print(f"RSP clean stats: mean={np.mean(rsp_clean):.4f}, std={np.std(rsp_clean):.4f}")

# ----------------------------
# Peak extraction
# ----------------------------
min_breath_sec = 1.5  # ~40 bpm max
min_dist = int(min_breath_sec * fs)

prom = max(0.2 * np.nanstd(rsp_clean), 0.05)
peaks, props = find_peaks(rsp_clean, distance=min_dist, prominence=prom)
rr_intervals = compute_rr_intervals(peaks, fs)
rr_rate = rr_to_inst_rate(rr_intervals)

print(f"Detected inhalation peaks: {len(peaks)}")
print(f"Detected RR intervals: {len(rr_intervals)}")
if len(rr_intervals) > 0:
    print(f"RR interval mean={np.mean(rr_intervals):.3f}s, std={np.std(rr_intervals):.3f}s")
    print(f"Respiratory rate mean={np.mean(rr_rate):.2f} bpm, std={np.std(rr_rate):.2f} bpm")

# ----------------------------
# Build respiratory rate time series
# ----------------------------
if len(peaks) >= 2:
    rr_t = (peaks[:-1] + peaks[1:]) / 2 / fs
    rr_inst = rr_rate
    rr_t_uniform = t
    rr_series = interpolate_series(rr_t, rr_inst, rr_t_uniform)
    rr_series = pd.Series(rr_series).interpolate(limit_direction="both").to_numpy()
else:
    rr_series = np.full(n, np.nan)

# ----------------------------
# Time-domain RRV metrics
# ----------------------------
rr = rr_intervals
metrics = {}

metrics["n_peaks"] = int(len(peaks))
metrics["n_rr_intervals"] = int(len(rr))
metrics["mean_rr_s"] = float(np.mean(rr)) if len(rr) else np.nan
metrics["median_rr_s"] = float(np.median(rr)) if len(rr) else np.nan
metrics["sdnn_rr_s"] = float(np.std(rr, ddof=1)) if len(rr) > 1 else np.nan
metrics["rmssd_rr_s"] = float(np.sqrt(np.mean(np.diff(rr) ** 2))) if len(rr) > 2 else np.nan
metrics["cv_rr"] = float(np.std(rr, ddof=1) / np.mean(rr)) if len(rr) > 1 and np.mean(rr) != 0 else np.nan
metrics["mean_rrv_bpm"] = float(np.mean(rr_rate)) if len(rr_rate) else np.nan
metrics["std_rrv_bpm"] = float(np.std(rr_rate, ddof=1)) if len(rr_rate) > 1 else np.nan
metrics["min_rr_s"] = float(np.min(rr)) if len(rr) else np.nan
metrics["max_rr_s"] = float(np.max(rr)) if len(rr) else np.nan
metrics["pnn20"] = float(np.mean(np.abs(np.diff(rr)) > 0.20)) if len(rr) > 2 else np.nan
metrics["pnn50"] = float(np.mean(np.abs(np.diff(rr)) > 0.50)) if len(rr) > 2 else np.nan
metrics["sampen_rr"] = float(sample_entropy(rr)) if len(rr) > 5 else np.nan
metrics["dfa_alpha"] = float(detrended_fluctuation_analysis(rr)) if len(rr) > 20 else np.nan

# ----------------------------
# Frequency-domain metrics
# ----------------------------
freq_metrics = {
    "vlf_power": np.nan,
    "lf_power": np.nan,
    "hf_power": np.nan,
    "total_power": np.nan,
    "lf_hf_ratio": np.nan,
    "lf_norm": np.nan,
    "hf_norm": np.nan,
    "peak_freq_hz": np.nan,
}
if np.sum(np.isfinite(rr_series)) > 10:
    rr_series_d = pd.Series(rr_series).interpolate(limit_direction="both").to_numpy()
    rr_series_d = signal.detrend(rr_series_d - np.nanmean(rr_series_d))
    nperseg = min(256, max(32, len(rr_series_d) // 4))
    f, pxx = welch(rr_series_d, fs=fs, nperseg=nperseg)
    vlf = power_in_band(f, pxx, 0.0033, 0.04)
    lf = power_in_band(f, pxx, 0.04, 0.15)
    hf = power_in_band(f, pxx, 0.15, 0.40)
    total = power_in_band(f, pxx, 0.0033, 0.40)
    freq_metrics["vlf_power"] = float(vlf)
    freq_metrics["lf_power"] = float(lf)
    freq_metrics["hf_power"] = float(hf)
    freq_metrics["total_power"] = float(total)
    freq_metrics["lf_hf_ratio"] = float(lf / hf) if hf and np.isfinite(hf) and hf > 0 else np.nan
    denom = (lf + hf)
    freq_metrics["lf_norm"] = float(lf / denom * 100.0) if denom and np.isfinite(denom) and denom > 0 else np.nan
    freq_metrics["hf_norm"] = float(hf / denom * 100.0) if denom and np.isfinite(denom) and denom > 0 else np.nan
    mask = (f >= 0.0033) & (f <= 0.4)
    if np.any(mask):
        freq_metrics["peak_freq_hz"] = float(f[mask][np.argmax(pxx[mask])])

metrics.update(freq_metrics)

# ----------------------------
# Nonlinear / geometric features
# ----------------------------
if len(rr) > 3:
    rr1 = rr[:-1]
    rr2 = rr[1:]
    sd1 = np.sqrt(np.var((rr2 - rr1) / np.sqrt(2), ddof=1)) if len(rr) > 2 else np.nan
    sd2 = np.sqrt(np.var((rr2 + rr1) / np.sqrt(2), ddof=1)) if len(rr) > 2 else np.nan
else:
    sd1, sd2 = np.nan, np.nan

metrics["poincare_sd1"] = float(sd1) if np.isfinite(sd1) else np.nan
metrics["poincare_sd2"] = float(sd2) if np.isfinite(sd2) else np.nan
metrics["poincare_sd1_sd2"] = float(sd1 / sd2) if np.isfinite(sd1) and np.isfinite(sd2) and sd2 > 0 else np.nan

# ----------------------------
# Save results
# ----------------------------
result_df = pd.DataFrame([metrics])
result_df.to_csv(outfile, index=False)
print("Saved:", outfile)
print(result_df.round(6).to_string(index=False))