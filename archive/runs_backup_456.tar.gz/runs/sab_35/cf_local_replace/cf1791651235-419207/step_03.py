import os
import numpy as np
import pandas as pd
from scipy import signal, stats, interpolate
from scipy.signal import find_peaks, welch

# ============================================================
# Robust RRV analysis for biosignals/bio_eventrelated_100hz.csv
# Output: pred_results/rrv_analysis_pred.csv
# ============================================================

INFILE = "biosignals/bio_eventrelated_100hz.csv"
OUTDIR = "pred_results"
OUTFILE = os.path.join(OUTDIR, "rrv_analysis_pred.csv")
FS = 100.0
os.makedirs(OUTDIR, exist_ok=True)

def sanitize_series(x):
    s = pd.to_numeric(x, errors="coerce").astype(float)
    s = s.replace([np.inf, -np.inf], np.nan)
    return s.interpolate(limit_direction="both").bfill().ffill().to_numpy(dtype=float)

def sos_bandpass(x, fs, low=0.05, high=2.0, order=4):
    sos = signal.butter(order, [low, high], btype="bandpass", fs=fs, output="sos")
    return signal.sosfiltfilt(sos, x)

def moving_average_reflect(x, win):
    win = int(max(1, win))
    if win <= 1:
        return x.copy()
    pad = win // 2
    xp = np.pad(x, (pad, pad), mode="reflect")
    y = np.convolve(xp, np.ones(win) / win, mode="valid")
    return y[:len(x)]

def zscore_standard(x):
    sd = np.std(x)
    if sd <= 1e-12:
        return x - np.mean(x)
    return (x - np.mean(x)) / sd

def sample_entropy(x, m=2, r=None):
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n <= m + 2:
        return np.nan
    if r is None:
        sd = np.std(x, ddof=1)
        if sd <= 1e-12:
            return np.nan
        r = 0.2 * sd

    def count(mm):
        c = 0
        for i in range(n - mm):
            xi = x[i:i + mm]
            for j in range(i + 1, n - mm + 1):
                if np.max(np.abs(xi - x[j:j + mm])) <= r:
                    c += 1
        return c

    b = count(m)
    a = count(m + 1)
    if a == 0 or b == 0:
        return np.nan
    return -np.log(a / b)

def approximate_entropy(x, m=2, r=None):
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n <= m + 2:
        return np.nan
    if r is None:
        sd = np.std(x, ddof=1)
        if sd <= 1e-12:
            return np.nan
        r = 0.2 * sd

    def phi(mm):
        vals = []
        for i in range(n - mm + 1):
            xi = x[i:i + mm]
            c = 0
            for j in range(n - mm + 1):
                if np.max(np.abs(xi - x[j:j + mm])) <= r:
                    c += 1
            vals.append(c / (n - mm + 1))
        vals = np.asarray(vals)
        vals = vals[vals > 0]
        return np.mean(np.log(vals)) if len(vals) else np.nan

    p1, p2 = phi(m), phi(m + 1)
    if not np.isfinite(p1) or not np.isfinite(p2):
        return np.nan
    return p1 - p2

def dfa_alpha(x):
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n < 20:
        return np.nan
    y = np.cumsum(x - np.mean(x))
    scales = np.unique(np.floor(np.logspace(np.log10(4), np.log10(max(5, n // 4)), 8)).astype(int))
    used, fluct = [], []
    for s in scales:
        if s < 4 or n // s < 2:
            continue
        rms = []
        for start in range(0, n - s + 1, s):
            seg = y[start:start + s]
            tt = np.arange(s)
            p = np.polyfit(tt, seg, 1)
            rms.append(np.sqrt(np.mean((seg - np.polyval(p, tt)) ** 2)))
        if rms and np.mean(rms) > 0:
            used.append(s)
            fluct.append(np.mean(rms))
    if len(fluct) < 2:
        return np.nan
    return stats.linregress(np.log(used), np.log(fluct)).slope

def band_power(freq, psd, lo, hi):
    mask = (freq >= lo) & (freq < hi)
    if np.sum(mask) < 2:
        return 0.0
    return float(np.trapz(psd[mask], freq[mask]))

def safe_float(x):
    try:
        x = float(x)
        return x if np.isfinite(x) else np.nan
    except Exception:
        return np.nan

# ----------------------------
# Load
# ----------------------------
df = pd.read_csv(INFILE)
print("Loaded:", INFILE, "shape=", df.shape, "columns=", list(df.columns))
if "RSP" not in df.columns:
    raise ValueError("RSP column not found")

rsp_raw = sanitize_series(df["RSP"])
n = len(rsp_raw)
duration_s = n / FS
time = np.arange(n) / FS

# ----------------------------
# Clean RSP and extract inhalation peaks
# ----------------------------
rsp_detrended = signal.detrend(rsp_raw, type="linear")
rsp_filtered = sos_bandpass(rsp_detrended, FS, low=0.05, high=2.0, order=4)
rsp_clean = moving_average_reflect(rsp_filtered, int(round(0.25 * FS)))
rsp_clean_z = zscore_standard(rsp_clean)

print("RSP raw mean/sd:", float(np.mean(rsp_raw)), float(np.std(rsp_raw, ddof=1)))
print("RSP cleaned z mean/sd/min/max:", float(np.mean(rsp_clean_z)), float(np.std(rsp_clean_z, ddof=1)), float(np.min(rsp_clean_z)), float(np.max(rsp_clean_z)))

min_dist = int(round(1.5 * FS))
prominence = max(0.20 * np.std(rsp_clean_z), 0.05)
peaks, props = find_peaks(rsp_clean_z, distance=min_dist, prominence=prominence)

# Fallback if needed
if len(peaks) < 10:
    peaks, props = find_peaks(rsp_clean_z, distance=min_dist, prominence=max(0.10 * np.std(rsp_clean_z), 0.03))

peak_times = peaks / FS
rri_all = np.diff(peak_times)
rate_all = 60.0 / rri_all if len(rri_all) else np.array([])
rate_times_all = (peak_times[:-1] + peak_times[1:]) / 2.0 if len(rri_all) else np.array([])

# Keep plausible respiratory cycles; first run showed all were plausible except none above 12s
valid = (rri_all >= 1.25) & (rri_all <= 12.0)
rri = rri_all[valid]
rate_bpm = 60.0 / rri if len(rri) else np.array([])
rate_times = rate_times_all[valid] if len(rate_times_all) else np.array([])

# ----------------------------
# Respiratory-rate signal and respiratory-rate-signal peaks
# ----------------------------
interp_fs = 4.0
uniform_t = np.arange(0, duration_s, 1.0 / interp_fs)
if len(rate_times) >= 2:
    interp_fun = interpolate.interp1d(
        rate_times, rate_bpm, kind="linear", bounds_error=False,
        fill_value=(rate_bpm[0], rate_bpm[-1])
    )
    rr_rate_signal = interp_fun(uniform_t)
    rr_rate_signal_smooth = moving_average_reflect(rr_rate_signal, int(round(1.0 * interp_fs)))
    rr_rate_z = zscore_standard(rr_rate_signal_smooth)
    rr_rate_peaks, _ = find_peaks(
        rr_rate_z,
        distance=max(1, int(round(3.0 * interp_fs))),
        prominence=max(0.10 * np.std(rr_rate_z), 0.03)
    )
else:
    rr_rate_signal = np.array([])
    rr_rate_signal_smooth = np.array([])
    rr_rate_peaks = np.array([])

# ----------------------------
# Metrics
# ----------------------------
d = np.diff(rri) if len(rri) > 1 else np.array([])
metrics = {}

metrics["duration_s"] = duration_s
metrics["rsp_raw_mean"] = np.mean(rsp_raw)
metrics["rsp_raw_sd"] = np.std(rsp_raw, ddof=1)
metrics["rsp_clean_mean"] = np.mean(rsp_clean_z)
metrics["rsp_clean_sd"] = np.std(rsp_clean_z, ddof=1)

metrics["n_inhalation_peaks"] = len(peaks)
metrics["n_resp_intervals"] = len(rri)
metrics["n_resp_rate_signal_peaks"] = len(rr_rate_peaks)

# Time domain
metrics["mean_breath_interval_s"] = np.mean(rri) if len(rri) else np.nan
metrics["median_breath_interval_s"] = np.median(rri) if len(rri) else np.nan
metrics["sdnn_breath_interval_s"] = np.std(rri, ddof=1) if len(rri) > 1 else np.nan
metrics["variance_breath_interval_s2"] = np.var(rri, ddof=1) if len(rri) > 1 else np.nan
metrics["min_breath_interval_s"] = np.min(rri) if len(rri) else np.nan
metrics["max_breath_interval_s"] = np.max(rri) if len(rri) else np.nan
metrics["iqr_breath_interval_s"] = stats.iqr(rri) if len(rri) else np.nan
metrics["mad_breath_interval_s"] = stats.median_abs_deviation(rri, scale=1.0) if len(rri) else np.nan
metrics["cv_breath_interval"] = np.std(rri, ddof=1) / np.mean(rri) if len(rri) > 1 and np.mean(rri) != 0 else np.nan

metrics["mean_resp_rate_bpm"] = np.mean(rate_bpm) if len(rate_bpm) else np.nan
metrics["median_resp_rate_bpm"] = np.median(rate_bpm) if len(rate_bpm) else np.nan
metrics["sd_resp_rate_bpm"] = np.std(rate_bpm, ddof=1) if len(rate_bpm) > 1 else np.nan
metrics["min_resp_rate_bpm"] = np.min(rate_bpm) if len(rate_bpm) else np.nan
metrics["max_resp_rate_bpm"] = np.max(rate_bpm) if len(rate_bpm) else np.nan

metrics["rmssd_breath_interval_s"] = np.sqrt(np.mean(d ** 2)) if len(d) else np.nan
metrics["sdsd_breath_interval_s"] = np.std(d, ddof=1) if len(d) > 1 else np.nan
metrics["mean_abs_successive_diff_s"] = np.mean(np.abs(d)) if len(d) else np.nan
metrics["pnn20"] = np.mean(np.abs(d) > 0.20) if len(d) else np.nan
metrics["pnn50"] = np.mean(np.abs(d) > 0.50) if len(d) else np.nan

# Frequency domain on 4 Hz interpolated respiratory-rate signal
if len(rr_rate_signal) >= 32:
    x = signal.detrend(rr_rate_signal - np.mean(rr_rate_signal))
    nperseg = min(len(x), 512)
    freq, psd = welch(x, fs=interp_fs, nperseg=nperseg, noverlap=nperseg // 2)
    vlf = band_power(freq, psd, 0.0033, 0.04)
    lf = band_power(freq, psd, 0.04, 0.15)
    hf = band_power(freq, psd, 0.15, 0.40)
    total = band_power(freq, psd, 0.0033, 0.40)
    mask = (freq >= 0.0033) & (freq <= 0.40)
    peak_freq = float(freq[mask][np.argmax(psd[mask])]) if np.any(mask) else np.nan
else:
    vlf = lf = hf = total = peak_freq = np.nan

metrics["vlf_power_bpm2"] = vlf
metrics["lf_power_bpm2"] = lf
metrics["hf_power_bpm2"] = hf
metrics["total_power_bpm2"] = total
metrics["lf_hf_ratio"] = lf / hf if np.isfinite(hf) and hf > 0 else np.nan
metrics["lf_norm_percent"] = 100.0 * lf / (lf + hf) if np.isfinite(lf + hf) and (lf + hf) > 0 else np.nan
metrics["hf_norm_percent"] = 100.0 * hf / (lf + hf) if np.isfinite(lf + hf) and (lf + hf) > 0 else np.nan
metrics["rrv_peak_frequency_hz"] = peak_freq

# Nonlinear
if len(rri) > 2:
    rr1, rr2 = rri[:-1], rri[1:]
    sd1 = np.sqrt(np.var((rr2 - rr1) / np.sqrt(2), ddof=1))
    sd2 = np.sqrt(np.var((rr2 + rr1) / np.sqrt(2), ddof=1))
else:
    sd1 = sd2 = np.nan

metrics["poincare_sd1_s"] = sd1
metrics["poincare_sd2_s"] = sd2
metrics["poincare_sd1_sd2_ratio"] = sd1 / sd2 if np.isfinite(sd1) and np.isfinite(sd2) and sd2 > 0 else np.nan
metrics["sample_entropy"] = sample_entropy(rri) if len(rri) >= 8 else np.nan
metrics["approximate_entropy"] = approximate_entropy(rri) if len(rri) >= 8 else np.nan
metrics["dfa_alpha"] = dfa_alpha(rri) if len(rri) >= 20 else np.nan
metrics["skew_breath_interval"] = stats.skew(rri, bias=False) if len(rri) > 2 else np.nan
metrics["kurtosis_breath_interval"] = stats.kurtosis(rri, bias=False) if len(rri) > 3 else np.nan

metrics = {k: safe_float(v) for k, v in metrics.items()}
out = pd.DataFrame([metrics])
out.to_csv(OUTFILE, index=False)

print("Detected inhalation peaks:", int(metrics["n_inhalation_peaks"]))
print("Valid respiratory intervals:", int(metrics["n_resp_intervals"]))
print("Detected respiratory-rate signal peaks:", int(metrics["n_resp_rate_signal_peaks"]))
print("Mean interval s:", round(metrics["mean_breath_interval_s"], 6))
print("Mean rate bpm:", round(metrics["mean_resp_rate_bpm"], 6))
print("SDNN s:", round(metrics["sdnn_breath_interval_s"], 6))
print("RMSSD s:", round(metrics["rmssd_breath_interval_s"], 6))
print("LF/HF:", round(metrics["lf_hf_ratio"], 6) if np.isfinite(metrics["lf_hf_ratio"]) else "nan")
print("Saved:", OUTFILE)
print(out.round(6).to_string(index=False))