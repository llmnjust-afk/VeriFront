import os
import importlib
import numpy as np
import pandas as pd

print("Checking available packages and NeuroKit2 respiratory functionality...")

for pkg in ["neurokit2", "scipy", "numpy", "pandas"]:
    spec = importlib.util.find_spec(pkg)
    print(f"{pkg}: {'available' if spec is not None else 'NOT available'}")

try:
    import neurokit2 as nk
    print("neurokit2 version:", getattr(nk, "__version__", "unknown"))
    rsp_funcs = [name for name in dir(nk) if name.startswith("rsp_") or "rrv" in name.lower()]
    print("Respiration/RRV-related functions:")
    print(rsp_funcs)
except Exception as e:
    print("Could not import/use neurokit2:", repr(e))

# Also record dataset duration
df = pd.read_csv("biosignals/bio_eventrelated_100hz.csv")
fs = 100
duration = len(df) / fs
print(f"Dataset duration at {fs} Hz: {duration:.2f} s ({duration/60:.2f} min)")