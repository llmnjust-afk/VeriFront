import os
import warnings
import numpy as np
import pandas as pd
from scipy import signal, stats
import neurokit2 as nk

warnings.filterwarnings("ignore")

# Paths and constants
infile = "biosignals/bio_eventrelated_100hz.csv"
outdir = "pred_results"
outfile = os.path.join(outdir, "rrv_analysis_pred.csv")
os.makedirs(outdir, exist_ok=True)
sampling_rate = 100

# Load signal
df = pd.read_csv(infile)
rsp_raw = df["RSP"].astype(float).to_numpy()
n = len(rsp_raw)
duration_s = n / sampling_rate

# Clean signal and extract respiratory features with NeuroKit2
rsp_clean = nk.rsp_clean(rsp_raw, sampling_rate=sampling_rate)
signals, info = nk.rsp_process(rsp_raw, sampling_rate=sampling_rate)

peak_indices = np.asarray(info.get("RSP_Peaks", np.where(signals["RSP_Peaks"].to_numpy() == 1)[0]), dtype=int)
trough_indices = np.asarray(info.get("RSP_Troughs", np.where(signals["RSP_Troughs"].to_numpy() == 1)[0]), dtype=int)
rsp_rate = signals["RSP_Rate"].astype(float).to_numpy()
rsp_amp = signals["RSP_Amplitude"].astype(float).to_numpy() if "RSP_Amplitude" in signals else np.full(n, np.nan)

# Built-in RRV indices: time, frequency, nonlinear
rrv = nk.rsp_rrv(signals, sampling_rate=sampling_rate)
features = rrv.iloc[0].to_dict()

# Breath-to-breath intervals from inhalation peaks
peak_times_s = peak_indices / sampling_rate
bb_s = np.diff(peak_times_s)
bb_ms = bb_s * 1000.0

# Respiratory-rate signal local maxima
finite_rate = np.asarray(rsp_rate, dtype=float)
finite_rate_for_peaks = finite_rate.copy()
if np.any(~np.isfinite(finite_rate_for_peaks)):
    med_rate = np.nanmedian(finite_rate_for_peaks)
    finite_rate_for_peaks[~np.isfinite(finite_rate_for_peaks)] = med_rate
rate_prominence = max(0.05, 0.10 * np.nanstd(finite_rate_for_peaks))
rate_peak_indices, rate_peak_props = signal.find_peaks(
    finite_rate_for_peaks,
    distance=max(1, int(1.0 * sampling_rate)),
    prominence=rate_prominence,
)

# Add extraction and signal-summary features
extra = {
    "Sampling_Rate_Hz": sampling_rate,
    "Duration_s": duration_s,
    "RSP_Raw_Mean": float(np.nanmean(rsp_raw)),
    "RSP_Raw_SD": float(np.nanstd(rsp_raw, ddof=1)),
    "RSP_Clean_Mean": float(np.nanmean(rsp_clean)),
    "RSP_Clean_SD": float(np.nanstd(rsp_clean, ddof=1)),
    "RSP_Inhalation_Peaks_N": int(len(peak_indices)),
    "RSP_Troughs_N": int(len(trough_indices)),
    "RSP_First_Peak_s": float(peak_times_s[0]) if len(peak_times_s) > 0 else np.nan,
    "RSP_Last_Peak_s": float(peak_times_s[-1]) if len(peak_times_s) > 0 else np.nan,
    "RSP_Rate_Mean_bpm": float(np.nanmean(rsp_rate)),
    "RSP_Rate_SD_bpm": float(np.nanstd(rsp_rate, ddof=1)),
    "RSP_Rate_Min_bpm": float(np.nanmin(rsp_rate)),
    "RSP_Rate_Max_bpm": float(np.nanmax(rsp_rate)),
    "RSP_Rate_Median_bpm": float(np.nanmedian(rsp_rate)),
    "RSP_Rate_Peaks_N": int(len(rate_peak_indices)),
    "RSP_Rate_Peaks_Mean_bpm": float(np.nanmean(finite_rate_for_peaks[rate_peak_indices])) if len(rate_peak_indices) else np.nan,
    "RSP_Amplitude_Mean": float(np.nanmean(rsp_amp)),
    "RSP_Amplitude_SD": float(np.nanstd(rsp_amp, ddof=1)),
}

# Additional breath interval distribution features
if len(bb_ms) > 0:
    extra.update({
        "BB_N": int(len(bb_ms)),
        "BB_Mean_ms_manual": float(np.mean(bb_ms)),
        "BB_SD_ms_manual": float(np.std(bb_ms, ddof=1)) if len(bb_ms) > 1 else np.nan,
        "BB_Min_ms": float(np.min(bb_ms)),
        "BB_Max_ms": float(np.max(bb_ms)),
        "BB_Median_ms_manual": float(np.median(bb_ms)),
        "BB_IQR_ms": float(np.percentile(bb_ms, 75) - np.percentile(bb_ms, 25)),
        "Breathing_Rate_From_Peaks_bpm": float(60.0 / np.mean(bb_s)),
        "BB_Skew": float(stats.skew(bb_ms, bias=False)) if len(bb_ms) > 2 else np.nan,
        "BB_Kurtosis": float(stats.kurtosis(bb_ms, bias=False)) if len(bb_ms) > 3 else np.nan,
    })
else:
    extra.update({
        "BB_N": 0,
        "BB_Mean_ms_manual": np.nan,
        "BB_SD_ms_manual": np.nan,
        "BB_Min_ms": np.nan,
        "BB_Max_ms": np.nan,
        "BB_Median_ms_manual": np.nan,
        "BB_IQR_ms": np.nan,
        "Breathing_Rate_From_Peaks_bpm": np.nan,
        "BB_Skew": np.nan,
        "BB_Kurtosis": np.nan,
    })

# Merge: keep NeuroKit RRV names and add supplementary columns
features.update(extra)

# Save final single-row result
result = pd.DataFrame([features])
result.to_csv(outfile, index=False)

# Save a companion diagnostic table with cleaned RSP, rate, peaks and rate-peak markers
diagnostic = pd.DataFrame({
    "RSP_Raw": rsp_raw,
    "RSP_Clean": rsp_clean,
    "RSP_Rate_bpm": rsp_rate,
    "RSP_Amplitude": rsp_amp,
    "RSP_Inhalation_Peak": np.isin(np.arange(n), peak_indices).astype(int),
    "RSP_Trough": np.isin(np.arange(n), trough_indices).astype(int),
    "RSP_Rate_Peak": np.isin(np.arange(n), rate_peak_indices).astype(int),
})
diag_path = os.path.join(outdir, "rrv_processed_signals_diagnostic.csv")
diagnostic.to_csv(diag_path, index=False)

print("RRV analysis completed.")
print("Input:", infile)
print("Output:", outfile)
print("Diagnostic:", diag_path)
print("Result shape:", result.shape)
print("Detected inhalation peaks:", len(peak_indices))
print("Detected respiratory-rate signal peaks:", len(rate_peak_indices))
print("Mean respiratory rate (bpm):", result.loc[0, "RSP_Rate_Mean_bpm"])
print("Main RRV columns:")
main_cols = [c for c in result.columns if c.startswith("RRV_")]
print(result[main_cols].to_string(index=False))
print("Saved columns:")
print(list(result.columns))