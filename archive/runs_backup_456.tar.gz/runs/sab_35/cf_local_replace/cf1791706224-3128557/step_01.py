import os
import numpy as np
import pandas as pd

# One round of progress: inspect the dataset and start basic RSP cleaning/peak extraction.
infile = "biosignals/bio_eventrelated_100hz.csv"
outdir = "pred_results"
os.makedirs(outdir, exist_ok=True)

df = pd.read_csv(infile)
print("Loaded:", infile)
print("Shape:", df.shape)
print("Columns:", list(df.columns))
print(df.head(5).to_string(index=False))

# Basic checks for RSP
rsp = df["RSP"].astype(float).to_numpy()
print("\nRSP summary:")
print("  n:", rsp.size)
print("  nan count:", np.isnan(rsp).sum())
print("  min/max:", float(np.nanmin(rsp)), float(np.nanmax(rsp)))
print("  mean/std:", float(np.nanmean(rsp)), float(np.nanstd(rsp)))

# Save a tiny diagnostic file for the next round if needed
diag = pd.DataFrame({
    "rsp_mean": [np.nanmean(rsp)],
    "rsp_std": [np.nanstd(rsp)],
    "rsp_min": [np.nanmin(rsp)],
    "rsp_max": [np.nanmax(rsp)],
    "n_samples": [rsp.size],
})
diag_path = os.path.join(outdir, "rrv_diagnostic_start.csv")
diag.to_csv(diag_path, index=False)
print("\nSaved diagnostic:", diag_path)