import os
import warnings
import numpy as np
import pandas as pd
import neurokit2 as nk

warnings.filterwarnings("ignore")
os.makedirs("pred_results", exist_ok=True)

infile = "biosignals/bio_eventrelated_100hz.csv"
fs = 100
df = pd.read_csv(infile)
rsp = df["RSP"].astype(float).to_numpy()

print("Trying NeuroKit2 RSP cleaning, peak extraction, and RRV feature functions...")
cleaned = nk.rsp_clean(rsp, sampling_rate=fs)
print("Cleaned signal:", len(cleaned), "mean/std:", float(np.mean(cleaned)), float(np.std(cleaned)))

# Process complete respiratory signal
signals, info = nk.rsp_process(rsp, sampling_rate=fs)
print("rsp_process signals columns:", list(signals.columns))
print("rsp_process info keys:", sorted(info.keys()))
for k, v in info.items():
    if isinstance(v, (list, np.ndarray, pd.Series)):
        print(k, "len", len(v), "first10", np.asarray(v)[:10])
    else:
        print(k, v)

# Extract peak/trough positions
peak_col = "RSP_Peaks"
trough_col = "RSP_Troughs"
peak_idx = np.where(signals[peak_col].to_numpy() == 1)[0] if peak_col in signals else np.asarray(info.get("RSP_Peaks", []), dtype=int)
trough_idx = np.where(signals[trough_col].to_numpy() == 1)[0] if trough_col in signals else np.asarray(info.get("RSP_Troughs", []), dtype=int)
print("Detected inhalation peaks:", len(peak_idx), peak_idx[:20])
print("Detected troughs:", len(trough_idx), trough_idx[:20])

# Respiratory rate series
rate = signals["RSP_Rate"].to_numpy() if "RSP_Rate" in signals else nk.rsp_rate(cleaned, peaks=peak_idx, sampling_rate=fs, desired_length=len(cleaned))
print("Rate bpm summary min/mean/max/std:", float(np.nanmin(rate)), float(np.nanmean(rate)), float(np.nanmax(rate)), float(np.nanstd(rate)))

# Try built-in RRV
try:
    rrv = nk.rsp_rrv(signals, sampling_rate=fs)
    print("\nrsp_rrv output shape/columns:", rrv.shape, list(rrv.columns))
    print(rrv.to_string(index=False))
    rrv.to_csv("pred_results/rrv_neurokit_trial.csv", index=False)
    print("Saved trial RRV:", "pred_results/rrv_neurokit_trial.csv")
except Exception as e:
    print("rsp_rrv failed:", repr(e))

# Save cleaned signal/rate/markers for reproducibility
diag = pd.DataFrame({
    "RSP_Raw": rsp,
    "RSP_Clean": cleaned,
    "RSP_Rate": rate,
    "RSP_Peaks": np.isin(np.arange(len(rsp)), peak_idx).astype(int),
    "RSP_Troughs": np.isin(np.arange(len(rsp)), trough_idx).astype(int),
})
diag_path = "pred_results/rsp_processed_diagnostic.csv"
diag.to_csv(diag_path, index=False)
print("Saved processed diagnostic:", diag_path)