import os
os.environ["MPLCONFIGDIR"] = os.path.abspath("./.mplconfig")
import numpy as np
import pandas as pd
import neurokit2 as nk
import traceback

sampling_rate = 100
df = pd.read_csv("biosignals/bio_eventrelated_100hz.csv")
rsp = df["RSP"].astype(float).to_numpy()

print("Input length:", len(rsp), "samples; duration:", len(rsp)/sampling_rate, "s")

try:
    signals, info = nk.rsp_process(rsp, sampling_rate=sampling_rate, method="khodadad2018")
    print("rsp_process ok")
    print("signals columns:", list(signals.columns))
    print("info keys:", info.keys())
    for k, v in info.items():
        if isinstance(v, (list, np.ndarray, pd.Series)):
            print(k, "len", len(v), "first10", np.asarray(v)[:10])
        else:
            print(k, v)

    peaks = np.where(signals["RSP_Peaks"].values == 1)[0]
    troughs = np.where(signals["RSP_Troughs"].values == 1)[0]
    print("peaks count:", len(peaks), "peaks:", peaks)
    print("troughs count:", len(troughs), "troughs:", troughs)
    print(signals[["RSP_Raw", "RSP_Clean", "RSP_Rate", "RSP_Amplitude"]].describe().T)

    rrv = nk.rsp_rrv(signals["RSP_Rate"], troughs=troughs, sampling_rate=sampling_rate, show=False, silent=False)
    print("rsp_rrv ok")
    print("rrv shape:", rrv.shape)
    print(rrv.T.to_string())

    interval = nk.rsp_intervalrelated(signals, sampling_rate=sampling_rate)
    print("intervalrelated ok")
    print("interval shape:", interval.shape)
    print(interval.T.to_string())

except Exception as e:
    print("ERROR:", repr(e))
    traceback.print_exc()