import neurokit2 as nk
import inspect

functions = [name for name in dir(nk) if name.startswith("rsp_") or "rrv" in name.lower()]
print("NeuroKit2 respiration/RRV-related functions:")
for name in functions:
    obj = getattr(nk, name)
    if callable(obj):
        try:
            sig = str(inspect.signature(obj))
        except Exception as e:
            sig = "(signature unavailable)"
        print(f"{name}{sig}")

for name in ["rsp_process", "rsp_analyze", "rsp_intervalrelated", "rsp_eventrelated", "rsp_peaks", "rsp_rate", "rsp_rrv"]:
    if hasattr(nk, name):
        print("\nDOC", name, ":\n", (inspect.getdoc(getattr(nk, name)) or "")[:2000])