import os
import numpy as np
import pandas as pd

# Explore the working directory
print("CWD:", os.getcwd())
print("\nFiles in cwd:")
for root, dirs, files in os.walk("."):
    for f in files:
        print(os.path.join(root, f))