import os
import sys
import importlib.util
import numpy as np
import pandas as pd

path = "biosignals/bio_eventrelated_100hz.csv"
df = pd.read_csv(path)
print("Loaded:", path)
print("Shape:", df.shape)
print("Columns:", list(df.columns))
print(df.head())
print(df.describe().T)

for pkg in ["neurokit2", "scipy", "numpy", "pandas"]:
    spec = importlib.util.find_spec(pkg)
    print(f"{pkg} installed:", spec is not None)
    if spec is not None:
        mod = __import__(pkg)
        print(f"  version: {getattr(mod, '__version__', 'unknown')}")