import os
os.environ["MPLCONFIGDIR"] = os.path.abspath("./.mplconfig")

import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import neurokit2 as nk
from scipy.signal import find_peaks

# -----------------------------
# Configuration
# -----------------------------
input_path = "biosignals/bio_eventrelated_100hz.csv"
output_dir = "pred_results"
output_path = os.path.join(output_dir, "rrv_analysis_pred.csv")
sampling_rate = 100  # Hz, from file name and task description

# -----------------------------
# Load data
# -----------------------------
df = pd.read_csv(input_path)
rsp_raw = pd.to_numeric(df["RSP"], errors="coerce").astype(float).to_numpy()

# Fill any possible missing values robustly.
if np.isnan(rsp_raw).any():
    rsp_raw = pd.Series(rsp_raw).interpolate(limit_direction="both").to_numpy()

duration_s = len(rsp_raw) / sampling_rate

# -----------------------------
# Clean RSP and extract respiratory landmarks/rate
# -----------------------------
# NeuroKit2's RSP_Troughs are inhalation onsets; RSP_Peaks are exhalation onsets
# for the default Khodadad et al. respiration pipeline.
signals, info = nk.rsp_process(
    rsp_raw,
    sampling_rate=sampling_rate,
    method="khodadad2018",
    method_rvt="harrison2021",
)

rsp_clean = signals["RSP_Clean"].to_numpy()
rsp_rate = signals["RSP_Rate"].to_numpy()

exhalation_peak_samples = np.where(signals["RSP_Peaks"].to_numpy() == 1)[0]
inhalation_peak_samples = np.where(signals["RSP_Troughs"].to_numpy() == 1)[0]
inhalation_peak_times_s = inhalation_peak_samples / sampling_rate

# Extract peaks in the respiratory-rate signal itself.
# Require at least ~2 s separation to avoid tiny interpolation wiggles being counted.
rate_peak_samples, rate_peak_props = find_peaks(
    rsp_rate,
    distance=int(2.0 * sampling_rate),
    prominence=max(0.05, 0.05 * np.nanstd(rsp_rate)),
)
rate_peak_times_s = rate_peak_samples / sampling_rate

# -----------------------------
# RRV analysis
# -----------------------------
# rsp_intervalrelated includes RRV time-domain, frequency-domain, nonlinear,
# respiratory amplitude variability, RVT, and phase/symmetry features.
interval_features = nk.rsp_intervalrelated(signals, sampling_rate=sampling_rate)

# Also calculate direct RRV table explicitly from the respiratory rate and
# inhalation landmarks to ensure all standard RRV indices are present.
rrv_features = nk.rsp_rrv(
    rsp_rate,
    troughs=inhalation_peak_samples,
    sampling_rate=sampling_rate,
    show=False,
    silent=True,
)

# Merge features, avoiding duplicate columns.
features = interval_features.copy()
for col in rrv_features.columns:
    if col not in features.columns:
        features[col] = rrv_features[col].iloc[0]

# -----------------------------
# Additional extracted-feature summaries
# -----------------------------
breath_intervals_ms = np.diff(inhalation_peak_samples) / sampling_rate * 1000.0
exhalation_intervals_ms = np.diff(exhalation_peak_samples) / sampling_rate * 1000.0

additional = {
    "Signal_SamplingRate": sampling_rate,
    "Signal_Length": len(rsp_raw),
    "Signal_Duration": duration_s,

    "RSP_Raw_Mean": float(np.nanmean(rsp_raw)),
    "RSP_Raw_SD": float(np.nanstd(rsp_raw, ddof=1)),
    "RSP_Clean_Mean": float(np.nanmean(rsp_clean)),
    "RSP_Clean_SD": float(np.nanstd(rsp_clean, ddof=1)),

    "RSP_InhalationPeak_Count": int(len(inhalation_peak_samples)),
    "RSP_ExhalationPeak_Count": int(len(exhalation_peak_samples)),
    "RSP_RatePeak_Count": int(len(rate_peak_samples)),

    "RSP_InhalationPeak_FirstTime": float(inhalation_peak_times_s[0]) if len(inhalation_peak_times_s) else np.nan,
    "RSP_InhalationPeak_LastTime": float(inhalation_peak_times_s[-1]) if len(inhalation_peak_times_s) else np.nan,
    "RSP_RatePeak_FirstTime": float(rate_peak_times_s[0]) if len(rate_peak_times_s) else np.nan,
    "RSP_RatePeak_LastTime": float(rate_peak_times_s[-1]) if len(rate_peak_times_s) else np.nan,

    "RSP_BreathInterval_Mean_ms": float(np.nanmean(breath_intervals_ms)) if len(breath_intervals_ms) else np.nan,
    "RSP_BreathInterval_SD_ms": float(np.nanstd(breath_intervals_ms, ddof=1)) if len(breath_intervals_ms) > 1 else np.nan,
    "RSP_BreathInterval_Min_ms": float(np.nanmin(breath_intervals_ms)) if len(breath_intervals_ms) else np.nan,
    "RSP_BreathInterval_Max_ms": float(np.nanmax(breath_intervals_ms)) if len(breath_intervals_ms) else np.nan,

    "RSP_ExhalationInterval_Mean_ms": float(np.nanmean(exhalation_intervals_ms)) if len(exhalation_intervals_ms) else np.nan,
    "RSP_ExhalationInterval_SD_ms": float(np.nanstd(exhalation_intervals_ms, ddof=1)) if len(exhalation_intervals_ms) > 1 else np.nan,

    "RSP_Rate_Mean": float(np.nanmean(rsp_rate)),
    "RSP_Rate_SD": float(np.nanstd(rsp_rate, ddof=1)),
    "RSP_Rate_Min": float(np.nanmin(rsp_rate)),
    "RSP_Rate_Max": float(np.nanmax(rsp_rate)),
    "RSP_Rate_Median": float(np.nanmedian(rsp_rate)),
    "RSP_RatePeak_RateMean": float(np.nanmean(rsp_rate[rate_peak_samples])) if len(rate_peak_samples) else np.nan,
    "RSP_RatePeak_RateMax": float(np.nanmax(rsp_rate[rate_peak_samples])) if len(rate_peak_samples) else np.nan,
}

for col, val in additional.items():
    features[col] = val

# Ensure a clean, single-row output table.
features = features.replace([np.inf, -np.inf], np.nan)
features.insert(0, "Source_File", input_path)

# -----------------------------
# Save required output
# -----------------------------
os.makedirs(output_dir, exist_ok=True)
features.to_csv(output_path, index=False)

print("Saved:", output_path)
print("Output shape:", features.shape)
print("Detected inhalation peaks:", len(inhalation_peak_samples))
print("Detected exhalation peaks:", len(exhalation_peak_samples))
print("Detected respiratory-rate peaks:", len(rate_peak_samples))
print("Mean respiratory rate (breaths/min):", features["RSP_Rate_Mean"].iloc[0])
print("Mean breath-to-breath interval (ms):", features["RRV_MeanBB"].iloc[0] if "RRV_MeanBB" in features else np.nan)
print("\nRRV/time-frequency-nonlinear feature preview:")
preview_cols = [c for c in features.columns if c.startswith("RRV_") or c in ["RSP_Rate_Mean", "RAV_Mean", "RSP_RVT"]]
print(features[preview_cols].T.to_string(header=False))