import inspect
import neurokit2 as nk

candidates = [name for name in dir(nk) if "rsp" in name.lower() or "rrv" in name.lower()]
print("Candidates:", candidates)

for name in candidates:
    if name in ["rsp_process", "rsp_peaks", "rsp_rate", "rsp_intervalrelated", "rsp_eventrelated", "rsp_analyze", "hrv_time", "hrv_frequency", "hrv_nonlinear"]:
        obj = getattr(nk, name)
        print("\n---", name, "---")
        try:
            print(inspect.signature(obj))
        except Exception as e:
            print("sig err", e)
        doc = inspect.getdoc(obj)
        print((doc or "")[:1000])