import os
import warnings
import numpy as np
import pandas as pd
import neurokit2 as nk

warnings.filterwarnings("ignore")

sampling_rate = 100
input_path = "biosignals/bio_eventrelated_100hz.csv"
out_path = "pred_results/rrv_analysis_pred.csv"
os.makedirs(os.path.dirname(out_path), exist_ok=True)

df = pd.read_csv(input_path)
rsp_raw = pd.to_numeric(df["RSP"], errors="coerce").to_numpy(dtype=float)
print("Loaded", input_path, "n=", len(rsp_raw), "duration_s=", len(rsp_raw)/sampling_rate)
print("NaNs:", np.isnan(rsp_raw).sum(), "min/max:", np.nanmin(rsp_raw), np.nanmax(rsp_raw))

# Fill missing values if any.
if np.isnan(rsp_raw).any():
    rsp_raw = pd.Series(rsp_raw).interpolate(limit_direction="both").to_numpy()

# Try NeuroKit's standard RSP processing pipeline.
signals = None
info = None
for method in ["khodadad2018", "biosppy"]:
    try:
        signals, info = nk.rsp_process(rsp_raw, sampling_rate=sampling_rate, method=method)
        print("rsp_process succeeded with method:", method)
        break
    except Exception as e:
        print("rsp_process failed with method:", method, repr(e))

if signals is None:
    raise RuntimeError("Could not process RSP signal with NeuroKit2.")

print("Processed columns:", list(signals.columns))
print("Info keys:", list(info.keys()))
for key in ["RSP_Peaks", "RSP_Troughs"]:
    vals = np.asarray(info.get(key, []), dtype=int)
    print(key, "count:", len(vals), "first10:", vals[:10].tolist())

# Compute RRV using respiratory-rate time series plus troughs (inhalation onsets).
rrv = nk.rsp_rrv(
    rsp_rate=signals["RSP_Rate"].to_numpy(),
    troughs=info.get("RSP_Troughs", None),
    sampling_rate=sampling_rate,
    show=False,
    silent=False,
)
print("RRV shape:", rrv.shape)
print("RRV columns:", list(rrv.columns))
print(rrv.T)

# Add transparent QC / extracted-feature summaries.
troughs = np.asarray(info.get("RSP_Troughs", []), dtype=int)
peaks = np.asarray(info.get("RSP_Peaks", []), dtype=int)
rate = signals["RSP_Rate"].to_numpy(dtype=float)
clean = signals["RSP_Clean"].to_numpy(dtype=float)
amp = signals["RSP_Amplitude"].to_numpy(dtype=float) if "RSP_Amplitude" in signals else np.full_like(rate, np.nan)

breath_intervals = np.diff(troughs) / sampling_rate if len(troughs) > 1 else np.array([])
inhalation_peak_values = clean[troughs] if len(troughs) else np.array([])
exhalation_peak_values = clean[peaks] if len(peaks) else np.array([])

extra = {
    "Sampling_Rate": sampling_rate,
    "Signal_Length_Samples": len(rsp_raw),
    "Signal_Duration_Seconds": len(rsp_raw) / sampling_rate,
    "RSP_Raw_Mean": float(np.nanmean(rsp_raw)),
    "RSP_Raw_SD": float(np.nanstd(rsp_raw, ddof=1)),
    "RSP_Clean_Mean": float(np.nanmean(clean)),
    "RSP_Clean_SD": float(np.nanstd(clean, ddof=1)),
    "RSP_Inhalation_Onsets_N": int(len(troughs)),
    "RSP_Exhalation_Peaks_N": int(len(peaks)),
    "RSP_Rate_Mean": float(np.nanmean(rate)),
    "RSP_Rate_SD": float(np.nanstd(rate, ddof=1)),
    "RSP_Rate_Min": float(np.nanmin(rate)),
    "RSP_Rate_Max": float(np.nanmax(rate)),
    "RSP_Amplitude_Mean": float(np.nanmean(amp)),
    "RSP_Amplitude_SD": float(np.nanstd(amp, ddof=1)),
    "Breath_Interval_Mean": float(np.nanmean(breath_intervals)) if len(breath_intervals) else np.nan,
    "Breath_Interval_SD": float(np.nanstd(breath_intervals, ddof=1)) if len(breath_intervals) > 1 else np.nan,
    "Inhalation_Peak_Value_Mean": float(np.nanmean(inhalation_peak_values)) if len(inhalation_peak_values) else np.nan,
    "Inhalation_Peak_Value_SD": float(np.nanstd(inhalation_peak_values, ddof=1)) if len(inhalation_peak_values) > 1 else np.nan,
    "Exhalation_Peak_Value_Mean": float(np.nanmean(exhalation_peak_values)) if len(exhalation_peak_values) else np.nan,
    "Exhalation_Peak_Value_SD": float(np.nanstd(exhalation_peak_values, ddof=1)) if len(exhalation_peak_values) > 1 else np.nan,
}

result = pd.concat([pd.DataFrame([extra]), rrv.reset_index(drop=True)], axis=1)
# Avoid duplicated columns if any.
result = result.loc[:, ~result.columns.duplicated()]
result.to_csv(out_path, index=False)

print("Saved:", out_path)
print("Final shape:", result.shape)
print("Final columns:", list(result.columns))
print(result.T)