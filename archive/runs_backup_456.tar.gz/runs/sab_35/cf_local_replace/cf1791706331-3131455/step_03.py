import inspect
import neurokit2 as nk

for name in ["rsp_rrv", "rsp_process", "rsp_findpeaks", "rsp_fixpeaks", "rsp_rate", "rsp_clean"]:
    obj = getattr(nk, name)
    print("\n---", name, "---")
    print(inspect.signature(obj))
    doc = inspect.getdoc(obj) or ""
    print(doc[:2500])