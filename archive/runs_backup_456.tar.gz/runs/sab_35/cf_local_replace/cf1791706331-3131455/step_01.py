import os
import numpy as np
import pandas as pd

print("CWD:", os.getcwd())
print("Files:", os.listdir('.'))
if os.path.exists('biosignals'):
    print("biosignals:", os.listdir('biosignals'))

df = pd.read_csv('biosignals/bio_eventrelated_100hz.csv')
print("Shape:", df.shape)
print("Columns:", list(df.columns))
print(df.head())
print(df.describe())

# Check neurokit2 availability
try:
    import neurokit2 as nk
    print("neurokit2 version:", nk.__version__)
except Exception as e:
    print("nk error:", e)