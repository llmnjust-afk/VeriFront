import os, sys
print(os.getcwd())
print(os.listdir('.'))
try:
    import neurokit2 as nk
    print("nk version", nk.__version__)
except Exception as e:
    print("no nk", e)
import pandas as pd
df = pd.read_csv('biosignals/bio_eventrelated_100hz.csv')
print(df.shape)
print(df.head())
print(df.columns)