import neurokit2 as nk
import inspect
funcs = [f for f in dir(nk) if f.startswith("rsp_") or "rrv" in f.lower()]
print(funcs)
for name in funcs:
    if name in ["rsp_process","rsp_peaks","rsp_rate","rsp_intervalrelated","rsp_analyze","rsp_rrv"]:
        obj=getattr(nk,name)
        print("\n", name, inspect.signature(obj))
        print((inspect.getdoc(obj) or "")[:1000])