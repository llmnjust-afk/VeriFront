import os
import numpy as np
import pandas as pd
import neurokit2 as nk

sr = 100
df = pd.read_csv("biosignals/bio_eventrelated_100hz.csv")
rsp = pd.to_numeric(df["RSP"], errors="coerce").interpolate().bfill().ffill().to_numpy()
print("n", len(rsp), "duration_s", len(rsp)/sr, "nan", np.isnan(rsp).sum(), "minmax", np.nanmin(rsp), np.nanmax(rsp))

for method in ["khodadad2018", "biosppy"]:
    try:
        signals, info = nk.rsp_process(rsp, sampling_rate=sr, method=method)
        print("\nMETHOD", method)
        print("signals shape", signals.shape)
        print("signals cols", list(signals.columns))
        print("info keys", info.keys())
        print({k: (len(v) if hasattr(v,'__len__') and not isinstance(v, str) else v) for k,v in info.items()})
        troughs = info.get("RSP_Troughs", [])
        peaks = info.get("RSP_Peaks", [])
        print("peaks", len(peaks), "troughs", len(troughs), "first peaks", peaks[:5], "first troughs", troughs[:5])
        rrv = nk.rsp_rrv(signals["RSP_Rate"].to_numpy(), troughs=troughs, sampling_rate=sr, silent=False)
        print("rrv shape", rrv.shape)
        print("rrv cols", list(rrv.columns))
        print(rrv.T.to_string())
        interval = nk.rsp_intervalrelated(signals, sampling_rate=sr)
        print("interval cols", list(interval.columns))
        print(interval.T.to_string())
    except Exception as e:
        print("FAILED", method, type(e).__name__, str(e))