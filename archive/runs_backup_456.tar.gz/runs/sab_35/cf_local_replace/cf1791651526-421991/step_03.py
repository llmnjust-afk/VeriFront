import neurokit2 as nk, inspect
for name in ["rsp_rrv","rsp_process","rsp_rate","rsp_findpeaks","rsp_fixpeaks"]:
    obj=getattr(nk,name)
    print("\n###", name, inspect.signature(obj))
    doc = inspect.getdoc(obj) or ""
    print(doc[:2500])