import os
import json
import warnings
import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

import neurokit2 as nk
from scipy.signal import find_peaks

# Configuration
input_path = "biosignals/bio_eventrelated_100hz.csv"
output_path = "pred_results/rrv_analysis_pred.csv"
sampling_rate = 100  # Hz, as specified by filename/task

# Load and clean input column
df = pd.read_csv(input_path)
if "RSP" not in df.columns:
    raise ValueError(f"Column 'RSP' not found in {input_path}. Columns: {list(df.columns)}")

rsp_raw = pd.to_numeric(df["RSP"], errors="coerce")
rsp_raw = rsp_raw.interpolate(limit_direction="both").bfill().ffill().to_numpy(dtype=float)

# Process RSP: cleaned signal, extrema, respiratory rate, phase, amplitude, etc.
signals, info = nk.rsp_process(
    rsp_raw,
    sampling_rate=sampling_rate,
    method="khodadad2018",
    method_rvt="harrison2021",
)

rsp_clean = signals["RSP_Clean"].to_numpy(dtype=float)
rsp_rate = signals["RSP_Rate"].to_numpy(dtype=float)

# NeuroKit extrema:
# In nk.rsp_peaks docs, RSP_Troughs correspond to inhalation onsets,
# while RSP_Peaks correspond to exhalation onsets / maxima depending on convention.
rsp_peaks = np.asarray(info.get("RSP_Peaks", []), dtype=int)
rsp_troughs = np.asarray(info.get("RSP_Troughs", []), dtype=int)

# Additionally extract maxima ("peaks") in the cleaned respiration signal and rate signal.
# Use a physiologically conservative minimum distance of 1 second at 100 Hz.
min_distance = int(1.0 * sampling_rate)
clean_maxima, clean_maxima_props = find_peaks(rsp_clean, distance=min_distance)
rate_maxima, rate_maxima_props = find_peaks(rsp_rate, distance=min_distance)

# RRV analysis using respiratory-rate trace and inhalation onsets/troughs.
rrv = nk.rsp_rrv(
    rsp_rate,
    troughs=rsp_troughs,
    sampling_rate=sampling_rate,
    show=False,
    silent=True,
)

# Interval-related respiration features include RRV + RAV/RVT/symmetry/phase summaries.
interval = nk.rsp_intervalrelated(signals, sampling_rate=sampling_rate)

# Combine interval/rrv indices with explicit extraction summary.
# interval already contains all RRV columns; rrv is used for validation/fallback if needed.
result = interval.copy()
for col in rrv.columns:
    if col not in result.columns:
        result[col] = rrv[col]

duration_s = len(rsp_raw) / sampling_rate
bb_intervals_ms = np.diff(rsp_troughs) / sampling_rate * 1000 if len(rsp_troughs) > 1 else np.array([])

feature_summary = {
    "Sampling_Rate": sampling_rate,
    "Duration_s": duration_s,
    "RSP_Raw_Mean": float(np.nanmean(rsp_raw)),
    "RSP_Raw_SD": float(np.nanstd(rsp_raw, ddof=1)),
    "RSP_Clean_Mean": float(np.nanmean(rsp_clean)),
    "RSP_Clean_SD": float(np.nanstd(rsp_clean, ddof=1)),
    "RSP_NeuroKit_Peaks_Count": int(len(rsp_peaks)),
    "RSP_Inhalation_Onsets_Count": int(len(rsp_troughs)),
    "RSP_Clean_Maxima_Count": int(len(clean_maxima)),
    "RSP_Rate_Maxima_Count": int(len(rate_maxima)),
    "RSP_Inhalation_Onset_First_s": float(rsp_troughs[0] / sampling_rate) if len(rsp_troughs) else np.nan,
    "RSP_Inhalation_Onset_Last_s": float(rsp_troughs[-1] / sampling_rate) if len(rsp_troughs) else np.nan,
    "RSP_Clean_Maxima_First_s": float(clean_maxima[0] / sampling_rate) if len(clean_maxima) else np.nan,
    "RSP_Rate_Maxima_First_s": float(rate_maxima[0] / sampling_rate) if len(rate_maxima) else np.nan,
    "BB_Intervals_Count": int(len(bb_intervals_ms)),
    "BB_Intervals_Min_ms": float(np.nanmin(bb_intervals_ms)) if len(bb_intervals_ms) else np.nan,
    "BB_Intervals_Max_ms": float(np.nanmax(bb_intervals_ms)) if len(bb_intervals_ms) else np.nan,
    "RSP_Rate_Min": float(np.nanmin(rsp_rate)),
    "RSP_Rate_Max": float(np.nanmax(rsp_rate)),
    "RSP_Rate_SD": float(np.nanstd(rsp_rate, ddof=1)),
}

for k, v in feature_summary.items():
    result[k] = v

# Store compact peak samples as semicolon-separated sample indices for traceability.
# These are short enough (~40 indices) to keep in a single-row CSV.
result["RSP_NeuroKit_Peaks_Samples"] = ";".join(map(str, rsp_peaks.tolist()))
result["RSP_Inhalation_Onsets_Samples"] = ";".join(map(str, rsp_troughs.tolist()))
result["RSP_Clean_Maxima_Samples"] = ";".join(map(str, clean_maxima.astype(int).tolist()))
result["RSP_Rate_Maxima_Samples"] = ";".join(map(str, rate_maxima.astype(int).tolist()))

# Save result
os.makedirs(os.path.dirname(output_path), exist_ok=True)
result.to_csv(output_path, index=False)

# Print verification
print(f"Saved: {output_path}")
print("Shape:", result.shape)
print("Columns:", list(result.columns))
print(result.T.to_string())
print("File exists:", os.path.exists(output_path), "size_bytes:", os.path.getsize(output_path))