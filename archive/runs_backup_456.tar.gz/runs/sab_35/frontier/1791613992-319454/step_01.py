#!/usr/bin/env python3
"""
RRV analysis for biosignals/bio_eventrelated_100hz.csv.

Outputs:
  pred_results/rrv_analysis_pred.csv

This script:
  1. Loads the RSP signal sampled at 100 Hz.
  2. Cleans the RSP signal with a respiration-band Butterworth filter.
  3. Extracts inhalation peaks from the cleaned RSP signal.
  4. Builds an instantaneous respiratory-rate signal and extracts its peaks.
  5. Computes respiratory-rate-variability indices:
     - Time domain
     - Frequency domain
     - Nonlinear / complexity
  6. Saves one row of features to the required CSV.
"""

import os
import math
import warnings
from pathlib import Path

import numpy as np
import pandas as pd

from scipy import signal, interpolate, stats
from scipy.spatial import cKDTree


FS = 100.0
INPUT_PATH = Path("biosignals/bio_eventrelated_100hz.csv")
OUTPUT_PATH = Path("pred_results/rrv_analysis_pred.csv")


def _as_float_array(x):
    x = pd.to_numeric(pd.Series(x), errors="coerce").to_numpy(dtype=float)
    if np.any(~np.isfinite(x)):
        idx = np.arange(len(x))
        good = np.isfinite(x)
        if good.sum() == 0:
            raise ValueError("Signal contains no finite samples.")
        x[~good] = np.interp(idx[~good], idx[good], x[good])
    return x


def clean_rsp_rspband(rsp, fs):
    """Respiration-band cleaning: detrend + bandpass + light smoothing."""
    rsp = _as_float_array(rsp)

    # Remove slow linear trend and center.
    x = signal.detrend(rsp, type="linear")
    x = x - np.nanmedian(x)

    # Respiration band. Upper bound kept below Nyquist.
    low = 0.05
    high = 1.00
    nyq = fs / 2.0
    sos = signal.butter(4, [low / nyq, high / nyq], btype="bandpass", output="sos")
    cleaned = signal.sosfiltfilt(sos, x)

    # Very light smoothing to reduce small high-frequency extrema.
    win = int(round(0.25 * fs))
    if win % 2 == 0:
        win += 1
    if win >= 5 and win < len(cleaned):
        cleaned = signal.savgol_filter(cleaned, window_length=win, polyorder=2, mode="interp")

    return cleaned


def detect_inhalation_peaks(cleaned, fs):
    """Adaptive peak picking for inhalation maxima in cleaned respiration."""
    x = np.asarray(cleaned, dtype=float)
    robust_sd = 1.4826 * np.nanmedian(np.abs(x - np.nanmedian(x)))
    if not np.isfinite(robust_sd) or robust_sd <= 0:
        robust_sd = float(np.nanstd(x))
    if not np.isfinite(robust_sd) or robust_sd <= 0:
        robust_sd = 1.0

    # Try increasingly permissive settings until a plausible number is found.
    attempts = [
        dict(distance=1.50, prominence=0.25),
        dict(distance=1.25, prominence=0.18),
        dict(distance=1.00, prominence=0.12),
        dict(distance=0.80, prominence=0.08),
    ]

    best_peaks = np.array([], dtype=int)
    best_props = {}
    for params in attempts:
        peaks, props = signal.find_peaks(
            x,
            distance=max(1, int(round(params["distance"] * fs))),
            prominence=params["prominence"] * robust_sd,
        )
        best_peaks, best_props = peaks, props
        duration_min = len(x) / fs / 60.0
        bpm = len(peaks) / duration_min if duration_min > 0 else 0
        # Plausible broad physiological range.
        if len(peaks) >= 3 and 3 <= bpm <= 45:
            break

    return best_peaks.astype(int), best_props


def interval_outlier_mask(intervals):
    """Mask physiologically plausible breath intervals and robust outliers."""
    intervals = np.asarray(intervals, dtype=float)
    mask = np.isfinite(intervals) & (intervals >= 1.0) & (intervals <= 15.0)
    if mask.sum() >= 5:
        vals = intervals[mask]
        med = np.median(vals)
        mad = np.median(np.abs(vals - med))
        if mad > 0:
            robust_z = 0.6745 * (intervals - med) / mad
            mask &= np.abs(robust_z) <= 4.5
    return mask


def make_rate_signal(peak_samples, intervals_s, valid_interval_mask, n_samples, fs):
    """
    Instantaneous respiratory rate in breaths/min.
    Intervals are assigned to the second peak of each interval and interpolated.
    """
    rate_signal = np.full(n_samples, np.nan, dtype=float)
    if len(intervals_s) == 0 or valid_interval_mask.sum() < 2:
        return rate_signal

    times = peak_samples[1:] / fs
    valid_times = times[valid_interval_mask]
    valid_rates = 60.0 / intervals_s[valid_interval_mask]

    order = np.argsort(valid_times)
    valid_times = valid_times[order]
    valid_rates = valid_rates[order]

    # Remove duplicate times if any.
    unique_times, unique_idx = np.unique(valid_times, return_index=True)
    valid_times = unique_times
    valid_rates = valid_rates[unique_idx]

    if len(valid_times) == 1:
        rate_signal[:] = valid_rates[0]
        return rate_signal

    sample_times = np.arange(n_samples) / fs
    rate_signal = np.interp(sample_times, valid_times, valid_rates)

    # Hold edge values.
    rate_signal[sample_times < valid_times[0]] = valid_rates[0]
    rate_signal[sample_times > valid_times[-1]] = valid_rates[-1]

    # Smooth over about 5 seconds to describe respiratory-rate trajectory.
    win = int(round(5.0 * fs))
    if win % 2 == 0:
        win += 1
    if win >= 7 and win < len(rate_signal):
        rate_signal = signal.savgol_filter(rate_signal, window_length=win, polyorder=2, mode="interp")

    return rate_signal


def detect_rate_peaks(rate_signal, fs):
    rr = np.asarray(rate_signal, dtype=float)
    finite = np.isfinite(rr)
    if finite.sum() < int(10 * fs):
        return np.array([], dtype=int), {}

    sd = np.nanstd(rr)
    prom = 0.05 * sd if sd > 0 else None
    kwargs = dict(distance=max(1, int(round(5.0 * fs))))
    if prom is not None and prom > 0:
        kwargs["prominence"] = prom
    peaks, props = signal.find_peaks(rr, **kwargs)
    return peaks.astype(int), props


def safe_mean(x):
    x = np.asarray(x, dtype=float)
    return float(np.nanmean(x)) if np.isfinite(x).any() else np.nan


def safe_std(x, ddof=1):
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    if len(x) <= ddof:
        return np.nan
    return float(np.std(x, ddof=ddof))


def safe_median(x):
    x = np.asarray(x, dtype=float)
    return float(np.nanmedian(x)) if np.isfinite(x).any() else np.nan


def safe_percentile(x, p):
    x = np.asarray(x, dtype=float)
    return float(np.nanpercentile(x, p)) if np.isfinite(x).any() else np.nan


def sample_entropy(x, m=2, r=None):
    """Sample entropy using Chebyshev-distance KDTree pair counts."""
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n < m + 2:
        return np.nan
    if r is None:
        sd = np.std(x, ddof=0)
        if sd <= 0 or not np.isfinite(sd):
            return np.nan
        r = 0.2 * sd

    def _embed(arr, dim):
        return np.array([arr[i:i + dim] for i in range(len(arr) - dim + 1)])

    xm = _embed(x, m)
    xm1 = _embed(x, m + 1)

    try:
        cm = len(cKDTree(xm).query_pairs(r=r, p=np.inf))
        cm1 = len(cKDTree(xm1).query_pairs(r=r, p=np.inf))
    except Exception:
        return np.nan

    if cm <= 0 or cm1 <= 0:
        return np.nan
    return float(-np.log(cm1 / cm))


def approximate_entropy(x, m=2, r=None):
    """Approximate entropy; uses KDTree neighbor counts including self."""
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n < m + 2:
        return np.nan
    if r is None:
        sd = np.std(x, ddof=0)
        if sd <= 0 or not np.isfinite(sd):
            return np.nan
        r = 0.2 * sd

    def _phi(dim):
        emb = np.array([x[i:i + dim] for i in range(n - dim + 1)])
        tree = cKDTree(emb)
        counts = np.array([len(tree.query_ball_point(row, r=r, p=np.inf)) for row in emb], dtype=float)
        c = counts / len(emb)
        c = np.maximum(c, np.finfo(float).tiny)
        return np.mean(np.log(c))

    try:
        return float(_phi(m) - _phi(m + 1))
    except Exception:
        return np.nan


def poincare_features(x):
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    if len(x) < 3:
        return np.nan, np.nan, np.nan, np.nan
    diff = np.diff(x)
    sd_diff = np.std(diff, ddof=1) if len(diff) > 1 else np.nan
    sd_x = np.std(x, ddof=1)
    sd1 = math.sqrt(0.5) * sd_diff if np.isfinite(sd_diff) else np.nan
    val = 2 * sd_x**2 - 0.5 * sd_diff**2 if np.isfinite(sd_x) and np.isfinite(sd_diff) else np.nan
    sd2 = math.sqrt(max(val, 0.0)) if np.isfinite(val) else np.nan
    ratio = sd1 / sd2 if np.isfinite(sd1) and np.isfinite(sd2) and sd2 > 0 else np.nan
    area = math.pi * sd1 * sd2 if np.isfinite(sd1) and np.isfinite(sd2) else np.nan
    return float(sd1), float(sd2), float(ratio), float(area)


def dfa_alpha(x, scale_min, scale_max):
    """Detrended fluctuation analysis alpha over scale range in samples/breaths."""
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n < max(scale_min * 3, 12):
        return np.nan

    y = np.cumsum(x - np.mean(x))
    max_scale = min(scale_max, n // 4)
    if max_scale <= scale_min:
        return np.nan

    scales = np.unique(np.floor(np.logspace(np.log10(scale_min), np.log10(max_scale), 12)).astype(int))
    flucts = []
    used_scales = []
    for s in scales:
        if s < 4:
            continue
        nseg = n // s
        if nseg < 2:
            continue
        rms = []
        for i in range(nseg):
            seg = y[i * s:(i + 1) * s]
            t = np.arange(s)
            coeff = np.polyfit(t, seg, 1)
            trend = coeff[0] * t + coeff[1]
            rms.append(np.sqrt(np.mean((seg - trend) ** 2)))
        f = np.sqrt(np.mean(np.asarray(rms) ** 2))
        if np.isfinite(f) and f > 0:
            flucts.append(f)
            used_scales.append(s)

    if len(used_scales) < 3:
        return np.nan
    slope, _ = np.polyfit(np.log(used_scales), np.log(flucts), 1)
    return float(slope)


def higuchi_fd(x, kmax=10):
    """Higuchi fractal dimension."""
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n < kmax * 2 or np.std(x) == 0:
        return np.nan
    lk = []
    kk = []
    for k in range(1, kmax + 1):
        lm = []
        for m in range(k):
            idx = np.arange(m, n, k)
            if len(idx) < 2:
                continue
            dist = np.sum(np.abs(np.diff(x[idx])))
            norm = (n - 1) / ((len(idx) - 1) * k)
            lm.append((dist * norm) / k)
        if len(lm) > 0 and np.mean(lm) > 0:
            lk.append(np.mean(lm))
            kk.append(k)
    if len(kk) < 3:
        return np.nan
    slope, _ = np.polyfit(np.log(1.0 / np.asarray(kk)), np.log(lk), 1)
    return float(slope)


def spectral_entropy_from_psd(psd):
    psd = np.asarray(psd, dtype=float)
    psd = psd[np.isfinite(psd) & (psd >= 0)]
    total = psd.sum()
    if total <= 0 or len(psd) == 0:
        return np.nan
    p = psd / total
    p = p[p > 0]
    return float(-np.sum(p * np.log2(p)) / np.log2(len(psd))) if len(psd) > 1 else np.nan


def band_power(freqs, psd, lo, hi):
    freqs = np.asarray(freqs)
    psd = np.asarray(psd)
    mask = (freqs >= lo) & (freqs < hi)
    if mask.sum() < 1:
        return np.nan, np.nan
    power = float(np.trapz(psd[mask], freqs[mask])) if mask.sum() >= 2 else 0.0
    peak_freq = float(freqs[mask][np.argmax(psd[mask])])
    return power, peak_freq


def frequency_features(interval_times_s, intervals_s):
    """
    Frequency-domain RRV from interpolated breath-interval tachogram.
    Frequencies are cycles per second/Hz over the interval series in time.
    """
    features = {}
    names = [
        "rrv_vlf_power", "rrv_lf_power", "rrv_hf_power", "rrv_total_power",
        "rrv_lf_hf_ratio", "rrv_lf_norm", "rrv_hf_norm",
        "rrv_vlf_peak_hz", "rrv_lf_peak_hz", "rrv_hf_peak_hz",
        "rrv_psd_peak_hz", "rrv_spectral_entropy"
    ]
    for name in names:
        features[name] = np.nan

    t = np.asarray(interval_times_s, dtype=float)
    x = np.asarray(intervals_s, dtype=float)
    good = np.isfinite(t) & np.isfinite(x)
    t, x = t[good], x[good]

    if len(x) < 8 or (t[-1] - t[0]) < 30:
        return features

    order = np.argsort(t)
    t = t[order]
    x = x[order]
    uniq_t, uniq_idx = np.unique(t, return_index=True)
    t = uniq_t
    x = x[uniq_idx]
    if len(x) < 8:
        return features

    fs_interp = 4.0
    grid = np.arange(t[0], t[-1], 1.0 / fs_interp)
    if len(grid) < 32:
        return features

    y = np.interp(grid, t, x)
    y = signal.detrend(y, type="linear")
    y = y - np.mean(y)

    nperseg = min(256, len(y))
    if nperseg < 16 or np.std(y) <= 0:
        return features

    freqs, psd = signal.welch(
        y,
        fs=fs_interp,
        window="hann",
        nperseg=nperseg,
        noverlap=nperseg // 2,
        detrend="constant",
        scaling="density",
    )

    # Common variability bands, reported for RRV as low-frequency variability
    # in the breath-interval sequence.
    vlf, vlf_peak = band_power(freqs, psd, 0.0033, 0.04)
    lf, lf_peak = band_power(freqs, psd, 0.04, 0.15)
    hf, hf_peak = band_power(freqs, psd, 0.15, 0.40)
    total, _ = band_power(freqs, psd, 0.0033, 0.40)

    lf_hf = lf / hf if np.isfinite(lf) and np.isfinite(hf) and hf > 0 else np.nan
    denom = lf + hf if np.isfinite(lf) and np.isfinite(hf) else np.nan
    lf_norm = 100.0 * lf / denom if np.isfinite(denom) and denom > 0 else np.nan
    hf_norm = 100.0 * hf / denom if np.isfinite(denom) and denom > 0 else np.nan

    in_band = (freqs >= 0.0033) & (freqs <= 0.40)
    psd_peak = float(freqs[in_band][np.argmax(psd[in_band])]) if in_band.sum() else np.nan

    features.update({
        "rrv_vlf_power": vlf,
        "rrv_lf_power": lf,
        "rrv_hf_power": hf,
        "rrv_total_power": total,
        "rrv_lf_hf_ratio": lf_hf,
        "rrv_lf_norm": lf_norm,
        "rrv_hf_norm": hf_norm,
        "rrv_vlf_peak_hz": vlf_peak,
        "rrv_lf_peak_hz": lf_peak,
        "rrv_hf_peak_hz": hf_peak,
        "rrv_psd_peak_hz": psd_peak,
        "rrv_spectral_entropy": spectral_entropy_from_psd(psd[in_band]) if in_band.sum() else np.nan,
    })
    return features


def compute_rrv_features(rsp, fs):
    cleaned = clean_rsp_rspband(rsp, fs)
    peak_samples, peak_props = detect_inhalation_peaks(cleaned, fs)
    peak_times = peak_samples / fs
    intervals = np.diff(peak_times)
    valid_mask = interval_outlier_mask(intervals)
    valid_intervals = intervals[valid_mask]
    valid_interval_times = peak_times[1:][valid_mask]

    rate_signal = make_rate_signal(peak_samples, intervals, valid_mask, len(rsp), fs)
    rate_peaks, rate_peak_props = detect_rate_peaks(rate_signal, fs)

    rr_bpm = 60.0 / valid_intervals if len(valid_intervals) else np.array([], dtype=float)
    diff_intervals = np.diff(valid_intervals) if len(valid_intervals) >= 2 else np.array([], dtype=float)

    features = {}

    # Metadata / peak extraction.
    duration_s = len(rsp) / fs
    features["sampling_rate_hz"] = fs
    features["recording_duration_s"] = duration_s
    features["recording_duration_min"] = duration_s / 60.0
    features["rsp_clean_mean"] = safe_mean(cleaned)
    features["rsp_clean_sd"] = safe_std(cleaned)
    features["rsp_clean_min"] = float(np.nanmin(cleaned))
    features["rsp_clean_max"] = float(np.nanmax(cleaned))
    features["rsp_inhalation_peak_count_raw"] = int(len(peak_samples))
    features["rsp_valid_interval_count"] = int(len(valid_intervals))
    features["rsp_rejected_interval_count"] = int(len(intervals) - len(valid_intervals))
    features["rsp_inhalation_peak_rate_per_min"] = float(len(peak_samples) / (duration_s / 60.0)) if duration_s > 0 else np.nan

    if len(peak_samples) > 0:
        features["rsp_first_inhalation_peak_s"] = float(peak_samples[0] / fs)
        features["rsp_last_inhalation_peak_s"] = float(peak_samples[-1] / fs)
        features["rsp_mean_inhalation_peak_amplitude"] = safe_mean(cleaned[peak_samples])
        features["rsp_sd_inhalation_peak_amplitude"] = safe_std(cleaned[peak_samples])
    else:
        features["rsp_first_inhalation_peak_s"] = np.nan
        features["rsp_last_inhalation_peak_s"] = np.nan
        features["rsp_mean_inhalation_peak_amplitude"] = np.nan
        features["rsp_sd_inhalation_peak_amplitude"] = np.nan

    # Respiratory-rate signal peak features.
    features["resp_rate_signal_peak_count"] = int(len(rate_peaks))
    features["resp_rate_signal_peak_rate_per_min"] = float(len(rate_peaks) / (duration_s / 60.0)) if duration_s > 0 else np.nan
    features["resp_rate_signal_mean_bpm"] = safe_mean(rate_signal)
    features["resp_rate_signal_sd_bpm"] = safe_std(rate_signal)
    features["resp_rate_signal_min_bpm"] = float(np.nanmin(rate_signal)) if np.isfinite(rate_signal).any() else np.nan
    features["resp_rate_signal_max_bpm"] = float(np.nanmax(rate_signal)) if np.isfinite(rate_signal).any() else np.nan
    features["resp_rate_signal_peak_mean_bpm"] = safe_mean(rate_signal[rate_peaks]) if len(rate_peaks) else np.nan
    features["resp_rate_signal_peak_sd_bpm"] = safe_std(rate_signal[rate_peaks]) if len(rate_peaks) else np.nan

    # Time-domain RRV indices on breath-to-breath intervals.
    features["rrv_mean_bbi_s"] = safe_mean(valid_intervals)
    features["rrv_median_bbi_s"] = safe_median(valid_intervals)
    features["rrv_sd_bbi_s"] = safe_std(valid_intervals)
    features["rrv_var_bbi_s2"] = float(np.nanvar(valid_intervals, ddof=1)) if len(valid_intervals) > 1 else np.nan
    features["rrv_min_bbi_s"] = float(np.nanmin(valid_intervals)) if len(valid_intervals) else np.nan
    features["rrv_max_bbi_s"] = float(np.nanmax(valid_intervals)) if len(valid_intervals) else np.nan
    features["rrv_range_bbi_s"] = features["rrv_max_bbi_s"] - features["rrv_min_bbi_s"] if len(valid_intervals) else np.nan
    features["rrv_iqr_bbi_s"] = safe_percentile(valid_intervals, 75) - safe_percentile(valid_intervals, 25) if len(valid_intervals) else np.nan
    features["rrv_mad_bbi_s"] = float(stats.median_abs_deviation(valid_intervals, nan_policy="omit")) if len(valid_intervals) else np.nan
    features["rrv_cv_bbi"] = features["rrv_sd_bbi_s"] / features["rrv_mean_bbi_s"] if np.isfinite(features["rrv_sd_bbi_s"]) and features["rrv_mean_bbi_s"] else np.nan

    features["rrv_rmssd_s"] = float(np.sqrt(np.mean(diff_intervals ** 2))) if len(diff_intervals) else np.nan
    features["rrv_sdsd_s"] = safe_std(diff_intervals)
    features["rrv_mean_abs_successive_diff_s"] = safe_mean(np.abs(diff_intervals)) if len(diff_intervals) else np.nan
    features["rrv_pnn50_percent"] = float(100 * np.mean(np.abs(diff_intervals) > 0.050)) if len(diff_intervals) else np.nan
    features["rrv_pnn100_percent"] = float(100 * np.mean(np.abs(diff_intervals) > 0.100)) if len(diff_intervals) else np.nan
    features["rrv_pnn200_percent"] = float(100 * np.mean(np.abs(diff_intervals) > 0.200)) if len(diff_intervals) else np.nan

    # Respiratory-rate summary from breath intervals.
    features["rrv_mean_resp_rate_bpm"] = safe_mean(rr_bpm)
    features["rrv_median_resp_rate_bpm"] = safe_median(rr_bpm)
    features["rrv_sd_resp_rate_bpm"] = safe_std(rr_bpm)
    features["rrv_min_resp_rate_bpm"] = float(np.nanmin(rr_bpm)) if len(rr_bpm) else np.nan
    features["rrv_max_resp_rate_bpm"] = float(np.nanmax(rr_bpm)) if len(rr_bpm) else np.nan
    features["rrv_cv_resp_rate"] = features["rrv_sd_resp_rate_bpm"] / features["rrv_mean_resp_rate_bpm"] if np.isfinite(features["rrv_sd_resp_rate_bpm"]) and features["rrv_mean_resp_rate_bpm"] else np.nan

    # Frequency-domain RRV.
    features.update(frequency_features(valid_interval_times, valid_intervals))

    # Nonlinear indices.
    sd1, sd2, sd_ratio, ellipse_area = poincare_features(valid_intervals)
    features["rrv_poincare_sd1_s"] = sd1
    features["rrv_poincare_sd2_s"] = sd2
    features["rrv_poincare_sd1_sd2_ratio"] = sd_ratio
    features["rrv_poincare_ellipse_area"] = ellipse_area
    features["rrv_sample_entropy"] = sample_entropy(valid_intervals, m=2)
    features["rrv_approximate_entropy"] = approximate_entropy(valid_intervals, m=2)
    features["rrv_dfa_alpha1"] = dfa_alpha(valid_intervals, scale_min=4, scale_max=16)
    features["rrv_dfa_alpha2"] = dfa_alpha(valid_intervals, scale_min=16, scale_max=64)
    features["rrv_higuchi_fd"] = higuchi_fd(valid_intervals, kmax=min(10, max(3, len(valid_intervals) // 5))) if len(valid_intervals) >= 20 else np.nan
    features["rrv_skewness_bbi"] = float(stats.skew(valid_intervals, bias=False, nan_policy="omit")) if len(valid_intervals) >= 3 else np.nan
    features["rrv_kurtosis_bbi"] = float(stats.kurtosis(valid_intervals, bias=False, nan_policy="omit")) if len(valid_intervals) >= 4 else np.nan

    return features, cleaned, peak_samples, rate_signal, rate_peaks


def main():
    warnings.filterwarnings("ignore", category=RuntimeWarning)

    if not INPUT_PATH.exists():
        raise FileNotFoundError(f"Missing input file: {INPUT_PATH}")

    df = pd.read_csv(INPUT_PATH)
    print(f"Loaded {INPUT_PATH} with shape {df.shape}")
    print(f"Columns: {list(df.columns)}")

    if "RSP" not in df.columns:
        raise ValueError("Input file does not contain required RSP column.")

    rsp = _as_float_array(df["RSP"])
    features, cleaned, inhalation_peaks, rate_signal, rate_peaks = compute_rrv_features(rsp, FS)

    out = pd.DataFrame([features])
    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(OUTPUT_PATH, index=False)

    print(f"Cleaned RSP length: {len(cleaned)} samples")
    print(f"Detected inhalation peaks: {len(inhalation_peaks)}")
    print(f"Detected respiratory-rate signal peaks: {len(rate_peaks)}")
    print("Key RRV results:")
    key_cols = [
        "recording_duration_min",
        "rsp_inhalation_peak_rate_per_min",
        "rsp_valid_interval_count",
        "rrv_mean_bbi_s",
        "rrv_sd_bbi_s",
        "rrv_rmssd_s",
        "rrv_mean_resp_rate_bpm",
        "rrv_sd_resp_rate_bpm",
        "rrv_lf_power",
        "rrv_hf_power",
        "rrv_lf_hf_ratio",
        "rrv_sample_entropy",
        "rrv_poincare_sd1_s",
        "rrv_poincare_sd2_s",
    ]
    for col in key_cols:
        print(f"  {col}: {out.loc[0, col]}")
    print(f"Saved {out.shape[1]} RRV feature columns to {OUTPUT_PATH}")


if __name__ == "__main__":
    main()