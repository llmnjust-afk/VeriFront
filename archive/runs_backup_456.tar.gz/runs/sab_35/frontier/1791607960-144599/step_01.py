#!/usr/bin/env python3
import os
import sys
import importlib.util
from pathlib import Path

import numpy as np
import pandas as pd

print("Working directory:", os.getcwd())
print("Python:", sys.version.split()[0])

data_path = Path("biosignals/bio_eventrelated_100hz.csv")
print("Input exists:", data_path.exists(), data_path)

if data_path.exists():
    df = pd.read_csv(data_path)
    print("Loaded shape:", df.shape)
    print("Columns:", list(df.columns))
    print("Head:")
    print(df.head().to_string())
    print("NaNs per column:")
    print(df.isna().sum().to_string())
    if "RSP" in df.columns:
        rsp = pd.to_numeric(df["RSP"], errors="coerce")
        print("RSP summary:")
        print(rsp.describe().to_string())
        print("Estimated duration seconds at 100 Hz:", len(rsp) / 100.0)

for pkg in ["neurokit2", "scipy", "numpy", "pandas"]:
    spec = importlib.util.find_spec(pkg)
    print(f"Package {pkg}:", "available" if spec is not None else "missing")

Path("pred_results").mkdir(exist_ok=True)
print("Created/verified pred_results/")