#!/usr/bin/env python3
import inspect
import neurokit2 as nk

print("NeuroKit2 version:", getattr(nk, "__version__", "unknown"))
names = [n for n in dir(nk) if n.startswith("rsp")]
print("RSP-related functions:")
for n in names:
    obj = getattr(nk, n)
    if callable(obj):
        try:
            sig = str(inspect.signature(obj))
        except Exception:
            sig = "(signature unavailable)"
        print(n + sig)

for fname in ["rsp_process", "rsp_clean", "rsp_peaks", "rsp_rate", "rsp_rrv", "rsp_analyze"]:
    if hasattr(nk, fname):
        print("\nDOC FIRST LINES:", fname)
        doc = inspect.getdoc(getattr(nk, fname)) or ""
        print("\n".join(doc.splitlines()[:40]))