#!/usr/bin/env python3
from pathlib import Path
import numpy as np
import pandas as pd
import neurokit2 as nk
import warnings

warnings.filterwarnings("ignore")

# Locate input
candidates = [
    Path("biosignals/bio_eventrelated_100hz.csv"),
    Path("benchmark/datasets/biosignals/bio_eventrelated_100hz.csv"),
    Path("/data/lab/sab_data/benchmark_verified/benchmark/datasets/biosignals/bio_eventrelated_100hz.csv"),
]
data_path = next((p for p in candidates if p.exists()), None)
if data_path is None:
    hits = list(Path(".").rglob("bio_eventrelated_100hz.csv"))
    data_path = hits[0] if hits else None
if data_path is None:
    raise FileNotFoundError("Could not locate bio_eventrelated_100hz.csv")

fs = 100
df = pd.read_csv(data_path)
rsp_raw = pd.to_numeric(df["RSP"], errors="coerce").interpolate(limit_direction="both").to_numpy(dtype=float)

print(f"Loaded {data_path} shape={df.shape}, duration={len(rsp_raw)/fs:.2f}s")
print(f"Raw RSP: mean={np.mean(rsp_raw):.6g}, sd={np.std(rsp_raw, ddof=1):.6g}, min={np.min(rsp_raw):.6g}, max={np.max(rsp_raw):.6g}")

# Process respiration using NeuroKit2
signals, info = nk.rsp_process(rsp_raw, sampling_rate=fs, method="khodadad2018")
print("Processed signal columns:", list(signals.columns))
print("Info keys:", list(info.keys()))

# NeuroKit labels peaks as exhalation onsets and troughs as inhalation onsets.
peak_idx = np.where(signals["RSP_Peaks"].to_numpy() == 1)[0]
trough_idx = np.where(signals["RSP_Troughs"].to_numpy() == 1)[0]
clean = signals["RSP_Clean"].to_numpy(dtype=float)
rate = signals["RSP_Rate"].to_numpy(dtype=float)

print(f"Detected exhalation peaks={len(peak_idx)}, inhalation peaks/troughs={len(trough_idx)}")
print("First exhalation peak samples:", peak_idx[:10].tolist())
print("First inhalation peak samples:", trough_idx[:10].tolist())
print(f"Respiratory rate signal: mean={np.nanmean(rate):.6g} bpm, sd={np.nanstd(rate, ddof=1):.6g}, min={np.nanmin(rate):.6g}, max={np.nanmax(rate):.6g}")

# Try NeuroKit's built-in RRV summary
built = None
try:
    built = nk.rsp_rrv(rate, troughs=trough_idx, sampling_rate=fs, show=False, silent=False)
    print("nk.rsp_rrv output:")
    print(built.to_string())
except Exception as e:
    print("nk.rsp_rrv failed:", repr(e))

# Custom RRV feature extraction from inhalation-to-inhalation intervals
inh_times = trough_idx / fs
rri = np.diff(inh_times)  # breath-to-breath intervals, seconds
rri_ms = rri * 1000.0
breath_rate_inst = 60.0 / rri

def safe_float(x):
    try:
        x = float(x)
        return x if np.isfinite(x) else np.nan
    except Exception:
        return np.nan

def sample_entropy(x, m=2, r=None):
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n <= m + 2:
        return np.nan
    if r is None:
        sd = np.std(x, ddof=0)
        if sd == 0:
            return np.nan
        r = 0.2 * sd
    def count(mm):
        c = 0
        for i in range(n - mm):
            template = x[i:i+mm]
            for j in range(i + 1, n - mm + 1):
                if np.max(np.abs(template - x[j:j+mm])) <= r:
                    c += 1
        return c
    b = count(m)
    a = count(m + 1)
    if b == 0 or a == 0:
        return np.nan
    return -np.log(a / b)

def poincare_features(x):
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    if len(x) < 3:
        return np.nan, np.nan, np.nan
    diff = np.diff(x)
    sd1 = np.sqrt(0.5) * np.std(diff, ddof=1)
    sd2_sq = 2 * np.var(x, ddof=1) - 0.5 * np.var(diff, ddof=1)
    sd2 = np.sqrt(sd2_sq) if sd2_sq > 0 else np.nan
    ratio = sd1 / sd2 if np.isfinite(sd2) and sd2 != 0 else np.nan
    return sd1, sd2, ratio

def spectral_features(times, values):
    from scipy.signal import welch
    times = np.asarray(times, dtype=float)
    values = np.asarray(values, dtype=float)
    mask = np.isfinite(times) & np.isfinite(values)
    times, values = times[mask], values[mask]
    if len(values) < 4 or times[-1] <= times[0]:
        return {}
    fs_interp = 4.0
    t_grid = np.arange(times[0], times[-1], 1 / fs_interp)
    if len(t_grid) < 16:
        return {}
    y = np.interp(t_grid, times, values)
    y = y - np.mean(y)
    nperseg = min(256, len(y))
    freqs, psd = welch(y, fs=fs_interp, nperseg=nperseg, detrend="constant")
    def band(lo, hi):
        mask = (freqs >= lo) & (freqs < hi)
        if not np.any(mask):
            return np.nan
        return np.trapz(psd[mask], freqs[mask])
    vlf = band(0.0033, 0.04)
    lf = band(0.04, 0.15)
    hf = band(0.15, 0.40)
    total = band(0.0033, 0.40)
    peak_freq = freqs[np.argmax(psd)] if len(psd) else np.nan
    return {
        "RRV_VLF": vlf,
        "RRV_LF": lf,
        "RRV_HF": hf,
        "RRV_TotalPower": total,
        "RRV_LFHF": lf / hf if np.isfinite(lf) and np.isfinite(hf) and hf != 0 else np.nan,
        "RRV_LFn": lf / (total - vlf) if np.isfinite(lf) and np.isfinite(total) and np.isfinite(vlf) and (total - vlf) != 0 else np.nan,
        "RRV_HFn": hf / (total - vlf) if np.isfinite(hf) and np.isfinite(total) and np.isfinite(vlf) and (total - vlf) != 0 else np.nan,
        "RRV_PeakFrequency": peak_freq,
    }

features = {
    "Sampling_Rate": fs,
    "Duration_s": len(rsp_raw) / fs,
    "RSP_Clean_Mean": np.mean(clean),
    "RSP_Clean_SD": np.std(clean, ddof=1),
    "RSP_Clean_Min": np.min(clean),
    "RSP_Clean_Max": np.max(clean),
    "RSP_Exhalation_Peaks_N": len(peak_idx),
    "RSP_Inhalation_Peaks_N": len(trough_idx),
    "RSP_Rate_Mean": np.nanmean(rate),
    "RSP_Rate_SD": np.nanstd(rate, ddof=1),
    "RSP_Rate_Min": np.nanmin(rate),
    "RSP_Rate_Max": np.nanmax(rate),
    "RRV_Breaths_N": len(rri),
}

if len(rri) > 0:
    features.update({
        "RRV_MeanBB_s": np.mean(rri),
        "RRV_MedianBB_s": np.median(rri),
        "RRV_SDBB_s": np.std(rri, ddof=1) if len(rri) > 1 else np.nan,
        "RRV_RMSSD_s": np.sqrt(np.mean(np.diff(rri) ** 2)) if len(rri) > 1 else np.nan,
        "RRV_SDSD_s": np.std(np.diff(rri), ddof=1) if len(rri) > 2 else np.nan,
        "RRV_CVBB": np.std(rri, ddof=1) / np.mean(rri) if len(rri) > 1 and np.mean(rri) != 0 else np.nan,
        "RRV_MeanRate_bpm": np.mean(breath_rate_inst),
        "RRV_MedianRate_bpm": np.median(breath_rate_inst),
        "RRV_RateSD_bpm": np.std(breath_rate_inst, ddof=1) if len(breath_rate_inst) > 1 else np.nan,
        "RRV_pNN50": np.mean(np.abs(np.diff(rri_ms)) > 50) * 100 if len(rri_ms) > 1 else np.nan,
        "RRV_pNN100": np.mean(np.abs(np.diff(rri_ms)) > 100) * 100 if len(rri_ms) > 1 else np.nan,
        "RRV_pNN200": np.mean(np.abs(np.diff(rri_ms)) > 200) * 100 if len(rri_ms) > 1 else np.nan,
        "RRV_SampEn": sample_entropy(rri),
    })
    sd1, sd2, sd12 = poincare_features(rri)
    features.update({"RRV_SD1_s": sd1, "RRV_SD2_s": sd2, "RRV_SD1SD2": sd12})
    # Associate each interval with its midpoint time for spectral interpolation.
    interval_times = (inh_times[:-1] + inh_times[1:]) / 2.0
    features.update(spectral_features(interval_times, rri))

# Merge built-in NeuroKit RRV features if available
if built is not None and len(built) > 0:
    for col, val in built.iloc[0].items():
        if col not in features:
            features[col] = safe_float(val)

out = pd.DataFrame([{k: safe_float(v) for k, v in features.items()}])
out = out.reindex(sorted(out.columns), axis=1)

Path("pred_results").mkdir(exist_ok=True)
out_path = Path("pred_results/rrv_analysis_pred.csv")
out.to_csv(out_path, index=False)

print(f"Saved {out_path} with shape {out.shape}")
print(out.T.to_string(header=False))