#!/usr/bin/env python3
import os
from pathlib import Path

print("Working directory:", os.getcwd())
print("Top-level directory contents:")
for p in sorted(Path(".").iterdir()):
    print(("DIR " if p.is_dir() else "FILE"), p)

print("\nSearching for bio_eventrelated_100hz.csv under current tree and nearby /data/lab...")
matches = []
for root in [Path("."), Path("/data/lab")]:
    try:
        for p in root.rglob("bio_eventrelated_100hz.csv"):
            matches.append(p)
            print("FOUND:", p)
            if len(matches) >= 20:
                break
    except Exception as e:
        print("Search error in", root, repr(e))
    if len(matches) >= 20:
        break

print("Total matches shown:", len(matches))
if matches:
    import pandas as pd
    path = matches[0]
    df = pd.read_csv(path)
    print("Using first match:", path)
    print("Shape:", df.shape)
    print("Columns:", list(df.columns))
    print(df.head().to_string())