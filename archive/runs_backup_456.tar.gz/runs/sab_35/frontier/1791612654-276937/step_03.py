#!/usr/bin/env python3
import os
import warnings
import numpy as np
import pandas as pd
from scipy import signal, interpolate, stats

warnings.filterwarnings("ignore")


def finite_array(x):
    x = np.asarray(x, dtype=float)
    if np.any(~np.isfinite(x)):
        s = pd.Series(x)
        x = s.interpolate(limit_direction="both").bfill().ffill().to_numpy(float)
    return x


def clean_rsp(rsp, fs):
    """Stable respiration cleaning with SOS bandpass + light smoothing."""
    rsp = finite_array(rsp)
    x = rsp - np.nanmedian(rsp)
    sos = signal.butter(2, [0.01 / (fs / 2), 0.70 / (fs / 2)], btype="bandpass", output="sos")
    y = signal.sosfiltfilt(sos, x)
    win = int(round(0.25 * fs))
    if win % 2 == 0:
        win += 1
    if win >= 5 and win < len(y):
        y = signal.savgol_filter(y, win, 3)
    return y


def detect_rsp_peaks(cleaned, fs):
    """Detect inhalation peaks; adapt threshold if required."""
    y = finite_array(cleaned)
    amp_range = np.percentile(y, 95) - np.percentile(y, 5)
    distance = int(round(1.2 * fs))
    best = np.array([], dtype=int)
    for prom_frac in [0.05, 0.03, 0.02, 0.01, 0.005]:
        prom = max(prom_frac * amp_range, 1e-12)
        peaks, _ = signal.find_peaks(y, distance=distance, prominence=prom)
        if len(peaks) > len(best):
            best = peaks
        if len(peaks) >= 8:
            best = peaks
            break

    # Remove implausibly close/far artefacts conservatively by rebuilding sequence.
    if len(best) >= 3:
        selected = [best[0]]
        for p in best[1:]:
            interval = (p - selected[-1]) / fs
            if interval < 1.0:
                # keep higher of the two peaks
                if y[p] > y[selected[-1]]:
                    selected[-1] = p
            elif interval <= 12.0:
                selected.append(p)
            else:
                selected.append(p)
        best = np.array(selected, dtype=int)
    return best


def respiratory_rate_from_peaks(peaks, duration, fs, out_fs=2.0):
    peak_times = np.asarray(peaks, dtype=float) / fs
    if len(peak_times) < 2:
        return peak_times, np.array([]), np.array([]), np.array([]), np.array([])
    intervals = np.diff(peak_times)
    valid = (intervals >= 1.0) & (intervals <= 12.0)
    rate_times = peak_times[:-1] + intervals / 2
    rates = 60.0 / intervals
    rate_times = rate_times[valid]
    rates = rates[valid]
    intervals = intervals[valid]
    t = np.arange(0, duration, 1 / out_fs)
    if len(rates) >= 2:
        f = interpolate.interp1d(rate_times, rates, bounds_error=False, fill_value=(rates[0], rates[-1]))
        rr_sig = f(t)
    elif len(rates) == 1:
        rr_sig = np.full_like(t, rates[0])
    else:
        rr_sig = np.full_like(t, np.nan)
    return peak_times, intervals, rate_times, rates, np.column_stack([t, rr_sig])


def mean(x):
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    return float(np.mean(x)) if len(x) else np.nan


def sd(x, ddof=1):
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    return float(np.std(x, ddof=ddof)) if len(x) > ddof else np.nan


def sample_entropy(x, m=2):
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n < m + 4 or np.std(x) == 0:
        return np.nan
    r = 0.2 * np.std(x, ddof=0)

    def count(mm):
        c = 0
        for i in range(n - mm):
            xi = x[i:i + mm]
            for j in range(i + 1, n - mm + 1):
                if np.max(np.abs(xi - x[j:j + mm])) <= r:
                    c += 1
        return c

    b = count(m)
    a = count(m + 1)
    return float(-np.log(a / b)) if a > 0 and b > 0 else np.nan


def approximate_entropy(x, m=2):
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n < m + 4 or np.std(x) == 0:
        return np.nan
    r = 0.2 * np.std(x, ddof=0)

    def phi(mm):
        patterns = np.array([x[i:i + mm] for i in range(n - mm + 1)])
        vals = []
        for p in patterns:
            d = np.max(np.abs(patterns - p), axis=1)
            vals.append(np.mean(d <= r))
        vals = np.maximum(vals, 1e-12)
        return np.mean(np.log(vals))
    return float(phi(m) - phi(m + 1))


def dfa_alpha(x):
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n < 16:
        return np.nan
    y = np.cumsum(x - np.mean(x))
    scales = np.unique(np.floor(np.logspace(np.log10(4), np.log10(max(4, n // 4)), 8)).astype(int))
    fs_ = []
    ss_ = []
    for s in scales:
        if s < 4 or n // s < 2:
            continue
        rms = []
        for start in range(0, n - s + 1, s):
            seg = y[start:start + s]
            tt = np.arange(s)
            coef = np.polyfit(tt, seg, 1)
            rms.append(np.sqrt(np.mean((seg - np.polyval(coef, tt)) ** 2)))
        if len(rms) and np.mean(rms) > 0:
            ss_.append(s)
            fs_.append(np.mean(rms))
    if len(fs_) < 2:
        return np.nan
    return float(stats.linregress(np.log(ss_), np.log(fs_)).slope)


def frequency_rrv(rate_times, rates):
    out = {
        "rrv_vlf_power": np.nan,
        "rrv_lf_power": np.nan,
        "rrv_hf_power": np.nan,
        "rrv_total_power": np.nan,
        "rrv_lf_hf_ratio": np.nan,
        "rrv_lf_norm": np.nan,
        "rrv_hf_norm": np.nan,
        "rrv_peak_frequency_hz": np.nan,
        "rrv_peak_frequency_bpm": np.nan,
        "rrv_spectral_entropy": np.nan,
    }
    rate_times = np.asarray(rate_times, float)
    rates = np.asarray(rates, float)
    ok = np.isfinite(rate_times) & np.isfinite(rates)
    rate_times, rates = rate_times[ok], rates[ok]
    if len(rates) < 4 or np.ptp(rate_times) <= 4:
        return out

    fs_i = 2.0
    t = np.arange(rate_times[0], rate_times[-1], 1 / fs_i)
    if len(t) < 8:
        return out
    y = interpolate.interp1d(rate_times, rates, fill_value="extrapolate")(t)
    y = signal.detrend(y)
    nperseg = min(256, len(y))
    freqs, psd = signal.welch(y, fs=fs_i, nperseg=nperseg, noverlap=nperseg // 2)

    def bp(lo, hi):
        idx = (freqs >= lo) & (freqs < hi)
        if idx.sum() == 0:
            return 0.0
        return float(np.trapz(psd[idx], freqs[idx]))

    vlf = bp(0.0033, 0.04)
    lf = bp(0.04, 0.15)
    hf = bp(0.15, 0.40)
    total = bp(0.0033, 0.40)
    idx = (freqs >= 0.0033) & (freqs <= 0.40)
    if idx.any():
        fi, pi = freqs[idx], psd[idx]
        peak_f = float(fi[np.argmax(pi)])
        pp = pi / np.sum(pi) if np.sum(pi) > 0 else np.full_like(pi, np.nan)
        sent = float(-np.nansum(pp * np.log2(pp + 1e-12)) / np.log2(len(pp))) if len(pp) > 1 else np.nan
    else:
        peak_f, sent = np.nan, np.nan

    out.update({
        "rrv_vlf_power": vlf,
        "rrv_lf_power": lf,
        "rrv_hf_power": hf,
        "rrv_total_power": total,
        "rrv_lf_hf_ratio": float(lf / hf) if hf > 0 else np.nan,
        "rrv_lf_norm": float(lf / (lf + hf)) if (lf + hf) > 0 else np.nan,
        "rrv_hf_norm": float(hf / (lf + hf)) if (lf + hf) > 0 else np.nan,
        "rrv_peak_frequency_hz": peak_f,
        "rrv_peak_frequency_bpm": float(peak_f * 60) if np.isfinite(peak_f) else np.nan,
        "rrv_spectral_entropy": sent,
    })
    return out


def main():
    fs = 100.0
    path = "biosignals/bio_eventrelated_100hz.csv"
    df = pd.read_csv(path)
    df.columns = [c.strip() for c in df.columns]
    rsp = finite_array(pd.to_numeric(df["RSP"], errors="coerce").to_numpy(float))
    duration = len(rsp) / fs

    cleaned = clean_rsp(rsp, fs)
    peaks = detect_rsp_peaks(cleaned, fs)
    peak_times, intervals, rate_times, rates, rr_mat = respiratory_rate_from_peaks(peaks, duration, fs, out_fs=2.0)
    rr_signal = rr_mat[:, 1] if len(rr_mat) else np.array([])

    if len(rr_signal) and np.isfinite(rr_signal).any():
        rr_prom = max(0.10 * np.nanstd(rr_signal), 1e-9)
        rr_peaks, _ = signal.find_peaks(rr_signal, distance=int(2.0 * 2.0), prominence=rr_prom)
        rr_peak_values = rr_signal[rr_peaks]
    else:
        rr_peaks = np.array([], dtype=int)
        rr_peak_values = np.array([])

    diffs = np.diff(intervals)
    absdiff = np.abs(diffs)
    interval_sd = sd(intervals)
    diff_sd = sd(diffs)
    sd1 = np.sqrt(0.5) * diff_sd if np.isfinite(diff_sd) else np.nan
    sd2 = np.sqrt(max(0.0, 2 * interval_sd**2 - 0.5 * diff_sd**2)) if np.isfinite(interval_sd) and np.isfinite(diff_sd) else np.nan

    features = {
        "sampling_rate_hz": fs,
        "duration_seconds": duration,
        "rsp_samples": int(len(rsp)),
        "rsp_inhalation_peak_count": int(len(peaks)),
        "rsp_first_inhalation_peak_time_s": float(peak_times[0]) if len(peak_times) else np.nan,
        "rsp_last_inhalation_peak_time_s": float(peak_times[-1]) if len(peak_times) else np.nan,
        "rsp_cleaned_mean": mean(cleaned),
        "rsp_cleaned_sd": sd(cleaned),
        "rsp_cleaned_peak_mean_amplitude": mean(cleaned[peaks]) if len(peaks) else np.nan,
        "rsp_cleaned_peak_sd_amplitude": sd(cleaned[peaks]) if len(peaks) else np.nan,
        "respiratory_rate_signal_mean_bpm": mean(rr_signal),
        "respiratory_rate_signal_sd_bpm": sd(rr_signal),
        "respiratory_rate_signal_min_bpm": float(np.nanmin(rr_signal)) if len(rr_signal) and np.isfinite(rr_signal).any() else np.nan,
        "respiratory_rate_signal_max_bpm": float(np.nanmax(rr_signal)) if len(rr_signal) and np.isfinite(rr_signal).any() else np.nan,
        "respiratory_rate_peak_count": int(len(rr_peaks)),
        "respiratory_rate_peak_mean_bpm": mean(rr_peak_values),
        "respiratory_rate_peak_sd_bpm": sd(rr_peak_values),
        "rrv_breath_interval_count": int(len(intervals)),
        "rrv_mean_breath_interval_s": mean(intervals),
        "rrv_median_breath_interval_s": float(np.median(intervals)) if len(intervals) else np.nan,
        "rrv_sd_breath_interval_s": sd(intervals),
        "rrv_min_breath_interval_s": float(np.min(intervals)) if len(intervals) else np.nan,
        "rrv_max_breath_interval_s": float(np.max(intervals)) if len(intervals) else np.nan,
        "rrv_range_breath_interval_s": float(np.ptp(intervals)) if len(intervals) else np.nan,
        "rrv_cv_breath_interval": float(sd(intervals) / mean(intervals)) if len(intervals) and mean(intervals) != 0 else np.nan,
        "rrv_rmssd_s": float(np.sqrt(np.mean(diffs**2))) if len(diffs) else np.nan,
        "rrv_sdsd_s": sd(diffs),
        "rrv_mad_breath_interval_s": float(stats.median_abs_deviation(intervals)) if len(intervals) else np.nan,
        "rrv_pnn50": float(np.mean(absdiff > 0.05)) if len(absdiff) else np.nan,
        "rrv_pnn250": float(np.mean(absdiff > 0.25)) if len(absdiff) else np.nan,
        "rrv_pnn500": float(np.mean(absdiff > 0.50)) if len(absdiff) else np.nan,
        "rrv_mean_rate_bpm": mean(rates),
        "rrv_median_rate_bpm": float(np.median(rates)) if len(rates) else np.nan,
        "rrv_sd_rate_bpm": sd(rates),
        "rrv_cv_rate": float(sd(rates) / mean(rates)) if len(rates) and mean(rates) != 0 else np.nan,
        "rrv_poincare_sd1_s": float(sd1) if np.isfinite(sd1) else np.nan,
        "rrv_poincare_sd2_s": float(sd2) if np.isfinite(sd2) else np.nan,
        "rrv_poincare_sd1_sd2_ratio": float(sd1 / sd2) if np.isfinite(sd1) and np.isfinite(sd2) and sd2 != 0 else np.nan,
        "rrv_sample_entropy": sample_entropy(intervals),
        "rrv_approximate_entropy": approximate_entropy(intervals),
        "rrv_dfa_alpha": dfa_alpha(intervals),
        "rrv_skewness_breath_interval": float(stats.skew(intervals, bias=False)) if len(intervals) >= 3 else np.nan,
        "rrv_kurtosis_breath_interval": float(stats.kurtosis(intervals, bias=False)) if len(intervals) >= 4 else np.nan,
    }
    features.update(frequency_rrv(rate_times, rates))

    os.makedirs("pred_results", exist_ok=True)
    out_path = "pred_results/rrv_analysis_pred.csv"
    result = pd.DataFrame([features])
    result.to_csv(out_path, index=False)

    print(f"Saved: {out_path}")
    print("shape", result.shape)
    print(result[[
        "duration_seconds", "rsp_inhalation_peak_count", "rrv_breath_interval_count",
        "rrv_mean_rate_bpm", "rrv_sd_rate_bpm", "rrv_rmssd_s",
        "respiratory_rate_peak_count", "rrv_lf_power", "rrv_hf_power",
        "rrv_sample_entropy"
    ]].to_string(index=False))
    print("first_10_inhalation_peak_times_s", np.round(peak_times[:10], 3).tolist())
    print("first_10_breath_intervals_s", np.round(intervals[:10], 3).tolist())


if __name__ == "__main__":
    main()