#!/usr/bin/env python3
import os
import numpy as np
import pandas as pd
from scipy import signal

path = "biosignals/bio_eventrelated_100hz.csv"
fs = 100.0
df = pd.read_csv(path)
df.columns = [c.strip() for c in df.columns]
rsp = pd.to_numeric(df["RSP"], errors="coerce").interpolate(limit_direction="both").to_numpy(float)
print("n", len(rsp), "duration", len(rsp)/fs)
print("raw finite", np.isfinite(rsp).sum(), "min", np.nanmin(rsp), "max", np.nanmax(rsp), "mean", np.nanmean(rsp), "sd", np.nanstd(rsp))
print("raw percentiles", np.nanpercentile(rsp, [0,1,5,25,50,75,95,99,100]))

# Try several cleaning options and peak detection thresholds.
x = rsp - np.nanmedian(rsp)
for low, high in [(0.01, 1.0), (0.03, 1.0), (0.05, 1.0), (0.01, 0.7), (0.02, 0.5)]:
    b, a = signal.butter(2, [low/(fs/2), high/(fs/2)], btype="bandpass")
    y = signal.filtfilt(b, a, x)
    print("\nfilter", low, high, "min max sd", np.min(y), np.max(y), np.std(y), "pct", np.percentile(y, [1,5,50,95,99]))
    for dist_s in [1.0, 1.5, 2.0]:
        for prom_frac in [0.02, 0.05, 0.1, 0.2]:
            prom = prom_frac * (np.percentile(y, 95) - np.percentile(y, 5))
            peaks, props = signal.find_peaks(y, distance=int(dist_s*fs), prominence=prom)
            if len(peaks) > 0:
                intervals = np.diff(peaks/fs)
                plausible = intervals[(intervals >= 1) & (intervals <= 12)]
                mean_rate = 60/np.mean(plausible) if len(plausible) else np.nan
            else:
                intervals = []
                mean_rate = np.nan
            print(f"dist={dist_s:.1f} prom_frac={prom_frac:.2f} peaks={len(peaks)} mean_rate={mean_rate}")
        print("---")

# Check inverse too
b, a = signal.butter(2, [0.01/(fs/2), 0.7/(fs/2)], btype="bandpass")
y = signal.filtfilt(b, a, x)
for sign in [1, -1]:
    yy = sign*y
    prom = 0.05*(np.percentile(yy,95)-np.percentile(yy,5))
    peaks, props = signal.find_peaks(yy, distance=int(1.2*fs), prominence=prom)
    print("sign", sign, "peaks", len(peaks), "first 20 times", np.round(peaks[:20]/fs, 2), "first amps", np.round(yy[peaks[:10]], 4))
    if len(peaks)>1:
        print("interval pct", np.percentile(np.diff(peaks/fs), [0,5,25,50,75,95,100]), "mean bpm", 60/np.mean(np.diff(peaks/fs)))