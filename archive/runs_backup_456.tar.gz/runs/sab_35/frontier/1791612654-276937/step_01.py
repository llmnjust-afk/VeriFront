#!/usr/bin/env python3
import os
import warnings
import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

from scipy import signal, interpolate, stats


def read_rsp(path):
    df = pd.read_csv(path)
    df.columns = [c.strip() for c in df.columns]
    if "RSP" not in df.columns:
        raise ValueError(f"RSP column not found. Columns: {df.columns.tolist()}")
    rsp = pd.to_numeric(df["RSP"], errors="coerce").to_numpy(dtype=float)
    # Fill missing values by linear interpolation.
    if np.any(~np.isfinite(rsp)):
        s = pd.Series(rsp)
        rsp = s.interpolate(limit_direction="both").to_numpy(dtype=float)
    return rsp, df


def robust_bandpass(x, fs, low=0.05, high=1.0, order=4):
    """Clean respiration with a physiologically plausible bandpass."""
    x = np.asarray(x, dtype=float)
    x = x - np.nanmedian(x)
    nyq = fs / 2.0
    low = max(low, 0.001)
    high = min(high, nyq * 0.95)
    b, a = signal.butter(order, [low / nyq, high / nyq], btype="bandpass")
    # padlen guard for short signals
    if len(x) > max(len(a), len(b)) * 6:
        y = signal.filtfilt(b, a, x)
    else:
        y = signal.lfilter(b, a, x)
    return y


def detect_inhalation_peaks(cleaned_rsp, fs):
    """Detect inhalation peaks in the cleaned RSP waveform."""
    x = np.asarray(cleaned_rsp, dtype=float)
    # Smooth slightly to prevent high-frequency peak fragmentation.
    win = int(round(0.25 * fs))
    if win % 2 == 0:
        win += 1
    if win >= 5 and len(x) > win:
        xs = signal.savgol_filter(x, window_length=win, polyorder=3)
    else:
        xs = x.copy()

    # Estimate robust amplitude scale.
    mad = np.median(np.abs(xs - np.median(xs)))
    robust_sd = 1.4826 * mad if mad > 0 else np.std(xs)
    prom = max(0.15 * robust_sd, 0.03 * (np.percentile(xs, 95) - np.percentile(xs, 5)))

    # Respiratory peaks: normally no closer than ~1.2 s (50 breaths/min).
    distance = int(round(1.2 * fs))
    peaks, props = signal.find_peaks(xs, distance=distance, prominence=prom)

    # If too few peaks, relax prominence.
    if len(peaks) < 5:
        peaks, props = signal.find_peaks(xs, distance=distance, prominence=max(prom * 0.33, 1e-12))

    # Keep peaks that imply plausible neighbouring breath intervals where possible.
    if len(peaks) >= 3:
        t = peaks / fs
        intervals = np.diff(t)
        plausible = (intervals >= 1.0) & (intervals <= 12.0)
        keep = np.ones(len(peaks), dtype=bool)
        # A peak is retained if either interval adjacent to it is plausible.
        for i in range(len(peaks)):
            left = plausible[i - 1] if i - 1 >= 0 and i - 1 < len(plausible) else False
            right = plausible[i] if i < len(plausible) else False
            keep[i] = left or right
        if keep.sum() >= 5:
            peaks = peaks[keep]

    return peaks, xs


def interp_rate_signal(peak_times, duration, fs):
    """Create a continuous respiratory-rate signal from inhalation peak intervals."""
    if len(peak_times) < 2:
        t_grid = np.arange(0, duration, 1 / fs)
        return t_grid, np.full_like(t_grid, np.nan, dtype=float), np.array([]), np.array([])

    intervals = np.diff(peak_times)
    rate_bpm = 60.0 / intervals
    # Rate estimate belongs between adjacent inhalation peaks.
    rate_times = peak_times[:-1] + intervals / 2.0

    valid = np.isfinite(rate_bpm) & (rate_bpm >= 3) & (rate_bpm <= 60)
    rate_times = rate_times[valid]
    rate_bpm = rate_bpm[valid]

    t_grid = np.arange(0, duration, 1 / fs)
    if len(rate_times) >= 2:
        f = interpolate.interp1d(
            rate_times,
            rate_bpm,
            kind="linear",
            bounds_error=False,
            fill_value=(rate_bpm[0], rate_bpm[-1]),
        )
        rr_signal = f(t_grid)
    elif len(rate_times) == 1:
        rr_signal = np.full_like(t_grid, rate_bpm[0], dtype=float)
    else:
        rr_signal = np.full_like(t_grid, np.nan, dtype=float)

    return t_grid, rr_signal, rate_times, rate_bpm


def safe_mean(x):
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    return float(np.mean(x)) if len(x) else np.nan


def safe_std(x, ddof=1):
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    return float(np.std(x, ddof=ddof)) if len(x) > ddof else np.nan


def sample_entropy(x, m=2, r=None):
    """Simple SampEn implementation for short one-dimensional RRV series."""
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n <= m + 2:
        return np.nan
    if r is None:
        sd = np.std(x, ddof=0)
        if sd == 0:
            return np.nan
        r = 0.2 * sd

    def _count(mm):
        count = 0
        total = 0
        for i in range(n - mm):
            template = x[i : i + mm]
            for j in range(i + 1, n - mm + 1):
                total += 1
                if np.max(np.abs(template - x[j : j + mm])) <= r:
                    count += 1
        return count, total

    b, _ = _count(m)
    a, _ = _count(m + 1)
    if b == 0 or a == 0:
        return np.nan
    return float(-np.log(a / b))


def approximate_entropy(x, m=2, r=None):
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n <= m + 2:
        return np.nan
    if r is None:
        sd = np.std(x, ddof=0)
        if sd == 0:
            return np.nan
        r = 0.2 * sd

    def _phi(mm):
        patterns = np.array([x[i : i + mm] for i in range(n - mm + 1)])
        c = []
        for p in patterns:
            dist = np.max(np.abs(patterns - p), axis=1)
            c.append(np.mean(dist <= r))
        c = np.array(c)
        c = c[c > 0]
        if len(c) == 0:
            return np.nan
        return np.mean(np.log(c))

    phi_m = _phi(m)
    phi_m1 = _phi(m + 1)
    if not np.isfinite(phi_m) or not np.isfinite(phi_m1):
        return np.nan
    return float(phi_m - phi_m1)


def dfa_alpha(x):
    """Detrended fluctuation analysis alpha over feasible scales."""
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n < 16:
        return np.nan
    y = np.cumsum(x - np.mean(x))
    scales = np.unique(np.floor(np.logspace(np.log10(4), np.log10(max(5, n // 4)), 8)).astype(int))
    flucts = []
    used_scales = []
    for s in scales:
        if s < 4 or n // s < 2:
            continue
        rms = []
        for start in range(0, n - s + 1, s):
            seg = y[start : start + s]
            t = np.arange(s)
            coef = np.polyfit(t, seg, 1)
            trend = np.polyval(coef, t)
            rms.append(np.sqrt(np.mean((seg - trend) ** 2)))
        if len(rms) and np.mean(rms) > 0:
            flucts.append(np.mean(rms))
            used_scales.append(s)
    if len(flucts) < 2:
        return np.nan
    slope, _, _, _, _ = stats.linregress(np.log(used_scales), np.log(flucts))
    return float(slope)


def frequency_features(rate_times, rate_bpm):
    """Welch PSD features from evenly sampled breath-to-breath respiratory-rate series."""
    out = {
        "rrv_vlf_power": np.nan,
        "rrv_lf_power": np.nan,
        "rrv_hf_power": np.nan,
        "rrv_total_power": np.nan,
        "rrv_lf_hf_ratio": np.nan,
        "rrv_lf_norm": np.nan,
        "rrv_hf_norm": np.nan,
        "rrv_peak_frequency_hz": np.nan,
        "rrv_peak_frequency_bpm": np.nan,
        "rrv_spectral_entropy": np.nan,
    }
    rate_times = np.asarray(rate_times, dtype=float)
    rate_bpm = np.asarray(rate_bpm, dtype=float)
    ok = np.isfinite(rate_times) & np.isfinite(rate_bpm)
    rate_times = rate_times[ok]
    rate_bpm = rate_bpm[ok]
    if len(rate_bpm) < 4 or np.ptp(rate_times) <= 0:
        return out

    # Interpolate breath-to-breath rate at 2 Hz, adequate for variability bands up to 0.4 Hz.
    fs_i = 2.0
    t_even = np.arange(rate_times[0], rate_times[-1], 1 / fs_i)
    if len(t_even) < 8:
        return out
    f_interp = interpolate.interp1d(rate_times, rate_bpm, kind="linear", fill_value="extrapolate")
    y = f_interp(t_even)
    y = signal.detrend(y)

    nperseg = min(256, len(y))
    if nperseg < 8:
        return out
    freqs, psd = signal.welch(y, fs=fs_i, nperseg=nperseg, noverlap=nperseg // 2)
    if len(freqs) < 2:
        return out

    def band_power(lo, hi):
        idx = (freqs >= lo) & (freqs < hi)
        if idx.sum() < 1:
            return 0.0
        return float(np.trapz(psd[idx], freqs[idx]))

    vlf = band_power(0.0033, 0.04)
    lf = band_power(0.04, 0.15)
    hf = band_power(0.15, 0.40)
    total = band_power(0.0033, 0.40)
    idx_total = (freqs >= 0.0033) & (freqs <= 0.40)
    if idx_total.any():
        peak_f = float(freqs[idx_total][np.argmax(psd[idx_total])])
        p = psd[idx_total].astype(float)
        psum = p.sum()
        sent = float(-(p / psum * np.log2((p / psum) + 1e-12)).sum() / np.log2(len(p))) if psum > 0 and len(p) > 1 else np.nan
    else:
        peak_f, sent = np.nan, np.nan

    out.update({
        "rrv_vlf_power": vlf,
        "rrv_lf_power": lf,
        "rrv_hf_power": hf,
        "rrv_total_power": total,
        "rrv_lf_hf_ratio": float(lf / hf) if hf > 0 else np.nan,
        "rrv_lf_norm": float(lf / (lf + hf)) if (lf + hf) > 0 else np.nan,
        "rrv_hf_norm": float(hf / (lf + hf)) if (lf + hf) > 0 else np.nan,
        "rrv_peak_frequency_hz": peak_f,
        "rrv_peak_frequency_bpm": float(peak_f * 60) if np.isfinite(peak_f) else np.nan,
        "rrv_spectral_entropy": sent,
    })
    return out


def compute_rrv(path="biosignals/bio_eventrelated_100hz.csv", fs=100.0):
    rsp, df = read_rsp(path)
    duration = len(rsp) / fs
    cleaned = robust_bandpass(rsp, fs)
    peaks, smoothed = detect_inhalation_peaks(cleaned, fs)
    peak_times = peaks / fs

    t_grid, rr_signal, rate_times, rate_bpm = interp_rate_signal(peak_times, duration, fs)

    # Extract peaks of the respiratory-rate signal.
    if np.isfinite(rr_signal).sum() > int(fs * 5):
        rr_for_peaks = rr_signal.copy()
        rr_for_peaks[~np.isfinite(rr_for_peaks)] = np.nanmedian(rr_for_peaks)
        rr_prom = max(0.1 * np.nanstd(rr_for_peaks), 1e-9)
        rr_peaks, _ = signal.find_peaks(rr_for_peaks, distance=int(2.0 * fs), prominence=rr_prom)
        rr_peak_times = rr_peaks / fs
        rr_peak_values = rr_signal[rr_peaks]
    else:
        rr_peaks = np.array([], dtype=int)
        rr_peak_times = np.array([])
        rr_peak_values = np.array([])

    intervals = np.diff(peak_times)
    valid_intervals = intervals[(intervals >= 1.0) & (intervals <= 12.0)]
    if len(valid_intervals) >= max(3, int(0.5 * len(intervals))):
        intervals = valid_intervals
    rate_from_intervals = 60.0 / intervals if len(intervals) else np.array([])

    diff_intervals = np.diff(intervals)
    abs_diff = np.abs(diff_intervals)

    # Poincare features on breath intervals.
    if len(diff_intervals) >= 1:
        sd1 = np.sqrt(0.5) * safe_std(diff_intervals, ddof=1)
        sdnn = safe_std(intervals, ddof=1)
        sd2_val = np.sqrt(max(0.0, 2 * sdnn * sdnn - 0.5 * safe_std(diff_intervals, ddof=1) ** 2)) if np.isfinite(sdnn) else np.nan
    else:
        sd1, sd2_val = np.nan, np.nan

    features = {
        "sampling_rate_hz": fs,
        "duration_seconds": duration,
        "rsp_samples": len(rsp),

        # Extracted inhalation peaks from cleaned RSP.
        "rsp_inhalation_peak_count": int(len(peaks)),
        "rsp_first_inhalation_peak_time_s": float(peak_times[0]) if len(peak_times) else np.nan,
        "rsp_last_inhalation_peak_time_s": float(peak_times[-1]) if len(peak_times) else np.nan,
        "rsp_cleaned_mean": safe_mean(cleaned),
        "rsp_cleaned_sd": safe_std(cleaned, ddof=1),
        "rsp_cleaned_peak_mean_amplitude": safe_mean(cleaned[peaks]) if len(peaks) else np.nan,
        "rsp_cleaned_peak_sd_amplitude": safe_std(cleaned[peaks], ddof=1) if len(peaks) else np.nan,

        # Respiratory-rate signal and its peaks.
        "respiratory_rate_signal_mean_bpm": safe_mean(rr_signal),
        "respiratory_rate_signal_sd_bpm": safe_std(rr_signal, ddof=1),
        "respiratory_rate_signal_min_bpm": float(np.nanmin(rr_signal)) if np.isfinite(rr_signal).any() else np.nan,
        "respiratory_rate_signal_max_bpm": float(np.nanmax(rr_signal)) if np.isfinite(rr_signal).any() else np.nan,
        "respiratory_rate_peak_count": int(len(rr_peaks)),
        "respiratory_rate_peak_mean_bpm": safe_mean(rr_peak_values),
        "respiratory_rate_peak_sd_bpm": safe_std(rr_peak_values, ddof=1),

        # Time-domain RRV from breath-to-breath intervals.
        "rrv_breath_interval_count": int(len(intervals)),
        "rrv_mean_breath_interval_s": safe_mean(intervals),
        "rrv_median_breath_interval_s": float(np.nanmedian(intervals)) if len(intervals) else np.nan,
        "rrv_sd_breath_interval_s": safe_std(intervals, ddof=1),
        "rrv_min_breath_interval_s": float(np.nanmin(intervals)) if len(intervals) else np.nan,
        "rrv_max_breath_interval_s": float(np.nanmax(intervals)) if len(intervals) else np.nan,
        "rrv_range_breath_interval_s": float(np.nanmax(intervals) - np.nanmin(intervals)) if len(intervals) else np.nan,
        "rrv_cv_breath_interval": float(safe_std(intervals, ddof=1) / safe_mean(intervals)) if len(intervals) and safe_mean(intervals) != 0 else np.nan,
        "rrv_rmssd_s": float(np.sqrt(np.mean(diff_intervals ** 2))) if len(diff_intervals) else np.nan,
        "rrv_sdsd_s": safe_std(diff_intervals, ddof=1),
        "rrv_mad_breath_interval_s": float(stats.median_abs_deviation(intervals, nan_policy="omit")) if len(intervals) else np.nan,
        "rrv_pnn50": float(np.mean(abs_diff > 0.05)) if len(abs_diff) else np.nan,
        "rrv_pnn250": float(np.mean(abs_diff > 0.25)) if len(abs_diff) else np.nan,
        "rrv_pnn500": float(np.mean(abs_diff > 0.50)) if len(abs_diff) else np.nan,
        "rrv_mean_rate_bpm": safe_mean(rate_from_intervals),
        "rrv_median_rate_bpm": float(np.nanmedian(rate_from_intervals)) if len(rate_from_intervals) else np.nan,
        "rrv_sd_rate_bpm": safe_std(rate_from_intervals, ddof=1),
        "rrv_cv_rate": float(safe_std(rate_from_intervals, ddof=1) / safe_mean(rate_from_intervals)) if len(rate_from_intervals) and safe_mean(rate_from_intervals) != 0 else np.nan,

        # Nonlinear RRV.
        "rrv_poincare_sd1_s": float(sd1) if np.isfinite(sd1) else np.nan,
        "rrv_poincare_sd2_s": float(sd2_val) if np.isfinite(sd2_val) else np.nan,
        "rrv_poincare_sd1_sd2_ratio": float(sd1 / sd2_val) if np.isfinite(sd1) and np.isfinite(sd2_val) and sd2_val != 0 else np.nan,
        "rrv_sample_entropy": sample_entropy(intervals, m=2),
        "rrv_approximate_entropy": approximate_entropy(intervals, m=2),
        "rrv_dfa_alpha": dfa_alpha(intervals),
        "rrv_skewness_breath_interval": float(stats.skew(intervals, bias=False)) if len(intervals) >= 3 else np.nan,
        "rrv_kurtosis_breath_interval": float(stats.kurtosis(intervals, bias=False)) if len(intervals) >= 4 else np.nan,
    }

    features.update(frequency_features(rate_times, rate_bpm))

    return features


def main():
    out_dir = "pred_results"
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "rrv_analysis_pred.csv")

    features = compute_rrv("biosignals/bio_eventrelated_100hz.csv", fs=100.0)
    result = pd.DataFrame([features])
    # Stable column order: as inserted.
    result.to_csv(out_path, index=False)

    print(f"Saved RRV analysis to: {out_path}")
    print(f"Shape: {result.shape}")
    print("Key extracted values:")
    key_cols = [
        "duration_seconds",
        "rsp_inhalation_peak_count",
        "respiratory_rate_peak_count",
        "rrv_breath_interval_count",
        "rrv_mean_rate_bpm",
        "rrv_sd_rate_bpm",
        "rrv_rmssd_s",
        "rrv_lf_power",
        "rrv_hf_power",
        "rrv_sample_entropy",
    ]
    print(result[key_cols].to_string(index=False))
    print("All columns:")
    print(", ".join(result.columns))


if __name__ == "__main__":
    main()