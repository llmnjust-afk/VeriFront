#!/usr/bin/env python3
"""
Locate the provided biosignal CSV files, then run RRV analysis if the target file
can be found under the working directory or nearby mounted paths.
"""

import os
import json
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import signal, interpolate, stats

warnings.filterwarnings("ignore", category=RuntimeWarning)

TARGET_NAME = "bio_eventrelated_100hz.csv"
OUTDIR = "pred_results"
OUTFILE = os.path.join(OUTDIR, "rrv_analysis_pred.csv")
FS = 100.0


def find_input_file():
    """Search common locations for bio_eventrelated_100hz.csv."""
    candidates = [
        Path("biosignals") / TARGET_NAME,
        Path(TARGET_NAME),
        Path("/data") / "biosignals" / TARGET_NAME,
        Path("/data/lab") / "biosignals" / TARGET_NAME,
        Path("/mnt/data") / "biosignals" / TARGET_NAME,
    ]
    for p in candidates:
        if p.exists():
            return p

    print("Target not found at standard paths. Listing nearby CSV files:")
    search_roots = [Path("."), Path(".."), Path("/data/lab/VeriFront")]
    seen = set()
    matches = []
    for root in search_roots:
        if not root.exists():
            continue
        try:
            for p in root.rglob("*.csv"):
                sp = str(p.resolve())
                if sp in seen:
                    continue
                seen.add(sp)
                matches.append(p)
                if p.name == TARGET_NAME:
                    return p
                if len(matches) <= 50:
                    print("  CSV:", p)
        except Exception as e:
            print(f"Could not fully search {root}: {e}")
    print(f"Total CSV files seen (limited listing shown): {len(matches)}")
    raise FileNotFoundError(f"Could not locate {TARGET_NAME}")


def as_float_array(x):
    x = pd.to_numeric(pd.Series(x), errors="coerce").astype(float)
    if x.isna().any():
        x = x.interpolate(limit_direction="both").ffill().bfill()
    return x.to_numpy(dtype=float)


def bandpass_clean_rsp(rsp, fs=100.0, low=0.05, high=1.0, order=4):
    x = np.asarray(rsp, dtype=float)
    x = signal.detrend(x, type="linear")
    nyq = fs / 2.0
    b, a = signal.butter(order, [low / nyq, high / nyq], btype="bandpass")
    try:
        return signal.filtfilt(b, a, x)
    except Exception:
        return signal.lfilter(b, a, x)


def robust_peak_detection(clean, fs=100.0):
    x = np.asarray(clean, dtype=float)
    robust_sd = 1.4826 * np.nanmedian(np.abs(x - np.nanmedian(x)))
    if not np.isfinite(robust_sd) or robust_sd <= 0:
        robust_sd = np.nanstd(x)
    if not np.isfinite(robust_sd) or robust_sd <= 0:
        robust_sd = 1.0
    min_distance = int(round(1.5 * fs))
    best_peaks, best_props = np.array([], dtype=int), {}
    for prom_factor in [0.35, 0.25, 0.15, 0.08, 0.04]:
        peaks, props = signal.find_peaks(x, distance=min_distance, prominence=prom_factor * robust_sd)
        if len(peaks) > len(best_peaks):
            best_peaks, best_props = peaks, props
        if len(peaks) >= 4:
            return peaks.astype(int), props
    if len(best_peaks) < 3:
        peaks, props = signal.find_peaks(x, distance=min_distance)
        if len(peaks) > len(best_peaks):
            best_peaks, best_props = peaks, props
    return best_peaks.astype(int), best_props


def remove_implausible_intervals(peaks, fs=100.0, min_period=1.5, max_period=15.0):
    peaks = np.asarray(peaks, dtype=int)
    if len(peaks) < 3:
        return peaks
    keep = np.ones(len(peaks), dtype=bool)
    intervals = np.diff(peaks) / fs
    for i, interval in enumerate(intervals):
        if interval < min_period and i + 1 < len(keep):
            keep[i + 1] = False
    peaks2 = peaks[keep]
    return peaks2 if len(peaks2) >= 3 else peaks


def compute_resp_rate_signal(peaks, n_samples, fs=100.0):
    rate = np.full(n_samples, np.nan, dtype=float)
    peaks = np.asarray(peaks, dtype=int)
    if len(peaks) < 2:
        return rate
    intervals_s = np.diff(peaks) / fs
    inst_rate = 60.0 / intervals_s
    mid_t = (peaks[:-1] + peaks[1:]) / (2.0 * fs)
    all_t = np.arange(n_samples) / fs
    valid = np.isfinite(inst_rate) & (inst_rate > 0) & (inst_rate < 60)
    if np.sum(valid) == 0:
        return rate
    if np.sum(valid) == 1:
        rate[:] = inst_rate[valid][0]
        return rate
    f = interpolate.interp1d(
        mid_t[valid], inst_rate[valid], kind="linear",
        bounds_error=False, fill_value=(inst_rate[valid][0], inst_rate[valid][-1])
    )
    return f(all_t)


def safe_stat_features(prefix, values):
    v = np.asarray(values, dtype=float)
    v = v[np.isfinite(v)]
    names = ["Mean", "Median", "SD", "Min", "Max", "Range", "IQR", "CV", "Skew", "Kurtosis"]
    if len(v) == 0:
        return {f"{prefix}_{name}": np.nan for name in names}
    sd = float(np.std(v, ddof=1)) if len(v) > 1 else 0.0
    mean = float(np.mean(v))
    return {
        f"{prefix}_Mean": mean,
        f"{prefix}_Median": float(np.median(v)),
        f"{prefix}_SD": sd,
        f"{prefix}_Min": float(np.min(v)),
        f"{prefix}_Max": float(np.max(v)),
        f"{prefix}_Range": float(np.max(v) - np.min(v)),
        f"{prefix}_IQR": float(np.percentile(v, 75) - np.percentile(v, 25)),
        f"{prefix}_CV": float(sd / mean) if mean != 0 else np.nan,
        f"{prefix}_Skew": float(stats.skew(v, bias=False)) if len(v) > 2 else np.nan,
        f"{prefix}_Kurtosis": float(stats.kurtosis(v, bias=False)) if len(v) > 3 else np.nan,
    }


def sample_entropy(x, m=2, r=None):
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n <= m + 2:
        return np.nan
    if r is None:
        sd = np.std(x, ddof=0)
        if sd == 0 or not np.isfinite(sd):
            return np.nan
        r = 0.2 * sd

    def count(mm):
        c = 0
        for i in range(n - mm):
            template = x[i:i + mm]
            for j in range(i + 1, n - mm + 1):
                if np.max(np.abs(template - x[j:j + mm])) <= r:
                    c += 1
        return c

    b = count(m)
    a = count(m + 1)
    return float(-np.log(a / b)) if a > 0 and b > 0 else np.nan


def approximate_entropy(x, m=2, r=None):
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n <= m + 2:
        return np.nan
    if r is None:
        sd = np.std(x, ddof=0)
        if sd == 0 or not np.isfinite(sd):
            return np.nan
        r = 0.2 * sd

    def phi(mm):
        patterns = np.array([x[i:i + mm] for i in range(n - mm + 1)])
        vals = []
        for p in patterns:
            d = np.max(np.abs(patterns - p), axis=1)
            vals.append(np.mean(d <= r))
        vals = np.asarray(vals)
        vals = vals[vals > 0]
        return np.mean(np.log(vals)) if len(vals) else np.nan

    p1, p2 = phi(m), phi(m + 1)
    return float(p1 - p2) if np.isfinite(p1) and np.isfinite(p2) else np.nan


def dfa_alpha(x):
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n < 12:
        return np.nan
    y = np.cumsum(x - np.mean(x))
    scales = np.unique(np.floor(np.logspace(np.log10(4), np.log10(max(5, n // 4)), 8)).astype(int))
    used, flucts = [], []
    for s in scales:
        if s < 4 or 2 * s > n:
            continue
        segments = n // s
        rms = []
        for k in range(segments):
            seg = y[k * s:(k + 1) * s]
            t = np.arange(s)
            coef = np.polyfit(t, seg, 1)
            rms.append(np.sqrt(np.mean((seg - np.polyval(coef, t)) ** 2)))
        f = np.sqrt(np.mean(np.asarray(rms) ** 2))
        if np.isfinite(f) and f > 0:
            used.append(s)
            flucts.append(f)
    return float(np.polyfit(np.log(used), np.log(flucts), 1)[0]) if len(flucts) >= 2 else np.nan


def compute_cycle_amplitudes(clean, peaks, fs=100.0):
    x = np.asarray(clean, dtype=float)
    troughs, _ = signal.find_peaks(-x, distance=int(1.0 * fs))
    amps = []
    for p in np.asarray(peaks, dtype=int):
        prev = troughs[troughs < p]
        if len(prev):
            amps.append(x[p] - x[prev[-1]])
    return np.asarray(amps, dtype=float)


def frequency_domain_features(intervals_s, peak_times_s):
    out = {}
    bands = {"VLF": (0.0033, 0.04), "LF": (0.04, 0.15), "HF": (0.15, 0.40), "Total": (0.0033, 0.40)}
    for band in bands:
        out[f"RRV_Frequency_{band}_Power"] = np.nan
    out.update({
        "RRV_Frequency_LFHF_Ratio": np.nan,
        "RRV_Frequency_LF_Norm": np.nan,
        "RRV_Frequency_HF_Norm": np.nan,
        "RRV_Frequency_Peak": np.nan,
    })
    intervals_s = np.asarray(intervals_s, dtype=float)
    peak_times_s = np.asarray(peak_times_s, dtype=float)
    if len(intervals_s) < 4 or len(peak_times_s) < 5:
        return out
    t = (peak_times_s[:-1] + peak_times_s[1:]) / 2.0
    if len(t) != len(intervals_s):
        n = min(len(t), len(intervals_s))
        t, intervals_s = t[:n], intervals_s[:n]
    valid = np.isfinite(t) & np.isfinite(intervals_s) & (intervals_s > 0)
    t, y = t[valid], intervals_s[valid]
    if len(y) < 4 or np.ptp(t) <= 10:
        return out
    fs_i = 4.0
    ti = np.arange(t[0], t[-1], 1.0 / fs_i)
    if len(ti) < 16:
        return out
    yi = interpolate.interp1d(t, y, kind="linear", bounds_error=False, fill_value="extrapolate")(ti)
    yi = signal.detrend(yi)
    if np.std(yi) == 0:
        return out
    nperseg = min(256, len(yi))
    freqs, psd = signal.welch(yi, fs=fs_i, nperseg=nperseg, noverlap=nperseg // 2)
    for band, (lo, hi) in bands.items():
        mask = (freqs >= lo) & (freqs < hi)
        if np.any(mask):
            out[f"RRV_Frequency_{band}_Power"] = float(np.trapz(psd[mask], freqs[mask]))
    lf, hf, total = out["RRV_Frequency_LF_Power"], out["RRV_Frequency_HF_Power"], out["RRV_Frequency_Total_Power"]
    if np.isfinite(lf) and np.isfinite(hf) and hf > 0:
        out["RRV_Frequency_LFHF_Ratio"] = float(lf / hf)
    if np.isfinite(total) and total > 0:
        out["RRV_Frequency_LF_Norm"] = float(lf / total) if np.isfinite(lf) else np.nan
        out["RRV_Frequency_HF_Norm"] = float(hf / total) if np.isfinite(hf) else np.nan
    mask = (freqs >= 0.0033) & (freqs < 0.40)
    if np.any(mask):
        out["RRV_Frequency_Peak"] = float(freqs[mask][np.argmax(psd[mask])])
    return out


def compute_features(rsp, fs=100.0):
    clean = bandpass_clean_rsp(rsp, fs)
    peaks, _ = robust_peak_detection(clean, fs)
    peaks = remove_implausible_intervals(peaks, fs)
    n = len(rsp)
    duration = n / fs
    peak_times = peaks / fs
    intervals = np.diff(peak_times)
    valid_intervals = intervals[(intervals >= 1.5) & (intervals <= 15.0)]
    intervals_ms = valid_intervals * 1000.0
    rate = compute_resp_rate_signal(peaks, n, fs)
    amps = compute_cycle_amplitudes(clean, peaks, fs)

    feat = {
        "Sampling_Rate_Hz": fs,
        "Recording_Duration_s": duration,
        "RSP_Peaks_N": int(len(peaks)),
        "RSP_Valid_Intervals_N": int(len(valid_intervals)),
        "RSP_Peaks_Per_Min": float(len(peaks) / duration * 60) if duration > 0 else np.nan,
        "First_Inhalation_Peak_s": float(peak_times[0]) if len(peak_times) else np.nan,
        "Last_Inhalation_Peak_s": float(peak_times[-1]) if len(peak_times) else np.nan,
        "RSP_Clean_Mean": float(np.mean(clean)),
        "RSP_Clean_SD": float(np.std(clean, ddof=1)) if len(clean) > 1 else 0.0,
    }
    feat.update(safe_stat_features("RRV_Time_BBI_ms", intervals_ms))
    if len(intervals_ms) >= 2:
        diff = np.diff(intervals_ms)
        feat["RRV_Time_RMSSD_ms"] = float(np.sqrt(np.mean(diff ** 2)))
        feat["RRV_Time_SDSD_ms"] = float(np.std(diff, ddof=1)) if len(diff) > 1 else 0.0
        feat["RRV_Time_pNN50"] = float(np.mean(np.abs(diff) > 50) * 100)
        feat["RRV_Time_pNN100"] = float(np.mean(np.abs(diff) > 100) * 100)
        med = np.median(intervals_ms)
        feat["RRV_Time_MCVBBI"] = float(np.median(np.abs(intervals_ms - med)) / med) if med != 0 else np.nan
    else:
        for k in ["RRV_Time_RMSSD_ms", "RRV_Time_SDSD_ms", "RRV_Time_pNN50", "RRV_Time_pNN100", "RRV_Time_MCVBBI"]:
            feat[k] = np.nan

    feat.update(safe_stat_features("RSP_Rate_bpm", rate))
    inst_rate = 60.0 / valid_intervals if len(valid_intervals) else np.array([])
    feat.update(safe_stat_features("RRV_InstantRate_bpm", inst_rate))
    feat.update(safe_stat_features("RSP_Amplitude", amps))
    feat.update(frequency_domain_features(valid_intervals, peak_times))
    feat["RRV_Nonlinear_SampEn"] = sample_entropy(intervals_ms)
    feat["RRV_Nonlinear_ApEn"] = approximate_entropy(intervals_ms)
    feat["RRV_Nonlinear_DFA_alpha"] = dfa_alpha(intervals_ms)
    if len(intervals_ms) >= 2:
        x1, x2 = intervals_ms[:-1], intervals_ms[1:]
        diff, summ = x2 - x1, x2 + x1
        sd1 = np.sqrt(np.var(diff, ddof=1) / 2.0) if len(diff) > 1 else np.nan
        sd2 = np.sqrt(np.var(summ, ddof=1) / 2.0) if len(summ) > 1 else np.nan
        feat["RRV_Nonlinear_SD1_ms"] = float(sd1) if np.isfinite(sd1) else np.nan
        feat["RRV_Nonlinear_SD2_ms"] = float(sd2) if np.isfinite(sd2) else np.nan
        feat["RRV_Nonlinear_SD1SD2_Ratio"] = float(sd1 / sd2) if np.isfinite(sd1) and np.isfinite(sd2) and sd2 != 0 else np.nan
        feat["RRV_Nonlinear_Ellipse_Area"] = float(np.pi * sd1 * sd2) if np.isfinite(sd1) and np.isfinite(sd2) else np.nan
    else:
        feat["RRV_Nonlinear_SD1_ms"] = np.nan
        feat["RRV_Nonlinear_SD2_ms"] = np.nan
        feat["RRV_Nonlinear_SD1SD2_Ratio"] = np.nan
        feat["RRV_Nonlinear_Ellipse_Area"] = np.nan

    return feat, clean, peaks, rate


def main():
    print("Current working directory:", os.getcwd())
    print("Top-level entries:", sorted(os.listdir("."))[:100])
    input_path = find_input_file()
    print("Using input file:", input_path)

    df = pd.read_csv(input_path)
    print("Loaded shape:", df.shape)
    print("Columns:", list(df.columns))
    if "RSP" not in df.columns:
        raise ValueError("RSP column not found in input file.")

    rsp = as_float_array(df["RSP"])
    features, clean, peaks, rate = compute_features(rsp, FS)

    os.makedirs(OUTDIR, exist_ok=True)
    result = pd.DataFrame([features])
    first_cols = [
        "Sampling_Rate_Hz", "Recording_Duration_s", "RSP_Peaks_N",
        "RSP_Valid_Intervals_N", "RSP_Peaks_Per_Min",
        "First_Inhalation_Peak_s", "Last_Inhalation_Peak_s",
    ]
    cols = [c for c in first_cols if c in result.columns] + sorted([c for c in result.columns if c not in first_cols])
    result = result[cols]
    result.to_csv(OUTFILE, index=False)

    meta = {
        "input": str(input_path),
        "output": OUTFILE,
        "n_samples": int(len(rsp)),
        "duration_s": float(len(rsp) / FS),
        "n_inhalation_peaks": int(len(peaks)),
        "first_10_peak_samples": [int(x) for x in peaks[:10]],
        "first_10_peak_seconds": [float(x / FS) for x in peaks[:10]],
        "feature_count": int(result.shape[1]),
    }
    with open(os.path.join(OUTDIR, "rrv_analysis_pred_metadata.json"), "w") as f:
        json.dump(meta, f, indent=2)

    print("Saved:", OUTFILE)
    print("Output shape:", result.shape)
    print("Detected inhalation peaks:", len(peaks))
    print("Duration seconds:", len(rsp) / FS)
    print("Mean respiratory rate bpm:", features.get("RSP_Rate_bpm_Mean"))
    print("Mean BBI ms:", features.get("RRV_Time_BBI_ms_Mean"))
    print("RMSSD ms:", features.get("RRV_Time_RMSSD_ms"))
    print("Feature preview:")
    print(result.iloc[:, :min(16, result.shape[1])].to_string(index=False))


if __name__ == "__main__":
    main()