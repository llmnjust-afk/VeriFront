#!/usr/bin/env python3
"""
Proper RRV analysis for the provided bio_eventrelated_100hz.csv.

The input file was located at:
  /data/lab/sab_data/benchmark_verified/benchmark/datasets/biosignals/bio_eventrelated_100hz.csv

This script performs a fresh analysis:
- cleans the RSP signal
- extracts inhalation peaks and respiratory-rate peaks
- computes RRV time-domain, frequency-domain, nonlinear, rate, and amplitude features
- attempts to augment with NeuroKit2 RRV features if NeuroKit2 is available
- saves pred_results/rrv_analysis_pred.csv
"""

import os
import json
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import signal, interpolate, stats

warnings.filterwarnings("ignore")

FS = 100.0
TARGET = "bio_eventrelated_100hz.csv"
OUTDIR = Path("pred_results")
OUTFILE = OUTDIR / "rrv_analysis_pred.csv"


def find_input_file():
    candidates = [
        Path("biosignals") / TARGET,
        Path("benchmark/datasets/biosignals") / TARGET,
        Path("/data/lab/sab_data/benchmark_verified/benchmark/datasets/biosignals") / TARGET,
        Path("/data/lab/sab_data/benchmark/datasets/biosignals") / TARGET,
        Path("/mnt/data/biosignals") / TARGET,
        Path(TARGET),
    ]
    for p in candidates:
        if p.exists():
            return p

    roots = [Path("."), Path("/data/lab/sab_data"), Path("/data/lab/VeriFront")]
    for root in roots:
        if root.exists():
            try:
                hits = list(root.rglob(TARGET))
                if hits:
                    return hits[0]
            except Exception as e:
                print(f"Search warning for {root}: {e}")
    raise FileNotFoundError(f"Could not locate {TARGET}")


def numeric_clean_series(s):
    x = pd.to_numeric(pd.Series(s), errors="coerce").astype(float)
    if x.isna().any():
        x = x.interpolate(limit_direction="both").ffill().bfill()
    return x.to_numpy(dtype=float)


def bandpass_clean_rsp(rsp, fs=100.0, low=0.05, high=1.0, order=4):
    x = np.asarray(rsp, dtype=float)
    x = signal.detrend(x, type="linear")
    nyq = fs / 2.0
    b, a = signal.butter(order, [low / nyq, high / nyq], btype="bandpass")
    return signal.filtfilt(b, a, x)


def detect_inhalation_peaks(clean, fs=100.0):
    x = np.asarray(clean, dtype=float)
    robust_sd = 1.4826 * np.nanmedian(np.abs(x - np.nanmedian(x)))
    if not np.isfinite(robust_sd) or robust_sd <= 0:
        robust_sd = np.nanstd(x)
    if not np.isfinite(robust_sd) or robust_sd <= 0:
        robust_sd = 1.0

    best_peaks = np.array([], dtype=int)
    best_props = {}
    distance = int(round(1.5 * fs))
    for prom_factor in [0.45, 0.35, 0.25, 0.15, 0.08, 0.04]:
        peaks, props = signal.find_peaks(x, distance=distance, prominence=prom_factor * robust_sd)
        if len(peaks) > len(best_peaks):
            best_peaks = peaks
            best_props = props
        if len(peaks) >= 5:
            break

    # Remove very short intervals by dropping the later peak.
    peaks = np.asarray(best_peaks, dtype=int)
    if len(peaks) >= 3:
        keep = np.ones(len(peaks), dtype=bool)
        intervals = np.diff(peaks) / fs
        for i, val in enumerate(intervals):
            if val < 1.5:
                keep[i + 1] = False
        peaks = peaks[keep]

    return peaks, best_props


def detect_troughs(clean, peaks, fs=100.0):
    troughs, _ = signal.find_peaks(-np.asarray(clean), distance=int(round(1.0 * fs)))
    return troughs.astype(int)


def respiratory_rate_signal(peaks, n_samples, fs=100.0):
    peaks = np.asarray(peaks, dtype=int)
    rate = np.full(n_samples, np.nan, dtype=float)
    if len(peaks) < 2:
        return rate

    intervals_s = np.diff(peaks) / fs
    bpm = 60.0 / intervals_s
    mid_t = (peaks[:-1] + peaks[1:]) / (2.0 * fs)
    valid = np.isfinite(bpm) & (bpm > 0) & (bpm < 60) & np.isfinite(mid_t)
    if np.sum(valid) == 0:
        return rate
    if np.sum(valid) == 1:
        rate[:] = bpm[valid][0]
        return rate

    t = np.arange(n_samples) / fs
    f = interpolate.interp1d(
        mid_t[valid],
        bpm[valid],
        kind="linear",
        bounds_error=False,
        fill_value=(bpm[valid][0], bpm[valid][-1]),
    )
    return f(t)


def detect_rate_peaks(rate, fs=100.0):
    r = np.asarray(rate, dtype=float)
    valid = np.isfinite(r)
    if np.sum(valid) < int(5 * fs):
        return np.array([], dtype=int)
    r2 = r.copy()
    r2[~valid] = np.nanmedian(r2[valid])
    sd = np.nanstd(r2)
    prominence = 0.10 * sd if np.isfinite(sd) and sd > 0 else None
    peaks, _ = signal.find_peaks(r2, distance=int(round(2.0 * fs)), prominence=prominence)
    return peaks.astype(int)


def stat_features(prefix, values):
    v = np.asarray(values, dtype=float)
    v = v[np.isfinite(v)]
    out = {}
    names = ["Mean", "Median", "SD", "Min", "Max", "Range", "IQR", "CV", "Skew", "Kurtosis"]
    if len(v) == 0:
        for name in names:
            out[f"{prefix}_{name}"] = np.nan
        return out
    mean = float(np.mean(v))
    sd = float(np.std(v, ddof=1)) if len(v) > 1 else 0.0
    out[f"{prefix}_Mean"] = mean
    out[f"{prefix}_Median"] = float(np.median(v))
    out[f"{prefix}_SD"] = sd
    out[f"{prefix}_Min"] = float(np.min(v))
    out[f"{prefix}_Max"] = float(np.max(v))
    out[f"{prefix}_Range"] = float(np.max(v) - np.min(v))
    out[f"{prefix}_IQR"] = float(np.percentile(v, 75) - np.percentile(v, 25))
    out[f"{prefix}_CV"] = float(sd / mean) if mean != 0 else np.nan
    out[f"{prefix}_Skew"] = float(stats.skew(v, bias=False)) if len(v) > 2 else np.nan
    out[f"{prefix}_Kurtosis"] = float(stats.kurtosis(v, bias=False)) if len(v) > 3 else np.nan
    return out


def sample_entropy(x, m=2, r=None):
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n <= m + 2:
        return np.nan
    if r is None:
        sd = np.std(x, ddof=0)
        if not np.isfinite(sd) or sd <= 0:
            return np.nan
        r = 0.2 * sd

    def count(mm):
        c = 0
        for i in range(n - mm):
            template = x[i:i + mm]
            for j in range(i + 1, n - mm + 1):
                if np.max(np.abs(template - x[j:j + mm])) <= r:
                    c += 1
        return c

    b = count(m)
    a = count(m + 1)
    return float(-np.log(a / b)) if a > 0 and b > 0 else np.nan


def approximate_entropy(x, m=2, r=None):
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n <= m + 2:
        return np.nan
    if r is None:
        sd = np.std(x, ddof=0)
        if not np.isfinite(sd) or sd <= 0:
            return np.nan
        r = 0.2 * sd

    def phi(mm):
        templates = np.array([x[i:i + mm] for i in range(n - mm + 1)])
        c = []
        for temp in templates:
            d = np.max(np.abs(templates - temp), axis=1)
            c.append(np.mean(d <= r))
        c = np.asarray(c)
        c = c[c > 0]
        return float(np.mean(np.log(c))) if len(c) else np.nan

    a = phi(m)
    b = phi(m + 1)
    return float(a - b) if np.isfinite(a) and np.isfinite(b) else np.nan


def dfa_alpha(x):
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n < 12:
        return np.nan
    y = np.cumsum(x - np.mean(x))
    max_scale = max(5, n // 4)
    scales = np.unique(np.floor(np.logspace(np.log10(4), np.log10(max_scale), 8)).astype(int))
    used, flucts = [], []
    for s in scales:
        if s < 4 or 2 * s > n:
            continue
        nseg = n // s
        rms = []
        t = np.arange(s)
        for k in range(nseg):
            seg = y[k * s:(k + 1) * s]
            coef = np.polyfit(t, seg, 1)
            rms.append(np.sqrt(np.mean((seg - np.polyval(coef, t)) ** 2)))
        f = np.sqrt(np.mean(np.asarray(rms) ** 2))
        if np.isfinite(f) and f > 0:
            used.append(s)
            flucts.append(f)
    if len(flucts) < 2:
        return np.nan
    return float(np.polyfit(np.log(used), np.log(flucts), 1)[0])


def frequency_features(intervals_s, peak_times_s):
    out = {}
    bands = {
        "VLF": (0.0033, 0.04),
        "LF": (0.04, 0.15),
        "HF": (0.15, 0.40),
        "Total": (0.0033, 0.40),
    }
    for k in bands:
        out[f"RRV_Frequency_{k}_Power_s2"] = np.nan
    out["RRV_Frequency_LFHF_Ratio"] = np.nan
    out["RRV_Frequency_LF_Norm"] = np.nan
    out["RRV_Frequency_HF_Norm"] = np.nan
    out["RRV_Frequency_Peak_Hz"] = np.nan

    intervals_s = np.asarray(intervals_s, dtype=float)
    peak_times_s = np.asarray(peak_times_s, dtype=float)
    if len(intervals_s) < 4 or len(peak_times_s) < 5:
        return out

    t = (peak_times_s[:-1] + peak_times_s[1:]) / 2.0
    n = min(len(t), len(intervals_s))
    t, y = t[:n], intervals_s[:n]
    valid = np.isfinite(t) & np.isfinite(y) & (y > 0)
    t, y = t[valid], y[valid]
    if len(y) < 4 or np.ptp(t) <= 10:
        return out

    fs_i = 4.0
    ti = np.arange(t[0], t[-1], 1 / fs_i)
    if len(ti) < 16:
        return out

    yi = interpolate.interp1d(t, y, kind="linear", fill_value="extrapolate")(ti)
    yi = signal.detrend(yi)
    if np.nanstd(yi) <= 0:
        return out

    nperseg = min(256, len(yi))
    freqs, psd = signal.welch(yi, fs=fs_i, nperseg=nperseg, noverlap=nperseg // 2)
    for band, (lo, hi) in bands.items():
        mask = (freqs >= lo) & (freqs < hi)
        if np.any(mask):
            out[f"RRV_Frequency_{band}_Power_s2"] = float(np.trapz(psd[mask], freqs[mask]))

    lf = out["RRV_Frequency_LF_Power_s2"]
    hf = out["RRV_Frequency_HF_Power_s2"]
    total = out["RRV_Frequency_Total_Power_s2"]
    if np.isfinite(lf) and np.isfinite(hf) and hf > 0:
        out["RRV_Frequency_LFHF_Ratio"] = float(lf / hf)
    if np.isfinite(total) and total > 0:
        out["RRV_Frequency_LF_Norm"] = float(lf / total) if np.isfinite(lf) else np.nan
        out["RRV_Frequency_HF_Norm"] = float(hf / total) if np.isfinite(hf) else np.nan
    mask = (freqs >= 0.0033) & (freqs < 0.40)
    if np.any(mask):
        out["RRV_Frequency_Peak_Hz"] = float(freqs[mask][np.argmax(psd[mask])])
    return out


def cycle_amplitudes(clean, peaks):
    x = np.asarray(clean, dtype=float)
    troughs = detect_troughs(x, peaks, FS)
    amps = []
    for p in peaks:
        prev = troughs[troughs < p]
        if len(prev):
            amps.append(x[p] - x[prev[-1]])
    return np.asarray(amps, dtype=float), troughs


def add_neurokit_features(rsp, features):
    try:
        import neurokit2 as nk
        print("NeuroKit2 available:", getattr(nk, "__version__", "unknown"))
    except Exception as e:
        print("NeuroKit2 not available or failed to import:", e)
        features["NeuroKit2_Used"] = False
        return features

    features["NeuroKit2_Used"] = True
    try:
        signals, info = nk.rsp_process(rsp, sampling_rate=int(FS))
        print("NeuroKit2 rsp_process columns:", list(signals.columns))
        if "RSP_Rate" in signals:
            features.update(stat_features("NK_RSP_Rate_bpm", signals["RSP_Rate"].to_numpy()))
        if "RSP_Amplitude" in signals:
            features.update(stat_features("NK_RSP_Amplitude", signals["RSP_Amplitude"].to_numpy()))
        if isinstance(info, dict):
            if "RSP_Peaks" in info:
                features["NK_RSP_Peaks_N"] = int(len(info["RSP_Peaks"]))
            if "RSP_Troughs" in info:
                features["NK_RSP_Troughs_N"] = int(len(info["RSP_Troughs"]))

        # Try event/interval-related NeuroKit summary routines.
        for funcname in ["rsp_intervalrelated", "rsp_analyze"]:
            if hasattr(nk, funcname):
                try:
                    func = getattr(nk, funcname)
                    nkdf = func(signals, sampling_rate=int(FS))
                    if isinstance(nkdf, pd.DataFrame) and len(nkdf) > 0:
                        for col in nkdf.columns:
                            val = nkdf.iloc[0][col]
                            if np.isscalar(val):
                                features[f"NK_{funcname}_{col}"] = val
                        print(f"Added NeuroKit2 {funcname} features:", nkdf.shape)
                except Exception as e:
                    print(f"NeuroKit2 {funcname} failed:", e)
    except Exception as e:
        print("NeuroKit2 processing failed:", e)

    return features


def compute_rrv(rsp):
    clean = bandpass_clean_rsp(rsp, FS)
    peaks, peak_props = detect_inhalation_peaks(clean, FS)
    peak_times = peaks / FS
    intervals_s_all = np.diff(peak_times)
    valid_mask = (intervals_s_all >= 1.5) & (intervals_s_all <= 15.0)
    intervals_s = intervals_s_all[valid_mask]
    intervals_ms = intervals_s * 1000.0

    rate = respiratory_rate_signal(peaks, len(rsp), FS)
    rate_peaks = detect_rate_peaks(rate, FS)
    amps, troughs = cycle_amplitudes(clean, peaks)

    features = {
        "Sampling_Rate_Hz": float(FS),
        "N_Samples": int(len(rsp)),
        "Duration_s": float(len(rsp) / FS),
        "RSP_Raw_Mean": float(np.mean(rsp)),
        "RSP_Raw_SD": float(np.std(rsp, ddof=1)),
        "RSP_Clean_Mean": float(np.mean(clean)),
        "RSP_Clean_SD": float(np.std(clean, ddof=1)),
        "RSP_Clean_Min": float(np.min(clean)),
        "RSP_Clean_Max": float(np.max(clean)),
        "RSP_Inhalation_Peaks_N": int(len(peaks)),
        "RSP_Inhalation_Onsets_Troughs_N": int(len(troughs)),
        "RSP_Rate_Peaks_N": int(len(rate_peaks)),
        "RSP_Inhalation_Peaks_Indices": ";".join(map(str, peaks.tolist())),
        "RSP_Inhalation_Peaks_Seconds": ";".join(f"{v:.3f}" for v in peak_times),
        "RSP_Rate_Peaks_Indices": ";".join(map(str, rate_peaks.tolist())),
        "RSP_Rate_Peaks_Seconds": ";".join(f"{v / FS:.3f}" for v in rate_peaks),
        "First_Inhalation_Peak_s": float(peak_times[0]) if len(peak_times) else np.nan,
        "Last_Inhalation_Peak_s": float(peak_times[-1]) if len(peak_times) else np.nan,
        "RSP_Breaths_Per_Min_CountBased": float(len(peaks) / (len(rsp) / FS) * 60.0),
    }

    features.update(stat_features("RSP_Rate_Signal_bpm", rate))
    inst_rate = 60.0 / intervals_s if len(intervals_s) else np.array([])
    features.update(stat_features("RRV_Instant_Rate_bpm", inst_rate))
    features.update(stat_features("RRV_Time_BreathToBreathInterval_ms", intervals_ms))
    features.update(stat_features("RSP_Cycle_Amplitude", amps))

    if len(intervals_ms) >= 2:
        diff = np.diff(intervals_ms)
        features["RRV_Time_RMSSD_ms"] = float(np.sqrt(np.mean(diff ** 2)))
        features["RRV_Time_SDSD_ms"] = float(np.std(diff, ddof=1)) if len(diff) > 1 else 0.0
        features["RRV_Time_CVSD"] = float(features["RRV_Time_RMSSD_ms"] / np.mean(intervals_ms)) if np.mean(intervals_ms) != 0 else np.nan
        features["RRV_Time_CVBB"] = float(np.std(intervals_ms, ddof=1) / np.mean(intervals_ms)) if np.mean(intervals_ms) != 0 else np.nan
        features["RRV_Time_pNN50_percent"] = float(np.mean(np.abs(diff) > 50.0) * 100.0)
        features["RRV_Time_pNN100_percent"] = float(np.mean(np.abs(diff) > 100.0) * 100.0)
        med = np.median(intervals_ms)
        features["RRV_Time_MedianCVBB"] = float(np.median(np.abs(intervals_ms - med)) / med) if med != 0 else np.nan
    else:
        for k in ["RRV_Time_RMSSD_ms", "RRV_Time_SDSD_ms", "RRV_Time_CVSD", "RRV_Time_CVBB",
                  "RRV_Time_pNN50_percent", "RRV_Time_pNN100_percent", "RRV_Time_MedianCVBB"]:
            features[k] = np.nan

    features.update(frequency_features(intervals_s, peak_times))
    features["RRV_Nonlinear_SampEn"] = sample_entropy(intervals_ms)
    features["RRV_Nonlinear_ApEn"] = approximate_entropy(intervals_ms)
    features["RRV_Nonlinear_DFA_alpha"] = dfa_alpha(intervals_ms)

    if len(intervals_ms) >= 2:
        x1, x2 = intervals_ms[:-1], intervals_ms[1:]
        d = x2 - x1
        s = x2 + x1
        sd1 = np.sqrt(np.var(d, ddof=1) / 2.0) if len(d) > 1 else np.nan
        sd2 = np.sqrt(np.var(s, ddof=1) / 2.0) if len(s) > 1 else np.nan
        features["RRV_Nonlinear_SD1_ms"] = float(sd1) if np.isfinite(sd1) else np.nan
        features["RRV_Nonlinear_SD2_ms"] = float(sd2) if np.isfinite(sd2) else np.nan
        features["RRV_Nonlinear_SD1SD2_Ratio"] = float(sd1 / sd2) if np.isfinite(sd1) and np.isfinite(sd2) and sd2 != 0 else np.nan
        features["RRV_Nonlinear_Poincare_Ellipse_Area"] = float(np.pi * sd1 * sd2) if np.isfinite(sd1) and np.isfinite(sd2) else np.nan
    else:
        features["RRV_Nonlinear_SD1_ms"] = np.nan
        features["RRV_Nonlinear_SD2_ms"] = np.nan
        features["RRV_Nonlinear_SD1SD2_Ratio"] = np.nan
        features["RRV_Nonlinear_Poincare_Ellipse_Area"] = np.nan

    features = add_neurokit_features(rsp, features)
    return features, clean, peaks, troughs, rate, rate_peaks


def main():
    print("Working directory:", os.getcwd())
    input_path = find_input_file()
    print("Using input:", input_path)

    df = pd.read_csv(input_path)
    print("Loaded input shape:", df.shape)
    print("Columns:", list(df.columns))
    if "RSP" not in df.columns:
        raise ValueError("Input CSV has no RSP column.")

    rsp = numeric_clean_series(df["RSP"])
    features, clean, peaks, troughs, rate, rate_peaks = compute_rrv(rsp)

    OUTDIR.mkdir(parents=True, exist_ok=True)
    result = pd.DataFrame([features])

    priority = [
        "Sampling_Rate_Hz", "N_Samples", "Duration_s",
        "RSP_Inhalation_Peaks_N", "RSP_Inhalation_Onsets_Troughs_N", "RSP_Rate_Peaks_N",
        "RSP_Rate_Signal_bpm_Mean", "RSP_Rate_Signal_bpm_SD",
        "RRV_Time_BreathToBreathInterval_ms_Mean", "RRV_Time_BreathToBreathInterval_ms_SD",
        "RRV_Time_RMSSD_ms", "RRV_Time_CVBB", "RRV_Time_CVSD",
        "RRV_Frequency_LF_Power_s2", "RRV_Frequency_HF_Power_s2", "RRV_Frequency_LFHF_Ratio",
        "RRV_Nonlinear_SampEn", "RRV_Nonlinear_ApEn", "RRV_Nonlinear_DFA_alpha",
    ]
    cols = [c for c in priority if c in result.columns] + sorted([c for c in result.columns if c not in priority])
    result = result[cols]
    result.to_csv(OUTFILE, index=False)

    # Save processed signal summary for traceability.
    debug = pd.DataFrame({
        "RSP_Raw": rsp,
        "RSP_Clean": clean,
        "RSP_Rate_bpm": rate,
        "RSP_Inhalation_Peak": np.isin(np.arange(len(rsp)), peaks).astype(int),
        "RSP_Trough": np.isin(np.arange(len(rsp)), troughs).astype(int),
        "RSP_Rate_Peak": np.isin(np.arange(len(rsp)), rate_peaks).astype(int),
    })
    debug.to_csv(OUTDIR / "rrv_processed_signals.csv", index=False)

    meta = {
        "input": str(input_path),
        "output": str(OUTFILE),
        "sampling_rate_hz": FS,
        "n_samples": int(len(rsp)),
        "duration_s": float(len(rsp) / FS),
        "n_inhalation_peaks": int(len(peaks)),
        "n_troughs": int(len(troughs)),
        "n_rate_peaks": int(len(rate_peaks)),
        "first_10_inhalation_peak_samples": [int(x) for x in peaks[:10]],
        "first_10_rate_peak_samples": [int(x) for x in rate_peaks[:10]],
        "n_features": int(result.shape[1]),
    }
    with open(OUTDIR / "rrv_analysis_pred_metadata.json", "w") as f:
        json.dump(meta, f, indent=2)

    print("Saved required output:", OUTFILE)
    print("Output shape:", result.shape)
    print("Detected inhalation peaks:", len(peaks))
    print("Detected trough/onset candidates:", len(troughs))
    print("Detected respiratory-rate peaks:", len(rate_peaks))
    print("Mean respiratory rate bpm:", features.get("RSP_Rate_Signal_bpm_Mean"))
    print("Mean BBI ms:", features.get("RRV_Time_BreathToBreathInterval_ms_Mean"))
    print("RMSSD ms:", features.get("RRV_Time_RMSSD_ms"))
    print("LF/HF:", features.get("RRV_Frequency_LFHF_Ratio"))
    print("Sample entropy:", features.get("RRV_Nonlinear_SampEn"))
    print("\nOutput preview:")
    print(result.iloc[:, :min(result.shape[1], 25)].to_string(index=False))


if __name__ == "__main__":
    main()