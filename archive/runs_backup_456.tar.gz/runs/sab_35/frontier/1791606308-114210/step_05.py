#!/usr/bin/env python3
"""
Diagnostic and corrected RRV analysis.

Previous custom detector found no peaks because the event-related RSP channel has
a strong low-frequency morphology for which the 0.05-1 Hz bandpass was too
aggressive. This version uses NeuroKit2's respiration cleaning/peak detection as
the primary method (as suggested by the benchmark), with a broad fallback
detector, then recomputes and saves RRV indices.
"""

import os
import json
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import signal, interpolate, stats

warnings.filterwarnings("ignore")

FS = 100.0
TARGET = "bio_eventrelated_100hz.csv"
OUTDIR = Path("pred_results")
OUTFILE = OUTDIR / "rrv_analysis_pred.csv"


def find_input_file():
    candidates = [
        Path("biosignals") / TARGET,
        Path("benchmark/datasets/biosignals") / TARGET,
        Path("/data/lab/sab_data/benchmark_verified/benchmark/datasets/biosignals") / TARGET,
        Path("/data/lab/sab_data/benchmark/datasets/biosignals") / TARGET,
        Path(TARGET),
    ]
    for p in candidates:
        if p.exists():
            return p
    for root in [Path("."), Path("/data/lab/sab_data"), Path("/data/lab/VeriFront")]:
        if root.exists():
            hits = list(root.rglob(TARGET))
            if hits:
                return hits[0]
    raise FileNotFoundError(TARGET)


def numeric_clean_series(s):
    x = pd.to_numeric(pd.Series(s), errors="coerce").astype(float)
    if x.isna().any():
        x = x.interpolate(limit_direction="both").ffill().bfill()
    return x.to_numpy(float)


def stat_features(prefix, values):
    v = np.asarray(values, dtype=float)
    v = v[np.isfinite(v)]
    names = ["Mean", "Median", "SD", "Min", "Max", "Range", "IQR", "CV", "Skew", "Kurtosis"]
    if len(v) == 0:
        return {f"{prefix}_{name}": np.nan for name in names}
    mean = float(np.mean(v))
    sd = float(np.std(v, ddof=1)) if len(v) > 1 else 0.0
    return {
        f"{prefix}_Mean": mean,
        f"{prefix}_Median": float(np.median(v)),
        f"{prefix}_SD": sd,
        f"{prefix}_Min": float(np.min(v)),
        f"{prefix}_Max": float(np.max(v)),
        f"{prefix}_Range": float(np.max(v) - np.min(v)),
        f"{prefix}_IQR": float(np.percentile(v, 75) - np.percentile(v, 25)),
        f"{prefix}_CV": float(sd / mean) if mean != 0 else np.nan,
        f"{prefix}_Skew": float(stats.skew(v, bias=False)) if len(v) > 2 else np.nan,
        f"{prefix}_Kurtosis": float(stats.kurtosis(v, bias=False)) if len(v) > 3 else np.nan,
    }


def sample_entropy(x, m=2, r=None):
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n <= m + 2:
        return np.nan
    if r is None:
        sd = np.std(x)
        if sd <= 0 or not np.isfinite(sd):
            return np.nan
        r = 0.2 * sd
    b = 0
    a = 0
    for i in range(n - m):
        tmpl = x[i:i + m]
        tmpl1 = x[i:i + m + 1]
        for j in range(i + 1, n - m):
            if np.max(np.abs(tmpl - x[j:j + m])) <= r:
                b += 1
                if j + m + 1 <= n and np.max(np.abs(tmpl1 - x[j:j + m + 1])) <= r:
                    a += 1
    return float(-np.log(a / b)) if a > 0 and b > 0 else np.nan


def approximate_entropy(x, m=2, r=None):
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n <= m + 2:
        return np.nan
    if r is None:
        sd = np.std(x)
        if sd <= 0 or not np.isfinite(sd):
            return np.nan
        r = 0.2 * sd

    def phi(mm):
        patterns = np.array([x[i:i + mm] for i in range(n - mm + 1)])
        vals = []
        for p in patterns:
            d = np.max(np.abs(patterns - p), axis=1)
            vals.append(np.mean(d <= r))
        vals = np.asarray(vals)
        vals = vals[vals > 0]
        return np.mean(np.log(vals)) if len(vals) else np.nan

    p1, p2 = phi(m), phi(m + 1)
    return float(p1 - p2) if np.isfinite(p1) and np.isfinite(p2) else np.nan


def dfa_alpha(x):
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n < 12:
        return np.nan
    y = np.cumsum(x - np.mean(x))
    scales = np.unique(np.floor(np.logspace(np.log10(4), np.log10(max(5, n // 4)), 8)).astype(int))
    used, flucts = [], []
    for s in scales:
        if s < 4 or 2 * s > n:
            continue
        rms = []
        t = np.arange(s)
        for k in range(n // s):
            seg = y[k * s:(k + 1) * s]
            coef = np.polyfit(t, seg, 1)
            rms.append(np.sqrt(np.mean((seg - np.polyval(coef, t)) ** 2)))
        f = np.sqrt(np.mean(np.asarray(rms) ** 2))
        if np.isfinite(f) and f > 0:
            used.append(s)
            flucts.append(f)
    return float(np.polyfit(np.log(used), np.log(flucts), 1)[0]) if len(flucts) >= 2 else np.nan


def frequency_features(intervals_s, interval_times_s):
    out = {}
    bands = {"VLF": (0.0033, 0.04), "LF": (0.04, 0.15), "HF": (0.15, 0.40), "Total": (0.0033, 0.40)}
    for b in bands:
        out[f"RRV_Frequency_{b}_Power_s2"] = np.nan
    out["RRV_Frequency_LFHF_Ratio"] = np.nan
    out["RRV_Frequency_LF_Norm"] = np.nan
    out["RRV_Frequency_HF_Norm"] = np.nan
    out["RRV_Frequency_Peak_Hz"] = np.nan

    y = np.asarray(intervals_s, dtype=float)
    t = np.asarray(interval_times_s, dtype=float)
    n = min(len(y), len(t))
    y, t = y[:n], t[:n]
    valid = np.isfinite(y) & np.isfinite(t) & (y > 0)
    y, t = y[valid], t[valid]
    if len(y) < 4 or np.ptp(t) < 10:
        return out

    fs_i = 4.0
    ti = np.arange(t[0], t[-1], 1.0 / fs_i)
    if len(ti) < 16:
        return out
    yi = interpolate.interp1d(t, y, kind="linear", fill_value="extrapolate")(ti)
    yi = signal.detrend(yi)
    if np.std(yi) <= 0:
        return out
    nperseg = min(256, len(yi))
    f, pxx = signal.welch(yi, fs=fs_i, nperseg=nperseg, noverlap=nperseg // 2)
    for band, (lo, hi) in bands.items():
        mask = (f >= lo) & (f < hi)
        if np.any(mask):
            out[f"RRV_Frequency_{band}_Power_s2"] = float(np.trapz(pxx[mask], f[mask]))
    lf = out["RRV_Frequency_LF_Power_s2"]
    hf = out["RRV_Frequency_HF_Power_s2"]
    total = out["RRV_Frequency_Total_Power_s2"]
    if np.isfinite(lf) and np.isfinite(hf) and hf > 0:
        out["RRV_Frequency_LFHF_Ratio"] = float(lf / hf)
    if np.isfinite(total) and total > 0:
        out["RRV_Frequency_LF_Norm"] = float(lf / total) if np.isfinite(lf) else np.nan
        out["RRV_Frequency_HF_Norm"] = float(hf / total) if np.isfinite(hf) else np.nan
    mask = (f >= 0.0033) & (f < 0.40)
    if np.any(mask):
        out["RRV_Frequency_Peak_Hz"] = float(f[mask][np.argmax(pxx[mask])])
    return out


def fallback_clean_and_peaks(rsp):
    # Very broad low-pass/high-pass suitable for slow event-related respiration.
    x = signal.detrend(rsp)
    b, a = signal.butter(3, [0.01 / (FS / 2), 0.8 / (FS / 2)], btype="bandpass")
    clean = signal.filtfilt(b, a, x)
    sd = 1.4826 * np.median(np.abs(clean - np.median(clean)))
    if sd <= 0 or not np.isfinite(sd):
        sd = np.std(clean)
    peaks, _ = signal.find_peaks(clean, distance=int(1.8 * FS), prominence=0.05 * sd)
    troughs, _ = signal.find_peaks(-clean, distance=int(1.8 * FS), prominence=0.05 * sd)
    return clean, peaks.astype(int), troughs.astype(int)


def neurokit_respiration(rsp):
    try:
        import neurokit2 as nk
        signals, info = nk.rsp_process(rsp, sampling_rate=int(FS))
        clean = pd.to_numeric(signals["RSP_Clean"], errors="coerce").interpolate(limit_direction="both").to_numpy(float)
        rate = pd.to_numeric(signals["RSP_Rate"], errors="coerce").interpolate(limit_direction="both").to_numpy(float)
        amp = pd.to_numeric(signals["RSP_Amplitude"], errors="coerce").interpolate(limit_direction="both").to_numpy(float)

        # NeuroKit stores binary marker columns and often also info arrays.
        peaks = np.where(np.asarray(signals["RSP_Peaks"]) == 1)[0] if "RSP_Peaks" in signals else np.array([], dtype=int)
        troughs = np.where(np.asarray(signals["RSP_Troughs"]) == 1)[0] if "RSP_Troughs" in signals else np.array([], dtype=int)
        if len(peaks) == 0 and isinstance(info, dict) and "RSP_Peaks" in info:
            peaks = np.asarray(info["RSP_Peaks"], dtype=int)
        if len(troughs) == 0 and isinstance(info, dict) and "RSP_Troughs" in info:
            troughs = np.asarray(info["RSP_Troughs"], dtype=int)

        nk_features = {}
        nk_features["NeuroKit2_Used"] = True
        nk_features["NK_RSP_Peaks_N"] = int(len(peaks))
        nk_features["NK_RSP_Troughs_N"] = int(len(troughs))
        nk_features.update(stat_features("NK_RSP_Rate_bpm", rate))
        nk_features.update(stat_features("NK_RSP_Amplitude", amp))

        for funcname in ["rsp_intervalrelated", "rsp_analyze"]:
            try:
                func = getattr(nk, funcname)
                nkdf = func(signals, sampling_rate=int(FS))
                if isinstance(nkdf, pd.DataFrame) and len(nkdf) > 0:
                    for col in nkdf.columns:
                        val = nkdf.iloc[0][col]
                        if np.isscalar(val):
                            nk_features[f"NK_{funcname}_{col}"] = val
                    print(f"NeuroKit {funcname} produced shape {nkdf.shape}")
            except Exception as e:
                print(f"NeuroKit {funcname} failed: {e}")

        return clean, peaks.astype(int), troughs.astype(int), rate, amp, nk_features

    except Exception as e:
        print("NeuroKit processing failed; using fallback:", e)
        clean, peaks, troughs = fallback_clean_and_peaks(rsp)
        rate = make_rate(peaks, len(rsp))
        amp = make_amplitudes(clean, peaks, troughs)
        return clean, peaks, troughs, rate, amp, {"NeuroKit2_Used": False}


def make_rate(peaks, n_samples):
    peaks = np.asarray(peaks, dtype=int)
    out = np.full(n_samples, np.nan)
    if len(peaks) < 2:
        return out
    intervals = np.diff(peaks) / FS
    bpm = 60 / intervals
    t = (peaks[:-1] + peaks[1:]) / (2 * FS)
    valid = np.isfinite(bpm) & (bpm > 0) & (bpm < 80)
    if np.sum(valid) == 0:
        return out
    if np.sum(valid) == 1:
        out[:] = bpm[valid][0]
        return out
    all_t = np.arange(n_samples) / FS
    return interpolate.interp1d(t[valid], bpm[valid], bounds_error=False,
                                fill_value=(bpm[valid][0], bpm[valid][-1]))(all_t)


def make_amplitudes(clean, peaks, troughs):
    amps = []
    for p in peaks:
        prev = troughs[troughs < p]
        if len(prev):
            amps.append(clean[p] - clean[prev[-1]])
    return np.asarray(amps, dtype=float)


def compute_rrv(rsp):
    clean, peaks, troughs, rate, amp_signal, nk_features = neurokit_respiration(rsp)

    # If NeuroKit gave too few peaks, use fallback detector.
    if len(peaks) < 3:
        fclean, fpeaks, ftroughs = fallback_clean_and_peaks(rsp)
        print(f"Fallback detector peaks={len(fpeaks)}, troughs={len(ftroughs)}")
        if len(fpeaks) > len(peaks):
            clean, peaks, troughs = fclean, fpeaks, ftroughs
            rate = make_rate(peaks, len(rsp))
            amp_signal = make_amplitudes(clean, peaks, troughs)

    peak_times = peaks / FS
    intervals_all = np.diff(peak_times)
    valid_interval_mask = (intervals_all >= 1.5) & (intervals_all <= 20.0)
    intervals_s = intervals_all[valid_interval_mask]
    intervals_ms = intervals_s * 1000.0
    interval_times = (peak_times[:-1] + peak_times[1:]) / 2.0
    interval_times = interval_times[valid_interval_mask] if len(interval_times) == len(valid_interval_mask) else interval_times[:len(intervals_s)]

    rate_peaks, _ = signal.find_peaks(
        np.nan_to_num(rate, nan=np.nanmedian(rate[np.isfinite(rate)]) if np.any(np.isfinite(rate)) else 0.0),
        distance=int(2 * FS),
        prominence=(0.05 * np.nanstd(rate) if np.nanstd(rate) > 0 else None),
    )

    cycle_amp = make_amplitudes(clean, peaks, troughs)
    if len(cycle_amp) == 0 and np.size(amp_signal) > 0:
        cycle_amp = np.asarray(amp_signal, dtype=float)

    features = {
        "Sampling_Rate_Hz": float(FS),
        "N_Samples": int(len(rsp)),
        "Duration_s": float(len(rsp) / FS),
        "RSP_Raw_Mean": float(np.mean(rsp)),
        "RSP_Raw_SD": float(np.std(rsp, ddof=1)),
        "RSP_Raw_Min": float(np.min(rsp)),
        "RSP_Raw_Max": float(np.max(rsp)),
        "RSP_Clean_Mean": float(np.mean(clean)),
        "RSP_Clean_SD": float(np.std(clean, ddof=1)),
        "RSP_Clean_Min": float(np.min(clean)),
        "RSP_Clean_Max": float(np.max(clean)),
        "RSP_Inhalation_Peaks_N": int(len(peaks)),
        "RSP_Inhalation_Onsets_Troughs_N": int(len(troughs)),
        "RSP_Rate_Peaks_N": int(len(rate_peaks)),
        "First_Inhalation_Peak_s": float(peak_times[0]) if len(peak_times) else np.nan,
        "Last_Inhalation_Peak_s": float(peak_times[-1]) if len(peak_times) else np.nan,
        "RSP_Breaths_Per_Min_CountBased": float(len(peaks) / (len(rsp) / FS) * 60.0),
        "RSP_Inhalation_Peaks_Indices": ";".join(map(str, peaks.tolist())),
        "RSP_Inhalation_Peaks_Seconds": ";".join(f"{x:.3f}" for x in peak_times),
        "RSP_Rate_Peaks_Indices": ";".join(map(str, rate_peaks.tolist())),
        "RSP_Rate_Peaks_Seconds": ";".join(f"{x / FS:.3f}" for x in rate_peaks),
    }

    features.update(stat_features("RSP_Rate_Signal_bpm", rate))
    inst_rate = 60.0 / intervals_s if len(intervals_s) else np.array([])
    features.update(stat_features("RRV_Instant_Rate_bpm", inst_rate))
    features.update(stat_features("RRV_Time_BreathToBreathInterval_ms", intervals_ms))
    features.update(stat_features("RSP_Cycle_Amplitude", cycle_amp))

    if len(intervals_ms) >= 2:
        diff = np.diff(intervals_ms)
        mean_bbi = np.mean(intervals_ms)
        features["RRV_Time_RMSSD_ms"] = float(np.sqrt(np.mean(diff ** 2)))
        features["RRV_Time_SDSD_ms"] = float(np.std(diff, ddof=1)) if len(diff) > 1 else 0.0
        features["RRV_Time_CVSD"] = float(features["RRV_Time_RMSSD_ms"] / mean_bbi) if mean_bbi != 0 else np.nan
        features["RRV_Time_CVBB"] = float(np.std(intervals_ms, ddof=1) / mean_bbi) if mean_bbi != 0 else np.nan
        features["RRV_Time_pNN50_percent"] = float(np.mean(np.abs(diff) > 50) * 100)
        features["RRV_Time_pNN100_percent"] = float(np.mean(np.abs(diff) > 100) * 100)
        med = np.median(intervals_ms)
        features["RRV_Time_MedianCVBB"] = float(np.median(np.abs(intervals_ms - med)) / med) if med != 0 else np.nan
    else:
        for k in ["RRV_Time_RMSSD_ms", "RRV_Time_SDSD_ms", "RRV_Time_CVSD", "RRV_Time_CVBB",
                  "RRV_Time_pNN50_percent", "RRV_Time_pNN100_percent", "RRV_Time_MedianCVBB"]:
            features[k] = np.nan

    features.update(frequency_features(intervals_s, interval_times))
    features["RRV_Nonlinear_SampEn"] = sample_entropy(intervals_ms)
    features["RRV_Nonlinear_ApEn"] = approximate_entropy(intervals_ms)
    features["RRV_Nonlinear_DFA_alpha"] = dfa_alpha(intervals_ms)

    if len(intervals_ms) >= 2:
        x1, x2 = intervals_ms[:-1], intervals_ms[1:]
        d, s = x2 - x1, x2 + x1
        sd1 = np.sqrt(np.var(d, ddof=1) / 2.0) if len(d) > 1 else np.nan
        sd2 = np.sqrt(np.var(s, ddof=1) / 2.0) if len(s) > 1 else np.nan
        features["RRV_Nonlinear_SD1_ms"] = float(sd1) if np.isfinite(sd1) else np.nan
        features["RRV_Nonlinear_SD2_ms"] = float(sd2) if np.isfinite(sd2) else np.nan
        features["RRV_Nonlinear_SD1SD2_Ratio"] = float(sd1 / sd2) if np.isfinite(sd1) and np.isfinite(sd2) and sd2 != 0 else np.nan
        features["RRV_Nonlinear_Poincare_Ellipse_Area"] = float(np.pi * sd1 * sd2) if np.isfinite(sd1) and np.isfinite(sd2) else np.nan
    else:
        features["RRV_Nonlinear_SD1_ms"] = np.nan
        features["RRV_Nonlinear_SD2_ms"] = np.nan
        features["RRV_Nonlinear_SD1SD2_Ratio"] = np.nan
        features["RRV_Nonlinear_Poincare_Ellipse_Area"] = np.nan

    features.update(nk_features)
    return features, clean, peaks, troughs, rate, rate_peaks


def main():
    print("CWD:", os.getcwd())
    input_path = find_input_file()
    print("Input:", input_path)
    df = pd.read_csv(input_path)
    print("Input shape:", df.shape, "columns:", list(df.columns))
    rsp = numeric_clean_series(df["RSP"])
    print("RSP diagnostics:")
    print("  raw min/max/mean/sd:", float(np.min(rsp)), float(np.max(rsp)), float(np.mean(rsp)), float(np.std(rsp, ddof=1)))
    print("  first 10:", np.array2string(rsp[:10], precision=5))

    features, clean, peaks, troughs, rate, rate_peaks = compute_rrv(rsp)

    OUTDIR.mkdir(exist_ok=True, parents=True)
    result = pd.DataFrame([features])
    priority = [
        "Sampling_Rate_Hz", "N_Samples", "Duration_s",
        "RSP_Inhalation_Peaks_N", "RSP_Inhalation_Onsets_Troughs_N", "RSP_Rate_Peaks_N",
        "RSP_Rate_Signal_bpm_Mean", "RSP_Rate_Signal_bpm_SD",
        "RRV_Time_BreathToBreathInterval_ms_Mean", "RRV_Time_BreathToBreathInterval_ms_SD",
        "RRV_Time_RMSSD_ms", "RRV_Time_CVBB", "RRV_Time_CVSD",
        "RRV_Frequency_LF_Power_s2", "RRV_Frequency_HF_Power_s2", "RRV_Frequency_LFHF_Ratio",
        "RRV_Nonlinear_SampEn", "RRV_Nonlinear_ApEn", "RRV_Nonlinear_DFA_alpha",
        "NeuroKit2_Used",
    ]
    cols = [c for c in priority if c in result.columns] + sorted([c for c in result.columns if c not in priority])
    result = result[cols]
    result.to_csv(OUTFILE, index=False)

    pd.DataFrame({
        "RSP_Raw": rsp,
        "RSP_Clean": clean,
        "RSP_Rate_bpm": rate,
        "RSP_Inhalation_Peak": np.isin(np.arange(len(rsp)), peaks).astype(int),
        "RSP_Trough": np.isin(np.arange(len(rsp)), troughs).astype(int),
        "RSP_Rate_Peak": np.isin(np.arange(len(rsp)), rate_peaks).astype(int),
    }).to_csv(OUTDIR / "rrv_processed_signals.csv", index=False)

    meta = {
        "input": str(input_path),
        "output": str(OUTFILE),
        "n_samples": int(len(rsp)),
        "duration_s": float(len(rsp) / FS),
        "n_inhalation_peaks": int(len(peaks)),
        "n_troughs": int(len(troughs)),
        "n_rate_peaks": int(len(rate_peaks)),
        "first_20_peak_seconds": [float(x / FS) for x in peaks[:20]],
        "feature_count": int(result.shape[1]),
    }
    with open(OUTDIR / "rrv_analysis_pred_metadata.json", "w") as f:
        json.dump(meta, f, indent=2)

    print("\nSaved:", OUTFILE)
    print("Output shape:", result.shape)
    print("Detected inhalation peaks:", len(peaks), "first seconds:", [round(x / FS, 3) for x in peaks[:10]])
    print("Detected troughs:", len(troughs), "rate peaks:", len(rate_peaks))
    print("Mean rate bpm:", features.get("RSP_Rate_Signal_bpm_Mean"))
    print("Mean BBI ms:", features.get("RRV_Time_BreathToBreathInterval_ms_Mean"))
    print("RMSSD ms:", features.get("RRV_Time_RMSSD_ms"))
    print("LF power:", features.get("RRV_Frequency_LF_Power_s2"))
    print("HF power:", features.get("RRV_Frequency_HF_Power_s2"))
    print("SampEn:", features.get("RRV_Nonlinear_SampEn"))
    print("\nPreview:")
    print(result.iloc[:, :min(30, result.shape[1])].to_string(index=False))


if __name__ == "__main__":
    main()