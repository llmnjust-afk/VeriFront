#!/usr/bin/env python3
"""
RRV analysis for biosignals/bio_eventrelated_100hz.csv.

This script:
- loads the RSP channel sampled at 100 Hz
- cleans/filters the respiration signal
- extracts inhalation peaks and respiratory rate
- computes respiratory-rate-variability (RRV) features:
  time-domain, frequency-domain, nonlinear, and descriptive signal features
- saves one-row results to pred_results/rrv_analysis_pred.csv
"""

import os
import json
import warnings
import numpy as np
import pandas as pd

from scipy import signal, interpolate, stats

warnings.filterwarnings("ignore", category=RuntimeWarning)

INPUT = "biosignals/bio_eventrelated_100hz.csv"
OUTDIR = "pred_results"
OUTFILE = os.path.join(OUTDIR, "rrv_analysis_pred.csv")
FS = 100.0


def as_float_array(x):
    x = pd.to_numeric(pd.Series(x), errors="coerce").astype(float)
    if x.isna().any():
        x = x.interpolate(limit_direction="both").ffill().bfill()
    return x.to_numpy(dtype=float)


def bandpass_clean_rsp(rsp, fs=100.0, low=0.05, high=1.0, order=4):
    """Detrend and bandpass-filter respiration to retain plausible breathing rhythm."""
    x = np.asarray(rsp, dtype=float)
    x = signal.detrend(x, type="linear")
    nyq = fs / 2.0
    low = max(low / nyq, 1e-5)
    high = min(high / nyq, 0.999)
    b, a = signal.butter(order, [low, high], btype="bandpass")
    try:
        y = signal.filtfilt(b, a, x)
    except Exception:
        y = signal.lfilter(b, a, x)
    return y


def robust_peak_detection(clean, fs=100.0):
    """
    Detect inhalation peaks from a cleaned RSP signal.
    Uses conservative constraints for typical respiration:
    distance >= 1.5 s, prominence based on robust signal scale.
    """
    x = np.asarray(clean, dtype=float)
    robust_sd = 1.4826 * np.nanmedian(np.abs(x - np.nanmedian(x)))
    if not np.isfinite(robust_sd) or robust_sd <= 0:
        robust_sd = np.nanstd(x)
    if not np.isfinite(robust_sd) or robust_sd <= 0:
        robust_sd = 1.0

    min_distance = int(round(1.5 * fs))
    # Try increasingly permissive prominence thresholds until a reasonable number of peaks is found.
    best_peaks = np.array([], dtype=int)
    best_props = {}
    for prom_factor in [0.35, 0.25, 0.15, 0.08, 0.04]:
        peaks, props = signal.find_peaks(
            x,
            distance=min_distance,
            prominence=prom_factor * robust_sd,
        )
        if len(peaks) > len(best_peaks):
            best_peaks, best_props = peaks, props
        if len(peaks) >= 4:
            return peaks.astype(int), props

    # Fallback: only distance constraint.
    if len(best_peaks) < 3:
        peaks, props = signal.find_peaks(x, distance=min_distance)
        if len(peaks) > len(best_peaks):
            best_peaks, best_props = peaks, props

    return best_peaks.astype(int), best_props


def remove_implausible_intervals(peaks, fs=100.0, min_period=1.5, max_period=15.0):
    """Remove peaks causing implausible breath-to-breath intervals."""
    peaks = np.asarray(peaks, dtype=int)
    if len(peaks) < 3:
        return peaks

    keep = np.ones(len(peaks), dtype=bool)
    intervals = np.diff(peaks) / fs
    bad = (intervals < min_period) | (intervals > max_period)

    # Iteratively remove the latter peak in bad short intervals and leave long gaps as missed breaths.
    # For long intervals, keeping both endpoints is preferable for valid observed intervals.
    for i, is_bad in enumerate(bad):
        if is_bad and intervals[i] < min_period and i + 1 < len(keep):
            keep[i + 1] = False

    peaks2 = peaks[keep]
    if len(peaks2) >= 3:
        return peaks2
    return peaks


def compute_resp_rate_signal(peaks, n_samples, fs=100.0):
    """Interpolate instantaneous respiratory rate in breaths/min over the full recording."""
    rate = np.full(n_samples, np.nan, dtype=float)
    peaks = np.asarray(peaks, dtype=int)
    if len(peaks) < 2:
        return rate

    intervals_s = np.diff(peaks) / fs
    inst_rate = 60.0 / intervals_s
    # Rate samples are assigned to midpoints between consecutive inhalation peaks.
    mid_t = (peaks[:-1] + peaks[1:]) / (2.0 * fs)
    all_t = np.arange(n_samples) / fs

    valid = np.isfinite(inst_rate) & (inst_rate > 0) & (inst_rate < 60)
    if np.sum(valid) == 0:
        return rate
    if np.sum(valid) == 1:
        rate[:] = inst_rate[valid][0]
        return rate

    f = interpolate.interp1d(
        mid_t[valid],
        inst_rate[valid],
        kind="linear",
        bounds_error=False,
        fill_value=(inst_rate[valid][0], inst_rate[valid][-1]),
    )
    return f(all_t)


def safe_stat_features(prefix, values):
    v = np.asarray(values, dtype=float)
    v = v[np.isfinite(v)]
    out = {}
    if len(v) == 0:
        for name in ["Mean", "Median", "SD", "Min", "Max", "Range", "IQR", "CV", "Skew", "Kurtosis"]:
            out[f"{prefix}_{name}"] = np.nan
        return out

    out[f"{prefix}_Mean"] = float(np.mean(v))
    out[f"{prefix}_Median"] = float(np.median(v))
    out[f"{prefix}_SD"] = float(np.std(v, ddof=1)) if len(v) > 1 else 0.0
    out[f"{prefix}_Min"] = float(np.min(v))
    out[f"{prefix}_Max"] = float(np.max(v))
    out[f"{prefix}_Range"] = float(np.max(v) - np.min(v))
    out[f"{prefix}_IQR"] = float(np.percentile(v, 75) - np.percentile(v, 25))
    out[f"{prefix}_CV"] = float(out[f"{prefix}_SD"] / out[f"{prefix}_Mean"]) if out[f"{prefix}_Mean"] != 0 else np.nan
    out[f"{prefix}_Skew"] = float(stats.skew(v, bias=False)) if len(v) > 2 else np.nan
    out[f"{prefix}_Kurtosis"] = float(stats.kurtosis(v, bias=False)) if len(v) > 3 else np.nan
    return out


def sample_entropy(x, m=2, r=None):
    """Simple SampEn implementation for short 1-D series."""
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n <= m + 2:
        return np.nan
    if r is None:
        sd = np.std(x, ddof=0)
        if sd == 0 or not np.isfinite(sd):
            return np.nan
        r = 0.2 * sd

    def _count(mm):
        count = 0
        total = 0
        for i in range(n - mm):
            template = x[i:i + mm]
            comp = np.array([np.max(np.abs(template - x[j:j + mm])) for j in range(i + 1, n - mm + 1)])
            count += np.sum(comp <= r)
            total += len(comp)
        return count, total

    b, _ = _count(m)
    a, _ = _count(m + 1)
    if b == 0 or a == 0:
        return np.nan
    return float(-np.log(a / b))


def approximate_entropy(x, m=2, r=None):
    """Approximate entropy for 1-D series."""
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n <= m + 2:
        return np.nan
    if r is None:
        sd = np.std(x, ddof=0)
        if sd == 0 or not np.isfinite(sd):
            return np.nan
        r = 0.2 * sd

    def phi(mm):
        patterns = np.array([x[i:i + mm] for i in range(n - mm + 1)])
        c = []
        for p in patterns:
            d = np.max(np.abs(patterns - p), axis=1)
            c.append(np.mean(d <= r))
        c = np.asarray(c)
        c = c[c > 0]
        if len(c) == 0:
            return np.nan
        return np.mean(np.log(c))

    p1 = phi(m)
    p2 = phi(m + 1)
    if not np.isfinite(p1) or not np.isfinite(p2):
        return np.nan
    return float(p1 - p2)


def dfa_alpha(x):
    """Detrended fluctuation analysis alpha over feasible small scales."""
    x = np.asarray(x, dtype=float)
    x = x[np.isfinite(x)]
    n = len(x)
    if n < 12:
        return np.nan
    y = np.cumsum(x - np.mean(x))
    scales = np.unique(np.floor(np.logspace(np.log10(4), np.log10(max(5, n // 4)), 8)).astype(int))
    flucts = []
    used = []
    for s in scales:
        if s < 4 or 2 * s > n:
            continue
        segments = n // s
        rms = []
        for k in range(segments):
            seg = y[k * s:(k + 1) * s]
            t = np.arange(s)
            coef = np.polyfit(t, seg, 1)
            trend = np.polyval(coef, t)
            rms.append(np.sqrt(np.mean((seg - trend) ** 2)))
        f = np.sqrt(np.mean(np.asarray(rms) ** 2))
        if np.isfinite(f) and f > 0:
            flucts.append(f)
            used.append(s)
    if len(flucts) < 2:
        return np.nan
    return float(np.polyfit(np.log(used), np.log(flucts), 1)[0])


def compute_cycle_amplitudes(clean, peaks, fs=100.0):
    """Amplitude for each inhalation peak relative to preceding trough."""
    x = np.asarray(clean, dtype=float)
    peaks = np.asarray(peaks, dtype=int)
    troughs, _ = signal.find_peaks(-x, distance=int(1.0 * fs))
    amps = []
    for p in peaks:
        prev_troughs = troughs[troughs < p]
        if len(prev_troughs) == 0:
            continue
        tr = prev_troughs[-1]
        amps.append(x[p] - x[tr])
    return np.asarray(amps, dtype=float)


def frequency_domain_features(intervals_s, peak_times_s):
    """
    Frequency-domain RRV on breath-interval tachogram.
    Interpolates intervals at 4 Hz and uses Welch PSD.
    """
    out = {}
    bands = {
        "VLF": (0.0033, 0.04),
        "LF": (0.04, 0.15),
        "HF": (0.15, 0.40),
        "Total": (0.0033, 0.40),
    }
    for band in bands:
        out[f"RRV_Frequency_{band}_Power"] = np.nan
    out["RRV_Frequency_LFHF_Ratio"] = np.nan
    out["RRV_Frequency_LF_Norm"] = np.nan
    out["RRV_Frequency_HF_Norm"] = np.nan
    out["RRV_Frequency_Peak"] = np.nan

    intervals_s = np.asarray(intervals_s, dtype=float)
    peak_times_s = np.asarray(peak_times_s, dtype=float)
    if len(intervals_s) < 4 or len(peak_times_s) < 4:
        return out

    # Interval values are located at midpoints between peaks.
    t = (peak_times_s[:-1] + peak_times_s[1:]) / 2.0
    valid = np.isfinite(intervals_s) & np.isfinite(t) & (intervals_s > 0)
    t = t[valid]
    y = intervals_s[valid]
    if len(y) < 4 or np.ptp(t) <= 10:
        return out

    fs_interp = 4.0
    ti = np.arange(t[0], t[-1], 1.0 / fs_interp)
    if len(ti) < 16:
        return out

    yi = interpolate.interp1d(t, y, kind="linear", bounds_error=False, fill_value="extrapolate")(ti)
    yi = signal.detrend(yi)
    if np.nanstd(yi) == 0:
        return out

    nperseg = min(256, len(yi))
    if nperseg < 16:
        return out
    freqs, psd = signal.welch(yi, fs=fs_interp, nperseg=nperseg, noverlap=nperseg // 2)

    for band, (lo, hi) in bands.items():
        mask = (freqs >= lo) & (freqs < hi)
        if np.any(mask):
            out[f"RRV_Frequency_{band}_Power"] = float(np.trapz(psd[mask], freqs[mask]))

    lf = out["RRV_Frequency_LF_Power"]
    hf = out["RRV_Frequency_HF_Power"]
    total = out["RRV_Frequency_Total_Power"]
    if np.isfinite(lf) and np.isfinite(hf) and hf > 0:
        out["RRV_Frequency_LFHF_Ratio"] = float(lf / hf)
    if np.isfinite(total) and total > 0:
        out["RRV_Frequency_LF_Norm"] = float(lf / total) if np.isfinite(lf) else np.nan
        out["RRV_Frequency_HF_Norm"] = float(hf / total) if np.isfinite(hf) else np.nan
    mask_total = (freqs >= 0.0033) & (freqs < 0.40)
    if np.any(mask_total):
        out["RRV_Frequency_Peak"] = float(freqs[mask_total][np.argmax(psd[mask_total])])
    return out


def compute_rrv_features(rsp, fs=100.0):
    clean = bandpass_clean_rsp(rsp, fs=fs)
    peaks, props = robust_peak_detection(clean, fs=fs)
    peaks = remove_implausible_intervals(peaks, fs=fs)

    n = len(rsp)
    duration_s = n / fs
    peak_times_s = peaks / fs
    intervals_s = np.diff(peak_times_s)
    # Keep physiologically plausible observed intervals for variability statistics.
    valid_intervals = intervals_s[(intervals_s >= 1.5) & (intervals_s <= 15.0)]
    intervals_ms = valid_intervals * 1000.0
    rate_signal = compute_resp_rate_signal(peaks, n, fs=fs)
    amplitudes = compute_cycle_amplitudes(clean, peaks, fs=fs)

    features = {
        "Sampling_Rate_Hz": float(fs),
        "Recording_Duration_s": float(duration_s),
        "RSP_Peaks_N": int(len(peaks)),
        "RSP_Valid_Intervals_N": int(len(valid_intervals)),
        "RSP_Peaks_Per_Min": float(len(peaks) / duration_s * 60.0) if duration_s > 0 else np.nan,
        "RSP_Clean_Mean": float(np.mean(clean)),
        "RSP_Clean_SD": float(np.std(clean, ddof=1)) if len(clean) > 1 else 0.0,
    }

    # Time-domain RRV from breath-to-breath intervals.
    features.update(safe_stat_features("RRV_Time_BBI_ms", intervals_ms))
    if len(intervals_ms) >= 2:
        diff_ms = np.diff(intervals_ms)
        features["RRV_Time_RMSSD_ms"] = float(np.sqrt(np.mean(diff_ms ** 2)))
        features["RRV_Time_SDSD_ms"] = float(np.std(diff_ms, ddof=1)) if len(diff_ms) > 1 else 0.0
        features["RRV_Time_pNN50"] = float(np.mean(np.abs(diff_ms) > 50.0) * 100.0)
        features["RRV_Time_pNN100"] = float(np.mean(np.abs(diff_ms) > 100.0) * 100.0)
        features["RRV_Time_MCVBBI"] = float(np.median(np.abs(intervals_ms - np.median(intervals_ms))) / np.median(intervals_ms)) if np.median(intervals_ms) != 0 else np.nan
    else:
        for k in ["RRV_Time_RMSSD_ms", "RRV_Time_SDSD_ms", "RRV_Time_pNN50", "RRV_Time_pNN100", "RRV_Time_MCVBBI"]:
            features[k] = np.nan

    # Respiratory rate signal descriptors.
    features.update(safe_stat_features("RSP_Rate_bpm", rate_signal))
    if len(valid_intervals) > 0:
        inst_rate_bpm = 60.0 / valid_intervals
    else:
        inst_rate_bpm = np.array([])
    features.update(safe_stat_features("RRV_InstantRate_bpm", inst_rate_bpm))

    # Amplitude descriptors.
    features.update(safe_stat_features("RSP_Amplitude", amplitudes))

    # Frequency domain.
    features.update(frequency_domain_features(valid_intervals, peak_times_s[:len(intervals_s) + 1]))

    # Nonlinear features from breath intervals.
    features["RRV_Nonlinear_SampEn"] = sample_entropy(intervals_ms)
    features["RRV_Nonlinear_ApEn"] = approximate_entropy(intervals_ms)
    features["RRV_Nonlinear_DFA_alpha"] = dfa_alpha(intervals_ms)

    if len(intervals_ms) >= 2:
        x1 = intervals_ms[:-1]
        x2 = intervals_ms[1:]
        diff = x2 - x1
        summ = x2 + x1
        sd1 = np.sqrt(np.var(diff, ddof=1) / 2.0) if len(diff) > 1 else np.nan
        sd2 = np.sqrt(np.var(summ, ddof=1) / 2.0) if len(summ) > 1 else np.nan
        features["RRV_Nonlinear_SD1_ms"] = float(sd1) if np.isfinite(sd1) else np.nan
        features["RRV_Nonlinear_SD2_ms"] = float(sd2) if np.isfinite(sd2) else np.nan
        features["RRV_Nonlinear_SD1SD2_Ratio"] = float(sd1 / sd2) if np.isfinite(sd1) and np.isfinite(sd2) and sd2 != 0 else np.nan
        features["RRV_Nonlinear_Ellipse_Area"] = float(np.pi * sd1 * sd2) if np.isfinite(sd1) and np.isfinite(sd2) else np.nan
    else:
        features["RRV_Nonlinear_SD1_ms"] = np.nan
        features["RRV_Nonlinear_SD2_ms"] = np.nan
        features["RRV_Nonlinear_SD1SD2_Ratio"] = np.nan
        features["RRV_Nonlinear_Ellipse_Area"] = np.nan

    # Metadata about extracted features for traceability.
    features["First_Inhalation_Peak_s"] = float(peak_times_s[0]) if len(peak_times_s) else np.nan
    features["Last_Inhalation_Peak_s"] = float(peak_times_s[-1]) if len(peak_times_s) else np.nan

    return features, clean, peaks, rate_signal


def main():
    os.makedirs(OUTDIR, exist_ok=True)

    print(f"Loading {INPUT}")
    df = pd.read_csv(INPUT)
    print(f"Columns: {list(df.columns)}")
    print(f"Rows: {len(df)}")

    if "RSP" not in df.columns:
        raise ValueError("Input file does not contain required RSP column.")

    rsp = as_float_array(df["RSP"])
    features, clean, peaks, rate_signal = compute_rrv_features(rsp, fs=FS)

    # Save final required CSV.
    result = pd.DataFrame([features])
    # Stable ordering: identifiers first, then alphabetical for remaining fields.
    first_cols = [
        "Sampling_Rate_Hz", "Recording_Duration_s", "RSP_Peaks_N",
        "RSP_Valid_Intervals_N", "RSP_Peaks_Per_Min",
        "First_Inhalation_Peak_s", "Last_Inhalation_Peak_s",
    ]
    cols = [c for c in first_cols if c in result.columns] + sorted([c for c in result.columns if c not in first_cols])
    result = result[cols]
    result.to_csv(OUTFILE, index=False)

    # Also save lightweight extraction metadata to aid reproducibility (not required by benchmark).
    meta = {
        "input": INPUT,
        "output": OUTFILE,
        "sampling_rate_hz": FS,
        "n_samples": int(len(rsp)),
        "duration_s": float(len(rsp) / FS),
        "n_inhalation_peaks": int(len(peaks)),
        "first_10_peak_samples": [int(x) for x in peaks[:10]],
        "first_10_peak_seconds": [float(x / FS) for x in peaks[:10]],
        "feature_count": int(result.shape[1]),
    }
    with open(os.path.join(OUTDIR, "rrv_analysis_pred_metadata.json"), "w") as f:
        json.dump(meta, f, indent=2)

    print("RRV analysis complete.")
    print(f"Detected inhalation peaks: {len(peaks)}")
    print(f"Duration (s): {len(rsp) / FS:.2f}")
    print(f"Mean interpolated respiratory rate (bpm): {features.get('RSP_Rate_bpm_Mean', np.nan):.4f}")
    print(f"Mean breath-to-breath interval (ms): {features.get('RRV_Time_BBI_ms_Mean', np.nan):.4f}")
    print(f"RMSSD (ms): {features.get('RRV_Time_RMSSD_ms', np.nan):.4f}")
    print(f"LF power: {features.get('RRV_Frequency_LF_Power', np.nan):.8g}")
    print(f"HF power: {features.get('RRV_Frequency_HF_Power', np.nan):.8g}")
    print(f"Sample entropy: {features.get('RRV_Nonlinear_SampEn', np.nan)}")
    print(f"Saved: {OUTFILE}")
    print(f"Output shape: {result.shape}")
    print("First columns and values:")
    print(result.iloc[:, :min(12, result.shape[1])].to_string(index=False))


if __name__ == "__main__":
    main()