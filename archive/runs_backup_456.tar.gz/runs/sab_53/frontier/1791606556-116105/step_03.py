#!/usr/bin/env python3
"""
Diagnostic + robust reclassification script.

The previous search only looked in the current run directory. This turn searches
nearby/common benchmark data locations, prints what is found, and if rasters are
located writes:
  pred_results/landCover_reclassified.tif
  pred_results/protected_status_reclassified.tif
"""

from pathlib import Path
import sys
import os
import numpy as np

try:
    import rasterio
except Exception as e:
    print("ERROR: rasterio import failed:", repr(e))
    sys.exit(1)

cwd = Path.cwd()
print("Current working directory:", cwd)

search_roots = []
for root in [
    cwd,
    cwd / "benchmark",
    cwd.parent,
    cwd.parent / "benchmark",
    Path("/data/lab/VeriFront"),
    Path("/data/lab/VeriFront/datasets"),
    Path("/data/lab/VeriFront/benchmark"),
    Path("/mnt/data"),
    Path("/data"),
]:
    if root.exists() and root.is_dir() and root not in search_roots:
        search_roots.append(root)

print("\nSearch roots:")
for r in search_roots:
    print(" ", r)

# Limit very broad searches; first do focused MountainLionNew directory search.
candidate_dirs = []
for root in search_roots:
    try:
        for p in root.rglob("MountainLionNew"):
            if p.is_dir():
                candidate_dirs.append(p)
    except Exception as e:
        print(f"  Warning: could not search for MountainLionNew under {root}: {e}")

print("\nCandidate MountainLionNew dirs:")
for d in candidate_dirs:
    print(" ", d)

all_tifs = []
if candidate_dirs:
    for d in candidate_dirs:
        try:
            all_tifs.extend(sorted(d.rglob("*.tif")))
        except Exception as e:
            print(f"  Warning: could not list tifs in {d}: {e}")
else:
    # Focused fallback: only within not-too-broad roots first.
    for root in search_roots[:4]:
        try:
            all_tifs.extend(sorted(root.rglob("*.tif")))
        except Exception as e:
            print(f"  Warning: could not search tifs under {root}: {e}")

# Deduplicate preserving order
seen = set()
dedup = []
for p in all_tifs:
    rp = str(p.resolve()) if p.exists() else str(p)
    if rp not in seen:
        dedup.append(p)
        seen.add(rp)
all_tifs = dedup

print(f"\nFound {len(all_tifs)} tif files in focused search:")
for p in all_tifs[:200]:
    print(" ", p)
if len(all_tifs) > 200:
    print(" ... truncated listing ...")

def find_exact_or_case(name_options):
    opts = {n.lower() for n in name_options}
    matches = [p for p in all_tifs if p.name.lower() in opts]
    if matches:
        # Prefer file inside a MountainLionNew folder and not already reclassified.
        matches = sorted(matches, key=lambda p: (0 if "mountainlionnew" in str(p).lower() else 1, len(str(p))))
        return matches[0]
    return None

land_src = find_exact_or_case(["landCover.tif", "landcover.tif"])
prot_src = find_exact_or_case(["Protected_Status.tif", "protected_status.tif"])

print("\nSelected inputs:")
print(" landCover:", land_src)
print(" Protected_Status:", prot_src)

if land_src is None or prot_src is None:
    print("\nCould not find exact rasters. Inspecting benchmark tree up to depth 4:")
    base = cwd / "benchmark"
    if base.exists():
        for dirpath, dirnames, filenames in os.walk(base):
            depth = Path(dirpath).relative_to(base).parts
            if len(depth) > 4:
                dirnames[:] = []
                continue
            print("DIR", dirpath)
            for fn in filenames[:20]:
                print("  FILE", fn)
            if len(filenames) > 20:
                print("  ...")
    print("ERROR: Required input rasters still not found.")
    sys.exit(1)

OUT_DIR = Path("pred_results")
OUT_DIR.mkdir(parents=True, exist_ok=True)

landCover_classification = {
    11: 10, 21: 8, 22: 7, 23: 8, 24: 9, 31: 6, 41: 2, 42: 1, 43: 2,
    52: 3, 71: 3, 72: 3, 81: 4, 82: 6, 90: 4, 95: 4, 255: 10,
}
protected_status_classification = {0: 1, 1: 3, 2: 6, 3: 9, 4: 10, 255: 10}

def reclassify_raster(src_path, dst_path, mapping, default_value=0):
    with rasterio.open(src_path) as src:
        arr = src.read(1)
        profile = src.profile.copy()
        unique_in = np.unique(arr)

        out = np.full(arr.shape, default_value, dtype=np.uint8)
        for old, new in mapping.items():
            out[arr == old] = np.uint8(new)

        unmapped = sorted(set(map(int, unique_in.tolist())) - set(map(int, mapping.keys())))

        profile.update(dtype=rasterio.uint8, count=1, compress="lzw")
        # Use 0 as nodata/background only if it occurs in output; otherwise preserve source nodata where possible.
        src_nodata = profile.get("nodata", None)
        if src_nodata is not None and 0 <= int(src_nodata) <= 255:
            # If source nodata is a mapped value (e.g. 255), the output nodata should be its mapped value.
            profile["nodata"] = mapping.get(int(src_nodata), int(src_nodata))
        elif np.any(out == default_value):
            profile["nodata"] = default_value
        else:
            profile.pop("nodata", None)

        with rasterio.open(dst_path, "w", **profile) as dst:
            dst.write(out, 1)

    vals, counts = np.unique(out, return_counts=True)
    print(f"\nWrote {dst_path}")
    print(f"  Source: {src_path}")
    print(f"  Shape: {arr.shape}")
    print(f"  Input dtype: {arr.dtype}; output dtype: {out.dtype}")
    print(f"  Input unique values: {unique_in.tolist()}")
    print(f"  Unmapped input values assigned to {default_value}: {unmapped}")
    print(f"  Output unique/counts: {dict(zip(vals.astype(int).tolist(), counts.astype(int).tolist()))}")
    with rasterio.open(dst_path) as chk:
        print(f"  Verified metadata: width={chk.width}, height={chk.height}, count={chk.count}, dtype={chk.dtypes[0]}, crs={chk.crs}, nodata={chk.nodata}")

reclassify_raster(land_src, OUT_DIR / "landCover_reclassified.tif", landCover_classification, default_value=0)
reclassify_raster(prot_src, OUT_DIR / "protected_status_reclassified.tif", protected_status_classification, default_value=0)

print("\nDone.")
print("Required output:", OUT_DIR / "landCover_reclassified.tif", "exists=", (OUT_DIR / "landCover_reclassified.tif").exists())
print("Protected output:", OUT_DIR / "protected_status_reclassified.tif", "exists=", (OUT_DIR / "protected_status_reclassified.tif").exists())