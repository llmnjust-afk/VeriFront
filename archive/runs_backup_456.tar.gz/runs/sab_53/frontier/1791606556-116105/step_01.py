#!/usr/bin/env python3
"""
Reclassify categorical land cover and protected status rasters to a common
1-10 suitability/standardized scale for mountain lion habitat analysis.

Outputs:
  pred_results/landCover_reclassified.tif
  pred_results/protected_status_reclassified.tif
"""

from pathlib import Path
import sys

import numpy as np

try:
    import rasterio
except Exception as e:
    print("ERROR: rasterio is required but could not be imported:", repr(e))
    sys.exit(1)


DATA_DIR = Path("MountainLionNew")
OUT_DIR = Path("pred_results")
OUT_DIR.mkdir(parents=True, exist_ok=True)

landCover_classification = {
    11: 10,  # Open Water
    21: 8,   # Developed, Open Space
    22: 7,   # Developed, Low Intensity
    23: 8,   # Developed, Medium Intensity
    24: 9,   # Developed, High Intensity
    31: 6,   # Barren Land
    41: 2,   # Deciduous Forest
    42: 1,   # Evergreen Forest
    43: 2,   # Mixed Forest
    52: 3,   # Shrub/Scrub
    71: 3,   # Grassland/Herbaceous
    72: 3,   # Sedge/Herbaceous
    81: 4,   # Hay/Pasture
    82: 6,   # Cultivated Crops
    90: 4,   # Woody Wetlands
    95: 4,   # Emergent Herbaceous Wetlands
    255: 10,
}

protected_status_classification = {
    0: 1,
    1: 3,
    2: 6,
    3: 9,
    4: 10,
    255: 10,
}


def reclassify_raster(src_path: Path, dst_path: Path, mapping: dict, default_value: int = 0):
    """Read a single-band categorical raster, reclassify by exact value lookup, and save GeoTIFF."""
    if not src_path.exists():
        raise FileNotFoundError(f"Input raster not found: {src_path}")

    with rasterio.open(src_path) as src:
        arr = src.read(1)
        profile = src.profile.copy()

        unique_in = np.unique(arr)
        mapping_keys = set(int(k) for k in mapping.keys())
        input_values = set(int(v) for v in unique_in.tolist())
        unmapped = sorted(input_values - mapping_keys)

        # Initialize to default_value so true NoData / unexpected classes are explicit.
        out = np.full(arr.shape, default_value, dtype=np.uint8)

        # Exact categorical lookup.
        for old_value, new_value in mapping.items():
            out[arr == old_value] = np.uint8(new_value)

        # Preserve georeferencing and make output compact and analysis-friendly.
        profile.update(
            dtype=rasterio.uint8,
            count=1,
            nodata=default_value if default_value in unmapped else profile.get("nodata", None),
            compress="lzw",
            tiled=False,
        )

        # If nodata is None but rasterio profile has invalid key value, keep it as None.
        if profile["nodata"] is None:
            profile.pop("nodata", None)

        with rasterio.open(dst_path, "w", **profile) as dst:
            dst.write(out, 1)

    unique_out, counts_out = np.unique(out, return_counts=True)
    print(f"\nReclassified: {src_path} -> {dst_path}")
    print(f"  shape: {arr.shape}")
    print(f"  input dtype: {arr.dtype}; output dtype: {out.dtype}")
    print(f"  input unique values: {unique_in.tolist()}")
    print(f"  unmapped input values assigned to {default_value}: {unmapped}")
    print(f"  output unique values and counts:")
    for val, count in zip(unique_out.tolist(), counts_out.tolist()):
        print(f"    {val}: {count}")

    # Re-open to verify file is readable and metadata was written.
    with rasterio.open(dst_path) as check:
        print(f"  verified output exists: {dst_path.exists()}")
        print(f"  verified CRS: {check.crs}")
        print(f"  verified transform: {check.transform}")
        print(f"  verified nodata: {check.nodata}")
        print(f"  verified dimensions: width={check.width}, height={check.height}, count={check.count}")


def main():
    print("Starting categorical raster reclassification.")
    print(f"Working directory outputs will be saved under: {OUT_DIR.resolve()}")

    land_src = DATA_DIR / "landCover.tif"
    prot_src = DATA_DIR / "Protected_Status.tif"

    land_dst = OUT_DIR / "landCover_reclassified.tif"
    prot_dst = OUT_DIR / "protected_status_reclassified.tif"

    # For land cover, class 0 appears in the raster preview but is not in the supplied
    # classification dictionary; keep it as output 0 / NoData-like background.
    reclassify_raster(
        src_path=land_src,
        dst_path=land_dst,
        mapping=landCover_classification,
        default_value=0,
    )

    # Protected status dictionary covers all expected values, including 0 and 255.
    # Any unexpected value would be written as 0.
    reclassify_raster(
        src_path=prot_src,
        dst_path=prot_dst,
        mapping=protected_status_classification,
        default_value=0,
    )

    print("\nDone.")
    print(f"Required output written: {land_dst}")
    print(f"Additional protected-status output written: {prot_dst}")


if __name__ == "__main__":
    main()