#!/usr/bin/env python3
"""
Locate the dataset rasters in the working directory tree, then reclassify
landCover and Protected_Status rasters if found.
"""

from pathlib import Path
import sys
import numpy as np

try:
    import rasterio
except Exception as e:
    print("ERROR: rasterio import failed:", repr(e))
    sys.exit(1)


print("Current working directory:", Path.cwd())
print("Top-level entries:")
for p in sorted(Path(".").iterdir()):
    print(" ", p, "DIR" if p.is_dir() else "FILE")

print("\nSearching for candidate rasters...")
all_tifs = sorted(Path(".").rglob("*.tif"))
for p in all_tifs:
    print(" ", p)

def find_one(names):
    lower_names = {n.lower() for n in names}
    matches = [p for p in all_tifs if p.name.lower() in lower_names]
    if matches:
        return matches[0]
    # fallback: stem contains tokens
    for p in all_tifs:
        n = p.name.lower()
        for target in lower_names:
            if target.replace(".tif", "") in n:
                return p
    return None

land_src = find_one(["landCover.tif", "landcover.tif"])
prot_src = find_one(["Protected_Status.tif", "protected_status.tif"])

print("\nSelected inputs:")
print(" landCover:", land_src)
print(" Protected_Status:", prot_src)

if land_src is None or prot_src is None:
    print("ERROR: Could not locate required input rasters. Stopping after diagnostic listing.")
    sys.exit(1)

OUT_DIR = Path("pred_results")
OUT_DIR.mkdir(parents=True, exist_ok=True)

landCover_classification = {
    11: 10,
    21: 8,
    22: 7,
    23: 8,
    24: 9,
    31: 6,
    41: 2,
    42: 1,
    43: 2,
    52: 3,
    71: 3,
    72: 3,
    81: 4,
    82: 6,
    90: 4,
    95: 4,
    255: 10,
}

protected_status_classification = {
    0: 1,
    1: 3,
    2: 6,
    3: 9,
    4: 10,
    255: 10,
}

def reclassify_raster(src_path, dst_path, mapping, default_value=0):
    with rasterio.open(src_path) as src:
        arr = src.read(1)
        profile = src.profile.copy()
        unique_in = np.unique(arr)

        out = np.full(arr.shape, default_value, dtype=np.uint8)
        for old, new in mapping.items():
            out[arr == old] = np.uint8(new)

        unmapped = sorted(set(int(v) for v in unique_in.tolist()) - set(int(k) for k in mapping))
        profile.update(dtype="uint8", count=1, compress="lzw")
        # Keep existing nodata if present; otherwise use 0 only when unmapped/background exists.
        if profile.get("nodata") is not None:
            profile["nodata"] = int(profile["nodata"])
        elif default_value in out:
            profile["nodata"] = default_value

        with rasterio.open(dst_path, "w", **profile) as dst:
            dst.write(out, 1)

    vals, counts = np.unique(out, return_counts=True)
    print(f"\nWrote {dst_path}")
    print(" input:", src_path)
    print(" shape:", arr.shape)
    print(" input unique:", unique_in.tolist())
    print(" unmapped input values assigned to", default_value, ":", unmapped)
    print(" output unique/counts:", dict(zip(vals.astype(int).tolist(), counts.astype(int).tolist())))
    with rasterio.open(dst_path) as chk:
        print(" verify readable:", chk.width, chk.height, chk.count, chk.dtypes, chk.crs, chk.nodata)

reclassify_raster(land_src, OUT_DIR / "landCover_reclassified.tif", landCover_classification, default_value=0)
reclassify_raster(prot_src, OUT_DIR / "protected_status_reclassified.tif", protected_status_classification, default_value=0)

print("\nDone. Required file exists:", (OUT_DIR / "landCover_reclassified.tif").exists())
print("Additional file exists:", (OUT_DIR / "protected_status_reclassified.tif").exists())