#!/usr/bin/env python3
"""
Reclassify land cover and protected status rasters to a common scale for
mountain lion habitat analysis.

Outputs:
  pred_results/landCover_reclassified.tif
  pred_results/protected_status_reclassified.tif
"""
from pathlib import Path
import sys
import numpy as np

try:
    import rasterio
except Exception as e:
    print("ERROR: rasterio is required but could not be imported:", repr(e))
    sys.exit(1)

# Input/output paths
base = Path("MountainLionNew")
out_dir = Path("pred_results")
out_dir.mkdir(parents=True, exist_ok=True)

land_in = base / "landCover.tif"
prot_in = base / "Protected_Status.tif"
land_out = out_dir / "landCover_reclassified.tif"
prot_out = out_dir / "protected_status_reclassified.tif"

# Classification dictionaries from task
landCover_classification = {
    11: 10,  # Open Water
    21: 8,   # Developed, Open Space
    22: 7,   # Developed, Low Intensity
    23: 8,   # Developed, Medium Intensity
    24: 9,   # Developed, High Intensity
    31: 6,   # Barren Land
    41: 2,   # Deciduous Forest
    42: 1,   # Evergreen Forest
    43: 2,   # Mixed Forest
    52: 3,   # Shrub/Scrub
    71: 3,   # Grassland/Herbaceous
    72: 3,   # Sedge/Herbaceous
    81: 4,   # Hay/Pasture
    82: 6,   # Cultivated Crops
    90: 4,   # Woody Wetlands
    95: 4,   # Emergent Herbaceous Wetlands
    255: 10,
}

protected_status_classification = {
    0: 1,
    1: 3,
    2: 6,
    3: 9,
    4: 10,
    255: 10,
}

def reclassify_raster(src_path: Path, dst_path: Path, mapping: dict, default_value: int = 0):
    if not src_path.exists():
        raise FileNotFoundError(f"Input raster not found: {src_path}")

    with rasterio.open(src_path) as src:
        profile = src.profile.copy()
        arr = src.read(1)

        # Build a 0..255 lookup table for uint8 categorical rasters.
        lut = np.full(256, default_value, dtype=np.uint8)
        for k, v in mapping.items():
            if not (0 <= int(k) <= 255):
                raise ValueError(f"Mapping key outside uint8 range: {k}")
            lut[int(k)] = np.uint8(v)

        if arr.dtype == np.uint8:
            out = lut[arr]
        else:
            out = np.full(arr.shape, default_value, dtype=np.uint8)
            for k, v in mapping.items():
                out[arr == k] = np.uint8(v)

        # Preserve georeferencing/projection/transform; write standardized byte classes.
        profile.update(
            dtype=rasterio.uint8,
            count=1,
            compress="lzw",
            nodata=None
        )

        with rasterio.open(dst_path, "w", **profile) as dst:
            dst.write(out, 1)

        in_vals, in_counts = np.unique(arr, return_counts=True)
        out_vals, out_counts = np.unique(out, return_counts=True)
        unmapped = sorted(int(v) for v in in_vals if int(v) not in mapping)

        return {
            "src": str(src_path),
            "dst": str(dst_path),
            "shape": arr.shape,
            "crs": str(src.crs),
            "transform": tuple(src.transform),
            "input_counts": dict(zip([int(v) for v in in_vals], [int(c) for c in in_counts])),
            "output_counts": dict(zip([int(v) for v in out_vals], [int(c) for c in out_counts])),
            "unmapped_input_values_defaulted_to_0": unmapped,
        }

def main():
    print("Starting categorical raster reclassification...")
    print(f"Input land cover: {land_in}")
    print(f"Input protected status: {prot_in}")
    print(f"Output directory: {out_dir.resolve()}")

    land_info = reclassify_raster(land_in, land_out, landCover_classification)
    prot_info = reclassify_raster(prot_in, prot_out, protected_status_classification)

    print("\nLand cover reclassification summary:")
    for k, v in land_info.items():
        print(f"  {k}: {v}")

    print("\nProtected status reclassification summary:")
    for k, v in prot_info.items():
        print(f"  {k}: {v}")

    # Verify files can be reopened and report final metadata.
    print("\nVerification:")
    for p in [land_out, prot_out]:
        with rasterio.open(p) as ds:
            data = ds.read(1)
            vals, counts = np.unique(data, return_counts=True)
            print(f"  {p}: exists={p.exists()}, size_bytes={p.stat().st_size}, "
                  f"shape={(ds.height, ds.width)}, dtype={ds.dtypes[0]}, "
                  f"crs={ds.crs}, classes={dict(zip([int(x) for x in vals], [int(c) for c in counts]))}")

    print("\nDone.")

if __name__ == "__main__":
    main()