#!/usr/bin/env python3
"""
Discover where the benchmark data are mounted/stored. This script searches the
working directory and likely parent/shared locations for the required rasters or
for any files resembling the MountainLionNew dataset, printing all findings.
"""
from pathlib import Path
import os
import sys

print("Working directory:", Path.cwd())

print("\nRecursive listing of current working directory (limited):")
count = 0
for p in sorted(Path(".").rglob("*")):
    print(" ", p, "DIR" if p.is_dir() else "FILE")
    count += 1
    if count >= 300:
        print(" ... listing truncated at 300 entries")
        break

search_roots = [
    Path("."),
    Path(".."),
    Path("../.."),
    Path("/data/lab/VeriFront"),
    Path("/data/lab"),
    Path("/mnt/data"),
    Path("/tmp"),
]

targets_lower = {"landcover.tif", "protected_status.tif", "mountainlionnew"}
all_hits = []
print("\nSearching likely roots for required dataset names...")
for root in search_roots:
    if not root.exists():
        print("Root missing:", root)
        continue
    print("\nROOT:", root.resolve())
    root_hits = []
    try:
        for dirpath, dirnames, filenames in os.walk(root):
            # Skip very noisy/cache dirs if present
            parts = Path(dirpath).parts
            if any(part in {".git", "__pycache__", ".cache", "node_modules"} for part in parts):
                continue

            dpath = Path(dirpath)
            if dpath.name.lower() in targets_lower:
                root_hits.append(dpath)

            for fn in filenames:
                if fn.lower() in targets_lower or fn.lower().endswith(".tif"):
                    path = dpath / fn
                    # Prefer printing all tifs that could be relevant, but cap per root.
                    if (
                        fn.lower() in {"landcover.tif", "protected_status.tif"} or
                        "mountain" in str(path).lower() or
                        "lion" in str(path).lower() or
                        "landcover" in fn.lower() or
                        "protected" in fn.lower()
                    ):
                        root_hits.append(path)

            if len(root_hits) > 100:
                break
    except Exception as e:
        print("  Could not fully search root:", root, "error:", repr(e))
    print("  hits:", len(root_hits))
    for h in root_hits[:100]:
        print("   ", h)
    all_hits.extend(root_hits)

print("\nSummary hit count:", len(all_hits))
if not all_hits:
    print("No dataset files found in searched locations.")
    sys.exit(1)

# If files were found, write a small manifest for the next step.
manifest = Path("pred_results/dataset_search_hits.txt")
manifest.parent.mkdir(exist_ok=True)
manifest.write_text("\n".join(str(h) for h in all_hits) + "\n")
print("Saved manifest:", manifest)