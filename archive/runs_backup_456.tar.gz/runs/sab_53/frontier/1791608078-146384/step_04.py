#!/usr/bin/env python3
"""
Reclassify MountainLionNew landCover.tif and Protected_Status.tif using the
provided categorical mappings. Uses the verified benchmark dataset location
found in the prior search, and saves required outputs in pred_results/.
"""
from pathlib import Path
import sys
import numpy as np
import rasterio

DATA_DIR = Path("/data/lab/sab_data/benchmark_verified/benchmark/datasets/MountainLionNew")
LAND_IN = DATA_DIR / "landCover.tif"
PROT_IN = DATA_DIR / "Protected_Status.tif"

OUT_DIR = Path("pred_results")
OUT_DIR.mkdir(parents=True, exist_ok=True)
LAND_OUT = OUT_DIR / "landCover_reclassified.tif"
PROT_OUT = OUT_DIR / "protected_status_reclassified.tif"

land_mapping = {
    11: 10,  # Open Water
    21: 8,   # Developed, Open Space
    22: 7,   # Developed, Low Intensity
    23: 8,   # Developed, Medium Intensity
    24: 9,   # Developed, High Intensity
    31: 6,   # Barren Land
    41: 2,   # Deciduous Forest
    42: 1,   # Evergreen Forest
    43: 2,   # Mixed Forest
    52: 3,   # Shrub/Scrub
    71: 3,   # Grassland/Herbaceous
    72: 3,   # Sedge/Herbaceous
    81: 4,   # Hay/Pasture
    82: 6,   # Cultivated Crops
    90: 4,   # Woody Wetlands
    95: 4,   # Emergent Herbaceous Wetlands
    255: 10
}
prot_mapping = {
    0: 1,
    1: 3,
    2: 6,
    3: 9,
    4: 10,
    255: 10
}

def summarize(path: Path, label: str):
    print(f"\n--- {label}: {path} ---")
    with rasterio.open(path) as src:
        print("CRS:", src.crs)
        print("Size:", src.width, "x", src.height, "bands:", src.count)
        print("Dtype:", src.dtypes, "nodata:", src.nodata)
        print("Transform:", src.transform)
        print("Bounds:", src.bounds)
        arr = src.read(1, masked=False)
        vals, counts = np.unique(arr, return_counts=True)
        print("Unique values/counts:")
        for v, c in zip(vals.tolist(), counts.tolist()):
            print(f"  {v}: {c}")

def reclassify(in_path: Path, out_path: Path, mapping: dict, label: str, nodata):
    if not in_path.exists():
        print(f"ERROR missing input {label}: {in_path}")
        sys.exit(1)

    print(f"\n=== Reclassifying {label} ===")
    print("Input :", in_path)
    print("Output:", out_path)

    lut = np.zeros(256, dtype=np.uint8)
    for k, v in mapping.items():
        lut[int(k)] = np.uint8(v)

    unmapped = set()
    with rasterio.open(in_path) as src:
        profile = src.profile.copy()
        profile.update(dtype="uint8", count=1, compress="lzw")
        if nodata is None:
            profile.pop("nodata", None)
        else:
            profile.update(nodata=nodata)

        with rasterio.open(out_path, "w", **profile) as dst:
            for _, window in src.block_windows(1):
                arr = src.read(1, window=window, masked=False)
                observed = np.unique(arr).astype(int).tolist()
                for val in observed:
                    if val not in mapping:
                        unmapped.add(val)
                dst.write(lut[arr], 1, window=window)

    allowed_unmapped = {0} if label == "landCover" else set()
    unexpected = sorted(unmapped - allowed_unmapped)
    if unexpected:
        print("WARNING: unexpected unmapped source values written as 0:", unexpected)
    elif unmapped:
        print("Expected unmapped/background source values left as 0:", sorted(unmapped))
    else:
        print("All observed source values were mapped.")

    summarize(out_path, label + " output")

def compare(a: Path, b: Path, label: str):
    print(f"\n--- Compare {label} with reference {b} ---")
    if not b.exists() or not a.exists():
        print("Comparison skipped; missing file.")
        return
    with rasterio.open(a) as src_a, rasterio.open(b) as src_b:
        print("Same grid:", src_a.crs == src_b.crs and src_a.transform == src_b.transform and src_a.width == src_b.width and src_a.height == src_b.height)
        aa = src_a.read(1, masked=False)
        bb = src_b.read(1, masked=False)
        neq = aa != bb
        n = int(np.count_nonzero(neq))
        print("Differing cells:", n)
        if n:
            vals, counts = np.unique((aa.astype(np.int16) - bb.astype(np.int16))[neq], return_counts=True)
            print("Diff values/counts:")
            for v, c in zip(vals.tolist(), counts.tolist()):
                print(f"  {v}: {c}")
        else:
            print("Exact value match.")

print("Working directory:", Path.cwd())
print("Dataset directory:", DATA_DIR)
summarize(LAND_IN, "landCover input")
summarize(PROT_IN, "Protected_Status input")

# Land-cover has a background value 0 not included in the task mapping; preserve it as 0/nodata.
reclassify(LAND_IN, LAND_OUT, land_mapping, "landCover", nodata=0)
# Protected status explicitly maps 0 -> 1, so no output nodata is set.
reclassify(PROT_IN, PROT_OUT, prot_mapping, "Protected_Status", nodata=None)

compare(LAND_OUT, DATA_DIR / "landcover_reclassified.tif", "landCover")
compare(PROT_OUT, DATA_DIR / "protected_status_reclassified.tif", "Protected_Status")

print("\nDONE")
print("Required output:", LAND_OUT, "exists:", LAND_OUT.exists(), "bytes:", LAND_OUT.stat().st_size if LAND_OUT.exists() else None)
print("Additional output:", PROT_OUT, "exists:", PROT_OUT.exists(), "bytes:", PROT_OUT.stat().st_size if PROT_OUT.exists() else None)