#!/usr/bin/env python3
"""
Locate the dataset files, then reclassify land cover and protected status rasters.

Outputs:
  pred_results/landCover_reclassified.tif
  pred_results/protected_status_reclassified.tif
"""
from pathlib import Path
import sys
import numpy as np

try:
    import rasterio
except Exception as e:
    print("ERROR: rasterio import failed:", repr(e))
    sys.exit(1)

print("Working directory:", Path.cwd())
print("\nTop-level directory listing:")
for p in sorted(Path(".").iterdir()):
    print(" ", p, "DIR" if p.is_dir() else "FILE")

def find_one(filename):
    hits = sorted(Path(".").rglob(filename))
    if not hits:
        # Also try case-insensitive basename match
        hits = sorted([p for p in Path(".").rglob("*") if p.name.lower() == filename.lower()])
    print(f"\nSearch for {filename}: {len(hits)} hit(s)")
    for h in hits[:20]:
        print(" ", h)
    return hits[0] if hits else None

land_in = find_one("landCover.tif")
prot_in = find_one("Protected_Status.tif")

if land_in is None or prot_in is None:
    print("\nERROR: Could not locate required input rasters.")
    print("Nearby tif files found:")
    for p in sorted(Path(".").rglob("*.tif"))[:100]:
        print(" ", p)
    sys.exit(1)

out_dir = Path("pred_results")
out_dir.mkdir(parents=True, exist_ok=True)
land_out = out_dir / "landCover_reclassified.tif"
prot_out = out_dir / "protected_status_reclassified.tif"

land_mapping = {
    11: 10, 21: 8, 22: 7, 23: 8, 24: 9, 31: 6, 41: 2, 42: 1, 43: 2,
    52: 3, 71: 3, 72: 3, 81: 4, 82: 6, 90: 4, 95: 4, 255: 10
}
prot_mapping = {0: 1, 1: 3, 2: 6, 3: 9, 4: 10, 255: 10}

def summarize(path, label):
    print(f"\n--- {label}: {path} ---")
    with rasterio.open(path) as src:
        print("CRS:", src.crs)
        print("Size:", src.width, "x", src.height, "bands:", src.count)
        print("Dtype:", src.dtypes, "nodata:", src.nodata)
        print("Transform:", src.transform)
        arr = src.read(1)
        vals, counts = np.unique(arr, return_counts=True)
        print("Unique values/counts:")
        for v, c in zip(vals.tolist(), counts.tolist()):
            print(f"  {v}: {c}")

def reclassify(in_path, out_path, mapping, label, output_nodata):
    print(f"\nReclassifying {label}")
    print(" input :", in_path)
    print(" output:", out_path)

    lut = np.zeros(256, dtype=np.uint8)
    for k, v in mapping.items():
        lut[int(k)] = np.uint8(v)

    unmapped = set()
    with rasterio.open(in_path) as src:
        profile = src.profile.copy()
        profile.update(dtype="uint8", count=1, compress="lzw")
        if output_nodata is None:
            profile.pop("nodata", None)
        else:
            profile.update(nodata=output_nodata)

        with rasterio.open(out_path, "w", **profile) as dst:
            for _, window in src.block_windows(1):
                data = src.read(1, window=window)
                for val in np.unique(data).astype(int).tolist():
                    if val not in mapping:
                        unmapped.add(val)
                dst.write(lut[data], 1, window=window)

    print("Wrote:", out_path)
    allowed = {0} if label == "landCover" else set()
    unexpected = sorted(unmapped - allowed)
    if unexpected:
        print("WARNING unexpected unmapped input values written as 0:", unexpected)
    elif unmapped:
        print("Expected unmapped/background values:", sorted(unmapped))
    else:
        print("All observed input values were mapped.")
    summarize(out_path, label + " reclassified")

summarize(land_in, "landCover input")
summarize(prot_in, "Protected_Status input")

# landCover has observed 0 background not in provided mapping; retain as output nodata/background 0.
reclassify(land_in, land_out, land_mapping, "landCover", output_nodata=0)
# protected status maps 0 to 1; avoid nodata metadata that would mask class 0 before reclass.
reclassify(prot_in, prot_out, prot_mapping, "Protected_Status", output_nodata=None)

print("\nDONE")
print("Required output:", land_out, "exists:", land_out.exists(), "bytes:", land_out.stat().st_size if land_out.exists() else None)
print("Additional output:", prot_out, "exists:", prot_out.exists(), "bytes:", prot_out.stat().st_size if prot_out.exists() else None)