#!/usr/bin/env python3
"""
Reclassify land cover and protected status rasters to a common suitability scale.

Outputs:
  pred_results/landCover_reclassified.tif
  pred_results/protected_status_reclassified.tif
"""

from pathlib import Path
import sys
import numpy as np

try:
    import rasterio
except Exception as e:
    print("ERROR: rasterio is required but could not be imported:", repr(e))
    sys.exit(1)


DATA_DIR = Path("MountainLionNew")
OUT_DIR = Path("pred_results")
OUT_DIR.mkdir(parents=True, exist_ok=True)

LAND_IN = DATA_DIR / "landCover.tif"
PROT_IN = DATA_DIR / "Protected_Status.tif"

LAND_OUT = OUT_DIR / "landCover_reclassified.tif"
PROT_OUT = OUT_DIR / "protected_status_reclassified.tif"

landCover_classification = {
    11: 10,  # Open Water
    21: 8,   # Developed, Open Space
    22: 7,   # Developed, Low Intensity
    23: 8,   # Developed, Medium Intensity
    24: 9,   # Developed, High Intensity
    31: 6,   # Barren Land
    41: 2,   # Deciduous Forest
    42: 1,   # Evergreen Forest
    43: 2,   # Mixed Forest
    52: 3,   # Shrub/Scrub
    71: 3,   # Grassland/Herbaceous
    72: 3,   # Sedge/Herbaceous
    81: 4,   # Hay/Pasture
    82: 6,   # Cultivated Crops
    90: 4,   # Woody Wetlands
    95: 4,   # Emergent Herbaceous Wetlands
    255: 10
}

protected_status_classification = {
    0: 1,
    1: 3,
    2: 6,
    3: 9,
    4: 10,
    255: 10
}


def inspect_raster(path: Path, label: str):
    print(f"\n--- Inspecting {label}: {path} ---")
    if not path.exists():
        print(f"ERROR: missing input raster: {path}")
        sys.exit(1)
    with rasterio.open(path) as src:
        print("CRS:", src.crs)
        print("Transform:", src.transform)
        print("Width x Height:", src.width, "x", src.height)
        print("Count:", src.count)
        print("Dtype:", src.dtypes)
        print("Nodata:", src.nodata)
        print("Bounds:", src.bounds)
        arr = src.read(1)
        vals, counts = np.unique(arr, return_counts=True)
        print("Unique values and counts:")
        for v, c in zip(vals.tolist(), counts.tolist()):
            print(f"  {v}: {c}")
    return True


def reclassify_raster(in_path: Path, out_path: Path, mapping: dict, label: str, preserve_unmapped_zero_as_nodata: bool = False):
    print(f"\n--- Reclassifying {label} ---")
    print("Input:", in_path)
    print("Output:", out_path)

    with rasterio.open(in_path) as src:
        profile = src.profile.copy()
        src_nodata = src.nodata

        profile.update(
            dtype=rasterio.uint8,
            count=1,
            compress="lzw",
            tiled=False
        )

        # For land cover, value 0 occurs and is not in the provided classification.
        # Treat it as NoData/background and keep it as 0 in the output.
        if preserve_unmapped_zero_as_nodata:
            profile.update(nodata=0)
        else:
            # The protected status scale legitimately maps 0 -> 1 and 255 -> 10,
            # so avoid carrying stale nodata metadata.
            profile.update(nodata=None)

        # Build a fast lookup table for uint8 rasters.
        lut = np.zeros(256, dtype=np.uint8)
        mapped_keys = []
        for k, v in mapping.items():
            if not (0 <= int(k) <= 255):
                raise ValueError(f"{label}: mapping key outside uint8 range: {k}")
            if not (0 <= int(v) <= 255):
                raise ValueError(f"{label}: mapping value outside uint8 range: {v}")
            lut[int(k)] = np.uint8(v)
            mapped_keys.append(int(k))

        with rasterio.open(out_path, "w", **profile) as dst:
            unmapped_observed = set()
            for _, window in src.block_windows(1):
                data = src.read(1, window=window)
                out = lut[data]

                observed = set(np.unique(data).astype(int).tolist())
                for val in observed:
                    if val not in mapping:
                        unmapped_observed.add(val)

                # Preserve only land-cover background value 0 as output 0.
                # Other unmapped values are reported below.
                dst.write(out, 1, window=window)

        print("Finished writing:", out_path)

    with rasterio.open(out_path) as chk:
        out_arr = chk.read(1)
        vals, counts = np.unique(out_arr, return_counts=True)
        print("Output metadata:")
        print("  CRS:", chk.crs)
        print("  Transform:", chk.transform)
        print("  Width x Height:", chk.width, "x", chk.height)
        print("  Dtype:", chk.dtypes)
        print("  Nodata:", chk.nodata)
        print("Output unique values and counts:")
        for v, c in zip(vals.tolist(), counts.tolist()):
            print(f"  {v}: {c}")

    allowed_unmapped = {0} if preserve_unmapped_zero_as_nodata else set()
    unexpected_unmapped = sorted(set(unmapped_observed) - allowed_unmapped)
    if unexpected_unmapped:
        print(f"WARNING: {label} had unmapped source values {unexpected_unmapped}; these were written as 0.")
    else:
        if unmapped_observed:
            print(f"Note: {label} had expected unmapped background/nodata values: {sorted(unmapped_observed)}")
        print(f"No unexpected unmapped source values for {label}.")

    return out_path


def compare_if_existing_reference(candidate_paths, produced_path, label):
    print(f"\n--- Optional comparison for {label} ---")
    found_any = False
    for cand in candidate_paths:
        cand = Path(cand)
        if not cand.exists():
            continue
        found_any = True
        print("Comparing against existing file:", cand)
        with rasterio.open(cand) as ref, rasterio.open(produced_path) as prod:
            same_grid = (
                ref.width == prod.width and ref.height == prod.height and
                ref.transform == prod.transform and ref.crs == prod.crs
            )
            print("  Same grid:", same_grid)
            if same_grid:
                a = ref.read(1)
                b = prod.read(1)
                diff = a.astype(np.int16) - b.astype(np.int16)
                n_diff = int(np.count_nonzero(diff))
                print("  Differing cells:", n_diff)
                if n_diff:
                    vals, counts = np.unique(diff[diff != 0], return_counts=True)
                    print("  Difference values/counts:")
                    for v, c in zip(vals.tolist(), counts.tolist()):
                        print(f"    {v}: {c}")
                else:
                    print("  Produced raster exactly matches existing reference values.")
    if not found_any:
        print("No existing reference file found to compare.")


def main():
    print("Starting mountain lion categorical raster reclassification.")
    print("Working directory:", Path.cwd())

    inspect_raster(LAND_IN, "landCover")
    inspect_raster(PROT_IN, "Protected_Status")

    reclassify_raster(
        LAND_IN,
        LAND_OUT,
        landCover_classification,
        "landCover",
        preserve_unmapped_zero_as_nodata=True
    )
    reclassify_raster(
        PROT_IN,
        PROT_OUT,
        protected_status_classification,
        "Protected_Status",
        preserve_unmapped_zero_as_nodata=False
    )

    compare_if_existing_reference(
        [DATA_DIR / "landcover_reclassified.tif", DATA_DIR / "landCover_reclassified.tif"],
        LAND_OUT,
        "landCover"
    )
    compare_if_existing_reference(
        [DATA_DIR / "protected_status_reclassified.tif", DATA_DIR / "Protected_Status_reclassified.tif"],
        PROT_OUT,
        "Protected_Status"
    )

    print("\nDONE")
    print("Required output exists:", LAND_OUT.exists(), LAND_OUT)
    print("Additional output exists:", PROT_OUT.exists(), PROT_OUT)


if __name__ == "__main__":
    main()