#!/usr/bin/env python3
"""
Reclassify land cover and protected status rasters to a common 1-10 scale.

Outputs:
  pred_results/landCover_reclassified.tif
  pred_results/protected_status_reclassified.tif
"""

from pathlib import Path
import sys
import numpy as np

try:
    import rasterio
except Exception as e:
    print("ERROR: rasterio is required but could not be imported:", repr(e))
    sys.exit(1)


DATA_DIR = Path("MountainLionNew")
OUT_DIR = Path("pred_results")
OUT_DIR.mkdir(parents=True, exist_ok=True)

LAND_SRC = DATA_DIR / "landCover.tif"
PROT_SRC = DATA_DIR / "Protected_Status.tif"

LAND_OUT = OUT_DIR / "landCover_reclassified.tif"
PROT_OUT = OUT_DIR / "protected_status_reclassified.tif"

landCover_classification = {
    11: 10,  # Open Water
    21: 8,   # Developed, Open Space
    22: 7,   # Developed, Low Intensity
    23: 8,   # Developed, Medium Intensity
    24: 9,   # Developed, High Intensity
    31: 6,   # Barren Land
    41: 2,   # Deciduous Forest
    42: 1,   # Evergreen Forest
    43: 2,   # Mixed Forest
    52: 3,   # Shrub/Scrub
    71: 3,   # Grassland/Herbaceous
    72: 3,   # Sedge/Herbaceous
    81: 4,   # Hay/Pasture
    82: 6,   # Cultivated Crops
    90: 4,   # Woody Wetlands
    95: 4,   # Emergent Herbaceous Wetlands
    255: 10
}

protected_status_classification = {
    0: 1,
    1: 3,
    2: 6,
    3: 9,
    4: 10,
    255: 10
}


def bincount_raster_values(path):
    """Return dict of value counts for a single-band integer raster."""
    counts = {}
    with rasterio.open(path) as src:
        for _, window in src.block_windows(1):
            arr = src.read(1, window=window, masked=False)
            vals, cnts = np.unique(arr, return_counts=True)
            for v, c in zip(vals.tolist(), cnts.tolist()):
                counts[int(v)] = counts.get(int(v), 0) + int(c)
    return dict(sorted(counts.items()))


def reclassify_raster(src_path, out_path, mapping, default_value=0):
    """
    Reclassify a uint/integer categorical raster using an explicit value mapping.
    Unmapped values are written as default_value, used here as NoData/unknown.
    """
    if not src_path.exists():
        raise FileNotFoundError(f"Missing source raster: {src_path}")

    # Make a lookup table for the common uint8 categorical rasters.
    lut = np.full(256, default_value, dtype=np.uint8)
    for old, new in mapping.items():
        if not (0 <= int(old) <= 255):
            raise ValueError(f"Mapping key outside uint8 range: {old}")
        if not (0 <= int(new) <= 255):
            raise ValueError(f"Mapping value outside uint8 range: {new}")
        lut[int(old)] = np.uint8(new)

    src_counts = bincount_raster_values(src_path)
    unmapped = sorted(v for v in src_counts if v not in mapping)

    with rasterio.open(src_path) as src:
        profile = src.profile.copy()
        print(f"\nSource: {src_path}")
        print(f"  size: {src.width} x {src.height}; dtype={src.dtypes[0]}; crs={src.crs}")
        print(f"  transform: {src.transform}")
        print(f"  source nodata: {src.nodata}")
        print(f"  source unique counts: {src_counts}")
        if unmapped:
            print(f"  WARNING: unmapped source values will become {default_value}: {unmapped}")
        else:
            print("  all observed source values are explicitly mapped")

        profile.update(
            driver="GTiff",
            dtype="uint8",
            count=1,
            nodata=default_value,
            compress="lzw",
            tiled=True,
            BIGTIFF="IF_SAFER"
        )

        with rasterio.open(out_path, "w", **profile) as dst:
            for _, window in src.block_windows(1):
                arr = src.read(1, window=window, masked=False)

                # Robust integer mapping. Inputs are expected uint8; this handles
                # integer arrays with possible out-of-range values by defaulting.
                if arr.dtype == np.uint8:
                    out = lut[arr]
                else:
                    out = np.full(arr.shape, default_value, dtype=np.uint8)
                    valid = (arr >= 0) & (arr <= 255)
                    out[valid] = lut[arr[valid].astype(np.uint8)]

                dst.write(out, 1, window=window)

    out_counts = bincount_raster_values(out_path)
    with rasterio.open(out_path) as chk:
        print(f"Output: {out_path}")
        print(f"  size: {chk.width} x {chk.height}; dtype={chk.dtypes[0]}; crs={chk.crs}")
        print(f"  output nodata: {chk.nodata}")
        print(f"  output unique counts: {out_counts}")

    return out_counts


def main():
    print("Starting raster reclassification for mountain lion habitat predictors.")
    print(f"Working directory outputs will be saved in: {OUT_DIR.resolve()}")

    land_counts = reclassify_raster(
        LAND_SRC,
        LAND_OUT,
        landCover_classification,
        default_value=0
    )

    prot_counts = reclassify_raster(
        PROT_SRC,
        PROT_OUT,
        protected_status_classification,
        default_value=0
    )

    required_ok = LAND_OUT.exists() and LAND_OUT.stat().st_size > 0
    prot_ok = PROT_OUT.exists() and PROT_OUT.stat().st_size > 0

    print("\nReclassification complete.")
    print(f"  Required output exists: {required_ok} -> {LAND_OUT}")
    print(f"  Protected-status output exists: {prot_ok} -> {PROT_OUT}")
    print(f"  landCover reclassified values: {sorted(land_counts.keys())}")
    print(f"  protected status reclassified values: {sorted(prot_counts.keys())}")

    if not required_ok:
        raise RuntimeError(f"Required output was not created correctly: {LAND_OUT}")


if __name__ == "__main__":
    main()