#!/usr/bin/env python3
"""
Round 2: Reclassify land cover and protected status rasters using the provided
classification dictionaries, preserving geospatial metadata, and save outputs
to pred_results/.
"""
from pathlib import Path
import numpy as np
import rasterio

data_dir = Path("MountainLionNew")
out_dir = Path("pred_results")
out_dir.mkdir(parents=True, exist_ok=True)

landCover_classification = {
    11: 10,  # Open Water
    21: 8,   # Developed, Open Space
    22: 7,   # Developed, Low Intensity
    23: 8,   # Developed, Medium Intensity
    24: 9,   # Developed, High Intensity
    31: 6,   # Barren Land
    41: 2,   # Deciduous Forest
    42: 1,   # Evergreen Forest
    43: 2,   # Mixed Forest
    52: 3,   # Shrub/Scrub
    71: 3,   # Grassland/Herbaceous
    72: 3,   # Sedge/Herbaceous
    81: 4,   # Hay/Pasture
    82: 6,   # Cultivated Crops
    90: 4,   # Woody Wetlands
    95: 4,   # Emergent Herbaceous Wetlands
    255: 10
}

protected_status_classification = {
    0: 1,
    1: 3,
    2: 6,
    3: 9,
    4: 10,
    255: 10
}

jobs = [
    (
        data_dir / "landCover.tif",
        out_dir / "landCover_reclassified.tif",
        landCover_classification,
        "landCover",
        0,  # preserve unlisted source value 0 as 0
    ),
    (
        data_dir / "Protected_Status.tif",
        out_dir / "protected_status_reclassified.tif",
        protected_status_classification,
        "Protected_Status",
        None,
    ),
]

def reclassify_raster(src_path, dst_path, mapping, label, default_value):
    print(f"\nReclassifying {label}")
    print("input:", src_path)
    print("output:", dst_path)
    with rasterio.open(src_path) as src:
        arr = src.read(1)
        in_vals, in_counts = np.unique(arr, return_counts=True)
        print("input unique values/counts:", list(zip(in_vals.tolist(), in_counts.tolist())))

        mapped_keys = set(mapping.keys())
        source_values = set(int(v) for v in in_vals.tolist())
        unmapped = sorted(source_values - mapped_keys)
        print("unmapped source values:", unmapped)

        if default_value is None and unmapped:
            raise ValueError(f"{label} has unmapped source values and no default: {unmapped}")

        if default_value is None:
            out = np.zeros(arr.shape, dtype=np.uint8)
        else:
            out = np.full(arr.shape, int(default_value), dtype=np.uint8)

        for old_value, new_value in mapping.items():
            out[arr == old_value] = new_value

        profile = src.profile.copy()
        profile.update(
            dtype=rasterio.uint8,
            count=1,
            compress="lzw",
            tiled=False,
            nodata=src.nodata,
        )

        with rasterio.open(dst_path, "w", **profile) as dst:
            dst.write(out, 1)

    with rasterio.open(dst_path) as check:
        out_arr = check.read(1)
        out_vals, out_counts = np.unique(out_arr, return_counts=True)
        print("output unique values/counts:", list(zip(out_vals.tolist(), out_counts.tolist())))
        print("output dtype:", check.dtypes[0])
        print("output crs:", check.crs)
        print("output transform:", check.transform)
        print("output size:", check.width, check.height)
        print("output nodata:", check.nodata)

for job in jobs:
    reclassify_raster(*job)

print("\nCreated files:")
for p in [out_dir / "landCover_reclassified.tif", out_dir / "protected_status_reclassified.tif"]:
    print(p, "exists:", p.exists(), "size_bytes:", p.stat().st_size if p.exists() else None)