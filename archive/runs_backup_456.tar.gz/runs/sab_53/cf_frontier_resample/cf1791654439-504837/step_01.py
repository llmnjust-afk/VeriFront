#!/usr/bin/env python3
"""
Round 1: Inspect available rasters, metadata, unique values, and any existing
reclassified rasters so we can perform a consistent reclassification next.
"""
from pathlib import Path
import sys
import numpy as np

print("Python:", sys.version)
root = Path(".")
data_dir = root / "MountainLionNew"
out_dir = root / "pred_results"

print("Working directory:", root.resolve())
print("Dataset directory exists:", data_dir.exists())
print("Output directory exists:", out_dir.exists())

try:
    import rasterio
    print("rasterio version:", rasterio.__version__)
except Exception as e:
    print("ERROR: rasterio import failed:", repr(e))
    raise

for p in [
    data_dir / "landCover.tif",
    data_dir / "Protected_Status.tif",
    data_dir / "landcover_reclassified.tif",
    data_dir / "protected_status_reclassified.tif",
]:
    print("\n---", p, "---")
    print("exists:", p.exists())
    if not p.exists():
        continue
    with rasterio.open(p) as src:
        print("driver:", src.driver)
        print("size:", src.width, src.height, "count:", src.count)
        print("dtype:", src.dtypes)
        print("crs:", src.crs)
        print("transform:", src.transform)
        print("nodata:", src.nodata)
        print("bounds:", src.bounds)
        arr = src.read(1)
        vals, counts = np.unique(arr, return_counts=True)
        print("unique count:", len(vals))
        print("unique values/counts:", list(zip(vals.tolist(), counts.tolist()))[:50])
        if len(vals) > 50:
            print("... last values/counts:", list(zip(vals.tolist(), counts.tolist()))[-10:])