#!/usr/bin/env python3
"""
Reclassify land cover and protected status rasters to a common categorical scale.

Inputs:
  MountainLionNew/landCover.tif
  MountainLionNew/Protected_Status.tif

Outputs:
  pred_results/landCover_reclassified.tif
  pred_results/protected_status_reclassified.tif
"""

from pathlib import Path
import sys
import numpy as np

try:
    import rasterio
except Exception as e:
    print("ERROR: rasterio is required but could not be imported:", repr(e))
    sys.exit(1)


DATA_DIR = Path("MountainLionNew")
OUT_DIR = Path("pred_results")
OUT_DIR.mkdir(parents=True, exist_ok=True)

landCover_classification = {
    11: 10,  # Open Water
    21: 8,   # Developed, Open Space
    22: 7,   # Developed, Low Intensity
    23: 8,   # Developed, Medium Intensity
    24: 9,   # Developed, High Intensity
    31: 6,   # Barren Land
    41: 2,   # Deciduous Forest
    42: 1,   # Evergreen Forest
    43: 2,   # Mixed Forest
    52: 3,   # Shrub/Scrub
    71: 3,   # Grassland/Herbaceous
    72: 3,   # Sedge/Herbaceous
    81: 4,   # Hay/Pasture
    82: 6,   # Cultivated Crops
    90: 4,   # Woody Wetlands
    95: 4,   # Emergent Herbaceous Wetlands
    255: 10
}

protected_status_classification = {
    0: 1,
    1: 3,
    2: 6,
    3: 9,
    4: 10,
    255: 10
}


def summarize_values(arr, label, max_items=30):
    vals, counts = np.unique(arr, return_counts=True)
    print(f"\n{label}: {len(vals)} unique values")
    for v, c in zip(vals[:max_items], counts[:max_items]):
        print(f"  value {int(v):>4}: {int(c)} cells")
    if len(vals) > max_items:
        print(f"  ... {len(vals) - max_items} more values not shown")
    return vals, counts


def reclassify_raster(src_path, dst_path, mapping, default_unmapped=0):
    src_path = Path(src_path)
    dst_path = Path(dst_path)

    if not src_path.exists():
        raise FileNotFoundError(f"Input raster not found: {src_path}")

    with rasterio.open(src_path) as src:
        data = src.read(1)
        profile = src.profile.copy()

        print("\n" + "=" * 72)
        print(f"Input:  {src_path}")
        print(f"Output: {dst_path}")
        print(f"Shape: {data.shape}")
        print(f"CRS: {src.crs}")
        print(f"Transform: {src.transform}")
        print(f"Source dtype: {data.dtype}")
        print(f"Source nodata: {src.nodata}")

        in_vals, _ = summarize_values(data, f"Input values for {src_path.name}")

        mapped_keys = set(int(k) for k in mapping.keys())
        unmapped_values = [int(v) for v in in_vals if int(v) not in mapped_keys]
        if unmapped_values:
            print(
                f"WARNING: {src_path.name} contains values not in the supplied "
                f"classification dictionary: {unmapped_values}. "
                f"These cells will be written as {default_unmapped}."
            )
        else:
            print("All input values are covered by the classification dictionary.")

        out = np.full(data.shape, default_unmapped, dtype=np.uint8)
        for old_value, new_value in mapping.items():
            out[data == old_value] = np.uint8(new_value)

        profile.update(
            driver="GTiff",
            dtype=rasterio.uint8,
            count=1,
            compress="lzw",
            tiled=False
        )

        # If the only unmapped class is 0, it is commonly a background/no-data class
        # in categorical rasters. Marking it as nodata keeps valid classes on 1-10.
        if 0 in np.unique(out):
            profile.update(nodata=0)
        else:
            profile.update(nodata=None)

        dst_path.parent.mkdir(parents=True, exist_ok=True)
        with rasterio.open(dst_path, "w", **profile) as dst:
            dst.write(out, 1)

    with rasterio.open(dst_path) as check:
        written = check.read(1)
        summarize_values(written, f"Written values for {dst_path.name}")
        print(f"Written profile dtype: {check.dtypes[0]}")
        print(f"Written nodata: {check.nodata}")
        print(f"Written CRS: {check.crs}")
        print(f"Written transform: {check.transform}")
        print(f"Saved: {dst_path.resolve()}")

    return dst_path


land_out = reclassify_raster(
    DATA_DIR / "landCover.tif",
    OUT_DIR / "landCover_reclassified.tif",
    landCover_classification,
    default_unmapped=0
)

protected_out = reclassify_raster(
    DATA_DIR / "Protected_Status.tif",
    OUT_DIR / "protected_status_reclassified.tif",
    protected_status_classification,
    default_unmapped=0
)

print("\n" + "=" * 72)
print("Reclassification complete.")
print(f"Required land cover output exists: {land_out.exists()} -> {land_out}")
print(f"Protected status output exists: {protected_out.exists()} -> {protected_out}")
print("=" * 72)