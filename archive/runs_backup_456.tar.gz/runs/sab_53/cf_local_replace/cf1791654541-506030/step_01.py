import os
from pathlib import Path
import numpy as np
import rasterio

base = Path("MountainLionNew")
outdir = Path("pred_results")
outdir.mkdir(exist_ok=True)

# Input / output paths
land_in = base / "landCover.tif"
prot_in = base / "Protected_Status.tif"
land_out = outdir / "landCover_reclassified.tif"
prot_out = outdir / "protected_status_reclassified.tif"

# Classification dictionaries from the prompt
landCover_classification = {
    11: 10,  # Open Water
    21: 8,   # Developed, Open Space
    22: 7,   # Developed, Low Intensity
    23: 8,   # Developed, Medium Intensity
    24: 9,   # Developed, High Intensity
    31: 6,   # Barren Land
    41: 2,   # Deciduous Forest
    42: 1,   # Evergreen Forest
    43: 2,   # Mixed Forest
    52: 3,   # Shrub/Scrub
    71: 3,   # Grassland/Herbaceous
    72: 3,   # Sedge/Herbaceous
    81: 4,   # Hay/Pasture
    82: 6,   # Cultivated Crops
    90: 4,   # Woody Wetlands
    95: 4,   # Emergent Herbaceous Wetlands
    255: 10
}

protected_status_classification = {
    0: 1,
    1: 3,
    2: 6,
    3: 9,
    4: 10,
    255: 10
}

def reclassify_raster(in_path, out_path, mapping, out_dtype=np.uint8):
    with rasterio.open(in_path) as src:
        arr = src.read(1)
        profile = src.profile.copy()

        # Determine nodata from source if present
        src_nodata = src.nodata

        # Build output array
        out = np.full(arr.shape, 255, dtype=out_dtype)

        # Reclassify known values
        for k, v in mapping.items():
            out[arr == k] = np.array(v, dtype=out_dtype)

        # Preserve nodata if source has one and it isn't already explicitly mapped
        if src_nodata is not None:
            out[arr == src_nodata] = np.array(src_nodata, dtype=out_dtype)

        profile.update(dtype=out_dtype, count=1, compress="lzw")
        if src_nodata is not None:
            profile.update(nodata=src_nodata)
        else:
            # keep 255 as a conventional fallback nodata only if not conflicting
            profile.update(nodata=255)

        with rasterio.open(out_path, "w", **profile) as dst:
            dst.write(out, 1)

        # Print checks
        uniq = np.unique(out)
        print(f"Wrote {out_path}")
        print(f"  shape={out.shape}, dtype={out.dtype}")
        print(f"  unique values (sample up to 20): {uniq[:20]}")
        if len(uniq) > 20:
            print(f"  ... total unique count={len(uniq)}")

reclassify_raster(land_in, land_out, landCover_classification)
reclassify_raster(prot_in, prot_out, protected_status_classification)

print("Done.")