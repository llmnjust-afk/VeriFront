import os
from pathlib import Path
import numpy as np
import rasterio

in_dir = Path("MountainLionNew")
out_dir = Path("pred_results")
out_dir.mkdir(exist_ok=True)

landCover_classification = {
    11:10,  # Open Water
    21:8,   # Developed, Open Space
    22:7,   # Developed, Low Intensity
    23:8,   # Developed, Medium Intensity
    24:9,   # Developed, High Intensity
    31:6,   # Barren Land
    41:2,   # Deciduous Forest
    42:1,   # Evergreen Forest
    43:2,   # Mixed Forest
    52:3,   # Shrub/Scrub
    71:3,   # Grassland/Herbaceous
    72:3,   # Sedge/Herbaceous
    81:4,   # Hay/Pasture
    82:6,   # Cultivated Crops
    90:4,   # Woody Wetlands
    95:4,   # Emergent Herbaceous Wetlands
    255:10
}

protected_status_classification = {
    0:1,
    1:3,
    2:6,
    3:9,
    4:10,
    255:10
}

def reclassify_raster(src_path, dst_path, mapping, default_value=0):
    with rasterio.open(src_path) as src:
        profile = src.profile.copy()
        profile.update(
            dtype=rasterio.uint8,
            count=1,
            compress="lzw",
            nodata=None
        )
        
        unique_in = set()
        unique_out = set()
        total_unmapped = 0
        
        with rasterio.open(dst_path, "w", **profile) as dst:
            for _, window in src.block_windows(1):
                arr = src.read(1, window=window)
                vals, counts = np.unique(arr, return_counts=True)
                unique_in.update(int(v) for v in vals)
                
                out = np.full(arr.shape, default_value, dtype=np.uint8)
                for old, new in mapping.items():
                    out[arr == old] = new
                
                mapped_keys = np.array(list(mapping.keys()), dtype=arr.dtype)
                unmapped_mask = ~np.isin(arr, mapped_keys)
                total_unmapped += int(unmapped_mask.sum())
                
                dst.write(out, 1, window=window)
                unique_out.update(int(v) for v in np.unique(out))
        
    return sorted(unique_in), sorted(unique_out), total_unmapped

results = []
for src_name, dst_name, mapping in [
    ("landCover.tif", "landCover_reclassified.tif", landCover_classification),
    ("Protected_Status.tif", "protected_status_reclassified.tif", protected_status_classification),
]:
    src = in_dir / src_name
    dst = out_dir / dst_name
    uin, uout, unmapped = reclassify_raster(src, dst, mapping, default_value=0)
    results.append((src_name, str(dst), uin, uout, unmapped))
    print(f"Reclassified {src_name} -> {dst}")
    print(f"  input unique values: {uin}")
    print(f"  output unique values: {uout}")
    print(f"  unmapped cells written as 0: {unmapped}")

print("Output directory contents:", sorted(p.name for p in out_dir.iterdir()))
for path in [out_dir / "landCover_reclassified.tif", out_dir / "protected_status_reclassified.tif"]:
    with rasterio.open(path) as src:
        data = src.read(1)
        vals, counts = np.unique(data, return_counts=True)
        print(f"{path}: shape={src.shape}, dtype={src.dtypes[0]}, crs={src.crs}, transform={src.transform}")
        print("  value counts:", dict(zip([int(v) for v in vals], [int(c) for c in counts])))