import os
from pathlib import Path

base = Path("MountainLionNew")
print("Files present:", sorted(p.name for p in base.iterdir())[:20], "..." if len(list(base.iterdir())) > 20 else "")

# Inspect available raster metadata and confirm existing outputs
try:
    import rasterio
    print("rasterio version:", rasterio.__version__)
    for fn in ["landCover.tif", "Protected_Status.tif", "landcover_reclassified.tif", "protected_status_reclassified.tif"]:
        path = base / fn
        if path.exists():
            with rasterio.open(path) as src:
                print(f"{fn}: shape={src.shape}, count={src.count}, dtype={src.dtypes[0]}, crs={src.crs}, transform={src.transform}")
        else:
            print(f"{fn}: not found")
except Exception as e:
    print("Raster inspection failed:", repr(e))