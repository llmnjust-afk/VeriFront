import os
import numpy as np
import rasterio

base = "MountainLionNew"
inputs = {
    "landCover": os.path.join(base, "landCover.tif"),
    "protected": os.path.join(base, "Protected_Status.tif"),
}
existing = {
    "landCover_existing": os.path.join(base, "landcover_reclassified.tif"),
    "protected_existing": os.path.join(base, "protected_status_reclassified.tif"),
}

for name, path in {**inputs, **existing}.items():
    print(f"\n--- {name}: {path} ---")
    with rasterio.open(path) as src:
        print("driver:", src.driver)
        print("shape:", (src.height, src.width), "count:", src.count)
        print("dtype:", src.dtypes)
        print("nodata:", src.nodata)
        print("crs:", src.crs)
        print("transform:", src.transform)
        print("bounds:", src.bounds)
        arr = src.read(1)
        vals, counts = np.unique(arr, return_counts=True)
        print("unique count:", len(vals))
        print("unique values/counts:", list(zip(vals.tolist(), counts.tolist()))[:50])
        print("min/max:", arr.min(), arr.max())

# Verify mappings cover source classes
land_map = {
  11:10, 21:8, 22:7, 23:8, 24:9, 31:6, 41:2, 42:1, 43:2,
  52:3, 71:3, 72:3, 81:4, 82:6, 90:4, 95:4, 255:10
}
prot_map = {0:1, 1:3, 2:6, 3:9, 4:10, 255:10}

for label, path, mp in [("landCover", inputs["landCover"], land_map), ("protected", inputs["protected"], prot_map)]:
    with rasterio.open(path) as src:
        arr = src.read(1)
    vals = set(np.unique(arr).tolist())
    missing = sorted(vals - set(mp.keys()))
    extra = sorted(set(mp.keys()) - vals)
    print(f"\n{label} mapping check")
    print("source values:", sorted(vals))
    print("missing from mapping:", missing)
    print("mapped values not present:", extra)