import os
import numpy as np

# Explore working directory
print("Current working directory:", os.getcwd())
print()

# Check what's available
for root, dirs, files in os.walk('.'):
    # Skip hidden dirs
    dirs[:] = [d for d in dirs if not d.startswith('.')]
    level = root.replace('.', '', 1).count(os.sep)
    indent = '  ' * level
    print(f"{indent}{os.path.basename(root)}/")
    for f in sorted(files):
        fp = os.path.join(root, f)
        size = os.path.getsize(fp)
        print(f"{indent}  {f} ({size} bytes)")
print()

# Check available python packages
try:
    import rasterio
    print("rasterio version:", rasterio.__version__)
except ImportError as e:
    print("rasterio not available:", e)

try:
    import osgeo
    from osgeo import gdal
    print("gdal version:", gdal.__version__)
except ImportError as e:
    print("gdal not available:", e)

try:
    import geopandas
    print("geopandas version:", geopandas.__version__)
except ImportError as e:
    print("geopandas not available:", e)