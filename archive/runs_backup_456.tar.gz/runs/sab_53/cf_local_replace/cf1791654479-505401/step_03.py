import os
import numpy as np
import rasterio
from rasterio.windows import Window

# Paths
in_dir = "MountainLionNew"
out_dir = "pred_results"
os.makedirs(out_dir, exist_ok=True)

land_in = os.path.join(in_dir, "landCover.tif")
prot_in = os.path.join(in_dir, "Protected_Status.tif")
land_out = os.path.join(out_dir, "landCover_reclassified.tif")
prot_out = os.path.join(out_dir, "protected_status_reclassified.tif")

# Provided classification dictionaries
landCover_classification = {
    11: 10,  # Open Water
    21: 8,   # Developed, Open Space
    22: 7,   # Developed, Low Intensity
    23: 8,   # Developed, Medium Intensity
    24: 9,   # Developed, High Intensity
    31: 6,   # Barren Land
    41: 2,   # Deciduous Forest
    42: 1,   # Evergreen Forest
    43: 2,   # Mixed Forest
    52: 3,   # Shrub/Scrub
    71: 3,   # Grassland/Herbaceous
    72: 3,   # Sedge/Herbaceous
    81: 4,   # Hay/Pasture
    82: 6,   # Cultivated Crops
    90: 4,   # Woody Wetlands
    95: 4,   # Emergent Herbaceous Wetlands
    255: 10
}

protected_status_classification = {
    0: 1,
    1: 3,
    2: 6,
    3: 9,
    4: 10,
    255: 10
}

def build_lookup(mapping, default_value=None):
    """Build uint8 lookup table for values 0..255."""
    lut = np.zeros(256, dtype=np.uint8)
    if default_value is None:
        # preserve unmapped values by default
        lut[:] = np.arange(256, dtype=np.uint8)
    else:
        lut[:] = np.uint8(default_value)
    for src_val, dst_val in mapping.items():
        lut[int(src_val)] = np.uint8(dst_val)
    return lut

def reclassify_raster(src_path, dst_path, mapping, preserve_unmapped=True):
    """Reclassify single-band uint8 raster using a lookup table and write GeoTIFF."""
    default = None if preserve_unmapped else 0
    lut = build_lookup(mapping, default_value=default)

    with rasterio.open(src_path) as src:
        profile = src.profile.copy()
        profile.update(
            dtype=rasterio.uint8,
            count=1,
            compress="lzw",
            tiled=True,
            blockxsize=256,
            blockysize=256,
            BIGTIFF="IF_SAFER"
        )

        # Ensure block sizes are legal for the image dimensions/profile.
        # Rasterio permits edge blocks smaller than block size.
        with rasterio.open(dst_path, "w", **profile) as dst:
            for _, window in src.block_windows(1):
                data = src.read(1, window=window)
                reclassed = lut[data]
                dst.write(reclassed, 1, window=window)

    # Summarize output
    with rasterio.open(src_path) as src, rasterio.open(dst_path) as dst:
        src_arr = src.read(1)
        dst_arr = dst.read(1)
        svals, scounts = np.unique(src_arr, return_counts=True)
        dvals, dcounts = np.unique(dst_arr, return_counts=True)
        print(f"\nCreated: {dst_path}")
        print("Input:", src_path)
        print("Shape:", dst_arr.shape, "dtype:", dst_arr.dtype)
        print("CRS:", dst.crs)
        print("Transform:", dst.transform)
        print("Input unique/counts:", list(zip(svals.tolist(), scounts.tolist())))
        print("Output unique/counts:", list(zip(dvals.tolist(), dcounts.tolist())))
        missing = sorted(set(svals.tolist()) - set(mapping.keys()))
        print("Input values not explicitly in mapping and preserved:", missing if preserve_unmapped else [])

# Reclassify. For land cover, value 0 exists in the raster but is not in the supplied
# classification dictionary, so preserve it rather than inventing a class.
reclassify_raster(land_in, land_out, landCover_classification, preserve_unmapped=True)
reclassify_raster(prot_in, prot_out, protected_status_classification, preserve_unmapped=True)

# Verify required paths exist
for p in [land_out, prot_out]:
    print(f"Exists {p}: {os.path.exists(p)}, size bytes: {os.path.getsize(p) if os.path.exists(p) else 'MISSING'}")