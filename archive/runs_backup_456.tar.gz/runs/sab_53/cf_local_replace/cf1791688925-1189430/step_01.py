import os
import numpy as np
import rasterio

base = "MountainLionNew"

def explore(path):
    print("="*70)
    print("FILE:", path)
    if not os.path.exists(path):
        print("  (missing)")
        return
    with rasterio.open(path) as src:
        print("  driver:", src.driver)
        print("  size:", src.width, "x", src.height)
        print("  count:", src.count)
        print("  dtype:", src.dtypes)
        print("  crs:", src.crs)
        print("  transform:", src.transform)
        print("  nodata:", src.nodata)
        print("  bounds:", src.bounds)
        arr = src.read(1)
        uniq, counts = np.unique(arr, return_counts=True)
        print("  unique values (val:count):")
        for u, c in zip(uniq, counts):
            print("    ", int(u), ":", int(c))
        # try vat / colormap
        try:
            cm = src.colormap(1)
            if cm:
                print("  colormap entries:", len(cm))
        except Exception as e:
            print("  colormap: none")
        try:
            print("  tags:", src.tags())
        except Exception:
            pass

for f in ["landCover.tif", "Protected_Status.tif",
          "protected_status_reclassified.tif", "landcover_reclassified.tif"]:
    explore(os.path.join(base, f))

print("\nExisting pred_results dir:", os.path.isdir("pred_results"))
if os.path.isdir("pred_results"):
    print(os.listdir("pred_results"))