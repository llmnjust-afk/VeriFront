import os
import numpy as np
import rasterio
from rasterio.enums import Resampling

os.makedirs("pred_results", exist_ok=True)

landCover_classification = {
    11:10, # Open Water
    21:8,  # Developed, Open Space
    22:7,  # Developed, Low Intensity
    23:8,  # Developed, Medium Intensity
    24:9,  # Developed, High Intensity
    31:6,  # Barren Land
    41:2,  # Deciduous Forest
    42:1,  # Evergreen Forest
    43:2,  # Mixed Forest
    52:3,  # Shrub/Scrub
    71:3,  # Grassland/Herbaceous
    72:3,  # Sedge/Herbaceous
    81:4,  # Hay/Pasture
    82:6,  # Cultivated Crops
    90:4,  # Woody Wetlands
    95:4,  # Emergent Herbaceous Wetlands
    255:10
}

protected_status_classification = {
    0:1,
    1:3,
    2:6,
    3:9,
    4:10,
    255:10
}

def reclassify_raster(src_path, dst_path, mapping, default_value=None):
    print("=" * 80)
    print(f"Reclassifying {src_path} -> {dst_path}")
    with rasterio.open(src_path) as src:
        profile = src.profile.copy()
        src_arr = src.read(1)
        in_unique = set(int(v) for v in np.unique(src_arr))
        map_keys = set(int(k) for k in mapping.keys())
        missing = sorted(in_unique - map_keys)
        extra = sorted(map_keys - in_unique)
        print("Input unique values:", sorted(in_unique))
        print("Mapping keys not present in input:", extra)
        print("Input values not in mapping:", missing)
        
        if missing and default_value is None:
            # Preserve unmapped values. This handles landCover value 0 exactly as the
            # existing reference raster in MountainLionNew/landcover_reclassified.tif does.
            out_arr = src_arr.copy()
            print("Unmapped values will be preserved unchanged.")
        else:
            fill = 0 if default_value is None else default_value
            out_arr = np.full(src_arr.shape, fill, dtype=np.uint8)
            print("Unmapped values will be set to:", fill)
        
        for old, new in mapping.items():
            out_arr[src_arr == old] = new
        
        # Categorical standardized scale is small integer; uint8 is adequate.
        profile.update(
            dtype=rasterio.uint8,
            count=1,
            compress="lzw",
            tiled=False,
            nodata=None
        )
        
        with rasterio.open(dst_path, "w", **profile) as dst:
            dst.write(out_arr.astype(np.uint8), 1)
            # Preserve dataset-level AREA_OR_POINT tag where possible.
            tags = src.tags().copy()
            if tags:
                dst.update_tags(**tags)
            # Also add explicit provenance/classification notes.
            dst.update_tags(
                reclassified_from=os.path.basename(src_path),
                reclassification="individual categorical lookup to common 1-10 scale"
            )
            try:
                dst.build_overviews([2, 4, 8, 16], Resampling.nearest)
                dst.update_tags(ns="rio_overview", resampling="nearest")
                print("Built internal overviews with nearest-neighbor resampling.")
            except Exception as e:
                print("Could not build overviews:", repr(e))
        
        out_unique, out_counts = np.unique(out_arr, return_counts=True)
        print("Output unique values (value: count):")
        for v, c in zip(out_unique, out_counts):
            print(f"  {int(v)}: {int(c)}")
        return out_arr

land_out = reclassify_raster(
    "MountainLionNew/landCover.tif",
    "pred_results/landCover_reclassified.tif",
    landCover_classification
)
prot_out = reclassify_raster(
    "MountainLionNew/Protected_Status.tif",
    "pred_results/protected_status_reclassified.tif",
    protected_status_classification
)

# Validate outputs exist and compare against provided reference rasters if available.
print("=" * 80)
print("Validation")
for path in ["pred_results/landCover_reclassified.tif", "pred_results/protected_status_reclassified.tif"]:
    print(path, "exists:", os.path.exists(path), "size bytes:", os.path.getsize(path) if os.path.exists(path) else None)
    with rasterio.open(path) as src:
        print("  shape:", (src.height, src.width), "dtype:", src.dtypes[0], "crs:", src.crs, "nodata:", src.nodata)
        print("  transform:", src.transform)

refs = [
    ("pred_results/landCover_reclassified.tif", "MountainLionNew/landcover_reclassified.tif"),
    ("pred_results/protected_status_reclassified.tif", "MountainLionNew/protected_status_reclassified.tif")
]
for made, ref in refs:
    if os.path.exists(ref):
        with rasterio.open(made) as a, rasterio.open(ref) as b:
            aa = a.read(1)
            bb = b.read(1)
            same = aa.shape == bb.shape and np.array_equal(aa, bb)
            print(f"Compare {made} to reference {ref}: identical pixels = {same}")
            if aa.shape == bb.shape:
                print("  differing pixel count:", int(np.count_nonzero(aa != bb)))