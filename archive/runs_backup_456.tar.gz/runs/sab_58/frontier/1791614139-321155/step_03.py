from pathlib import Path
import pandas as pd

src = Path("nvc/ind_data_for_plot.csv")
df = pd.read_csv(src)
print("Source shape:", df.shape)
print("Source columns:", list(df.columns))
print("Full source:")
print(df.to_string(index=False))

# Parse the one semicolon-separated column to verify rows and totals.
col = df.columns[0]
parsed = df[col].str.split(";", expand=True)
parsed.columns = ["Model", "Rule", "Num persons"]
parsed["Num persons"] = pd.to_numeric(parsed["Num persons"])
print("\nParsed shape:", parsed.shape)
print(parsed.to_string(index=False))
print("\nTotal count across rows:", parsed["Num persons"].sum())
print("Rows by model:")
print(parsed.groupby("Model")["Num persons"].agg(["count","sum"]).to_string())

ragni = pd.read_csv("nvc/Ragni2016.csv")
print("\nUnique participant ids:", ragni["id"].nunique())
print("Rows per participant min/max:", ragni.groupby("id").size().min(), ragni.groupby("id").size().max())

# Create required output directory at working-directory root and write the required file.
out_dir = Path("pred_results")
out_dir.mkdir(exist_ok=True)
out = out_dir / "individuals.csv"

# The required row format is exactly "Model; Rule; Num persons"; write a one-column CSV
# with that header and rows as semicolon-separated records, matching the provided data.
out_df = pd.DataFrame({
    "Model; Rule; Num persons": parsed["Model"] + "; " + parsed["Rule"] + "; " + parsed["Num persons"].astype(str)
})
out_df.to_csv(out, index=False)

print("\nWrote:", out)
print("Output exists:", out.exists(), "size:", out.stat().st_size)
print("Output contents:")
print(out.read_text())