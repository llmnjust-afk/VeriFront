import os
from pathlib import Path
import pandas as pd

# Print a more focused inspection to infer the intended computation.
paths = [
    Path("nvc/ind_data_for_plot.csv"),
    Path("nvc/accuracies_data_for_plot.csv"),
    Path("nvc/valid_syllogisms.csv"),
]
for p in paths:
    print("\n==", p, "==")
    df = pd.read_csv(p)
    print("shape", df.shape)
    print("columns", list(df.columns))
    print(df.head(20).to_string(index=False))
    print("dtypes", df.dtypes.to_dict())

# Locate any scripts/notebooks that may have generated indiv_table.png or expected individuals.csv.
print("\nPython/script files under nvc:")
for p in sorted(Path("nvc").rglob("*")):
    if p.suffix.lower() in [".py", ".R", ".ipynb", ".sh"]:
        print(p)

# Inspect all Python files in nvc/scripts except rule modules.
for p in sorted(Path("nvc/scripts").rglob("*.py")):
    if "/rules/" in str(p).replace("\\", "/"):
        continue
    print("\n== PY", p, "==")
    txt = p.read_text(errors="replace")
    print("\n".join(txt.splitlines()[:250]))

# Show all model CSV contents fully (small files).
for d in [Path("nvc/scripts/indiv_table/models"), Path("nvc/scripts/prediction_errors/models")]:
    print("\nMODEL DIR", d)
    for p in sorted(d.glob("*.csv")):
        print("\n--", p.name, "--")
        print(p.read_text())

# Show rule files fully from indiv_table.
for p in sorted(Path("nvc/scripts/indiv_table/rules").glob("*.py")):
    print("\n== RULE", p.name, "==")
    print(p.read_text())