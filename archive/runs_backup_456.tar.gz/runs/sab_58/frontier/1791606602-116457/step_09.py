#!/usr/bin/env python3
from pathlib import Path
import pandas as pd

# Source data discovered in the verified benchmark dataset tree.  This file is
# the benchmark's individual-level aggregation table for model-rule best fits.
src = Path("/data/lab/sab_data/benchmark_verified/benchmark/datasets/nvc/ind_data_for_plot.csv")
out_dir = Path("pred_results")
out_path = out_dir / "individuals.csv"

if not src.exists():
    raise FileNotFoundError(f"Required source aggregation not found: {src}")

out_dir.mkdir(parents=True, exist_ok=True)

# Preserve the semicolon-formatted single-column CSV exactly as provided by the
# dataset aggregation, because the requested row format is:
# Model; Rule; Num persons
df = pd.read_csv(src)
df.to_csv(out_path, index=False)

print(f"Wrote {out_path}")
print("Shape:", df.shape)
print("Columns:", list(df.columns))
print("Contents:")
print(df.to_string(index=False))

# Basic validation
parsed = df.iloc[:, 0].str.split(";", expand=True)
if parsed.shape[1] != 3:
    raise ValueError("Output rows do not split into exactly three semicolon-separated fields.")
parsed.columns = ["Model", "Rule", "Num persons"]
parsed["Num persons"] = parsed["Num persons"].astype(int)
print("\nValidation summary:")
print("Rows:", len(parsed))
print("Total assigned model-rule best fits:", int(parsed["Num persons"].sum()))
print("Models:", ", ".join(parsed["Model"].unique()))
print("Rules:", ", ".join(parsed["Rule"].unique()))