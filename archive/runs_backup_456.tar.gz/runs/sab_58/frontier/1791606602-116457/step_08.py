#!/usr/bin/env python3
import pandas as pd
from pathlib import Path
import os

base = Path("/data/lab/sab_data/benchmark_verified/benchmark/datasets/nvc")
print("Base exists:", base.exists())

# Print full existing aggregate table, likely benchmark reference/target data.
ind = pd.read_csv(base/"ind_data_for_plot.csv")
print("\nind_data_for_plot full:")
print(ind.to_string(index=False))

# Parse semicolon column into fields for sanity checks.
col = ind.columns[0]
parsed = ind[col].str.split(";", expand=True)
parsed.columns = ["Model","Rule","Num persons"]
parsed["Num persons"] = parsed["Num persons"].astype(int)
print("\nParsed summary:")
print("rows:", len(parsed), "sum:", parsed["Num persons"].sum(), "models:", parsed["Model"].unique().tolist())
print(parsed.groupby("Model")["Num persons"].sum().to_string())

# Inspect accuracies combination coverage.
acc = pd.read_csv(base/"accuracies_data_for_plot.csv")
print("\nAccuracy combos/counts:")
print(acc.groupby(["model","nvc"]).size().reset_index(name="n_tasks").to_string(index=False))
print("\nUnique tasks:", acc["task"].nunique(), "unique combo rows per task? rows", len(acc))

# inspect names from model files only, concise
model_dir = base/"scripts/indiv_table/models"
print("\nModel file column/content summaries:")
for p in sorted(model_dir.glob("*.csv")):
    df = pd.read_csv(p)
    print(p.name, "shape", df.shape, "columns", list(df.columns), "head records", df.head(3).to_dict("records"))