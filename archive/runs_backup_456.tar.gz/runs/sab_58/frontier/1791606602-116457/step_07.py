#!/usr/bin/env python3
import pandas as pd
from pathlib import Path
import os, sys, importlib.util, inspect

base = Path("/data/lab/sab_data/benchmark_verified/benchmark/datasets/nvc")
print("Using base", base, "exists", base.exists())

# Inspect core CSVs
for fname in ["ind_data_for_plot.csv","accuracies_data_for_plot.csv","valid_syllogisms.csv","Ragni2016.csv"]:
    p = base/fname
    print("\n==", fname, p.exists(), p.stat().st_size if p.exists() else None)
    df = pd.read_csv(p)
    print("shape", df.shape)
    print("columns", list(df.columns))
    print(df.head(10).to_string(index=False))
    if fname == "Ragni2016.csv":
        print("ids", df["id"].nunique(), "rows/id minmax", df.groupby("id").size().min(), df.groupby("id").size().max())
        print("responses sample", df["response"].value_counts().head(10).to_string())

# Inspect model csvs
model_dir = base/"scripts/indiv_table/models"
print("\nModel files:")
for p in sorted(model_dir.glob("*.csv")):
    df = pd.read_csv(p)
    print("\n--", p.name, "shape", df.shape, "cols", list(df.columns))
    print(df.to_string(index=False))

# Inspect rule scripts
for sub in ["indiv_table", "prediction_errors", "nvc_prediction"]:
    rule_dir = base/f"scripts/{sub}/rules"
    print("\nRULE DIR", rule_dir)
    for p in sorted(rule_dir.glob("*.py")):
        print("\n--", p.name)
        txt = p.read_text()
        print(txt[:2500])