#!/usr/bin/env python3
import os
from pathlib import Path
import pandas as pd

base = Path("benchmark")
print("Benchmark exists:", base.exists(), "contents:")
for p in sorted(base.iterdir()) if base.exists() else []:
    print(("DIR " if p.is_dir() else "FILE"), p)

print("\nFind nvc-like paths and csvs up to depth 8")
csvs = []
pys = []
for root, dirs, files in os.walk(base):
    rel = Path(root)
    depth = len(rel.parts)
    if depth > 9:
        dirs[:] = []
        continue
    if "nvc" in str(rel).lower() or any(f.endswith(".csv") for f in files):
        print(root, "dirs=", dirs[:8], "files=", files[:12])
    for f in files:
        if f.endswith(".csv"):
            csvs.append(Path(root)/f)
        elif f.endswith(".py") and "rules" in root:
            pys.append(Path(root)/f)

print("\nCSV count", len(csvs))
for p in csvs[:50]:
    print(p)
print("\nRule py count", len(pys))
for p in pys[:30]:
    print(p)

# Try exact tree under benchmark/nvc
for candidate in [Path("benchmark/nvc"), Path("benchmark")/"nvc"]:
    print("\nCandidate", candidate, candidate.exists())
    if candidate.exists():
        for target in ["Ragni2016.csv","ind_data_for_plot.csv","valid_syllogisms.csv","accuracies_data_for_plot.csv"]:
            p = candidate/target
            print(p, p.exists())
            if p.exists():
                df = pd.read_csv(p)
                print(df.shape, list(df.columns), df.head(2).to_dict("records"))