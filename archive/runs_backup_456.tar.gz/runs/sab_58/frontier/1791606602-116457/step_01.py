#!/usr/bin/env python3
import os
import pandas as pd

print("Working directory:", os.getcwd())
for root, dirs, files in os.walk("nvc"):
    level = root.count(os.sep)
    if level <= 3:
        print(root, "dirs=", dirs, "files=", files[:10])

paths = [
    "nvc/ind_data_for_plot.csv",
    "nvc/valid_syllogisms.csv",
    "nvc/accuracies_data_for_plot.csv",
    "nvc/Ragni2016.csv",
]
for p in paths:
    print("\n==", p, "==")
    if os.path.exists(p):
        try:
            df = pd.read_csv(p)
            print(df.shape)
            print(df.head())
            print("columns:", list(df.columns))
        except Exception as e:
            print("read error", type(e), e)
    else:
        print("missing")

for sub in ["indiv_table", "prediction_errors"]:
    model_dir = f"nvc/scripts/{sub}/models"
    print("\nModels in", model_dir)
    if os.path.isdir(model_dir):
        for f in sorted(os.listdir(model_dir)):
            p = os.path.join(model_dir, f)
            try:
                df = pd.read_csv(p)
                print(f, df.shape, list(df.columns), df.head(2).to_dict("records"))
            except Exception as e:
                print(f, "error", e)

print("\nRule files preview:")
for sub in ["indiv_table", "prediction_errors", "nvc_prediction"]:
    rule_dir = f"nvc/scripts/{sub}/rules"
    print("==", rule_dir)
    if os.path.isdir(rule_dir):
        for f in sorted(os.listdir(rule_dir)):
            if f.endswith(".py") and f != "__init__.py":
                p = os.path.join(rule_dir, f)
                print("--", f)
                with open(p, "r", encoding="utf-8") as fh:
                    lines = fh.readlines()[:50]
                print("".join(lines[:20]))
                break