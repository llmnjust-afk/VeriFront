#!/usr/bin/env python3
from pathlib import Path
import os

patterns = ["Ragni", "syllog", "PSYCOP", "Atmosphere", "indiv_table", "nvc"]
print("Targeted search under current directory...")
matches = []
for root, dirs, files in os.walk("."):
    # prune huge image dirs and hidden/cache
    dirs[:] = [d for d in dirs if d not in {".git", "__pycache__"} and "images" not in d.lower()]
    for name in dirs + files:
        s = name.lower()
        full = str(Path(root)/name)
        if any(p.lower() in s or p.lower() in full.lower() for p in patterns):
            try:
                size = (Path(root)/name).stat().st_size if (Path(root)/name).is_file() else None
            except Exception:
                size = None
            matches.append((full, size))
            print(full, size)
print("Total matches:", len(matches))

print("\nTop-level pred_results content:")
pr = Path("pred_results")
pr.mkdir(exist_ok=True)
for p in sorted(pr.iterdir()):
    print(p, p.stat().st_size if p.is_file() else "DIR")