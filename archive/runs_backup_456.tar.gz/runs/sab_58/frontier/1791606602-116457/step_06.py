#!/usr/bin/env python3
from pathlib import Path
import os

print("Searching nearby /data/lab for nvc/Ragni2016.csv and model files (pruned)...")
roots = [Path("/data/lab/VeriFront"), Path("/data/lab")]
targets = {"Ragni2016.csv", "ind_data_for_plot.csv", "valid_syllogisms.csv", "accuracies_data_for_plot.csv",
           "PSYCOP.csv", "Matching.csv", "VerbalModels.csv", "MMT.csv", "Conversion.csv", "PHM.csv", "Atmosphere.csv"}
found = []
visited = 0
for start in roots:
    if not start.exists():
        continue
    print("START", start)
    for root, dirs, files in os.walk(start):
        visited += 1
        # prune expensive/unrelated/cache dirs
        dirs[:] = [d for d in dirs if d not in {".git", "__pycache__", ".cache", "node_modules"} and not d.startswith(".")]
        # only descend into likely run/benchmark dirs but keep broad for first levels
        rp = Path(root)
        if len(rp.parts) - len(start.parts) > 8:
            dirs[:] = []
        hits = [f for f in files if f in targets]
        if hits:
            print("HITDIR", root, hits)
            for f in hits:
                p = Path(root)/f
                found.append(p)
                print(" ", p, p.stat().st_size)
        if visited % 20000 == 0:
            print("visited", visited, "dirs; found", len(found))
        if len(found) >= 30 and any(p.name=="Ragni2016.csv" for p in found):
            break
    if found:
        break
print("Done. visited", visited, "found", len(found))
for p in found:
    print("FOUND", p)