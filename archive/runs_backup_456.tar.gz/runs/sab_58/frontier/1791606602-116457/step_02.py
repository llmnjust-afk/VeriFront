#!/usr/bin/env python3
import os
from pathlib import Path

print("CWD:", os.getcwd())
print("Top-level entries:")
for p in sorted(Path(".").iterdir()):
    print(("DIR " if p.is_dir() else "FILE"), p)

print("\nSearching for relevant files/directories up to depth 5...")
names = {"Ragni2016.csv", "ind_data_for_plot.csv", "valid_syllogisms.csv", "accuracies_data_for_plot.csv",
         "PSYCOP.csv", "Matching.csv", "VerbalModels.csv", "MMT.csv", "Conversion.csv", "PHM.csv", "Atmosphere.csv"}
for root, dirs, files in os.walk("."):
    depth = Path(root).relative_to(".").parts
    if len(depth) > 6:
        dirs[:] = []
        continue
    hits = [f for f in files if f in names or f.endswith(".py")]
    if "nvc" in root or hits:
        print(root, "dirs=", dirs[:10], "hits=", hits[:20])