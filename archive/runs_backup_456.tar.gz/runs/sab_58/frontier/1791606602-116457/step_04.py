#!/usr/bin/env python3
import os
from pathlib import Path

print("Recursive listing of benchmark/datasets (limited):")
for root, dirs, files in os.walk("benchmark/datasets"):
    rel = Path(root)
    depth = len(rel.parts)
    if depth > 10:
        dirs[:] = []
        continue
    print(root, "dirs=", dirs[:20], "files=", files[:20])

print("\nAll files up to depth 12:")
count=0
for root, dirs, files in os.walk("."):
    if len(Path(root).parts) > 12:
        dirs[:] = []
        continue
    for f in files:
        p=Path(root)/f
        print(p, p.stat().st_size)
        count += 1
        if count > 300:
            print("... stopping at 300")
            raise SystemExit
print("total listed", count)