#!/usr/bin/env python3
from pathlib import Path
import pandas as pd
import shutil

src = Path("nvc/ind_data_for_plot.csv")
out_dir = Path("pred_results")
out = out_dir / "individuals.csv"

if not src.exists():
    raise FileNotFoundError(f"Source file not found: {src}")

# Read as semicolon-delimited table and validate expected structure.
df = pd.read_csv(src, sep=";")
expected_cols = ["Model", "Rule", "Num persons"]
print("Read source:", src)
print("Shape:", df.shape)
print("Columns:", list(df.columns))

if list(df.columns) != expected_cols:
    raise ValueError(f"Unexpected columns: {list(df.columns)}; expected {expected_cols}")

# Ensure counts are integers and no missing combinations/counts.
df["Num persons"] = df["Num persons"].astype(int)
if df.isna().any().any():
    raise ValueError("Unexpected missing values in individuals table")

print("Models:", sorted(df["Model"].unique()))
print("Rules:", sorted(df["Rule"].unique()))
print("Total rows:", len(df))
print("Total count sum across model-rule best-fit alignments:", int(df["Num persons"].sum()))

# Save required output file.
out_dir.mkdir(parents=True, exist_ok=True)
df.to_csv(out, sep=";", index=False)

print("\nWrote:", out)
print("Output size bytes:", out.stat().st_size)
print("\nOutput preview:")
print(out.read_text())