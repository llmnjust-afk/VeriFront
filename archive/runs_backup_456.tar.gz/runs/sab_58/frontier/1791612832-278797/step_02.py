#!/usr/bin/env python3
from pathlib import Path
import pandas as pd
import csv
import os

def show_file(path, max_chars=5000):
    print(f"\n===== RAW {path} =====")
    p = Path(path)
    if not p.exists():
        print("MISSING")
        return
    txt = p.read_text(errors="replace")
    print(txt[:max_chars])
    print(f"--- length {len(txt)} chars ---")

show_file("nvc/ind_data_for_plot.csv", 10000)
show_file("nvc/accuracies_data_for_plot.csv", 3000)
show_file("nvc/valid_syllogisms.csv", 3000)

# More compact CSV inspection for models
for path in sorted(Path("nvc/scripts/indiv_table/models").glob("*.csv")):
    print(f"\n===== RAW MODEL {path.name} =====")
    print(path.read_text()[:2000])

# Inspect full rule files compactly
for path in sorted(Path("nvc/scripts/indiv_table/rules").glob("*.py")):
    print(f"\n===== RULE {path.name} =====")
    print(path.read_text())

# Analyze Ragni dimensions, individuals counts and responses
df = pd.read_csv("nvc/Ragni2016.csv")
print("\n===== Ragni summary =====")
print("shape", df.shape)
print("n ids", df["id"].nunique(), "min rows per id", df.groupby("id").size().min(), "max", df.groupby("id").size().max())
print("task count", df["task"].nunique())
print("sequence range", df["sequence"].min(), df["sequence"].max())
print("response counts top")
print(df["response"].value_counts().head(20).to_string())
print("first id tasks/responses")
print(df[df.id == df.id.min()].head(64)[["id","sequence","task","response"]].to_string(index=False))