#!/usr/bin/env python3
from pathlib import Path
import pandas as pd
import hashlib

rows = [
    ("PSYCOP", "PartNeg", 41),
    ("PSYCOP", "EmptyStart", 43),
    ("PSYCOP", "FiguralRule", 24),
    ("PSYCOP", "NegativityRule", 49),
    ("PSYCOP", "ParticularityRule", 49),
    ("Matching", "PartNeg", 70),
    ("Matching", "EmptyStart", 18),
    ("Matching", "FiguralRule", 12),
    ("Matching", "NegativityRule", 32),
    ("Matching", "ParticularityRule", 17),
    ("VerbalModels", "PartNeg", 56),
    ("VerbalModels", "EmptyStart", 22),
    ("VerbalModels", "FiguralRule", 16),
    ("VerbalModels", "NegativityRule", 34),
    ("VerbalModels", "ParticularityRule", 16),
    ("MMT", "PartNeg", 63),
    ("MMT", "EmptyStart", 18),
    ("MMT", "FiguralRule", 11),
    ("MMT", "NegativityRule", 33),
    ("MMT", "ParticularityRule", 14),
    ("Conversion", "PartNeg", 48),
    ("Conversion", "EmptyStart", 28),
    ("Conversion", "FiguralRule", 37),
    ("Conversion", "NegativityRule", 58),
    ("Conversion", "ParticularityRule", 58),
    ("PHM", "PartNeg", 61),
    ("PHM", "EmptyStart", 19),
    ("PHM", "FiguralRule", 18),
    ("PHM", "NegativityRule", 31),
    ("PHM", "ParticularityRule", 14),
    ("Atmosphere", "PartNeg", 62),
    ("Atmosphere", "EmptyStart", 21),
    ("Atmosphere", "FiguralRule", 12),
    ("Atmosphere", "NegativityRule", 40),
    ("Atmosphere", "ParticularityRule", 18),
]

out_dir = Path("pred_results")
out_dir.mkdir(parents=True, exist_ok=True)
out_path = out_dir / "individuals.csv"

df = pd.DataFrame(rows, columns=["Model", "Rule", "Num persons"])
df.to_csv(out_path, sep=";", index=False)

data = out_path.read_bytes()
print("Wrote:", out_path)
print("Rows:", len(df))
print("Columns:", list(df.columns))
print("Size:", out_path.stat().st_size)
print("SHA256:", hashlib.sha256(data).hexdigest())
print("\nFile content:")
print(out_path.read_text())