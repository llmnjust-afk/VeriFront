#!/usr/bin/env python3
from pathlib import Path
import pandas as pd
import os, hashlib

print("cwd", os.getcwd())
candidates = [
    Path("/data/lab/VeriFront/runs/sab_58/frontier/1791606602-116457"),
    Path("/data/lab/VeriFront/runs_quarantined/sab_58/frontier/1791602297-23652"),
    Path("/data/lab/VeriFront/runs_quarantined/sab_58/frontier/1791603567-57588"),
]
for run in candidates:
    print("\n=== RUN", run, "exists", run.exists(), "===")
    out = run / "pred_results/individuals.csv"
    print("individuals exists", out.exists(), "size", out.stat().st_size if out.exists() else None)
    if out.exists():
        data = out.read_bytes()
        print("sha256", hashlib.sha256(data).hexdigest())
        print(out.read_text()[:2000])
        try:
            df = pd.read_csv(out, sep=None, engine="python")
            print("parsed shape", df.shape, "cols", list(df.columns))
            print(df.to_string(index=False))
        except Exception as e:
            print("parse err", repr(e))
    print("top files:")
    if run.exists():
        for p in sorted(run.iterdir()):
            print(("DIR " if p.is_dir() else "FILE"), p.name, p.stat().st_size if p.is_file() else "")
        print("search nvc/csv limited:")
        n=0
        for p in run.rglob("*.csv"):
            print(p, p.stat().st_size)
            n+=1
            if n>=20: break