#!/usr/bin/env python3
import os
import pandas as pd
from pathlib import Path

print("Working directory:", os.getcwd())
base = Path("nvc")
print("Exists nvc:", base.exists())

for p in [
    "nvc/ind_data_for_plot.csv",
    "nvc/accuracies_data_for_plot.csv",
    "nvc/valid_syllogisms.csv",
    "nvc/Ragni2016.csv",
]:
    path = Path(p)
    print("\n==", p, "==")
    print("exists:", path.exists(), "size:", path.stat().st_size if path.exists() else None)
    if path.exists():
        try:
            df = pd.read_csv(path)
            print("shape:", df.shape)
            print("columns:", list(df.columns))
            print(df.head(10).to_string(index=False))
        except Exception as e:
            print("read error:", repr(e))

for sub in ["nvc/scripts/indiv_table/models", "nvc/scripts/prediction_errors/models"]:
    print("\nListing", sub)
    for f in sorted(Path(sub).glob("*.csv")):
        try:
            df = pd.read_csv(f)
            print(f.name, "shape", df.shape, "cols", list(df.columns)[:10])
            print(df.head(3).to_string(index=False))
        except Exception as e:
            print(f.name, "error", repr(e))

for sub in ["nvc/scripts/indiv_table/rules", "nvc/scripts/prediction_errors/rules", "nvc/scripts/nvc_prediction/rules"]:
    print("\nListing", sub)
    for f in sorted(Path(sub).glob("*.py")):
        print("----", f.name)
        txt = f.read_text(encoding="utf-8", errors="replace")
        print("\n".join(txt.splitlines()[:60]))