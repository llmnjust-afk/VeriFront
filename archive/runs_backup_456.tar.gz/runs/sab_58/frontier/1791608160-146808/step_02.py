#!/usr/bin/env python3
from pathlib import Path
import os
import pandas as pd

print("cwd", os.getcwd())
print("Top-level listing:")
for p in sorted(Path(".").iterdir()):
    print(("DIR " if p.is_dir() else "FILE"), p, "size", (p.stat().st_size if p.is_file() else ""))

print("\nSearching for Ragni2016.csv / nvc directory up to moderate depth...")
matches = []
for root in [Path("."), Path("/data/lab/VeriFront/runs"), Path("/data/lab/VeriFront")]:
    if root.exists():
        try:
            for p in root.rglob("Ragni2016.csv"):
                matches.append(p)
                print("Found Ragni:", p)
                if len(matches) > 20:
                    break
        except Exception as e:
            print("search error", root, repr(e))
    if len(matches) > 20:
        break

print("\nSearching for individuals.csv existing:")
cnt=0
for root in [Path("."), Path("/data/lab/VeriFront")]:
    if root.exists():
        try:
            for p in root.rglob("individuals.csv"):
                print("Found existing:", p)
                cnt += 1
                if cnt > 20: break
        except Exception as e:
            print("error", repr(e))
    if cnt > 20: break

if matches:
    base = matches[0].parent
    print("\nUsing base:", base)
    for f in ["ind_data_for_plot.csv", "accuracies_data_for_plot.csv", "valid_syllogisms.csv", "Ragni2016.csv"]:
        p = base / f
        print("\n==", p, "== exists", p.exists())
        if p.exists():
            df = pd.read_csv(p)
            print("shape", df.shape, "columns", list(df.columns))
            print(df.head(8).to_string(index=False))
else:
    print("No dataset found.")