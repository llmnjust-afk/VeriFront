#!/usr/bin/env python3
from pathlib import Path
import os
import pandas as pd

print("cwd", os.getcwd())
print("benchmark tree (first 200 entries):")
root = Path("benchmark")
for i, p in enumerate(sorted(root.rglob("*"))):
    if i >= 200:
        print("... truncated")
        break
    print(("DIR " if p.is_dir() else "FILE"), p, "size", p.stat().st_size if p.is_file() else "")

print("\nCSV files under benchmark:")
for p in sorted(root.rglob("*.csv")):
    print(p, "size", p.stat().st_size)
    try:
        df = pd.read_csv(p)
        print("  shape", df.shape, "cols", list(df.columns)[:12])
        print(df.head(3).to_string(index=False))
    except Exception as e:
        print("  read error", repr(e))

print("\nPython files under benchmark:")
for p in sorted(root.rglob("*.py"))[:50]:
    print(p, "size", p.stat().st_size)