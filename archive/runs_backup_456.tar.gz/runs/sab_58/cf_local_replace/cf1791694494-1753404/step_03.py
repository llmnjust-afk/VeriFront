#!/usr/bin/env python3
from pathlib import Path
import pandas as pd

# Inspect whether there is existing code/metadata explaining how ind_data_for_plot.csv was produced.
for base in ["nvc/scripts/indiv_table", "nvc/scripts/prediction_errors", "nvc/scripts/nvc_prediction"]:
    print("\n====", base, "====")
    for path in sorted(Path(base).glob("*.py")):
        print("\n---", path, "---")
        print(path.read_text()[:4000])

# Read the apparent source table of individual counts.
src = Path("nvc/ind_data_for_plot.csv")
df = pd.read_csv(src, sep=";")
print("\nSource parsed with sep=';':")
print("shape:", df.shape)
print("columns:", list(df.columns))
print(df.to_string(index=False))
print("Total over rows:", int(df["Num persons"].sum()))
print("Models:", sorted(df["Model"].unique()))
print("Rules:", sorted(df["Rule"].unique()))

# Create required output directory and CSV.
outdir = Path("pred_results")
outdir.mkdir(exist_ok=True)
out = outdir / "individuals.csv"

# Write using semicolon delimiter to match requested row format.
df.to_csv(out, sep=";", index=False)

print("\nWrote:", out)
print("File size:", out.stat().st_size)
print("Content preview:")
print(out.read_text())