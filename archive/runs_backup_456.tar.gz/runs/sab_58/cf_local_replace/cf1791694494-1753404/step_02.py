#!/usr/bin/env python3
from pathlib import Path

def show(p, n=60):
    path = Path(p)
    print("="*80)
    print(path)
    if not path.exists():
        print("MISSING")
        return
    txt = path.read_text()
    lines = txt.splitlines()
    print("total lines:", len(lines))
    for l in lines[:n]:
        print(l)

show("nvc/ind_data_for_plot.csv")
show("nvc/valid_syllogisms.csv")
show("nvc/accuracies_data_for_plot.csv", 40)