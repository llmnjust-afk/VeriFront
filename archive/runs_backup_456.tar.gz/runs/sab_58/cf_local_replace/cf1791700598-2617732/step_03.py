from pathlib import Path
import pandas as pd
import os

base = Path("nvc")

print("Find scripts and relevant CSVs:")
for p in sorted(base.rglob("*")):
    if p.suffix in {".py", ".csv"} and ("__pycache__" not in str(p)):
        print(p)

print("\nFull nvc/ind_data_for_plot.csv:")
ind = pd.read_csv(base/"ind_data_for_plot.csv")
print(ind.to_string(index=False))
print("Rows:", len(ind))

print("\nValue parsing check:")
parsed = ind.iloc[:,0].str.split(";", expand=True)
parsed.columns = ["Model","Rule","Num persons"]
parsed["Num persons"] = parsed["Num persons"].astype(int)
print(parsed.to_string(index=False))
print("Total Num persons:", parsed["Num persons"].sum())
print("Models:", sorted(parsed["Model"].unique()))
print("Rules:", sorted(parsed["Rule"].unique()))

print("\nFull accuracies group keys:")
acc = pd.read_csv(base/"accuracies_data_for_plot.csv")
print("shape", acc.shape)
print(acc.groupby(["model","nvc"]).size().reset_index(name="n").to_string(index=False))
print("unique models", sorted(acc["model"].unique()))
print("unique nvc", sorted(acc["nvc"].unique()))

print("\nInspect model prediction contents:")
for csv in sorted((base/"scripts"/"indiv_table"/"models").glob("*.csv")):
    df = pd.read_csv(csv)
    print("\n", csv.name)
    print(df.head(12).to_string(index=False))
    print("Prediction unique sample:", df["Prediction"].drop_duplicates().head(20).tolist())

print("\nInspect first 200 lines of any possible script outside rule/model dirs:")
for py in sorted(base.rglob("*.py")):
    if "__pycache__" in str(py) or "/rules/" in str(py):
        continue
    print("\nPY", py)
    print("\n".join(py.read_text().splitlines()[:220]))