import os
import re
from pathlib import Path
import pandas as pd

base = Path("nvc")
models_dir = base / "scripts" / "indiv_table" / "models"
rules_dir = base / "scripts" / "indiv_table" / "rules"
out_dir = Path("pred_results")
out_dir.mkdir(exist_ok=True)

# Load participant data
ragni = pd.read_csv(base / "Ragni2016.csv")
print("Ragni shape:", ragni.shape)
print("Unique ids:", ragni["id"].nunique())

# Infer task index order per participant
ragni = ragni.sort_values(["id", "sequence"]).reset_index(drop=True)

# Read model prediction files
model_preds = {}
for csv in sorted(models_dir.glob("*.csv")):
    df = pd.read_csv(csv)
    model_preds[csv.stem] = df
    print(f"Loaded model {csv.stem}: shape={df.shape}, columns={list(df.columns)}")

# Read/inspect rule files to determine if they produce prediction labels
rule_files = sorted([p for p in rules_dir.glob("*.py") if p.name != "__init__.py"])
print("Rule files:", [p.stem for p in rule_files])

# Heuristic: parse any prediction tables already stored in scripts/indiv_table/pred_results if present
pred_res_dir = base / "scripts" / "indiv_table" / "pred_results"
for p in sorted(pred_res_dir.glob("*")):
    print("Existing pred_result artifact:", p.name)

# Build a simple alignment table from the model CSVs.
# These files usually contain predicted responses per syllogism, one column per rule or a single response column.
# We will robustly inspect their structure and pick the first non-identifying column as the predicted response.
def extract_prediction_column(df):
    cols = list(df.columns)
    # Prefer typical prediction columns
    for candidate in ["prediction", "pred", "response", "resp", "answer", "output"]:
        if candidate in cols:
            return candidate
    # Otherwise choose the first non-index-like column
    for c in cols:
        if c.lower() not in {"id", "sequence", "task", "syllog", "figure", "mood"}:
            return c
    return cols[0]

# Create a compact report of model tables
model_info = {}
for name, df in model_preds.items():
    pred_col = extract_prediction_column(df)
    model_info[name] = {"pred_col": pred_col, "columns": list(df.columns), "df": df}
    print(f"Model {name}: using prediction column '{pred_col}'")

# Also inspect valid syllogisms and ind_data_for_plot to understand expected indexing
for csv in [base / "valid_syllogisms.csv", base / "ind_data_for_plot.csv", base / "accuracies_data_for_plot.csv"]:
    if csv.exists():
        df = pd.read_csv(csv)
        print(f"{csv.name}: shape={df.shape}, columns={list(df.columns)}")
        print(df.head().to_string(index=False))

# Since the exact best-fit rule combination mapping isn't yet established from the source files,
# compute a provisional count table by aligning each participant's response pattern to the available
# model-rule tables on exact match of predicted responses where possible.
# This round just prepares the needed joined matrix for the next turn.
participants = ragni["id"].unique().tolist()
rows = []

# Build a per-model signature over the 64 syllogisms if possible
for model_name, info in model_info.items():
    df = info["df"].copy()
    pred_col = info["pred_col"]
    if len(df) >= 64:
        sig = tuple(df[pred_col].astype(str).tolist()[:64])
        rows.append({"Model": model_name, "Rule": "NA", "Num persons": 0, "Signature_len": len(sig)})
    else:
        rows.append({"Model": model_name, "Rule": "NA", "Num persons": 0, "Signature_len": len(df)})

tmp = pd.DataFrame(rows)
print("\nProvisional model table:")
print(tmp.to_string(index=False))

# Write a placeholder CSV so the next turn can refine it after inspecting actual prediction structures.
out_path = out_dir / "individuals.csv"
tmp[["Model", "Rule", "Num persons"]].to_csv(out_path, index=False)
print("\nWrote:", out_path)
print(out_path.read_text())