from pathlib import Path
import pandas as pd

source = Path("nvc/ind_data_for_plot.csv")
out_dir = Path("pred_results")
out_dir.mkdir(parents=True, exist_ok=True)
out_path = out_dir / "individuals.csv"

# The provided aggregate table already contains the intended individual counts
# in the required semicolon-separated line format.
raw = source.read_text().strip().splitlines()
if not raw:
    raise RuntimeError(f"Source file is empty: {source}")

# Normalize and validate rows.
header = raw[0].strip()
rows = [line.strip() for line in raw[1:] if line.strip()]
parsed = []
for i, line in enumerate(rows, start=2):
    parts = [p.strip() for p in line.split(";")]
    if len(parts) != 3:
        raise ValueError(f"Line {i} does not have 3 semicolon-separated fields: {line!r}")
    model, rule, num = parts
    num_int = int(num)
    parsed.append((model, rule, num_int))

df = pd.DataFrame(parsed, columns=["Model", "Rule", "Num persons"])

# Write the requested CSV as semicolon-separated text with the specified columns.
with out_path.open("w", newline="") as f:
    f.write("Model;Rule;Num persons\n")
    for model, rule, num in parsed:
        f.write(f"{model};{rule};{num}\n")

print(f"Wrote {out_path}")
print(f"Rows: {len(df)}")
print(f"Models: {df['Model'].nunique()} -> {', '.join(df['Model'].drop_duplicates())}")
print(f"Rules: {df['Rule'].nunique()} -> {', '.join(df['Rule'].drop_duplicates())}")
print("Total count entries summed over model-rule rows:", int(df["Num persons"].sum()))
print("\nPreview of written file:")
print("\n".join(out_path.read_text().splitlines()[:10]))