#!/usr/bin/env python3
from pathlib import Path

def show(rel, n=None):
    p = Path(rel)
    print("="*70)
    print("FILE:", rel, "exists:", p.exists())
    print("="*70)
    if p.exists():
        txt = p.read_text()
        lines = txt.splitlines()
        if n:
            lines = lines[:n]
        print("\n".join(lines))

# The target-ish file
show("nvc/ind_data_for_plot.csv")
show("nvc/valid_syllogisms.csv")