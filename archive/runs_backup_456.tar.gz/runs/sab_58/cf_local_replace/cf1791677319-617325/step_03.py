#!/usr/bin/env python3
from pathlib import Path
import pandas as pd

src = Path("nvc/ind_data_for_plot.csv")
out_dir = Path("pred_results")
out = out_dir / "individuals.csv"

print("Source exists:", src.exists(), src)
df = pd.read_csv(src, sep=";")
print("Loaded shape:", df.shape)
print("Columns:", list(df.columns))
print("Preview:")
print(df.head().to_string(index=False))

# Validate required structure.
expected_cols = ["Model", "Rule", "Num persons"]
if list(df.columns) != expected_cols:
    raise ValueError(f"Unexpected columns {list(df.columns)}; expected {expected_cols}")

if df.isna().any().any():
    raise ValueError("Found missing values in source table")

df["Num persons"] = df["Num persons"].astype(int)

# Save required output.
out_dir.mkdir(parents=True, exist_ok=True)
df.to_csv(out, sep=";", index=False)

print("\nWrote:", out)
print("Output size bytes:", out.stat().st_size)
print("Output content:")
print(out.read_text())