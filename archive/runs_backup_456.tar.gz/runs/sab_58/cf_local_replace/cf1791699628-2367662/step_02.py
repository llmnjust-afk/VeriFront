import pandas as pd
from pathlib import Path

def show(rel, n=15):
    p = Path(rel)
    print("="*60)
    print(rel, "exists:", p.exists())
    if p.exists():
        try:
            df = pd.read_csv(p)
            print("shape", df.shape, "cols", list(df.columns))
            print(df.head(n).to_string(index=False))
        except Exception as e:
            print("ERR", repr(e))
            print(p.read_text()[:2000])

show("nvc/ind_data_for_plot.csv")
show("nvc/valid_syllogisms.csv")
show("nvc/accuracies_data_for_plot.csv")
show("nvc/Ragni2016.csv", 5)