#!/usr/bin/env python3
import pandas as pd
from pathlib import Path
try:
    import ccobra
    print("ccobra available", ccobra)
    rag = pd.read_csv("nvc/Ragni2016.csv")
    for i,row in rag.head(10).iterrows():
        item = type("Item", (), {})()
        item.task = [[part.strip() for part in prem.split(";")] for prem in row["task"].split("/")]
        item.choices = []
        syl = ccobra.syllogistic.Syllogism(item)
        print(i, row["task"], "encoded_task", syl.encoded_task, "figure", syl.figure, "resp", row["response"], "encresp", syl.encode_response([p.strip() for p in row["response"].split(";")] if row["response"]!="NVC" else "NVC"))
except Exception as e:
    print("ccobra not available or error:", repr(e))