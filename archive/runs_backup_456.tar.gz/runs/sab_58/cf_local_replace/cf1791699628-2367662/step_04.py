#!/usr/bin/env python3
from pathlib import Path

for path in sorted(Path("nvc/scripts/indiv_table/rules").glob("*.py")):
    print("\n" + "="*80)
    print(path)
    print(path.read_text())