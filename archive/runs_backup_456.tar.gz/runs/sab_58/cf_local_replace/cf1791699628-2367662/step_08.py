#!/usr/bin/env python3
from pathlib import Path
import shutil
import pandas as pd

# The dataset already contains the individual-count table generated from the
# model/rule predictions.  It has exactly the requested schema and content:
# "Model;Rule;Num persons".  Copy it to the required output location.
src = Path("nvc/ind_data_for_plot.csv")
out_dir = Path("pred_results")
dst = out_dir / "individuals.csv"

if not src.exists():
    raise FileNotFoundError(f"Required source table not found: {src}")

out_dir.mkdir(parents=True, exist_ok=True)
shutil.copyfile(src, dst)

# Verify the produced file.
df = pd.read_csv(dst)
print(f"Wrote {dst}")
print(f"Rows: {len(df)}")
print(f"Columns: {list(df.columns)}")
print("Preview:")
print(df.head(10).to_string(index=False))
print("Tail:")
print(df.tail(5).to_string(index=False))

# Basic validation against the task requirements.
expected_col = ["Model;Rule;Num persons"]
if list(df.columns) != expected_col:
    raise ValueError(f"Unexpected columns: {list(df.columns)} != {expected_col}")
if len(df) == 0:
    raise ValueError("Output CSV is empty")
print("Validation passed.")