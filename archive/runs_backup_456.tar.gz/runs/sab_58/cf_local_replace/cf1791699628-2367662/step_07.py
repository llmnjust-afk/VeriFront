#!/usr/bin/env python3
import pandas as pd
import ccobra

rag = pd.read_csv("nvc/Ragni2016.csv")
class Item:
    def __init__(self, row):
        self.identifier = str(row["sequence"])
        self.task = [[part.strip() for part in prem.split(";")] for prem in row["task"].split("/")]
        self.choices = []
        self.response_type = row["response_type"]
        self.domain = row["domain"]

for i,row in rag.head(12).iterrows():
    try:
        item = Item(row)
        syl = ccobra.syllogistic.Syllogism(item)
        resp = "NVC" if row["response"] == "NVC" else [p.strip() for p in row["response"].split(";")]
        print(i, row["task"], "=> encoded_task", syl.encoded_task, "figure", syl.figure, "response", row["response"], "enc", syl.encode_response(resp))
    except Exception as e:
        print("ERR row", i, repr(e))