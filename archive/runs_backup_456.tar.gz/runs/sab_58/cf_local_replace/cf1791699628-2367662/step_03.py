#!/usr/bin/env python3
from pathlib import Path
import pandas as pd

print("Full ind_data_for_plot.csv raw:")
print(Path("nvc/ind_data_for_plot.csv").read_text())

print("\nUnique combos/counts in accuracies_data_for_plot:")
acc = pd.read_csv("nvc/accuracies_data_for_plot.csv")
print("models:", sorted(acc["model"].unique()))
print("nvc rules:", sorted(acc["nvc"].unique()))
print("combo count:", acc[["model","nvc"]].drop_duplicates().shape[0])
print(acc.groupby(["model","nvc"]).size().to_string())

print("\nRagni ids/tasks:")
rag = pd.read_csv("nvc/Ragni2016.csv")
print("n rows", len(rag), "n ids", rag["id"].nunique(), "tasks per id min/max", rag.groupby("id").size().min(), rag.groupby("id").size().max())
print("first ids:", rag["id"].drop_duplicates().head(10).tolist())

print("\nModel CSV contents:")
for path in sorted(Path("nvc/scripts/indiv_table/models").glob("*.csv")):
    print("\n---", path.name, "---")
    print(path.read_text())