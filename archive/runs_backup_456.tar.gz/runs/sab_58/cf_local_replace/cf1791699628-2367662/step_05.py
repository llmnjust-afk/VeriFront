#!/usr/bin/env python3
from pathlib import Path
for name in ["particularity.py","partneg.py"]:
    p=Path("nvc/scripts/indiv_table/rules")/name
    print("\n==", name, "==")
    print(p.read_text())