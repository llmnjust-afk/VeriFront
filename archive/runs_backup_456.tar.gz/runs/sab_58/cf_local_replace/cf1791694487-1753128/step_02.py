#!/usr/bin/env python3
import pandas as pd
from pathlib import Path

root = Path("nvc")
pred_dir = Path("pred_results")
pred_dir.mkdir(exist_ok=True)

# Load the individual-level data. It is a one-column CSV whose header contains the semicolon-delimited fields.
ind = pd.read_csv(root / "ind_data_for_plot.csv")
col = ind.columns[0]
df = ind.copy()
df[["Model", "Rule", "Num persons"]] = df[col].str.split(";", expand=True)
df["Num persons"] = pd.to_numeric(df["Num persons"], errors="coerce").astype("Int64")
df = df[["Model", "Rule", "Num persons"]].fillna("")

# Save requested output.
out = pred_dir / "individuals.csv"
df.to_csv(out, index=False)

print("Saved:", out)
print("Rows:", len(df))
print("Total persons:", int(df["Num persons"].sum()))
print(df.to_string(index=False))