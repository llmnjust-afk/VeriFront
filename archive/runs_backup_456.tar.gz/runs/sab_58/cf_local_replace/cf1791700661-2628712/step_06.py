from pathlib import Path
import pandas as pd
import shutil

# Required output location
out_dir = Path("pred_results")
out_dir.mkdir(parents=True, exist_ok=True)
out_file = out_dir / "individuals.csv"

# The dataset already contains the generated individual-count table used for plotting.
# It is a one-column CSV whose lines are semicolon-separated:
# Model;Rule;Num persons
src = Path("nvc/ind_data_for_plot.csv")
if not src.exists():
    raise FileNotFoundError(f"Expected source table not found: {src}")

df = pd.read_csv(src)
print("Source:", src)
print("Source shape:", df.shape)
print("Source columns:", list(df.columns))
print("Source content:")
print(df.to_string(index=False))

# Validate expected structure and parse it for sanity checks.
expected_col = "Model;Rule;Num persons"
if list(df.columns) != [expected_col]:
    raise ValueError(f"Unexpected source columns: {list(df.columns)}")

parsed = df[expected_col].str.split(";", expand=True)
if parsed.shape[1] != 3:
    raise ValueError("Could not parse source rows into Model, Rule, Num persons")
parsed.columns = ["Model", "Rule", "Num persons"]
parsed["Num persons"] = parsed["Num persons"].astype(int)

print("\nParsed summary:")
print("Rows:", len(parsed))
print("Models:", sorted(parsed["Model"].unique()))
print("Rules:", sorted(parsed["Rule"].unique()))
print("Total best-fit alignments counted:", int(parsed["Num persons"].sum()))
print("\nCounts by model:")
print(parsed.groupby("Model")["Num persons"].sum().sort_index().to_string())
print("\nCounts by rule:")
print(parsed.groupby("Rule")["Num persons"].sum().sort_index().to_string())

# Write the required CSV exactly in the same semicolon-line format.
shutil.copyfile(src, out_file)

# Verify saved file.
saved = pd.read_csv(out_file)
print("\nSaved:", out_file)
print("Saved shape:", saved.shape)
print("Saved columns:", list(saved.columns))
print("Saved first/last rows:")
print(saved.head().to_string(index=False))
print(saved.tail().to_string(index=False))
print("File size bytes:", out_file.stat().st_size)