from pathlib import Path

rules_dir = Path("nvc/scripts/indiv_table/rules")
for name in ["atmosphere.py","emptystart.py","figural.py","negativity.py","particularity.py","partneg.py"]:
    p = rules_dir/name
    print("\n---", name, "---")
    for i, line in enumerate(p.read_text().splitlines(), 1):
        print(f"{i:03d}: {line}")

# Also inspect existing pred_results image metadata/dimensions and root dirs
from PIL import Image
img_path = Path("nvc/scripts/indiv_table/pred_results/indiv_table.png")
if img_path.exists():
    img = Image.open(img_path)
    print("\nimage", img_path, "size", img.size, "mode", img.mode)
print("\nroot dirs:")
for p in sorted(Path(".").iterdir()):
    print(p)