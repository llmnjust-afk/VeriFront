import os
from pathlib import Path
import pandas as pd

base = Path("nvc")
models_dir = base/"scripts"/"indiv_table"/"models"
for csv in sorted(models_dir.glob("*.csv")):
    df = pd.read_csv(csv)
    print("\n===== MODEL", csv.name, "shape", df.shape, "cols", list(df.columns))
    print(df.to_string())

rules_dir = base/"scripts"/"indiv_table"/"rules"
for py in sorted(rules_dir.glob("*.py")):
    print("\n===== RULEFILE", py.name)
    print(py.read_text())