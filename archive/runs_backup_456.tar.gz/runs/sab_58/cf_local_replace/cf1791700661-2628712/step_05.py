from pathlib import Path
import pandas as pd
import importlib.util
import sys

# Concise inspection of remaining required structure and ccobra availability.
for csv in ["nvc/ind_data_for_plot.csv", "nvc/accuracies_data_for_plot.csv", "nvc/valid_syllogisms.csv"]:
    df = pd.read_csv(csv)
    print("\n==", csv, df.shape)
    print("columns:", list(df.columns))
    print(df.head(30).to_csv(index=False))
    for col in df.columns:
        nun = df[col].nunique(dropna=False)
        print(col, "nunique", nun, "sample", df[col].dropna().unique()[:10].tolist())

print("\nRule files complete:")
for p in sorted(Path("nvc/scripts/indiv_table/rules").glob("*.py")):
    print("\n--", p.name)
    print(p.read_text())

print("\nccobra availability:")
try:
    import ccobra
    print("ccobra imported", ccobra)
    # Try construct item/Syllogism? Need inspect interface.
    print("ccobra attrs sample", [a for a in dir(ccobra) if not a.startswith("_")][:50])
    print("syllogistic attrs", [a for a in dir(ccobra.syllogistic) if not a.startswith("_")][:50])
except Exception as e:
    print("ccobra import failed:", repr(e))

print("\nKnown generated output dir:")
pr = Path("nvc/scripts/indiv_table/pred_results")
print(list(pr.iterdir()) if pr.exists() else "missing")