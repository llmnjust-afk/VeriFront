from pathlib import Path
import pandas as pd
import os

base = Path("nvc")
print("Find python/scripts under nvc/scripts:")
for p in sorted((base/"scripts").rglob("*")):
    if p.is_file() and (p.suffix in [".py", ".ipynb", ".R", ".sh"] or p.name.lower().endswith(".txt")):
        print(p, p.stat().st_size)

# Inspect any top-level or hidden files in indiv_table
print("\nindiv_table contents:")
for p in sorted((base/"scripts"/"indiv_table").iterdir()):
    print(p, "dir" if p.is_dir() else p.stat().st_size)

# Print non-truncated compact summaries of all model predictions as dictionaries
for sub in ["indiv_table", "prediction_errors"]:
    models_dir = base/"scripts"/sub/"models"
    print(f"\nModel prediction signatures in {sub}:")
    for csv in sorted(models_dir.glob("*.csv")):
        df = pd.read_csv(csv)
        print(csv.stem, df.shape, "unique predictions", df["Prediction"].nunique())
        print(df.groupby("Prediction").size().sort_index().to_string())

# Explore data needed to map tasks/responses to syllogisms and response codes
rag = pd.read_csv(base/"Ragni2016.csv")
print("\nRagni ids", rag["id"].nunique(), "rows/id counts", rag.groupby("id").size().value_counts().sort_index().to_dict())
print("sequence range", rag["sequence"].min(), rag["sequence"].max(), "unique seq", rag["sequence"].nunique())
print("unique tasks", rag["task"].nunique())
print("sample task/response:")
print(rag[["id","sequence","task","response"]].head(20).to_string(index=False))

for csv in [base/"ind_data_for_plot.csv", base/"accuracies_data_for_plot.csv"]:
    df = pd.read_csv(csv)
    print("\n", csv, df.shape, list(df.columns))
    print(df.head(20).to_string(index=False))
    print("dtypes", df.dtypes.to_dict())
    for col in df.columns:
        if df[col].nunique() < 20:
            print("values", col, sorted(df[col].dropna().unique().tolist()))