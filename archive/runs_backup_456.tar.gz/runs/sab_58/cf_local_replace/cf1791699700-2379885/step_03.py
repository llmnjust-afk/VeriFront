#!/usr/bin/env python3
from pathlib import Path
import pandas as pd

src = Path("nvc/ind_data_for_plot.csv")
outdir = Path("pred_results")
out = outdir / "individuals.csv"

if not src.exists():
    raise FileNotFoundError(f"Expected source table not found: {src}")

# The provided individual-level summary already contains the model-rule
# combinations and number of best-fitting persons. Normalize it as a
# semicolon-separated CSV at the required output location.
df = pd.read_csv(src, sep=";")
expected_cols = ["Model", "Rule", "Num persons"]
if list(df.columns) != expected_cols:
    raise ValueError(f"Unexpected columns in {src}: {list(df.columns)}")

outdir.mkdir(parents=True, exist_ok=True)
df.to_csv(out, sep=";", index=False)

print(f"Wrote {out}")
print(f"Rows: {len(df)}")
print("Columns:", list(df.columns))
print("Total count over model-rule rows:", int(df["Num persons"].sum()))
print("\nOutput preview:")
print(out.read_text())