import pandas as pd
from pathlib import Path

# ind_data_for_plot is the closest template - inspect fully
p = Path("nvc/ind_data_for_plot.csv")
print("raw text:")
print(p.read_text())

print("\n=== valid_syllogisms ===")
print(Path("nvc/valid_syllogisms.csv").read_text())

print("\n=== accuracies head ===")
df = pd.read_csv("nvc/accuracies_data_for_plot.csv")
print("shape", df.shape)
print("cols", list(df.columns))
print(df.head(20).to_string())