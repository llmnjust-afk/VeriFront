from pathlib import Path
import pandas as pd
import textwrap

base=Path("nvc")
print("ind_data_for_plot:")
print(pd.read_csv(base/"ind_data_for_plot.csv").to_string(index=False))
print("\naccuracies columns/head:")
acc=pd.read_csv(base/"accuracies_data_for_plot.csv")
print(acc.shape, list(acc.columns))
print(acc.head(30).to_string(index=False))
print("unique counts:")
for c in acc.columns:
    print(c, acc[c].nunique(), acc[c].dropna().unique()[:20])

print("\nvalid_syllogisms:")
print(pd.read_csv(base/"valid_syllogisms.csv").to_string(index=False))

print("\nRule files:")
for f in sorted((base/"scripts"/"indiv_table"/"rules").glob("*.py")):
    print("\n###", f.name)
    print(f.read_text())

print("\nModel predictions first/last with syllogisms:")
for f in sorted((base/"scripts"/"indiv_table"/"models").glob("*.csv")):
    df=pd.read_csv(f)
    print("\n###", f.stem, df.shape)
    print(df.head(8).to_string(index=False))
    print(df.tail(8).to_string(index=False))