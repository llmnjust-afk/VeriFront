from pathlib import Path
import pandas as pd

# The repository already contains the individual model-rule counts used for plotting.
# Convert/copy them to the required output location.
src = Path("nvc/ind_data_for_plot.csv")
required_dir = Path("pred_results")
required_dir.mkdir(parents=True, exist_ok=True)
out = required_dir / "individuals.csv"

if not src.exists():
    raise FileNotFoundError(f"Source file not found: {src}")

# Read as raw semicolon-formatted lines to preserve the intended CSV structure.
lines = src.read_text().splitlines()
print(f"Read {len(lines)-1} data rows from {src}")
print("Source header:", lines[0])

# Normalize header to the requested field names. Keep semicolon delimiter.
# Rows are already in the desired Model;Rule;Num persons format.
normalized = ["Model;Rule;Num persons"] + [ln.strip() for ln in lines[1:] if ln.strip()]
out.write_text("\n".join(normalized) + "\n")

# Verify output
print(f"Saved required file: {out}")
print(f"Output exists: {out.exists()}, bytes: {out.stat().st_size}")
df = pd.read_csv(out, sep=";")
print("Output shape:", df.shape)
print("Total rows:", len(df))
print("Models:", sorted(df["Model"].unique()))
print("Rules:", sorted(df["Rule"].unique()))
print("\nPreview:")
print(df.head(10).to_string(index=False))