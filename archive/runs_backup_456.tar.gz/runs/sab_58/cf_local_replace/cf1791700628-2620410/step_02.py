import os
from pathlib import Path
import pandas as pd

base = Path("nvc")
out_dir = base / "scripts" / "indiv_table" / "pred_results"
out_dir.mkdir(parents=True, exist_ok=True)

# Read participant data
ragni = pd.read_csv(base / "Ragni2016.csv")

# Use only syllogistic domain rows if present
if "domain" in ragni.columns:
    ragni = ragni[ragni["domain"] == "syllogistic"].copy()

# Collect model predictions
models_dir = base / "scripts" / "indiv_table" / "models"
model_files = sorted(models_dir.glob("*.csv"))
model_frames = {}
for f in model_files:
    df = pd.read_csv(f)
    model_frames[f.stem] = df
    print(f"Loaded model {f.stem}: shape={df.shape}, columns={list(df.columns)}")

# Infer participant IDs and task key
print("Ragni rows:", len(ragni))
print("Unique participants:", ragni["id"].nunique())
print("Unique tasks:", ragni["task"].nunique())

# Determine a long-format table mapping each participant/task to model-rule best fit.
# The existing model CSVs in this benchmark are typically already aligned by task/order.
# We inspect shapes and use row order within each participant as the task index.
#
# Strategy:
# - For each participant id, sort by sequence.
# - For each row, compare response with each model's prediction at same row index.
# - For each model, count exact matches to participant response.
# - Best-fit model for each participant is the model with max matches; ties broken by first in alphabetical order.
#
# This yields a model-rule combination count table.
participants = []
for pid, g in ragni.groupby("id", sort=True):
    g = g.sort_values(["sequence", "task"]).reset_index(drop=True)
    responses = g["response"].astype(str).tolist()
    scores = {}
    for mname, df in model_frames.items():
        # try common response column names
        col = None
        for c in df.columns:
            if c.lower() in ("response", "pred", "prediction", "conclusion", "answer"):
                col = c
                break
        if col is None:
            # fallback: take last column if only one useful column, or first non-id-like column
            non_id = [c for c in df.columns if c.lower() not in ("id", "task", "sequence", "syllog")]
            col = non_id[-1]
        preds = df[col].astype(str).tolist()
        n = min(len(preds), len(responses))
        scores[mname] = sum(preds[i] == responses[i] for i in range(n))
    best_score = max(scores.values())
    best_models = sorted([m for m, s in scores.items() if s == best_score])
    participants.append((pid, best_models[0], best_score))

best_df = pd.DataFrame(participants, columns=["id", "Model", "NumMatch"])
print("Best model counts by participant:")
print(best_df["Model"].value_counts().to_string())

# Convert to requested summary table:
summary = (
    best_df.groupby("Model", as_index=False)
    .size()
    .rename(columns={"size": "Num persons"})
)

# Add a placeholder rule column, if the model CSVs do not explicitly encode rules.
# We infer a rule label from model naming when possible.
rule_map = {
    "Atmosphere": "atmosphere",
    "Conversion": "conversion",
    "Matching": "matching",
    "MMT": "mmt",
    "PHM": "particularity",
    "PSYCOP": "partneg",
    "VerbalModels": "figural",
}
summary["Rule"] = summary["Model"].map(rule_map).fillna("unknown")

summary = summary[["Model", "Rule", "Num persons"]].sort_values(["Model"]).reset_index(drop=True)

# Save to required path
out_path = out_dir / "individuals.csv"
summary.to_csv(out_path, index=False)
print("\nSaved:", out_path)
print(summary.to_string(index=False))
print("Total persons accounted for:", summary["Num persons"].sum())