from pathlib import Path
import pandas as pd
import os, sys, importlib.util, inspect

base = Path("nvc")
print("Top-level tree relevant:")
for p in sorted(base.rglob("*")):
    if p.is_file() and ("scripts" in p.parts or p.name.endswith(".csv")):
        print(p, p.stat().st_size)

print("\nModel CSV full previews:")
for f in sorted((base/"scripts"/"indiv_table"/"models").glob("*.csv")):
    df = pd.read_csv(f)
    print("\n==", f.name, "==")
    print(df.to_string(index=False))

print("\nRule files full contents:")
for f in sorted((base/"scripts"/"indiv_table"/"rules").glob("*.py")):
    print("\n==", f, "==")
    print(f.read_text())

print("\nOther data summaries:")
for f in [base/"ind_data_for_plot.csv", base/"accuracies_data_for_plot.csv", base/"valid_syllogisms.csv"]:
    df = pd.read_csv(f)
    print("\n==", f, "shape", df.shape, "columns", list(df.columns), "==")
    print(df.head(20).to_string(index=False))
    print("tail")
    print(df.tail(5).to_string(index=False))

print("\nCurrent produced file exists?")
for f in [Path("pred_results/individuals.csv"), Path("nvc/scripts/indiv_table/pred_results/individuals.csv")]:
    print(f, f.exists())
    if f.exists():
        print(pd.read_csv(f).to_string(index=False))