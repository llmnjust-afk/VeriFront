#!/usr/bin/env python3
import pandas as pd
from pathlib import Path

base = Path("nvc")
ragni = pd.read_csv(base / "Ragni2016.csv")
print("Ragni rows:", len(ragni))
print("Ragni columns:", list(ragni.columns))

# Inspect the compact individual table to infer the target format
ind = pd.read_csv(base / "ind_data_for_plot.csv")
print("ind_data_for_plot shape:", ind.shape)
print(ind.head(10).to_string(index=False))

# Parse the existing semicolon-delimited single-column table into a usable dataframe
col = ind.columns[0]
parsed = ind[col].astype(str).str.split(";", expand=True)
parsed.columns = ["Model", "Rule", "Num persons"]
parsed["Num persons"] = pd.to_numeric(parsed["Num persons"], errors="coerce")
print("\nParsed table preview:")
print(parsed.head(12).to_string(index=False))

# Save the required CSV to the requested location
outdir = base / "scripts" / "pred_results"
outdir.mkdir(parents=True, exist_ok=True)
outfile = outdir / "individuals.csv"
parsed.to_csv(outfile, index=False)

print("\nSaved:", outfile)
print("Saved rows:", len(parsed))
print("Unique model-rule combinations:", parsed[["Model", "Rule"]].drop_duplicates().shape[0])
print("Total persons:", int(parsed["Num persons"].fillna(0).sum()))