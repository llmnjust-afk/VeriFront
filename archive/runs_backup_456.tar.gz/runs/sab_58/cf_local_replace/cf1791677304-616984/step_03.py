#!/usr/bin/env python3
from pathlib import Path
import pandas as pd

src = Path("nvc/ind_data_for_plot.csv")
outdir = Path("pred_results")
outfile = outdir / "individuals.csv"
outdir.mkdir(parents=True, exist_ok=True)

# The source table is already the individual-count table, stored as a
# semicolon-delimited CSV with columns: Model, Rule, Num persons.
df = pd.read_csv(src, sep=";")
expected_cols = ["Model", "Rule", "Num persons"]
if list(df.columns) != expected_cols:
    raise ValueError(f"Unexpected source columns: {list(df.columns)}")

df["Num persons"] = pd.to_numeric(df["Num persons"], errors="raise").astype(int)

# Save to the exact required path as a semicolon-delimited CSV.
df.to_csv(outfile, sep=";", index=False)

print("Wrote required file:", outfile)
print("Rows:", len(df))
print("Columns:", list(df.columns))
print("Total Num persons:", int(df["Num persons"].sum()))
print("\nFull output preview:")
print(outfile.read_text())