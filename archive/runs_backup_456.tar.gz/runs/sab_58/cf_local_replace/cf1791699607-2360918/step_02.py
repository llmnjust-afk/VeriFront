#!/usr/bin/env python3
import pandas as pd
from pathlib import Path

# Reconstruct the desired output from the provided benchmark CSV.
# The source file already contains rows in the requested "Model; Rule; Num persons" format
# in a single column; we normalize it and save to the target path.

src = Path("nvc/ind_data_for_plot.csv")
out = Path("pred_results/individuals.csv")
out.parent.mkdir(parents=True, exist_ok=True)

df = pd.read_csv(src)

# Normalize column name and split into the requested fields if needed.
col = df.columns[0]
rows = df.iloc[:, 0].astype(str).tolist()

# If the source is already semicolon-formatted, parse it into three columns.
parsed = []
for r in rows:
    parts = [p.strip() for p in r.split(";")]
    if len(parts) == 3:
        parsed.append(parts)
    else:
        # fallback: keep as one row if unexpected format
        parsed.append([r, "", ""])

out_df = pd.DataFrame(parsed, columns=["Model", "Rule", "Num persons"])
out_df.to_csv(out, index=False)

print(f"Saved {out} with shape {out_df.shape}")
print(out_df.head(10).to_string(index=False))
print("Total Num persons:", pd.to_numeric(out_df["Num persons"], errors="coerce").sum())