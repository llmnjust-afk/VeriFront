#!/usr/bin/env python3
from pathlib import Path
import pandas as pd

src = Path("nvc/ind_data_for_plot.csv")
out = Path("pred_results/individuals.csv")
out.parent.mkdir(parents=True, exist_ok=True)

# Read the provided individual-count data, normalize whitespace, and write it as
# a semicolon-delimited CSV matching the requested row format:
# Model; Rule; Num persons
raw = pd.read_csv(src)
first_col = raw.columns[0]

records = []
for val in raw.iloc[:, 0].astype(str):
    parts = [p.strip() for p in val.split(";")]
    if len(parts) != 3:
        raise ValueError(f"Unexpected row format in {src}: {val!r}")
    model, rule, num = parts
    records.append((model, rule, int(num)))

df = pd.DataFrame(records, columns=["Model", "Rule", "Num persons"])
df.to_csv(out, sep=";", index=False)

print(f"Wrote {out.resolve()}")
print(f"Rows: {len(df)}")
print(f"Columns: {list(df.columns)}")
print("Total persons counted across combinations:", int(df["Num persons"].sum()))
print("\nFull output preview:")
print(out.read_text())