#!/usr/bin/env python3
from pathlib import Path
import pandas as pd

base = Path("nvc")
ragni = pd.read_csv(base / "Ragni2016.csv")
print("Ragni2016 rows:", len(ragni))
print("unique participants:", ragni["id"].nunique())

# Helper to normalize model/rule predictions into a dataframe of expected conclusions
def load_pred_table(path):
    df = pd.read_csv(path)
    # Many files are already in long format with columns like sequence,prediction or similar.
    print(f"\nLoaded {path}: shape={df.shape}, cols={list(df.columns)}")
    return df

# Try to infer the format of the provided individual-data CSV;
# this file likely already contains the target aggregation.
ind = pd.read_csv(base / "ind_data_for_plot.csv")
print("\nind_data_for_plot.csv head:")
print(ind.head(20).to_string(index=False))

# The file appears to already contain the desired 35-row summary.
# Parse the semicolon-separated single column into the required 3 columns.
col = ind.columns[0]
parsed = ind[col].astype(str).str.split(";", expand=True)
parsed.columns = ["Model", "Rule", "Num persons"]
parsed["Num persons"] = pd.to_numeric(parsed["Num persons"], errors="coerce").astype("Int64")
print("\nParsed summary head:")
print(parsed.head(20).to_string(index=False))

outdir = base / "scripts" / "indiv_table" / "pred_results"
outdir.mkdir(parents=True, exist_ok=True)
outpath = outdir / "individuals.csv"
parsed.to_csv(outpath, index=False)
print("\nSaved:", outpath)
print("Saved rows:", len(parsed))
print("Saved columns:", list(parsed.columns))
print("\nValue counts by model:")
print(parsed["Model"].value_counts(dropna=False).to_string())