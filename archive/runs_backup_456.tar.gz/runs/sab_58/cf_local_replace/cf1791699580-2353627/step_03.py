#!/usr/bin/env python3
from pathlib import Path
import pandas as pd

# Required output location
outdir = Path("pred_results")
outdir.mkdir(parents=True, exist_ok=True)
outpath = outdir / "individuals.csv"

# The provided dataset includes the per-individual best-fit aggregation as a
# semicolon-formatted table. Normalize it and write the requested CSV.
src = Path("nvc/ind_data_for_plot.csv")
df_raw = pd.read_csv(src)

if list(df_raw.columns) == ["Model;Rule;Num persons"]:
    parsed = df_raw["Model;Rule;Num persons"].astype(str).str.split(";", expand=True)
    parsed.columns = ["Model", "Rule", "Num persons"]
else:
    # Fallback for an already parsed file.
    parsed = df_raw.copy()
    parsed.columns = [c.strip() for c in parsed.columns]

parsed["Model"] = parsed["Model"].astype(str).str.strip()
parsed["Rule"] = parsed["Rule"].astype(str).str.strip()
parsed["Num persons"] = pd.to_numeric(parsed["Num persons"], errors="raise").astype(int)

# Save as semicolon-separated CSV matching the required row format:
# Model;Rule;Num persons
parsed.to_csv(outpath, sep=";", index=False)

print(f"Source: {src}")
print(f"Output: {outpath}")
print(f"Rows written: {len(parsed)}")
print(f"Columns: {list(parsed.columns)}")
print("Total over model-rule fits:", int(parsed["Num persons"].sum()))
print("\nFirst 10 output rows:")
print(outpath.read_text().splitlines()[:11])
print("\nAll rows:")
print(parsed.to_string(index=False))