#!/usr/bin/env python3
import os
import pandas as pd
from pathlib import Path

print("Working directory:", os.getcwd())
root = Path("nvc")
print("Exists nvc:", root.exists())

# List relevant files with sizes
for p in sorted(root.rglob("*")):
    if p.is_file():
        print(p, p.stat().st_size)

# Inspect key CSVs
for rel in [
    "nvc/ind_data_for_plot.csv",
    "nvc/valid_syllogisms.csv",
    "nvc/accuracies_data_for_plot.csv",
    "nvc/Ragni2016.csv",
]:
    path = Path(rel)
    print("\n---", rel, "---")
    if path.exists():
        try:
            df = pd.read_csv(path)
            print("shape", df.shape)
            print("columns", list(df.columns))
            print(df.head(10).to_string(index=False))
        except Exception as e:
            print("Error reading:", repr(e))
    else:
        print("missing")

# Inspect model prediction CSVs
for sub in ["indiv_table", "prediction_errors"]:
    print(f"\n=== models in {sub} ===")
    for path in sorted(Path(f"nvc/scripts/{sub}/models").glob("*.csv")):
        try:
            df = pd.read_csv(path)
            print("\n---", path, "---")
            print("shape", df.shape)
            print("columns", list(df.columns))
            print(df.head(8).to_string(index=False))
        except Exception as e:
            print(path, "error", repr(e))

# Print rules source names and first lines
for sub in ["indiv_table", "prediction_errors", "nvc_prediction"]:
    print(f"\n=== rules in {sub} ===")
    for path in sorted(Path(f"nvc/scripts/{sub}/rules").glob("*.py")):
        print("\n---", path, "---")
        txt = path.read_text()
        print("\n".join(txt.splitlines()[:80]))