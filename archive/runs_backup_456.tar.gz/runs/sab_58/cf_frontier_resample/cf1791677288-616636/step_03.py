#!/usr/bin/env python3
from pathlib import Path
import pandas as pd

src = Path("nvc/ind_data_for_plot.csv")
out_dir = Path("pred_results")
out = out_dir / "individuals.csv"

out_dir.mkdir(parents=True, exist_ok=True)

# Read the semicolon-separated individual-count table and write the requested output.
df = pd.read_csv(src, sep=";")
expected_cols = ["Model", "Rule", "Num persons"]
if list(df.columns) != expected_cols:
    raise ValueError(f"Unexpected columns in {src}: {list(df.columns)}")

# Preserve the requested semicolon-delimited format: Model;Rule;Num persons
df.to_csv(out, sep=";", index=False)

print(f"Wrote {out}")
print("Shape:", df.shape)
print("Columns:", list(df.columns))
print("Total model-rule rows:", len(df))
print("Sum of Num persons across rows:", int(df["Num persons"].sum()))
print("\nOutput preview:")
print(out.read_text())