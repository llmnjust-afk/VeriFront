#!/usr/bin/env python3
from pathlib import Path
import pandas as pd
import os

def show(path, n=20, sep=None):
    print(f"\n### {path}")
    if not Path(path).exists():
        print("MISSING")
        return
    if sep is None:
        df = pd.read_csv(path)
    else:
        df = pd.read_csv(path, sep=sep)
    print("shape:", df.shape)
    print("columns:", list(df.columns))
    print(df.head(n).to_string(index=False))
    print("dtypes:", df.dtypes.to_dict())

# The likely target data, parse both default and semicolon
show("nvc/ind_data_for_plot.csv", n=40)
show("nvc/ind_data_for_plot.csv", n=40, sep=";")

show("nvc/accuracies_data_for_plot.csv", n=20)
show("nvc/accuracies_data_for_plot.csv", n=20, sep=";")

show("nvc/valid_syllogisms.csv", n=20)
show("nvc/valid_syllogisms.csv", n=20, sep=";")

# Concise model CSV exact contents
for path in sorted(Path("nvc/scripts/indiv_table/models").glob("*.csv")):
    print(f"\n### MODEL {path.name}")
    print(path.read_text())

# Rule full contents once
for path in sorted(Path("nvc/scripts/indiv_table/rules").glob("*.py")):
    if path.name == "__init__.py":
        continue
    print(f"\n### RULE {path.name}")
    print(path.read_text())

# Dataset basic stats: participants and task counts
rag = pd.read_csv("nvc/Ragni2016.csv")
print("\n### Ragni stats")
print("shape:", rag.shape)
print("unique ids:", rag["id"].nunique())
print("rows per id describe:")
print(rag.groupby("id").size().describe().to_string())
print("first rows:")
print(rag.head(5).to_string(index=False))
print("unique sequence min/max/count:", rag["sequence"].min(), rag["sequence"].max(), rag["sequence"].nunique())