#!/usr/bin/env python3
from pathlib import Path
import pandas as pd
import csv
import os

print("PWD", os.getcwd())

# Read the small aggregate file exactly and show all rows/raw content
p = Path("nvc/ind_data_for_plot.csv")
print("\nRAW ind_data_for_plot.csv:")
print(p.read_text())

# Read with semicolon separator as likely intended
print("\nParsed with sep=';':")
df = pd.read_csv(p, sep=";")
print("shape", df.shape)
print("columns", list(df.columns))
print(df.to_string(index=False))

# Inspect model files raw, since their delimiter/header matters
for path in sorted(Path("nvc/scripts/indiv_table/models").glob("*.csv")):
    print(f"\nRAW MODEL FILE {path}:")
    print(path.read_text())

# Inspect valid syllogisms
print("\nRAW valid_syllogisms.csv:")
print(Path("nvc/valid_syllogisms.csv").read_text())

# Inspect row counts/ids in Ragni
rag = pd.read_csv("nvc/Ragni2016.csv")
print("\nRagni shape:", rag.shape)
print("unique ids:", rag["id"].nunique(), "min", rag["id"].min(), "max", rag["id"].max())
print("rows per id value counts:")
print(rag.groupby("id").size().value_counts().sort_index().to_string())
print("first participant rows:")
print(rag[rag["id"] == rag["id"].min()].head().to_string(index=False))