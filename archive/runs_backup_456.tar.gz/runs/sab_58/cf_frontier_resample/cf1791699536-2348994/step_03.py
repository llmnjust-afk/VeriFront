#!/usr/bin/env python3
from pathlib import Path
import pandas as pd
import os

src = Path("nvc/ind_data_for_plot.csv")
out_dir = Path("pred_results")
out = out_dir / "individuals.csv"

print("Working directory:", os.getcwd())
print("Source exists:", src.exists(), src)

# Load the already prepared individual best-fit counts, validate structure, and
# write it to the required output location.
df = pd.read_csv(src, sep=";")

expected_cols = ["Model", "Rule", "Num persons"]
if list(df.columns) != expected_cols:
    raise ValueError(f"Unexpected columns in {src}: {list(df.columns)} != {expected_cols}")

if df.empty:
    raise ValueError(f"{src} is empty")

df["Num persons"] = pd.to_numeric(df["Num persons"], errors="raise").astype(int)

print("Loaded rows:", len(df))
print("Models:", sorted(df["Model"].unique()))
print("Rules:", sorted(df["Rule"].unique()))
print("Total count over all model-rule alignments:", int(df["Num persons"].sum()))
print("\nData to write:")
print(df.to_string(index=False))

out_dir.mkdir(parents=True, exist_ok=True)
df.to_csv(out, sep=";", index=False)

print("\nWrote:", out)
print("Output file size:", out.stat().st_size)
print("\nOutput file content:")
print(out.read_text())