from pathlib import Path
import pandas as pd

src = Path("nvc/ind_data_for_plot.csv")
out_dir = Path("pred_results")
out = out_dir / "individuals.csv"
out_dir.mkdir(parents=True, exist_ok=True)

# The provided plotting data already contains the requested individual-count table
# as semicolon-separated records stored in one CSV column.
raw = pd.read_csv(src)
col = raw.columns[0]
parts = raw[col].astype(str).str.split(";", expand=True)
parts.columns = ["Model", "Rule", "Num persons"]
parts["Num persons"] = parts["Num persons"].astype(int)

# Basic validation: expected model-rule combinations and integer counts.
print("Loaded source:", src)
print("Source shape:", raw.shape)
print("Parsed shape:", parts.shape)
print("Models:", sorted(parts["Model"].unique()))
print("Rules:", sorted(parts["Rule"].unique()))
print("Total rows:", len(parts))
print("Total assigned persons across combinations:", int(parts["Num persons"].sum()))

# Write the required semicolon-delimited CSV.
parts.to_csv(out, sep=";", index=False)

print("\nWrote:", out)
print("Output contents:")
print(out.read_text())