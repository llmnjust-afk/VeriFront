import os
from pathlib import Path
import pandas as pd

base = Path("nvc")
print("Tree selected scripts:")
for root, dirs, files in os.walk(base/"scripts"):
    level = len(Path(root).relative_to(base/"scripts").parts)
    if level <= 2:
        print("  "*level + Path(root).name + "/")
        for f in files:
            print("  "*(level+1) + f)

print("\nModel CSV full contents:")
for csv in sorted((base/"scripts"/"indiv_table"/"models").glob("*.csv")):
    print("\n==", csv.name, "==")
    print(csv.read_text())

print("\nRule files full contents:")
for py in sorted((base/"scripts"/"indiv_table"/"rules").glob("*.py")):
    print("\n==", py.name, "==")
    print(py.read_text())

print("\nOther data summaries:")
for csv in [base/"valid_syllogisms.csv", base/"ind_data_for_plot.csv", base/"accuracies_data_for_plot.csv"]:
    df = pd.read_csv(csv)
    print("\n==", csv, "== shape", df.shape)
    print(df.to_string(max_rows=100, max_cols=20, index=False))

# inspect Ragni IDs and sequence structure
rag = pd.read_csv(base/"Ragni2016.csv")
print("\nRagni unique ids", rag["id"].nunique(), "min", rag["id"].min(), "max", rag["id"].max())
print("rows per id value counts:")
print(rag.groupby("id").size().value_counts().sort_index().to_string())
print("sequence unique count", rag["sequence"].nunique(), "minmax", rag["sequence"].min(), rag["sequence"].max())
print("responses top:")
print(rag["response"].value_counts().head(20).to_string())

# derive syllogism code candidate from task, inspect first person's all tasks with code
def task_to_code(task):
    # Premises separated by '/', each premise is Quant;subj;pred.
    # Need encode moods A/I/E/O and figure by middle term positions.
    qmap = {"All": "A", "Some": "I", "No": "E", "Some not": "O"}
    p1, p2 = task.split("/")
    q1, s1, p1t = p1.split(";")
    q2, s2, p2t = p2.split(";")
    # conclusion terms are the two non-middle terms; middle appears in both premises
    terms1 = {s1, p1t}; terms2 = {s2, p2t}
    middle = list(terms1 & terms2)
    if not middle:
        return None
    m = middle[0]
    # Figures convention:
    # 1: M-P / S-M ; 2: P-M / S-M ; 3: M-P / M-S ; 4: P-M / M-S
    # Where first premise contains P and M, second contains S and M.
    # Determine position of M in each premise: subject or predicate
    mpos1 = "subj" if s1 == m else "pred"
    mpos2 = "subj" if s2 == m else "pred"
    figmap = {("subj","pred"): "1", ("pred","pred"): "2", ("subj","subj"): "3", ("pred","subj"): "4"}
    return qmap[q1] + qmap[q2] + figmap[(mpos1, mpos2)]
sample = rag[rag["id"] == rag["id"].min()].copy()
sample["syllog"] = sample["task"].map(task_to_code)
print("\nFirst id tasks/codes/responses:")
print(sample[["sequence","task","syllog","response"]].to_string(index=False))
print("All derived syllog unique", rag["task"].map(task_to_code).nunique(), sorted(rag["task"].map(task_to_code).unique())[:10])