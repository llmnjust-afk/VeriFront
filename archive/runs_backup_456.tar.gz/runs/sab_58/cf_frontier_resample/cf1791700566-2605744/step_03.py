from pathlib import Path
import pandas as pd, os, re, json

base = Path("nvc")
print("Check possible precomputed data")
for f in [base/"ind_data_for_plot.csv", base/"accuracies_data_for_plot.csv", base/"valid_syllogisms.csv"]:
    print("\n==", f, "==")
    df = pd.read_csv(f)
    print("shape", df.shape)
    print("columns", df.columns.tolist())
    print(df.head(20).to_string(index=False))
    print("tail")
    print(df.tail(10).to_string(index=False))

# Check whether source scripts exist as py maybe hidden? 
print("\nPython scripts under nvc/scripts")
for p in sorted((base/"scripts").rglob("*.py")):
    print(p, p.stat().st_size)

# Print full small-ish maybe indiv data
df = pd.read_csv(base/"ind_data_for_plot.csv")
print("\nind_data_for_plot value counts and unique values")
for col in df.columns:
    print("COL", col, "nunique", df[col].nunique())
    print(df[col].value_counts(dropna=False).head(30).to_string())

# Full accuracies maybe rows limited
acc = pd.read_csv(base/"accuracies_data_for_plot.csv")
print("\naccuracies group summaries")
for col in acc.columns:
    print("COL", col, "nunique", acc[col].nunique())
    print(acc[col].value_counts(dropna=False).head(20).to_string())