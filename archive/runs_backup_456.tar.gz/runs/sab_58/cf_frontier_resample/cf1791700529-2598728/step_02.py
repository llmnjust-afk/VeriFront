import os
from pathlib import Path
import pandas as pd

base = Path("nvc")
print("Top-level files/dirs:")
for p in sorted(Path(".").iterdir()):
    print(p, "dir" if p.is_dir() else p.stat().st_size)

print("\nSearch Python/scripts under nvc/scripts:")
for p in sorted((base/"scripts").rglob("*")):
    if p.is_file() and p.suffix in [".py", ".ipynb", ".R", ".sh"]:
        print("\n###", p, "size", p.stat().st_size)
        txt = p.read_text(errors="replace")
        print("\n".join(txt.splitlines()[:220]))

print("\nModel CSV compact previews")
for folder in ["indiv_table", "prediction_errors"]:
    print("\nFOLDER", folder)
    models_dir = base/"scripts"/folder/"models"
    for csv in sorted(models_dir.glob("*.csv")):
        df = pd.read_csv(csv)
        print(csv.name, "shape", df.shape, "cols", list(df.columns))
        print(df.to_string(index=False))

print("\nOther CSV summaries")
for csv in [base/"valid_syllogisms.csv", base/"ind_data_for_plot.csv", base/"accuracies_data_for_plot.csv"]:
    df = pd.read_csv(csv)
    print("\n", csv, df.shape, list(df.columns))
    print(df.head(20).to_string(index=False))
    print("tail")
    print(df.tail(10).to_string(index=False))
    for col in df.columns:
        print(col, "nunique", df[col].nunique(dropna=False), "sample", df[col].drop_duplicates().head(10).tolist())