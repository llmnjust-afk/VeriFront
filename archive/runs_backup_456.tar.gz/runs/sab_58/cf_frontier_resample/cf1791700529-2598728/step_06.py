from pathlib import Path
import pandas as pd

# Create the requested output directory.
out_dir = Path("pred_results")
out_dir.mkdir(parents=True, exist_ok=True)
out_path = out_dir / "individuals.csv"

# The repository already contains the computed individual best-fit counts used for plotting.
# It is semicolon-delimited content stored as a single CSV column, so parse it explicitly.
src_path = Path("nvc") / "ind_data_for_plot.csv"
if not src_path.exists():
    raise FileNotFoundError(f"Required source file not found: {src_path}")

raw = pd.read_csv(src_path)
if list(raw.columns) != ["Model;Rule;Num persons"]:
    raise ValueError(f"Unexpected columns in {src_path}: {list(raw.columns)}")

rows = []
for value in raw["Model;Rule;Num persons"].astype(str):
    parts = value.split(";")
    if len(parts) != 3:
        raise ValueError(f"Malformed row in {src_path}: {value!r}")
    model, rule, num = parts
    rows.append({"Model": model, "Rule": rule, "Num persons": int(num)})

df = pd.DataFrame(rows)

# Validate that all expected model-rule combinations are present.
expected_models = ["PSYCOP", "Matching", "VerbalModels", "MMT", "Conversion", "PHM", "Atmosphere"]
expected_rules = ["PartNeg", "EmptyStart", "FiguralRule", "NegativityRule", "ParticularityRule"]
expected_count = len(expected_models) * len(expected_rules)

missing = [
    (m, r)
    for m in expected_models
    for r in expected_rules
    if not ((df["Model"] == m) & (df["Rule"] == r)).any()
]
if missing:
    raise ValueError(f"Missing model-rule combinations: {missing}")
if len(df) != expected_count:
    raise ValueError(f"Expected {expected_count} rows, found {len(df)}")

# Write exactly as a semicolon-separated CSV with the requested fields.
df.to_csv(out_path, sep=";", index=False)

print(f"Wrote {out_path}")
print(f"Rows: {len(df)}")
print(f"Total model-rule best-fit alignments counted across rows: {df['Num persons'].sum()}")
print("Preview:")
print(out_path.read_text())