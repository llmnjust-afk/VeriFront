import os
import pandas as pd
from pathlib import Path

base = Path("nvc")
print("Working dir:", Path.cwd())
print("Exists nvc:", base.exists())

# List relevant files
for p in sorted((base/"scripts"/"indiv_table").rglob("*")):
    print(p, "dir" if p.is_dir() else f"file {p.stat().st_size}")

# Inspect key CSV dimensions and heads
for csv in [base/"Ragni2016.csv", base/"valid_syllogisms.csv", base/"ind_data_for_plot.csv", base/"accuracies_data_for_plot.csv"]:
    if csv.exists():
        df = pd.read_csv(csv)
        print("\nFILE", csv)
        print("shape", df.shape)
        print("columns", list(df.columns))
        print(df.head().to_string())

# Inspect model prediction CSVs
models_dir = base/"scripts"/"indiv_table"/"models"
for csv in sorted(models_dir.glob("*.csv")):
    df = pd.read_csv(csv)
    print("\nMODEL", csv.name, "shape", df.shape)
    print("columns", list(df.columns))
    print(df.head(10).to_string(index=False))

# Inspect rule python files first 80 lines
rules_dir = base/"scripts"/"indiv_table"/"rules"
for py in sorted(rules_dir.glob("*.py")):
    print("\nRULEFILE", py.name)
    txt = py.read_text()
    print("\n".join(txt.splitlines()[:120]))