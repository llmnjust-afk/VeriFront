from pathlib import Path
import pandas as pd
import os, re

print("Find files mentioning individuals / indiv / Num persons / pred_results")
for p in sorted(Path("nvc").rglob("*")):
    if p.is_file() and p.suffix.lower() in [".py", ".csv", ".txt", ".md"]:
        txt = p.read_text(errors="replace") if p.suffix.lower() == ".py" else ""
        name = str(p).lower()
        if any(s in name for s in ["indiv", "individual"]) or any(s in txt.lower() for s in ["num persons", "individuals.csv", "pred_results", "ind_data"]):
            print("\nFILE", p, "size", p.stat().st_size)
            if p.suffix.lower()==".py":
                print(txt[:4000])

# Print complete rules small files and any non-rule py paths
for p in sorted(Path("nvc/scripts").rglob("*.py")):
    print("\nPY", p)
    print(p.read_text(errors="replace"))

# Inspect ind_data full enough
for csv in [Path("nvc/ind_data_for_plot.csv"), Path("nvc/accuracies_data_for_plot.csv")]:
    df = pd.read_csv(csv)
    print("\nCSV", csv, "shape", df.shape, "columns", list(df.columns))
    print(df.to_string(max_rows=200, index=False))