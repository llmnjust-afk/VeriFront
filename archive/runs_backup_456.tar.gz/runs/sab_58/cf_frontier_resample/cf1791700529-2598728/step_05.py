from pathlib import Path
import pandas as pd
pd.set_option("display.max_columns", 100)
pd.set_option("display.width", 240)

for csv in ["nvc/ind_data_for_plot.csv", "nvc/accuracies_data_for_plot.csv"]:
    df = pd.read_csv(csv)
    print("\nFILE", csv, "shape", df.shape)
    print("columns repr:", repr(list(df.columns)))
    print("dtypes:", df.dtypes.to_string())
    print("head 30:")
    print(df.head(30).to_string(index=False))
    print("tail 30:")
    print(df.tail(30).to_string(index=False))
    print("describe:")
    print(df.describe(include="all").to_string())

print("\nvalid_syllogisms full:")
print(pd.read_csv("nvc/valid_syllogisms.csv").to_string(index=False))

# Print each rule full concise
for p in sorted(Path("nvc/scripts/indiv_table/rules").glob("*.py")):
    print("\n===", p.name, "===")
    print(p.read_text())

# check pred_results dir
for p in sorted(Path("pred_results").glob("*")):
    print("pred_results contains", p, p.stat().st_size if p.is_file() else "dir")