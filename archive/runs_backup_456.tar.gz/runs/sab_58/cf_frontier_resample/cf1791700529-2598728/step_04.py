from pathlib import Path
import pandas as pd
pd.set_option("display.max_columns", 50)
pd.set_option("display.width", 200)

# Show complete model CSVs and compact data summaries without giant rule dumps
for folder in ["indiv_table", "prediction_errors"]:
    print("\n====", folder, "models ====")
    for csv in sorted((Path("nvc/scripts")/folder/"models").glob("*.csv")):
        df = pd.read_csv(csv)
        print("\n---", csv, "shape", df.shape, "---")
        print(df.to_string(index=False))

print("\n==== main data summaries ====")
for csv in [Path("nvc/ind_data_for_plot.csv"), Path("nvc/accuracies_data_for_plot.csv"), Path("nvc/valid_syllogisms.csv")]:
    df = pd.read_csv(csv)
    print("\n---", csv, "shape", df.shape, "cols", list(df.columns), "---")
    print(df.head(80).to_string(index=False))
    print("tail:")
    print(df.tail(20).to_string(index=False))
    for c in df.columns:
        print("col", c, "nunique", df[c].nunique(dropna=False), "values", df[c].drop_duplicates().head(20).tolist())

# Dataset per participant counts
rag = pd.read_csv("nvc/Ragni2016.csv")
print("\nRagni shape", rag.shape)
print("participants", rag["id"].nunique(), "rows per participant value_counts")
print(rag.groupby("id").size().value_counts().sort_index().to_string())
print("sequence nunique", rag["sequence"].nunique(), "min max", rag["sequence"].min(), rag["sequence"].max())
print("tasks nunique", rag["task"].nunique())
print(rag[["id","sequence","task","response"]].head(20).to_string(index=False))