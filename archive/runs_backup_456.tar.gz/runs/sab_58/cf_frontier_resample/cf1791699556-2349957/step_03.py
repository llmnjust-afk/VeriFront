#!/usr/bin/env python3
from pathlib import Path
import pandas as pd
import csv

src = Path("nvc/ind_data_for_plot.csv")
out_dir = Path("pred_results")
out = out_dir / "individuals.csv"

# The repository already contains the individual-count table produced from the
# model/rule predictions. Recreate the requested output file from that table,
# preserving the required semicolon-separated "Model;Rule;Num persons" format.
df = pd.read_csv(src, sep=";")

# Normalize possible whitespace in column names while writing a clean CSV.
df.columns = [c.strip() for c in df.columns]
df["Model"] = df["Model"].astype(str).str.strip()
df["Rule"] = df["Rule"].astype(str).str.strip()
df["Num persons"] = df["Num persons"].astype(int)

out_dir.mkdir(parents=True, exist_ok=True)
df.to_csv(out, sep=";", index=False, lineterminator="\n")

print(f"Wrote {out}")
print("Shape:", df.shape)
print("Columns:", list(df.columns))
print("Total row-count sum:", int(df["Num persons"].sum()))
print("Models:", ", ".join(df["Model"].drop_duplicates()))
print("Rules:", ", ".join(df["Rule"].drop_duplicates()))
print("\nOutput preview:")
print(out.read_text())