#!/usr/bin/env python3
from pathlib import Path
import pandas as pd
import csv
import os

print("Focused inspection")

# Read semicolon-ish ind_data manually
p = Path("nvc/ind_data_for_plot.csv")
print("\nRaw ind_data_for_plot.csv:")
print(p.read_text())

# Read valid
print("\nRaw valid_syllogisms.csv:")
print(Path("nvc/valid_syllogisms.csv").read_text())

# Show full model CSV raw
for path in sorted(Path("nvc/scripts/indiv_table/models").glob("*.csv")):
    print("\n===== RAW", path, "=====")
    print(path.read_text())

# Show complete rule files
for path in sorted(Path("nvc/scripts/indiv_table/rules").glob("*.py")):
    print("\n===== RULE", path, "=====")
    print(path.read_text())

# Basic Ragni structure
rag = pd.read_csv("nvc/Ragni2016.csv")
print("\nRagni shape", rag.shape)
print("unique ids", rag["id"].nunique(), "min/max seq", rag["sequence"].min(), rag["sequence"].max())
print("rows per id first 20:")
print(rag.groupby("id").size().head(20).to_string())
print("response values sample/counts:")
print(rag["response"].value_counts().head(20).to_string())

# Determine unique tasks and possible encoding
print("\nFirst 20 unique tasks:")
for t in rag["task"].drop_duplicates().head(20):
    print(t)

print("\nLast rows:")
print(rag.tail(10).to_string(index=False))