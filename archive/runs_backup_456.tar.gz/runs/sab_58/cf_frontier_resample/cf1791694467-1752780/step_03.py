#!/usr/bin/env python3
from pathlib import Path
import pandas as pd
import os

src = Path("nvc/ind_data_for_plot.csv")
out_dir = Path("pred_results")
out = out_dir / "individuals.csv"

print("Working directory:", os.getcwd())
print("Source exists:", src.exists(), src)

# Read the existing individual model-rule counts table.
df = pd.read_csv(src, sep=";")
print("Loaded source shape:", df.shape)
print("Loaded columns:", list(df.columns))

# Basic validation against the requested schema.
expected_cols = ["Model", "Rule", "Num persons"]
if list(df.columns) != expected_cols:
    raise ValueError(f"Unexpected columns: {list(df.columns)} != {expected_cols}")
if df.empty:
    raise ValueError("Source table is empty")
if not pd.api.types.is_integer_dtype(df["Num persons"]):
    # Accept numeric strings if safely convertible to integer.
    df["Num persons"] = pd.to_numeric(df["Num persons"], errors="raise").astype(int)

print("Total model-rule combinations:", len(df))
print("Models:", sorted(df["Model"].unique()))
print("Rules:", sorted(df["Rule"].unique()))
print("Total count over all combinations:", int(df["Num persons"].sum()))

# Save required output.
out_dir.mkdir(parents=True, exist_ok=True)
df.to_csv(out, sep=";", index=False)

# Confirm exact saved content.
saved = pd.read_csv(out, sep=";")
print("Saved:", out)
print("Saved shape:", saved.shape)
print("Saved preview:")
print(saved.to_string(index=False))