#!/usr/bin/env python3
from pathlib import Path
import pandas as pd
import os

print("PWD", os.getcwd())

# Show ind_data_for_plot exactly
p = Path("nvc/ind_data_for_plot.csv")
print("\n=== raw ind_data_for_plot.csv ===")
print(p.read_text())

# Show valid_syllogisms
p = Path("nvc/valid_syllogisms.csv")
print("\n=== raw valid_syllogisms.csv ===")
print(p.read_text())

# More compact model files as raw
for p in sorted(Path("nvc/scripts/indiv_table/models").glob("*.csv")):
    print(f"\n=== raw {p} ===")
    print(p.read_text())

# Show full rule files
for p in sorted(Path("nvc/scripts/indiv_table/rules").glob("*.py")):
    print(f"\n=== full {p} ===")
    print(p.read_text())

# Inspect Ragni2016 counts and tasks
df = pd.read_csv("nvc/Ragni2016.csv")
print("\nRagni shape", df.shape)
print("unique ids", df["id"].nunique(), "min rows/id", df.groupby("id").size().min(), "max", df.groupby("id").size().max())
print("unique sequences", df["sequence"].nunique(), sorted(df["sequence"].unique())[:10], sorted(df["sequence"].unique())[-10:])
print("first participant tasks/responses:")
print(df[df.id == df.id.iloc[0]][["sequence","task","response"]].head(20).to_string(index=False))
print("response value counts head")
print(df["response"].value_counts().head(20).to_string())

# Inspect accuracies columns/head/tail
acc = pd.read_csv("nvc/accuracies_data_for_plot.csv")
print("\naccuracies shape", acc.shape)
print("columns", list(acc.columns))
print(acc.head(20).to_string(index=False))
print(acc.tail(20).to_string(index=False))