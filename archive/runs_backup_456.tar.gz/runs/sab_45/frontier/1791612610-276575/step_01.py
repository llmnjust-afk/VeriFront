#!/usr/bin/env python3
import os
import pickle
import pandas as pd

DATA_PATH = "biopsykit_questionnaire_data/questionnaire_data.pkl"
OUT_PATH = "pred_results/questionnaire_pred.csv"

def load_dataframe(path):
    obj = pd.read_pickle(path)
    if isinstance(obj, pd.DataFrame):
        return obj.copy()
    # fallback if pickle contains another object wrapping a DataFrame
    if hasattr(obj, "data") and isinstance(obj.data, pd.DataFrame):
        return obj.data.copy()
    raise TypeError(f"Unsupported pickle content type: {type(obj)}")

def main():
    df = load_dataframe(DATA_PATH)
    print("Loaded dataframe:")
    print("  shape:", df.shape)
    print("  columns first 12:", list(df.columns[:12]))
    print("  index name:", df.index.name)

    # Ensure subject is available as a column.
    if "subject" not in df.columns:
        if df.index.name == "subject":
            df = df.reset_index()
        else:
            raise KeyError("Could not find 'subject' column or index.")

    pss_cols = [f"PSS_{i:02d}" for i in range(1, 11)]
    missing = [c for c in pss_cols if c not in df.columns]
    if missing:
        raise KeyError(f"Missing required PSS columns: {missing}")

    # PSS-10 scoring:
    # Perceived helplessness = items 1, 2, 3, 6, 9, 10, scored directly.
    # Perceived self-efficacy items = 4, 5, 7, 8, positively stated and reverse-scored for PSS stress scoring.
    helpless_cols = ["PSS_01", "PSS_02", "PSS_03", "PSS_06", "PSS_09", "PSS_10"]
    selfeff_cols = ["PSS_04", "PSS_05", "PSS_07", "PSS_08"]

    pss = df[["subject"] + pss_cols].copy()
    for c in pss_cols:
        pss[c] = pd.to_numeric(pss[c], errors="raise")

    helplessness = pss[helpless_cols].sum(axis=1)
    self_efficacy_reversed = (4 - pss[selfeff_cols]).sum(axis=1)
    total = helplessness + self_efficacy_reversed

    out = pd.DataFrame({
        "subject": pss["subject"],
        "perceived_helplessness": helplessness.astype(int),
        "perceived_self_efficacy": self_efficacy_reversed.astype(int),
        "total_pss": total.astype(int),
    })

    os.makedirs(os.path.dirname(OUT_PATH), exist_ok=True)
    out.to_csv(OUT_PATH, index=False, header=False)

    print("Wrote:", OUT_PATH)
    print("Output shape:", out.shape)
    print("First 10 rows:")
    print(out.head(10).to_string(index=False, header=False))
    print("Summary:")
    print(out[["perceived_helplessness", "perceived_self_efficacy", "total_pss"]].describe().to_string())

if __name__ == "__main__":
    main()