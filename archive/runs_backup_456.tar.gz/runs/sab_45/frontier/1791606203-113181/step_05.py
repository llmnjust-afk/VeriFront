#!/usr/bin/env python3
import os
import pandas as pd
from biopsykit.questionnaires import pss as biopsykit_pss

DATA_PATH = "benchmark/datasets/biopsykit_questionnaire_data/questionnaire_data.pkl"
OUT_PATH = "pred_results/questionnaire_pred.csv"

df = pd.read_pickle(DATA_PATH)
pss_cols = [f"PSS_{i:02d}" for i in range(1, 11)]
subject = pd.Series(df.index.astype(str), index=df.index, name="subject")

print("Input shape:", df.shape)
print("Subjects:", list(subject))

# Use BioPsyKit implementation, which encodes the benchmark-provided PSS domain knowledge.
score = biopsykit_pss(df, columns=pss_cols)
print("BioPsyKit PSS output:")
print(score.to_string())
print("BioPsyKit PSS columns:", list(score.columns))

# Print manual variants for transparent verification.
pss_data = df[pss_cols].apply(pd.to_numeric)
helpless_cols = ["PSS_01", "PSS_02", "PSS_03", "PSS_06", "PSS_09", "PSS_10"]
selfeff_cols = ["PSS_04", "PSS_05", "PSS_07", "PSS_08"]
manual = pd.DataFrame(index=df.index)
manual["subject"] = subject
manual["helpless_raw"] = pss_data[helpless_cols].sum(axis=1)
manual["selfeff_raw"] = pss_data[selfeff_cols].sum(axis=1)
manual["selfeff_reverse_contribution"] = (4 - pss_data[selfeff_cols]).sum(axis=1)
manual["total_raw_plus_reverse"] = manual["helpless_raw"] + manual["selfeff_reverse_contribution"]
print("\nManual scoring variants:")
print(manual.to_string(index=False))

# Determine columns produced by BioPsyKit robustly.
lower_map = {str(c).lower(): c for c in score.columns}
def find_col(keywords):
    for c in score.columns:
        lc = str(c).lower()
        if all(k.lower() in lc for k in keywords):
            return c
    return None

help_col = find_col(["help"]) or find_col(["helpless"]) or find_col(["Hilflos"])
self_col = find_col(["self"]) or find_col(["eff"]) or find_col(["selbst"])
total_col = find_col(["total"]) or find_col(["sum"]) or find_col(["pss"])

print("\nDetected score columns:", help_col, self_col, total_col)

# If detection fails, use standard PSS-10 subscale names/order from BioPsyKit documentation.
if help_col is None or self_col is None or total_col is None:
    print("Column detection fallback triggered.")
    print("Available columns:", list(score.columns))
    # Common BioPsyKit convention for questionnaires: subscales plus total score
    if len(score.columns) >= 3:
        help_col, self_col, total_col = score.columns[:3]
    else:
        raise RuntimeError("Unexpected BioPsyKit PSS output columns.")

result = pd.DataFrame({
    "subject": subject.values,
    "perceived_helplessness": score[help_col].astype(int).values,
    "perceived_self_efficacy": score[self_col].astype(int).values,
    "total_pss": score[total_col].astype(int).values,
})

print("\nFinal result to save:")
print(result.to_string(index=False))

os.makedirs(os.path.dirname(OUT_PATH), exist_ok=True)
result.to_csv(OUT_PATH, index=False, header=False)
print("\nSaved:", OUT_PATH)
print("Saved file content:")
with open(OUT_PATH, "r", encoding="utf-8") as f:
    print(f.read())