#!/usr/bin/env python3
import os
import inspect
import pkgutil
import importlib
import pandas as pd

DATA_PATH = "benchmark/datasets/biopsykit_questionnaire_data/questionnaire_data.pkl"
print("Loading:", DATA_PATH)
df = pd.read_pickle(DATA_PATH)
print("Loaded:", type(df), df.shape)
print("Index:", type(df.index), "name:", df.index.name, "first:", list(df.index[:5]))
print("Columns:", list(df.columns))
pss_cols = [c for c in df.columns if str(c).startswith("PSS_")]
print("PSS columns:", pss_cols)

subject = df["subject"] if "subject" in df.columns else pd.Series(df.index.astype(str), index=df.index, name="subject")
print(pd.concat([subject, df[pss_cols]], axis=1).head().to_string(index=False))

# Inspect BioPsyKit questionnaire code if available, especially PSS subscale/scoring definitions.
try:
    import biopsykit
    print("biopsykit version:", getattr(biopsykit, "__version__", "unknown"))
    found_mods = []
    for modinfo in pkgutil.walk_packages(biopsykit.__path__, biopsykit.__name__ + "."):
        name = modinfo.name
        if "question" in name.lower() or "pss" in name.lower():
            found_mods.append(name)
    print("Candidate modules:", found_mods[:100], "count", len(found_mods))
    for name in found_mods:
        try:
            mod = importlib.import_module(name)
        except Exception as e:
            continue
        candidates = [m for m in dir(mod) if "PSS" in m or "pss" in m or "Perceived" in m]
        if candidates:
            print("\nMODULE", name, "candidates:", candidates)
            for cand in candidates:
                attr = getattr(mod, cand)
                print("ATTR", cand, attr)
                try:
                    src = inspect.getsource(attr)
                    print(src[:5000])
                except Exception as e:
                    print("no source:", repr(e))
except Exception as e:
    print("BioPsyKit inspection failed:", repr(e))

# Compute variants.
pss = df[pss_cols].apply(pd.to_numeric)
neg = ["PSS_01", "PSS_02", "PSS_03", "PSS_06", "PSS_09", "PSS_10"]
pos = ["PSS_04", "PSS_05", "PSS_07", "PSS_08"]
helplessness_raw = pss[neg].sum(axis=1)
selfeff_raw = pss[pos].sum(axis=1)
selfeff_reversed = (4 - pss[pos]).sum(axis=1)
total_standard = helplessness_raw + selfeff_reversed
print("\nScoring variants head:")
variants = pd.DataFrame({
    "subject": subject.values,
    "helplessness_raw": helplessness_raw.values,
    "selfeff_raw": selfeff_raw.values,
    "selfeff_reversed": selfeff_reversed.values,
    "total_standard": total_standard.values,
    "raw_sum": pss.sum(axis=1).values,
})
print(variants.to_string(index=False))
print("\nVariant summaries:")
print(variants.drop(columns=["subject"]).describe().to_string())