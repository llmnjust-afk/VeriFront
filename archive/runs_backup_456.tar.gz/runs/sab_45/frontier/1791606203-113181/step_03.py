#!/usr/bin/env python3
import os
import inspect
import pkgutil
import importlib
import pandas as pd

DATA_PATH = "benchmark/datasets/biopsykit_questionnaire_data/questionnaire_data.pkl"
print("Loading:", DATA_PATH)
df = pd.read_pickle(DATA_PATH)
print("Loaded:", type(df), df.shape)
pss_cols = [c for c in df.columns if str(c).startswith("PSS_")]
print("PSS columns:", pss_cols)
print(df[["subject"] + pss_cols].head().to_string(index=False))

# Inspect BioPsyKit questionnaire code if available, especially PSS subscale/scoring definitions.
try:
    import biopsykit
    print("biopsykit version:", getattr(biopsykit, "__version__", "unknown"))
    print("Searching biopsykit modules/members for PSS...")
    found_mods = []
    for modinfo in pkgutil.walk_packages(biopsykit.__path__, biopsykit.__name__ + "."):
        name = modinfo.name
        if "question" in name.lower() or "pss" in name.lower():
            found_mods.append(name)
    print("Candidate modules:", found_mods[:100], "count", len(found_mods))
    for name in found_mods:
        try:
            mod = importlib.import_module(name)
        except Exception as e:
            continue
        candidates = [m for m in dir(mod) if "PSS" in m or "pss" in m or "Perceived" in m]
        if candidates:
            print("\nMODULE", name, "candidates:", candidates)
            for cand in candidates:
                attr = getattr(mod, cand)
                print("ATTR", cand, attr)
                try:
                    src = inspect.getsource(attr)
                    print(src[:5000])
                except Exception as e:
                    print("no source:", repr(e))
except Exception as e:
    print("BioPsyKit inspection failed:", repr(e))

# Also compute plausible variants to compare expected ranges.
pss = df[pss_cols].apply(pd.to_numeric)
neg = ["PSS_01", "PSS_02", "PSS_03", "PSS_06", "PSS_09", "PSS_10"]
pos = ["PSS_04", "PSS_05", "PSS_07", "PSS_08"]
helplessness_raw = pss[neg].sum(axis=1)
selfeff_raw = pss[pos].sum(axis=1)
selfeff_reversed = (4 - pss[pos]).sum(axis=1)
total_standard = helplessness_raw + selfeff_reversed
print("\nScoring variants head:")
variants = pd.DataFrame({
    "subject": df["subject"],
    "helplessness_raw": helplessness_raw,
    "selfeff_raw": selfeff_raw,
    "selfeff_reversed": selfeff_reversed,
    "total_standard": total_standard,
    "raw_sum": pss.sum(axis=1),
})
print(variants.head(20).to_string(index=False))
print("\nVariant summaries:")
print(variants.drop(columns=["subject"]).describe().to_string())