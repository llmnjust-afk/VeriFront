#!/usr/bin/env python3
import os
import pickle
import inspect
import pandas as pd

DATA_PATH = "biopsykit_questionnaire_data/questionnaire_data.pkl"
OUT_PATH = "pred_results/questionnaire_pred.csv"

print("Loading:", DATA_PATH)
obj = pd.read_pickle(DATA_PATH)
print("Loaded object type:", type(obj))
if isinstance(obj, pd.DataFrame):
    df = obj.copy()
else:
    df = pd.DataFrame(obj)
print("Shape:", df.shape)
print("Columns:", list(df.columns)[:20], "... total", len(df.columns))
print("Head PSS columns:")
pss_cols = [c for c in df.columns if str(c).startswith("PSS_")]
print(pss_cols)
print(df[["subject"] + pss_cols].head().to_string(index=False))

# Inspect whether BioPsyKit is installed and has PSS scoring functions/classes.
try:
    import biopsykit
    print("biopsykit version:", getattr(biopsykit, "__version__", "unknown"))
    import biopsykit.questionnaires as q
    print("biopsykit.questionnaires members containing PSS/pss/question:", 
          [m for m in dir(q) if "PSS" in m or "pss" in m or "Question" in m][:50])
    for name in dir(q):
        if "PSS" in name or "pss" in name:
            attr = getattr(q, name)
            print("Found q member:", name, attr)
            try:
                print(inspect.getsource(attr)[:4000])
            except Exception as e:
                print("Could not inspect:", e)
except Exception as e:
    print("BioPsyKit import/inspection failed:", repr(e))

# Compute PSS-10 scores using standard Cohen PSS-10 scoring:
# perceived helplessness: negatively worded items 1,2,3,6,9,10 (raw)
# perceived self-efficacy contribution to stress score: positively worded items 4,5,7,8 reverse-scored
# total PSS score: sum of helplessness + reverse-scored self-efficacy items
pss = df[pss_cols].apply(pd.to_numeric)
negative_items = ["PSS_01", "PSS_02", "PSS_03", "PSS_06", "PSS_09", "PSS_10"]
positive_items = ["PSS_04", "PSS_05", "PSS_07", "PSS_08"]

helplessness = pss[negative_items].sum(axis=1)
self_efficacy_reversed = (4 - pss[positive_items]).sum(axis=1)
total = helplessness + self_efficacy_reversed

res = pd.DataFrame({
    "subject": df["subject"],
    "perceived_helplessness": helplessness.astype(int),
    "perceived_self_efficacy": self_efficacy_reversed.astype(int),
    "total_pss": total.astype(int),
})

print("Computed result head:")
print(res.head(10).to_string(index=False))
print("Summary:")
print(res.describe(include="all").to_string())

os.makedirs(os.path.dirname(OUT_PATH), exist_ok=True)
res.to_csv(OUT_PATH, index=False, header=False)
print("Saved:", OUT_PATH)
print("First lines of saved file:")
with open(OUT_PATH, "r", encoding="utf-8") as f:
    for i, line in zip(range(10), f):
        print(line.rstrip())