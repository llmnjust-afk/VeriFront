#!/usr/bin/env python3
import os
import glob

print("Current working directory:", os.getcwd())
print("Top-level directory listing:")
for p in sorted(os.listdir(".")):
    print(" ", p)

print("\nSearching for questionnaire_data.pkl under current tree (limited):")
matches = []
for root, dirs, files in os.walk("."):
    # avoid very large hidden/cache dirs
    dirs[:] = [d for d in dirs if not d.startswith(".") and d not in {"__pycache__", "pred_results"}]
    if "questionnaire_data.pkl" in files:
        matches.append(os.path.join(root, "questionnaire_data.pkl"))
    if len(matches) >= 20:
        break
print(matches)

print("\nSearching one/two levels up:")
for pattern in [
    "../**/questionnaire_data.pkl",
    "../../**/questionnaire_data.pkl",
    "/data/**/questionnaire_data.pkl",
]:
    try:
        found = glob.glob(pattern, recursive=True)
        print(pattern, "=>", found[:20], "count", len(found))
    except Exception as e:
        print(pattern, "failed:", repr(e))