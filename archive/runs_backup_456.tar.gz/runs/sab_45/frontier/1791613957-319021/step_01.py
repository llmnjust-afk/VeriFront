#!/usr/bin/env python3
import os
import pickle
from pathlib import Path

import pandas as pd

DATA_PATH = Path("biopsykit_questionnaire_data/questionnaire_data.pkl")
OUT_PATH = Path("pred_results/questionnaire_pred.csv")

def load_dataframe(path: Path) -> pd.DataFrame:
    obj = pd.read_pickle(path)
    if isinstance(obj, pd.DataFrame):
        return obj.copy()
    # fallback in case pickle contains another object convertible to DataFrame
    return pd.DataFrame(obj)

def main():
    df = load_dataframe(DATA_PATH)
    print("Loaded:", DATA_PATH)
    print("Shape:", df.shape)
    print("Columns first 15:", list(df.columns[:15]))
    print("Index name:", df.index.name)

    # Ensure subject is available as a column.
    if "subject" not in df.columns:
        if df.index.name == "subject" or df.index.dtype == object:
            df = df.reset_index()
            if "index" in df.columns and "subject" not in df.columns:
                df = df.rename(columns={"index": "subject"})
        else:
            raise ValueError("Could not find subject column or suitable subject index.")

    pss_cols = [f"PSS_{i:02d}" for i in range(1, 11)]
    missing = [c for c in pss_cols if c not in df.columns]
    if missing:
        raise ValueError(f"Missing PSS columns: {missing}")

    pss = df[pss_cols].apply(pd.to_numeric)

    # PSS-10 scoring:
    # Negatively phrased/helplessness items: 1,2,3,6,9,10 scored directly.
    # Positively phrased/self-efficacy items: 4,5,7,8 reverse scored on 0..4 as 4 - response.
    helpless_cols = ["PSS_01", "PSS_02", "PSS_03", "PSS_06", "PSS_09", "PSS_10"]
    selfeff_cols = ["PSS_04", "PSS_05", "PSS_07", "PSS_08"]

    perceived_helplessness = pss[helpless_cols].sum(axis=1)
    perceived_self_efficacy = (4 - pss[selfeff_cols]).sum(axis=1)
    total_pss = perceived_helplessness + perceived_self_efficacy

    out = pd.DataFrame({
        "subject": df["subject"],
        "perceived_helplessness": perceived_helplessness.astype(int),
        "perceived_self_efficacy": perceived_self_efficacy.astype(int),
        "total_pss": total_pss.astype(int),
    })

    OUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(OUT_PATH, index=False, header=False)

    print("PSS response min/max:", int(pss.min().min()), int(pss.max().max()))
    print("Output shape:", out.shape)
    print("First 5 output rows:")
    print(out.head().to_string(index=False))
    print("Saved:", OUT_PATH)

if __name__ == "__main__":
    main()