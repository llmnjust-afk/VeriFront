#!/usr/bin/env python3
import os
import glob
from pathlib import Path

print("Current working directory:", os.getcwd())
print("Top-level entries:")
for p in sorted(os.listdir(".")):
    print(" -", p)

print("\nSearching for questionnaire_data.pkl under current tree and nearby common roots...")
patterns = [
    "**/questionnaire_data.pkl",
    "../**/questionnaire_data.pkl",
    "/data/lab/VeriFront/**/questionnaire_data.pkl",
]
found = []
for pat in patterns:
    try:
        matches = glob.glob(pat, recursive=True)
        for m in matches:
            if m not in found:
                found.append(m)
    except Exception as e:
        print(f"Pattern {pat!r} failed: {e!r}")

print("Found paths:")
for m in found[:50]:
    print(" -", m)
print("Total found:", len(found))

if not found:
    raise FileNotFoundError("Could not find questionnaire_data.pkl")

# Save discovered path for next turn/use.
with open("questionnaire_data_path.txt", "w") as f:
    f.write(found[0])
print("Saved first found path to questionnaire_data_path.txt:", found[0])