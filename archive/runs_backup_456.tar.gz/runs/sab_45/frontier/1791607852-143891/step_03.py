#!/usr/bin/env python3
import os
import glob
import pandas as pd
import numpy as np

OUT_PATH = "pred_results/questionnaire_pred.csv"

candidate_paths = [
    "biopsykit_questionnaire_data/questionnaire_data.pkl",
    "benchmark/datasets/biopsykit_questionnaire_data/questionnaire_data.pkl",
]
if os.path.exists("questionnaire_data_path.txt"):
    with open("questionnaire_data_path.txt", "r") as f:
        candidate_paths.insert(0, f.read().strip())
candidate_paths += glob.glob("**/questionnaire_data.pkl", recursive=True)

data_path = None
for p in candidate_paths:
    if p and os.path.exists(p):
        data_path = p
        break
if data_path is None:
    raise FileNotFoundError("Could not find questionnaire_data.pkl")

print(f"Loading questionnaire data from: {data_path}")
df = pd.read_pickle(data_path)
print("Loaded shape:", df.shape)
print("Columns include:", list(df.columns[:12]))

pss_cols = [f"PSS_{i:02d}" for i in range(1, 11)]
required = ["subject"] + pss_cols
missing = [c for c in required if c not in df.columns]
if missing:
    raise ValueError(f"Missing required columns: {missing}")

pss = df[required].copy()
for c in pss_cols:
    pss[c] = pd.to_numeric(pss[c], errors="raise")

print("PSS response value ranges:")
print(pss[pss_cols].agg(["min", "max"]).to_string())

# Standard PSS-10 scoring (Cohen):
# - Items 1,2,3,6,9,10 are negatively worded and summed directly as "perceived helplessness".
# - Items 4,5,7,8 are positively worded and reverse-scored (0<->4, 1<->3, 2<->2) before
#   contributing to stress; this reverse-scored sum is the PSS "perceived self-efficacy" subscore
#   as used for the total stress score.
helpless_items = ["PSS_01", "PSS_02", "PSS_03", "PSS_06", "PSS_09", "PSS_10"]
selfeff_items = ["PSS_04", "PSS_05", "PSS_07", "PSS_08"]

result = pd.DataFrame({
    "subject": pss["subject"],
    "perceived_helplessness": pss[helpless_items].sum(axis=1).astype(int),
    "perceived_self_efficacy": (4 - pss[selfeff_items]).sum(axis=1).astype(int),
})
result["total_pss_score"] = (
    result["perceived_helplessness"] + result["perceived_self_efficacy"]
).astype(int)

os.makedirs(os.path.dirname(OUT_PATH), exist_ok=True)
result.to_csv(OUT_PATH, index=False, header=False)

print(f"Saved result CSV without header to: {OUT_PATH}")
print("Number of rows:", len(result))
print("Preview:")
print(result.head(10).to_string(index=False))
print("Score summary:")
print(result[["perceived_helplessness", "perceived_self_efficacy", "total_pss_score"]].describe().to_string())
print("Output file first 5 lines:")
with open(OUT_PATH, "r") as f:
    for i, line in zip(range(5), f):
        print(line.rstrip())