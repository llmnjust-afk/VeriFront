#!/usr/bin/env python3
import os
import pickle
import inspect
import pandas as pd

DATA_PATH = "biopsykit_questionnaire_data/questionnaire_data.pkl"
OUT_PATH = "pred_results/questionnaire_pred.csv"

print(f"Loading data from {DATA_PATH!r} ...")
df = pd.read_pickle(DATA_PATH)
print("Loaded object type:", type(df))
print("Shape:", getattr(df, "shape", None))
print("Columns:", list(df.columns)[:20], "... total", len(df.columns))
print("First rows PSS:")
print(df[["subject"] + [f"PSS_{i:02d}" for i in range(1, 11)]].head().to_string(index=False))

# Try to inspect BioPsyKit's PSS implementation if available, to confirm scoring.
try:
    import biopsykit
    print("BioPsyKit available:", getattr(biopsykit, "__version__", "unknown version"))
    try:
        import biopsykit.questionnaires as questionnaires
        print("biopsykit.questionnaires members containing 'PSS' or 'Stress':")
        print([name for name in dir(questionnaires) if "PSS" in name.upper() or "STRESS" in name.upper()])
    except Exception as e:
        print("Could not inspect biopsykit.questionnaires:", repr(e))
except Exception as e:
    print("BioPsyKit not available or import failed:", repr(e))

# PSS-10 scoring:
# Negative / perceived helplessness items: 1, 2, 3, 6, 9, 10 are summed as-is.
# Positive / perceived self-efficacy items: 4, 5, 7, 8 are reverse-scored on the 0-4 scale, then summed.
# Total PSS score is the sum of both subscales.
pss_cols = [f"PSS_{i:02d}" for i in range(1, 11)]
missing = [c for c in ["subject"] + pss_cols if c not in df.columns]
if missing:
    raise ValueError(f"Missing required columns: {missing}")

helpless_cols = ["PSS_01", "PSS_02", "PSS_03", "PSS_06", "PSS_09", "PSS_10"]
selfeff_cols = ["PSS_04", "PSS_05", "PSS_07", "PSS_08"]

work = df[["subject"] + pss_cols].copy()
for c in pss_cols:
    work[c] = pd.to_numeric(work[c], errors="raise")

result = pd.DataFrame()
result["subject"] = work["subject"]
result["perceived_helplessness"] = work[helpless_cols].sum(axis=1)
result["perceived_self_efficacy"] = (4 - work[selfeff_cols]).sum(axis=1)
result["total_pss_score"] = result["perceived_helplessness"] + result["perceived_self_efficacy"]

os.makedirs(os.path.dirname(OUT_PATH), exist_ok=True)
result.to_csv(OUT_PATH, index=False, header=False)

print(f"Wrote {len(result)} rows to {OUT_PATH!r} without header.")
print("Result preview:")
print(result.head(10).to_string(index=False))
print("Summary:")
print(result[["perceived_helplessness", "perceived_self_efficacy", "total_pss_score"]].describe().to_string())