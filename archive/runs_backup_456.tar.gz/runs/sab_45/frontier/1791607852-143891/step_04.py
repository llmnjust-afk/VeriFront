#!/usr/bin/env python3
import os
import glob
import inspect
import pandas as pd

OUT_PATH = "pred_results/questionnaire_pred.csv"

# Locate dataset.
candidate_paths = [
    "benchmark/datasets/biopsykit_questionnaire_data/questionnaire_data.pkl",
    "biopsykit_questionnaire_data/questionnaire_data.pkl",
]
if os.path.exists("questionnaire_data_path.txt"):
    with open("questionnaire_data_path.txt", "r") as f:
        candidate_paths.insert(0, f.read().strip())
candidate_paths += glob.glob("**/questionnaire_data.pkl", recursive=True)

data_path = next((p for p in candidate_paths if p and os.path.exists(p)), None)
if data_path is None:
    raise FileNotFoundError("Could not find questionnaire_data.pkl")

print(f"Loading questionnaire data from: {data_path}")
df = pd.read_pickle(data_path)
print("Loaded shape:", df.shape)
print("Index name:", df.index.name)
print("Index preview:", list(df.index[:5]))
print("Columns preview:", list(df.columns[:15]))

# Inspect BioPsyKit if available, mainly to document/verify scoring conventions.
try:
    import biopsykit
    print("BioPsyKit version:", getattr(biopsykit, "__version__", "unknown"))
    import biopsykit.questionnaires as bq
    names = [n for n in dir(bq) if "PSS" in n.upper() or "PERCEIVED" in n.upper()]
    print("BioPsyKit questionnaire names containing PSS/Perceived:", names)
    for n in names:
        try:
            obj = getattr(bq, n)
            print(f"\n--- Source/header for biopsykit.questionnaires.{n} ---")
            src = inspect.getsource(obj)
            print("\n".join(src.splitlines()[:80]))
        except Exception as e:
            print(f"Could not inspect {n}: {e!r}")
except Exception as e:
    print("BioPsyKit inspection not available/failed:", repr(e))

pss_cols = [f"PSS_{i:02d}" for i in range(1, 11)]
missing = [c for c in pss_cols if c not in df.columns]
if missing:
    raise ValueError(f"Missing required PSS columns: {missing}")

# Subject is either an explicit column (as in preview rendering) or the DataFrame index.
if "subject" in df.columns:
    subjects = df["subject"]
else:
    subjects = df.index.to_series().reset_index(drop=True)
    if df.index.name is None:
        print("No explicit subject column; using DataFrame index as subject.")

pss = df[pss_cols].copy()
for c in pss_cols:
    pss[c] = pd.to_numeric(pss[c], errors="raise")

print("\nPSS data preview:")
preview = pss.copy()
preview.insert(0, "subject", list(subjects))
print(preview.head().to_string(index=False))
print("\nPSS response value ranges:")
print(pss.agg(["min", "max"]).to_string())

# Standard PSS-10 scoring:
# Negative/perceived helplessness items are scored as-is.
# Positive/perceived self-efficacy items are reverse-scored on the 0-4 scale for stress scoring.
helpless_items = ["PSS_01", "PSS_02", "PSS_03", "PSS_06", "PSS_09", "PSS_10"]
selfeff_items = ["PSS_04", "PSS_05", "PSS_07", "PSS_08"]

result = pd.DataFrame()
result["subject"] = list(subjects)
result["perceived_helplessness"] = pss[helpless_items].sum(axis=1).astype(int).to_numpy()
result["perceived_self_efficacy"] = (4 - pss[selfeff_items]).sum(axis=1).astype(int).to_numpy()
result["total_pss_score"] = (
    result["perceived_helplessness"] + result["perceived_self_efficacy"]
).astype(int)

os.makedirs(os.path.dirname(OUT_PATH), exist_ok=True)
result.to_csv(OUT_PATH, index=False, header=False)

print(f"\nSaved result CSV without header to: {OUT_PATH}")
print("Number of rows:", len(result))
print("Result preview:")
print(result.to_string(index=False))
print("\nScore summary:")
print(result[["perceived_helplessness", "perceived_self_efficacy", "total_pss_score"]].describe().to_string())
print("\nOutput file contents:")
with open(OUT_PATH, "r") as f:
    print(f.read())