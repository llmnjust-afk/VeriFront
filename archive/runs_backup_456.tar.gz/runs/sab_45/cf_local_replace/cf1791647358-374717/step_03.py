import inspect
import pandas as pd
from biopsykit.questionnaires import pss

print("pss module:", pss)
print("public attrs:", [a for a in dir(pss) if not a.startswith("_")])
for name in [a for a in dir(pss) if not a.startswith("_")]:
    obj = getattr(pss, name)
    if callable(obj):
        print("\nCALLABLE", name)
        try:
            print(inspect.signature(obj))
        except Exception as e:
            print("signature error", e)
        try:
            print(inspect.getsource(obj)[:4000])
        except Exception as e:
            print("source error", e)

df = pd.read_pickle("biopsykit_questionnaire_data/questionnaire_data.pkl")
try:
    print("\nTrying pss(dataframe):")
    print(pss.pss(df))
except Exception as e:
    print("pss.pss failed:", type(e).__name__, str(e))