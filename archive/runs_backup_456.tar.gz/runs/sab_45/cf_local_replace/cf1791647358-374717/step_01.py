import pandas as pd

df = pd.read_pickle("biopsykit_questionnaire_data/questionnaire_data.pkl")
print(df.shape)
print(df.columns.tolist())
print(df.head())
print(df.dtypes)
print(df.isna().sum().sum())