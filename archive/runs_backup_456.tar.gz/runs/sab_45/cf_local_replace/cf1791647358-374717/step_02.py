import importlib.util
import pandas as pd

print("biopsykit available:", importlib.util.find_spec("biopsykit") is not None)
if importlib.util.find_spec("biopsykit") is not None:
    import biopsykit
    print("biopsykit version:", getattr(biopsykit, "__version__", "unknown"))
    import biopsykit.questionnaires as q
    print("questionnaires attrs containing PSS/pss/perceived:")
    print([a for a in dir(q) if "PSS" in a or "pss" in a.lower() or "stress" in a.lower()])
    print("all public questionnaire attrs:")
    print([a for a in dir(q) if not a.startswith("_")][:200])

df = pd.read_pickle("biopsykit_questionnaire_data/questionnaire_data.pkl")
pss_cols = [f"PSS_{i:02d}" for i in range(1, 11)]
print("PSS data:")
print(df[pss_cols])
neg = ["PSS_01","PSS_02","PSS_03","PSS_06","PSS_09","PSS_10"]
pos = ["PSS_04","PSS_05","PSS_07","PSS_08"]
manual = pd.DataFrame(index=df.index)
manual["helplessness_raw"] = df[neg].sum(axis=1)
manual["selfeff_raw"] = df[pos].sum(axis=1)
manual["selfeff_reversed"] = (4 - df[pos]).sum(axis=1)
manual["total"] = manual["helplessness_raw"] + manual["selfeff_reversed"]
print("manual candidate:")
print(manual)