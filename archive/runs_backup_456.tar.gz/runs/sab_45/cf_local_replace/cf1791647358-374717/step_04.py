import inspect
import os
import pandas as pd
from biopsykit.questionnaires import pss

print("pss object:", pss)
print("signature:", inspect.signature(pss))
print("source:")
print(inspect.getsource(pss))

df = pd.read_pickle("biopsykit_questionnaire_data/questionnaire_data.pkl")
pss_cols = [f"PSS_{i:02d}" for i in range(1, 11)]
for data, label in [(df, "full df"), (df[pss_cols], "pss cols")]:
    print("\nTrying", label)
    try:
        res = pss(data)
        print(type(res))
        print(res)
    except Exception as e:
        print("failed:", type(e).__name__, str(e))