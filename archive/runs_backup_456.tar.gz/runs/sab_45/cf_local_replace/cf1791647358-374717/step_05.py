import os
import pandas as pd
from biopsykit.questionnaires import pss

# Load questionnaire data
data_path = "biopsykit_questionnaire_data/questionnaire_data.pkl"
df = pd.read_pickle(data_path)

# Select PSS item columns in the required order
pss_cols = [f"PSS_{i:02d}" for i in range(1, 11)]

# Compute PSS scores:
# - PSS_Helpless: perceived helplessness
# - PSS_SelfEff: perceived self-efficacy, with positive items reverse-scored as required
# - PSS_Total: total perceived stress scale score
pss_scores = pss(df[pss_cols])

# Build output table with subject as first column and no header
out = pd.DataFrame({
    "subject": pss_scores.index,
    "perceived_helplessness": pss_scores["PSS_Helpless"].astype(int),
    "perceived_self_efficacy": pss_scores["PSS_SelfEff"].astype(int),
    "total_pss_score": pss_scores["PSS_Total"].astype(int),
})

# Save required CSV without header
os.makedirs("pred_results", exist_ok=True)
out_path = "pred_results/questionnaire_pred.csv"
out.to_csv(out_path, index=False, header=False)

print(f"Saved {out_path}")
print(out)