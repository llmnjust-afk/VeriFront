import os
import pickle
import inspect
import pandas as pd
import biopsykit.questionnaires.pss as pss

print("pss module file:", pss.__file__)
print("pss module dir:", [x for x in dir(pss) if not x.startswith("__")])
for name in dir(pss):
    if not name.startswith("__"):
        obj = getattr(pss, name)
        if callable(obj):
            print("\nCALLABLE:", name)
            try:
                print("signature:", inspect.signature(obj))
            except Exception as e:
                print("signature error:", e)
            try:
                print(inspect.getdoc(obj))
            except Exception as e:
                print("doc error:", e)

with open("biopsykit_questionnaire_data/questionnaire_data.pkl", "rb") as f:
    df = pickle.load(f)

pss_cols = [f"PSS_{i:02d}" for i in range(1, 11)]
print("\nPSS data:")
print(df[pss_cols].to_string())

# Try known/likely BioPsyKit scoring functions if present
for func_name in ["pss", "score_pss", "compute_pss", "calculate_pss", "process_pss"]:
    if hasattr(pss, func_name):
        func = getattr(pss, func_name)
        print("\nTrying", func_name)
        try:
            res = func(df[pss_cols])
            print(type(res))
            print(res)
        except Exception as e:
            print("failed:", repr(e))