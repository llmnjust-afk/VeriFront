import os
import pickle
import inspect
import pandas as pd
import biopsykit.questionnaires as q

print("PSS function source:")
print(inspect.getsource(q.pss))

with open("biopsykit_questionnaire_data/questionnaire_data.pkl", "rb") as f:
    df = pickle.load(f)

pss_cols = [f"PSS_{i:02d}" for i in range(1, 11)]
print("\nBioPsyKit q.pss output:")
res = q.pss(df, columns=pss_cols)
print(res)
print("columns:", res.columns.tolist())

print("\nManual possible variants:")
raw = df[pss_cols]
help_items = ["PSS_01", "PSS_02", "PSS_03", "PSS_06", "PSS_09", "PSS_10"]
self_items = ["PSS_04", "PSS_05", "PSS_07", "PSS_08"]

manual_original_self = pd.DataFrame({
    "subject": df.index,
    "Helpness_sum_raw": raw[help_items].sum(axis=1),
    "SelfEff_sum_raw": raw[self_items].sum(axis=1),
    "PSS_total_standard": raw[help_items].sum(axis=1) + (4 - raw[self_items]).sum(axis=1),
})
print(manual_original_self.to_string(index=False))

manual_reversed_self = pd.DataFrame({
    "subject": df.index,
    "Helpness": raw[help_items].sum(axis=1),
    "SelfEff_reversed_stress": (4 - raw[self_items]).sum(axis=1),
    "PSS_total": raw[help_items].sum(axis=1) + (4 - raw[self_items]).sum(axis=1),
})
print(manual_reversed_self.to_string(index=False))