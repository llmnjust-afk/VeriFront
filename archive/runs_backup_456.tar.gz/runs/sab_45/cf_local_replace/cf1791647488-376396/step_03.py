import os
import pickle
import inspect
import importlib
import pkgutil
import pandas as pd

import biopsykit.questionnaires as q

print("biopsykit.questionnaires path:", q.__path__)
print("pss attribute in q:", getattr(q, "pss", None))
print("type:", type(getattr(q, "pss", None)))

print("\nSubmodules containing pss:")
for m in pkgutil.walk_packages(q.__path__, q.__name__ + "."):
    if "pss" in m.name.lower():
        print(m)

# Inspect attribute rather than direct submodule import
pss_attr = getattr(q, "pss", None)
if pss_attr is not None:
    print("\nq.pss signature/doc if callable:")
    if callable(pss_attr):
        try:
            print(inspect.signature(pss_attr))
        except Exception as e:
            print("sig error", e)
        print(inspect.getdoc(pss_attr))
    else:
        print(dir(pss_attr))

# Inspect central questionnaires submodule
try:
    qq = importlib.import_module("biopsykit.questionnaires.questionnaires")
    print("\nquestionnaires.questionnaires members with pss:")
    for name in dir(qq):
        if "pss" in name.lower():
            obj = getattr(qq, name)
            print(name, type(obj), callable(obj))
            if callable(obj):
                try:
                    print(inspect.signature(obj))
                except Exception as e:
                    print("sig error:", e)
                print(inspect.getdoc(obj))
except Exception as e:
    print("import central failed", repr(e))

with open("biopsykit_questionnaire_data/questionnaire_data.pkl", "rb") as f:
    df = pickle.load(f)
pss_cols = [f"PSS_{i:02d}" for i in range(1, 11)]

# Try q.pss directly
if callable(pss_attr):
    print("\nTrying q.pss")
    for inp in [df[pss_cols], df]:
        try:
            res = pss_attr(inp)
            print("input shape", inp.shape, "->", type(res))
            print(res)
        except Exception as e:
            print("failed for input shape", inp.shape, repr(e))

print("\nManual candidate scores:")
raw = df[pss_cols]
# Standard PSS-10: positive/eustress items 4,5,7,8 are reverse-coded (0-4), total all items.
rev_items = ["PSS_04", "PSS_05", "PSS_07", "PSS_08"]
helpless_items = ["PSS_01", "PSS_02", "PSS_03", "PSS_06", "PSS_09", "PSS_10"]
selfeff_items = rev_items
scored = raw.copy()
scored[rev_items] = 4 - scored[rev_items]
out = pd.DataFrame({
    "subject": df.index,
    "perceived_helplessness": scored[helpless_items].sum(axis=1),
    "perceived_self_efficacy": scored[selfeff_items].sum(axis=1),
    "total": scored.sum(axis=1),
}, index=df.index)
print(out.to_string(index=False))