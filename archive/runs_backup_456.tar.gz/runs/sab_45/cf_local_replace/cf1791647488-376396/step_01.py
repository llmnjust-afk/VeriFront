import pandas as pd
import numpy as np
import pickle
import biopsykit as bp
import inspect

path = 'biopsykit_questionnaire_data/questionnaire_data.pkl'
with open(path, 'rb') as f:
    df = pickle.load(f)
print(type(df))
print(df.shape)
print(df.columns.tolist())
print(df.head())
print(df.dtypes)
print(df.describe(include='all'))

# Explore biopsykit questionnaire module
import biopsykit.questionnaires as q
print('questionnaires module:', dir(q))
# Search for PSS related functions/classes
for name in dir(bp):
    if 'pss' in name.lower() or 'question' in name.lower():
        print('bp attr', name)
for name in dir(q):
    if 'pss' in name.lower() or 'stress' in name.lower() or 'question' in name.lower():
        print('q attr', name)