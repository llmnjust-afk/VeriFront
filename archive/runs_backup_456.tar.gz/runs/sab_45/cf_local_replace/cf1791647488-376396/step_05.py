import os
import pickle
import pandas as pd
import biopsykit.questionnaires as q

# Load questionnaire data
input_path = "biopsykit_questionnaire_data/questionnaire_data.pkl"
with open(input_path, "rb") as f:
    data = pickle.load(f)

# Compute PSS scores using BioPsyKit's validated implementation.
# It reverse-scores PSS items 4, 5, 7, and 8 and returns:
# PSS_Helpless, PSS_SelfEff, PSS_Total.
pss_cols = [f"PSS_{i:02d}" for i in range(1, 11)]
pss_scores = q.pss(data, columns=pss_cols)

# Assemble required output: subject, perceived helplessness,
# perceived self-efficacy, total PSS score. No header.
out = pd.DataFrame({
    "subject": pss_scores.index,
    "perceived_helplessness": pss_scores["PSS_Helpless"].astype(int),
    "perceived_self_efficacy": pss_scores["PSS_SelfEff"].astype(int),
    "total_pss_score": pss_scores["PSS_Total"].astype(int),
})

os.makedirs("pred_results", exist_ok=True)
output_path = "pred_results/questionnaire_pred.csv"
out.to_csv(output_path, index=False, header=False)

print("Saved:", output_path)
print("Shape:", out.shape)
print(out.to_string(index=False))
print("\nFile contents:")
with open(output_path, "r") as f:
    print(f.read())