import os
import pandas as pd
import numpy as np

df = pd.read_pickle("biopsykit_questionnaire_data/questionnaire_data.pkl")
pss = df[[f"PSS_{i:02d}" for i in range(1, 11)]].copy()

# Standard PSS-10 scoring:
# Perceived helplessness: items 1,2,3,6,9,10 (direct)
# Perceived self-efficacy: items 4,5,7,8 are positively stated and reverse-scored (0<->4) for stress burden
helpless_items = ["PSS_01", "PSS_02", "PSS_03", "PSS_06", "PSS_09", "PSS_10"]
selfeff_items = ["PSS_04", "PSS_05", "PSS_07", "PSS_08"]

result = pd.DataFrame(index=df.index)
result["perceived_helplessness"] = pss[helpless_items].sum(axis=1)
result["perceived_self_efficacy"] = (4 - pss[selfeff_items]).sum(axis=1)
result["total_pss_score"] = result["perceived_helplessness"] + result["perceived_self_efficacy"]

out = result.reset_index()
out.columns = ["subject", "perceived_helplessness", "perceived_self_efficacy", "total_pss_score"]

os.makedirs("pred_results", exist_ok=True)
out.to_csv("pred_results/questionnaire_pred.csv", index=False, header=False)

print(out)
print("Saved:", "pred_results/questionnaire_pred.csv")
print("CSV preview:")
print(open("pred_results/questionnaire_pred.csv", "r").read())