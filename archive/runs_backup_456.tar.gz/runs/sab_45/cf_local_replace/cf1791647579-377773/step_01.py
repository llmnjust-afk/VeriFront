import pandas as pd
import numpy as np

df = pd.read_pickle("biopsykit_questionnaire_data/questionnaire_data.pkl")
print(type(df))
print(df.shape)
print(df.columns.tolist())
print(df.head())
print(df.index)