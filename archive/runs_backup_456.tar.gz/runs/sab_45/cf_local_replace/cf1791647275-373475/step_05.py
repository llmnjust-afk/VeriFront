import os
import pickle
import pandas as pd
from biopsykit.questionnaires import pss

input_path = "biopsykit_questionnaire_data/questionnaire_data.pkl"
output_path = "pred_results/questionnaire_pred.csv"

with open(input_path, "rb") as f:
    df = pickle.load(f)

pss_cols = [f"PSS_{i:02d}" for i in range(1, 11)]
scores = pss(df, columns=pss_cols)

print("Computed BioPsyKit PSS scores:")
print(scores)
print("Score columns:", list(scores.columns))

# Required columns: subject, perceived helplessness, perceived self-efficacy, total PSS score.
# BioPsyKit returns PSS_Helpless, PSS_SelfEff, PSS_Total; SelfEff is computed after reversing items 4,5,7,8.
out = pd.DataFrame({
    "subject": scores.index,
    "perceived_helplessness": scores["PSS_Helpless"].astype(int),
    "perceived_self_efficacy": scores["PSS_SelfEff"].astype(int),
    "total_pss_score": scores["PSS_Total"].astype(int),
})

os.makedirs(os.path.dirname(output_path), exist_ok=True)
out.to_csv(output_path, index=False, header=False)

print(f"\nSaved {len(out)} rows to {output_path} without header.")
print("Output preview:")
print(out)
print("\nCSV contents:")
with open(output_path, "r") as f:
    print(f.read())