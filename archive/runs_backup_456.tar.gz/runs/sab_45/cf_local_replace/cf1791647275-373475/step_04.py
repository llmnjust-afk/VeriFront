import inspect
from biopsykit.questionnaires import pss
print("signature:", inspect.signature(pss))
src = inspect.getsource(pss)
print(src)