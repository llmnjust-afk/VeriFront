import pandas as pd
import pickle

with open('biopsykit_questionnaire_data/questionnaire_data.pkl', 'rb') as f:
    data = pickle.load(f)

print(type(data))
if isinstance(data, dict):
    for k, v in data.items():
        print(k, type(v))
        if hasattr(v, 'shape'):
            print(v.shape)
        print(v if not hasattr(v, 'head') else v.head())
else:
    print(data.shape if hasattr(data, 'shape') else None)
    print(data.head() if hasattr(data, 'head') else data)
    if hasattr(data, 'columns'):
        print(list(data.columns))
    if hasattr(data, 'index'):
        print('index', data.index)