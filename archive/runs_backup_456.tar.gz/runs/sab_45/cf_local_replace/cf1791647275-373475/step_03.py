import inspect
import biopsykit.questionnaires as bq
import biopsykit.questionnaires.questionnaires as qq

print("biopsykit.questionnaires contents:")
for name in dir(bq):
    if not name.startswith("_"):
        obj = getattr(bq, name)
        print(name, type(obj))

print("\nquestionnaires module contents:")
for name in dir(qq):
    if not name.startswith("_"):
        obj = getattr(qq, name)
        print(name, type(obj))

# Print source/signatures for questionnaire-related classes/functions containing PSS
for mod in [bq, qq]:
    print("\nMOD", mod.__name__)
    for name in dir(mod):
        if "PSS" in name.upper() or "QUESTION" in name.upper():
            obj = getattr(mod, name)
            print("NAME", name, obj)
            try:
                print("SIG", inspect.signature(obj))
            except Exception as e:
                print("No sig", e)
            try:
                src = inspect.getsource(obj)
                print(src[:4000])
            except Exception as e:
                print("No source", e)