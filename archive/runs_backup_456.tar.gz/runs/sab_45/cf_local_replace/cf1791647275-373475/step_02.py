import importlib.util
import pandas as pd
import pickle

print("biopsykit available:", importlib.util.find_spec("biopsykit") is not None)
if importlib.util.find_spec("biopsykit") is not None:
    import biopsykit
    print("biopsykit version:", getattr(biopsykit, "__version__", "unknown"))
    # List likely questionnaire modules/classes
    import pkgutil
    mods = [m.name for m in pkgutil.walk_packages(biopsykit.__path__, biopsykit.__name__ + ".") if "question" in m.name.lower() or "pss" in m.name.lower()]
    print("matching modules:")
    for m in mods[:100]:
        print(m)

with open('biopsykit_questionnaire_data/questionnaire_data.pkl', 'rb') as f:
    df = pickle.load(f)
pss_cols = [f"PSS_{i:02d}" for i in range(1,11)]
print("PSS raw:")
print(df[pss_cols])
# compute candidate scores
neg = ["PSS_01","PSS_02","PSS_03","PSS_06","PSS_09","PSS_10"]
pos = ["PSS_04","PSS_05","PSS_07","PSS_08"]
helpless = df[neg].sum(axis=1)
self_raw = df[pos].sum(axis=1)
self_rev = (4 - df[pos]).sum(axis=1)
total = helpless + self_rev
cand = pd.DataFrame({"helpless": helpless, "self_raw": self_raw, "self_rev": self_rev, "total": total})
print("candidate scores:")
print(cand)