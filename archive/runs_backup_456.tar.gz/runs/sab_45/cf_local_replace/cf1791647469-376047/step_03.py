import os
import pandas as pd

# Load questionnaire data
df = pd.read_pickle("biopsykit_questionnaire_data/questionnaire_data.pkl")

# PSS-10 scoring:
# Perceived Helplessness: items 1, 2, 3, 6, 9, 10
# Perceived Self-Efficacy: items 4, 5, 7, 8, reverse-scored on 0..4 scale
helplessness_items = ["PSS_01", "PSS_02", "PSS_03", "PSS_06", "PSS_09", "PSS_10"]
self_efficacy_items = ["PSS_04", "PSS_05", "PSS_07", "PSS_08"]

perceived_helplessness = df[helplessness_items].sum(axis=1)
perceived_self_efficacy = (4 - df[self_efficacy_items]).sum(axis=1)
total_pss = perceived_helplessness + perceived_self_efficacy

out = pd.DataFrame({
    "subject": df.index,
    "perceived_helplessness": perceived_helplessness.astype(int).values,
    "perceived_self_efficacy": perceived_self_efficacy.astype(int).values,
    "total_pss_score": total_pss.astype(int).values,
})

os.makedirs("pred_results", exist_ok=True)
out_path = "pred_results/questionnaire_pred.csv"
out.to_csv(out_path, index=False, header=False)

print("Wrote:", out_path)
print("Shape:", out.shape)
print(out.to_string(index=False))