import os
import pandas as pd

infile = "biopsykit_questionnaire_data/questionnaire_data.pkl"
df = pd.read_pickle(infile)

print("Loaded shape:", df.shape)
print("Columns:", list(df.columns[:15]), "...")
print(df.head(3).to_string(index=False))