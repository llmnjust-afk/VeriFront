import importlib.util
import pandas as pd

df = pd.read_pickle("biopsykit_questionnaire_data/questionnaire_data.pkl")
print("Index type:", type(df.index))
print("Index name:", df.index.name)
print("Index values:", list(df.index))
print("Has subject column?", "subject" in df.columns)

spec = importlib.util.find_spec("biopsykit")
print("biopsykit available:", spec is not None)
if spec is not None:
    import biopsykit
    print("biopsykit version:", getattr(biopsykit, "__version__", "unknown"))

pss_cols = [f"PSS_{i:02d}" for i in range(1, 11)]
print("PSS data:")
print(df[pss_cols].to_string())