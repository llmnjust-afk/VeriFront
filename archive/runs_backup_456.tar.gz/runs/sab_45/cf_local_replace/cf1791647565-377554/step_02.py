import os
import pickle
import pandas as pd

data_path = "biopsykit_questionnaire_data/questionnaire_data.pkl"
out_path = "pred_results/questionnaire_pred.csv"

with open(data_path, "rb") as f:
    df = pickle.load(f)
if not isinstance(df, pd.DataFrame):
    df = pd.DataFrame(df)

# PSS-10 scoring:
# Perceived helplessness: negatively phrased items summed as-is.
# Perceived self-efficacy: positively phrased items reverse-scored (0<->4, 1<->3, 2 stays 2) and summed.
helpless_items = ["PSS_01", "PSS_02", "PSS_03", "PSS_06", "PSS_09", "PSS_10"]
selfeff_items = ["PSS_04", "PSS_05", "PSS_07", "PSS_08"]

missing = [c for c in helpless_items + selfeff_items if c not in df.columns]
if missing:
    raise ValueError(f"Missing required PSS columns: {missing}")

helplessness = df[helpless_items].sum(axis=1)
self_efficacy = (4 - df[selfeff_items]).sum(axis=1)
total_pss = helplessness + self_efficacy

subjects = df.index.to_series().astype(str)
if df.index.name is None and "subject" in df.columns:
    subjects = df["subject"].astype(str)

result = pd.DataFrame({
    "subject": subjects.values,
    "perceived_helplessness": helplessness.astype(int).values,
    "perceived_self_efficacy": self_efficacy.astype(int).values,
    "total_pss": total_pss.astype(int).values,
})

os.makedirs(os.path.dirname(out_path), exist_ok=True)
result.to_csv(out_path, index=False, header=False)

print("Saved:", out_path)
print("Result shape:", result.shape)
print(result)