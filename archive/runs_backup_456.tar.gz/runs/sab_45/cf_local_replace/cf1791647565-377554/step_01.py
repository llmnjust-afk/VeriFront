import os
import pickle
import pandas as pd

data_path = "biopsykit_questionnaire_data/questionnaire_data.pkl"
out_path = "pred_results/questionnaire_pred.csv"

with open(data_path, "rb") as f:
    data = pickle.load(f)

if not isinstance(data, pd.DataFrame):
    data = pd.DataFrame(data)

print("Loaded data shape:", data.shape)
print("Columns:", list(data.columns[:15]), "..." if len(data.columns) > 15 else "")
print("Head of PSS columns:")
print(data[[c for c in data.columns if c.startswith("PSS_")]].head())

os.makedirs(os.path.dirname(out_path), exist_ok=True)