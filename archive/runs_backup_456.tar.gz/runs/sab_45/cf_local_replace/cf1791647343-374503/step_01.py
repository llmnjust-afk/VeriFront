import os
import pickle
import pandas as pd
import numpy as np

# Load questionnaire data
path = "biopsykit_questionnaire_data/questionnaire_data.pkl"
with open(path, "rb") as f:
    data = pickle.load(f)

# Convert to DataFrame if needed
if not isinstance(data, pd.DataFrame):
    data = pd.DataFrame(data)

print("Loaded data shape:", data.shape)
print("Columns:", list(data.columns[:15]), "..." if data.shape[1] > 15 else "")

# Identify PSS items
pss_cols = [c for c in data.columns if c.startswith("PSS_")]
print("PSS columns:", pss_cols)

# Try to compute PSS using standard scoring:
# Positive items: 4, 5, 7, 8
# Negative items: 1, 2, 3, 6, 9, 10
# Assume item scores are on 0-4 or 1-5; reverse with max+min - x based on observed range.
pss = data[pss_cols].copy()

# Determine item scale from observed values
vals = pd.to_numeric(pss.stack(), errors="coerce")
min_v, max_v = float(vals.min()), float(vals.max())
print("Observed PSS value range:", min_v, max_v)

# Standard PSS-10 scoring components
helpless_items = ["PSS_01", "PSS_02", "PSS_03", "PSS_06", "PSS_09", "PSS_10"]
selfeff_items = ["PSS_04", "PSS_05", "PSS_07", "PSS_08"]

# Reverse score self-efficacy items
reverse_offset = min_v + max_v
pss_rev = pss.copy()
for c in selfeff_items:
    if c in pss_rev.columns:
        pss_rev[c] = reverse_offset - pd.to_numeric(pss_rev[c], errors="coerce")

# Compute scores
perceived_helplessness = pd.to_numeric(pss[helpless_items].sum(axis=1), errors="coerce")
perceived_self_efficacy = pd.to_numeric(pss_rev[selfeff_items].sum(axis=1), errors="coerce")
total_pss = perceived_helplessness + perceived_self_efficacy

out = pd.DataFrame({
    "subject": data["subject"],
    "perceived_helplessness": perceived_helplessness,
    "perceived_self_efficacy": perceived_self_efficacy,
    "total_pss": total_pss
})

print(out.head())

# Save without header as requested
os.makedirs("pred_results", exist_ok=True)
out.to_csv("pred_results/questionnaire_pred.csv", index=False, header=False)

print("Saved to pred_results/questionnaire_pred.csv")
print("Output shape:", out.shape)