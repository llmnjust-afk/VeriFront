import os
import pickle
import pandas as pd
import numpy as np

# Load questionnaire data
path = "biopsykit_questionnaire_data/questionnaire_data.pkl"
with open(path, "rb") as f:
    data = pickle.load(f)

if not isinstance(data, pd.DataFrame):
    data = pd.DataFrame(data)

print("Loaded data shape:", data.shape)
print("Index name:", data.index.name)
print("Index preview:", list(data.index[:5]))
print("Columns preview:", list(data.columns[:12]))

# In the actual pickle, subject is stored as the index (preview showed it as a column).
subjects = data["subject"] if "subject" in data.columns else data.index.to_series(index=data.index)

# PSS-10 standard scoring:
# Perceived helplessness subscale: items 1,2,3,6,9,10 (not reverse scored)
# Perceived self-efficacy subscale: items 4,5,7,8 (reverse scored for total PSS contribution)
helpless_items = ["PSS_01", "PSS_02", "PSS_03", "PSS_06", "PSS_09", "PSS_10"]
selfeff_items = ["PSS_04", "PSS_05", "PSS_07", "PSS_08"]
all_items = helpless_items + selfeff_items

missing = [c for c in all_items if c not in data.columns]
if missing:
    raise ValueError(f"Missing required PSS columns: {missing}")

pss = data[all_items].apply(pd.to_numeric, errors="coerce")

# PSS data are 0..4 in this dataset; reverse scoring is 4 - item.
min_v = pss.min().min()
max_v = pss.max().max()
reverse_offset = min_v + max_v
print("Observed PSS range:", min_v, max_v, "reverse offset:", reverse_offset)

perceived_helplessness = pss[helpless_items].sum(axis=1)
perceived_self_efficacy = (reverse_offset - pss[selfeff_items]).sum(axis=1)
total_pss = perceived_helplessness + perceived_self_efficacy

out = pd.DataFrame({
    "subject": subjects.values,
    "perceived_helplessness": perceived_helplessness.values,
    "perceived_self_efficacy": perceived_self_efficacy.values,
    "total_pss": total_pss.values,
})

# Prefer integer-looking CSV values
for c in ["perceived_helplessness", "perceived_self_efficacy", "total_pss"]:
    if np.all(np.isfinite(out[c])) and np.allclose(out[c], np.round(out[c])):
        out[c] = out[c].astype(int)

print("Computed output:")
print(out)

os.makedirs("pred_results", exist_ok=True)
out_path = "pred_results/questionnaire_pred.csv"
out.to_csv(out_path, index=False, header=False)

print("Saved:", out_path)
print("Output shape:", out.shape)