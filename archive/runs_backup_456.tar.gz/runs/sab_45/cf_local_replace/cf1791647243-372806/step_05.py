import os
import pandas as pd
from biopsykit.questionnaires.questionnaires import pss

input_path = "biopsykit_questionnaire_data/questionnaire_data.pkl"
output_path = "pred_results/questionnaire_pred.csv"

df = pd.read_pickle(input_path)
pss_cols = [f"PSS_{i:02d}" for i in range(1, 11)]

scores = pss(df, columns=pss_cols)
out = scores.reset_index()[["subject", "PSS_Helpless", "PSS_SelfEff", "PSS_Total"]]

os.makedirs(os.path.dirname(output_path), exist_ok=True)
out.to_csv(output_path, index=False, header=False)

print("Saved:", output_path)
print("Output shape:", out.shape)
print(out.to_string(index=False))
print("\nFile content preview:")
with open(output_path, "r", encoding="utf-8") as f:
    print(f.read())