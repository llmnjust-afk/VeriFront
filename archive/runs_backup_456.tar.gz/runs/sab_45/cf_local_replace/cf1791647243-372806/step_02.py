import importlib
import pandas as pd

print("Checking available BioPsyKit and possible PSS scoring helpers...")
mods = ["biopsykit", "biopsykit.questionnaires", "biopsykit.questionnaires.questionnaire"]
for m in mods:
    try:
        mod = importlib.import_module(m)
        print(m, "imported:", mod)
        print("dir sample:", [x for x in dir(mod) if "PSS" in x or "Question" in x or "score" in x.lower()][:30])
    except Exception as e:
        print(m, "not importable:", repr(e))

# inspect installed package names/modules if possible
try:
    import biopsykit
    print("biopsykit version:", getattr(biopsykit, "__version__", "unknown"))
except Exception as e:
    print("No biopsykit:", e)

df = pd.read_pickle("biopsykit_questionnaire_data/questionnaire_data.pkl")
print("Index name:", df.index.name)
print("Index first:", list(df.index[:5]))
print("PSS item descriptive stats:")
print(df[[f"PSS_{i:02d}" for i in range(1, 11)]].describe().to_string())