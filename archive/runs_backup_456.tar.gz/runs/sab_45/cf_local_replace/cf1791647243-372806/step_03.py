import os
import pkgutil
import importlib
import inspect
import biopsykit.questionnaires as q

print("biopsykit.questionnaires submodules:")
for info in pkgutil.walk_packages(q.__path__, q.__name__ + "."):
    if "pss" in info.name.lower() or "question" in info.name.lower() or "utils" in info.name.lower():
        print(info.name)

print("\nAll immediate questionnaire modules:")
for info in pkgutil.iter_modules(q.__path__):
    print(info.name)

# Try to find PSS classes/functions in all questionnaire modules
print("\nSearching for PSS in questionnaire package modules...")
for info in pkgutil.walk_packages(q.__path__, q.__name__ + "."):
    try:
        mod = importlib.import_module(info.name)
    except Exception as e:
        continue
    hits = [name for name, obj in vars(mod).items() if "PSS" in name.upper() or "STRESS" in name.upper()]
    if hits:
        print(info.name, hits)
        for h in hits[:5]:
            obj = getattr(mod, h)
            try:
                print(" ", h, inspect.signature(obj) if callable(obj) else type(obj))
            except Exception:
                print(" ", h, type(obj))