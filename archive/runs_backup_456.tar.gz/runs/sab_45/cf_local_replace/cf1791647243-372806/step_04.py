import pandas as pd
from biopsykit.questionnaires.questionnaires import pss

df = pd.read_pickle("biopsykit_questionnaire_data/questionnaire_data.pkl")
pss_cols = [f"PSS_{i:02d}" for i in range(1, 11)]

print("Calling BioPsyKit pss() on PSS columns...")
res_default = pss(df, columns=pss_cols)
print("Result type:", type(res_default))
print("Shape:", res_default.shape)
print("Columns:", list(res_default.columns))
print(res_default.to_string())

print("\nTrying to inspect pss source for subscale definitions...")
import inspect
print(inspect.getsource(pss))