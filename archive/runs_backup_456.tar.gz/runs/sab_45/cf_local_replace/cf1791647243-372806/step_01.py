import os
import pandas as pd

path = "biopsykit_questionnaire_data/questionnaire_data.pkl"
print("Loading:", path)

try:
    df = pd.read_pickle(path)
except Exception as e:
    print("Failed to load pickle directly:", repr(e))
    raise

print("Shape:", df.shape)
print("Columns:", list(df.columns[:15]), "..." if len(df.columns) > 15 else "")
print(df.head(3).to_string())

# Save a quick inspection of unique subject count and PSS item presence
pss_cols = [c for c in df.columns if c.startswith("PSS_")]
print("PSS columns:", pss_cols)
print("Number of subjects:", df["subject"].nunique() if "subject" in df.columns else "no subject column")