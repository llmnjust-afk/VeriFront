#!/usr/bin/env python3
import os
import pandas as pd

INPUT_PATH = "biopsykit_questionnaire_data/questionnaire_data.pkl"
OUTPUT_DIR = "pred_results"
OUTPUT_PATH = os.path.join(OUTPUT_DIR, "questionnaire_pred.csv")

def main():
    df = pd.read_pickle(INPUT_PATH)

    print("Loaded data:")
    print(f"  shape: {df.shape}")
    print(f"  index name: {df.index.name!r}")
    print(f"  index preview: {list(df.index[:5])}")
    print(f"  columns first 12: {list(df.columns[:12])}")

    # In this pickle the subject identifiers are stored as the DataFrame index.
    if "subject" in df.columns:
        subjects = df["subject"]
    else:
        subjects = pd.Series(df.index, index=df.index, name="subject")

    # PSS-10 scoring (0..4 response scale):
    # - perceived helplessness items are scored directly
    # - perceived self-efficacy items are positively phrased and reverse-scored (4 - item)
    helplessness_items = ["PSS_01", "PSS_02", "PSS_03", "PSS_06", "PSS_09", "PSS_10"]
    self_efficacy_items = ["PSS_04", "PSS_05", "PSS_07", "PSS_08"]

    missing = [c for c in helplessness_items + self_efficacy_items if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required PSS columns: {missing}")

    out = pd.DataFrame({
        "subject": subjects.to_numpy(),
        "perceived_helplessness": df[helplessness_items].sum(axis=1).to_numpy(),
        "perceived_self_efficacy": (4 - df[self_efficacy_items]).sum(axis=1).to_numpy(),
    })
    out["total_pss_score"] = out["perceived_helplessness"] + out["perceived_self_efficacy"]

    os.makedirs(OUTPUT_DIR, exist_ok=True)
    out.to_csv(OUTPUT_PATH, index=False, header=False)

    print("\nComputed PSS results:")
    print(f"  rows: {len(out)}")
    print(f"  total PSS min/max: {out['total_pss_score'].min()} / {out['total_pss_score'].max()}")
    print(f"  saved file exists: {os.path.exists(OUTPUT_PATH)}")
    print("\nPreview of output dataframe:")
    print(out.head().to_string(index=False))
    print("\nPreview of saved CSV:")
    with open(OUTPUT_PATH, "r", encoding="utf-8") as f:
        for i, line in enumerate(f):
            if i >= 5:
                break
            print(line.rstrip())
    print(f"\nSaved: {OUTPUT_PATH}")

if __name__ == "__main__":
    main()