#!/usr/bin/env python3
import os
import pandas as pd

INPUT_PATH = "biopsykit_questionnaire_data/questionnaire_data.pkl"
OUTPUT_DIR = "pred_results"
OUTPUT_PATH = os.path.join(OUTPUT_DIR, "questionnaire_pred.csv")

def main():
    # Load questionnaire data
    df = pd.read_pickle(INPUT_PATH)
    print("Loaded data:")
    print(f"  shape: {df.shape}")
    print(f"  columns first 12: {list(df.columns[:12])}")

    # PSS-10 scoring:
    # Perceived helplessness: negatively phrased items, scored directly
    helplessness_items = ["PSS_01", "PSS_02", "PSS_03", "PSS_06", "PSS_09", "PSS_10"]
    # Perceived self-efficacy: positively phrased items, reverse scored for stress contribution
    self_efficacy_items = ["PSS_04", "PSS_05", "PSS_07", "PSS_08"]

    # Check required columns
    required = ["subject"] + helplessness_items + self_efficacy_items
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    pss = df[["subject"]].copy()
    pss["perceived_helplessness"] = df[helplessness_items].sum(axis=1)
    pss["perceived_self_efficacy"] = (4 - df[self_efficacy_items]).sum(axis=1)
    pss["total_pss_score"] = pss["perceived_helplessness"] + pss["perceived_self_efficacy"]

    # Save without header and without index as required
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    pss.to_csv(OUTPUT_PATH, index=False, header=False)

    print("\nComputed PSS results:")
    print(f"  number of subjects: {len(pss)}")
    print(f"  helplessness min/max: {pss['perceived_helplessness'].min()} / {pss['perceived_helplessness'].max()}")
    print(f"  self-efficacy stress contribution min/max: {pss['perceived_self_efficacy'].min()} / {pss['perceived_self_efficacy'].max()}")
    print(f"  total PSS min/max: {pss['total_pss_score'].min()} / {pss['total_pss_score'].max()}")
    print("\nPreview:")
    print(pss.head().to_string(index=False))
    print(f"\nSaved: {OUTPUT_PATH}")

if __name__ == "__main__":
    main()