#!/usr/bin/env python3
import os
import pickle
import pandas as pd
import numpy as np

print("Working directory:", os.getcwd())
path = "biopsykit_questionnaire_data/questionnaire_data.pkl"
print("Exists:", os.path.exists(path), path)

# Load data
obj = pd.read_pickle(path)
print("Loaded type:", type(obj))
if isinstance(obj, pd.DataFrame):
    df = obj
else:
    print("Object repr:", repr(obj)[:1000])
    df = pd.DataFrame(obj)

print("Shape:", df.shape)
print("Columns:", list(df.columns)[:80])
print("Head:")
print(df.head().to_string())

# Check installed BioPsyKit and possible PSS functionality
try:
    import biopsykit
    print("biopsykit version:", getattr(biopsykit, "__version__", "unknown"))
    import biopsykit.questionnaires as bq
    print("biopsykit.questionnaires attrs containing PSS/Stress/Questionnaire:")
    attrs = [a for a in dir(bq) if any(s.lower() in a.lower() for s in ["pss", "stress", "question"])]
    print(attrs)
except Exception as e:
    print("BioPsyKit import/check failed:", repr(e))

# Manual PSS sanity calculation using standard PSS-10 scoring:
# negative/helplessness items: 1,2,3,6,9,10; positive/self-efficacy items: 4,5,7,8 reverse-scored (0<->4, 1<->3)
pss_cols = [f"PSS_{i:02d}" for i in range(1, 11)]
print("PSS columns present:", all(c in df.columns for c in pss_cols))
print("PSS value ranges:")
print(df[pss_cols].agg(["min", "max", "mean"]).to_string())

helpless_cols = ["PSS_01", "PSS_02", "PSS_03", "PSS_06", "PSS_09", "PSS_10"]
selfeff_cols = ["PSS_04", "PSS_05", "PSS_07", "PSS_08"]
helpless = df[helpless_cols].sum(axis=1)
selfeff_reversed = (4 - df[selfeff_cols]).sum(axis=1)
total = helpless + selfeff_reversed

res = pd.DataFrame({
    "subject": df["subject"],
    "perceived_helplessness": helpless,
    "perceived_self_efficacy": selfeff_reversed,
    "pss_total": total,
})
print("Manual standard PSS result preview:")
print(res.head(10).to_string(index=False))
print("Summary:")
print(res.iloc[:, 1:].describe().to_string())

# Save candidate result now; can refine if subsequent observation indicates BioPsyKit differs.
os.makedirs("pred_results", exist_ok=True)
out_path = "pred_results/questionnaire_pred.csv"
res.to_csv(out_path, index=False, header=False)
print("Saved:", out_path)
print("Saved file preview:")
with open(out_path, "r", encoding="utf-8") as f:
    for i, line in zip(range(10), f):
        print(line.rstrip())