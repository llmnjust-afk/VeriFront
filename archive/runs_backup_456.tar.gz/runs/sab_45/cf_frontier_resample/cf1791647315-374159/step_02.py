#!/usr/bin/env python3
import os
import inspect
import pkgutil
import pandas as pd
import numpy as np

os.environ.setdefault("MPLCONFIGDIR", os.path.abspath(".mplconfig"))

path = "biopsykit_questionnaire_data/questionnaire_data.pkl"
df = pd.read_pickle(path)
print("Loaded dataframe shape:", df.shape)
print("Index name:", df.index.name)
print("Index preview:", list(df.index[:5]))
print("Columns preview:", list(df.columns[:12]))

# Inspect BioPsyKit questionnaire scoring classes/functions relevant to PSS
try:
    import biopsykit
    print("biopsykit version:", getattr(biopsykit, "__version__", "unknown"))
    import biopsykit.questionnaires as questionnaires
    print("questionnaires module:", questionnaires)
    names = [n for n in dir(questionnaires) if "PSS" in n.upper() or "STRESS" in n.upper() or "QUESTION" in n.upper()]
    print("Top-level relevant names:", names)
    # Walk submodules looking for PSS
    found = []
    for modinfo in pkgutil.walk_packages(questionnaires.__path__, questionnaires.__name__ + "."):
        if any(s in modinfo.name.lower() for s in ["pss", "stress", "questionnaire", "utils", "score"]):
            found.append(modinfo.name)
    print("Relevant submodules:", found[:100])
    for modname in found:
        try:
            mod = __import__(modname, fromlist=["*"])
            mod_names = [n for n in dir(mod) if "PSS" in n.upper() or "STRESS" in n.upper()]
            if mod_names:
                print("Module", modname, "names", mod_names)
                for n in mod_names[:10]:
                    obj = getattr(mod, n)
                    try:
                        print("SOURCE/INFO for", modname, n)
                        print(inspect.getsource(obj)[:4000])
                    except Exception as e:
                        print("No source for", n, type(obj), repr(e))
        except Exception as e:
            print("Could not import", modname, repr(e))
except Exception as e:
    print("BioPsyKit inspection failed:", repr(e))

# Compute both possible variants for inspection:
pss_cols = [f"PSS_{i:02d}" for i in range(1, 11)]
helpless_cols = ["PSS_01", "PSS_02", "PSS_03", "PSS_06", "PSS_09", "PSS_10"]
selfeff_cols = ["PSS_04", "PSS_05", "PSS_07", "PSS_08"]

helpless = df[helpless_cols].sum(axis=1).astype(int)
selfeff_raw = df[selfeff_cols].sum(axis=1).astype(int)
selfeff_reversed = (4 - df[selfeff_cols]).sum(axis=1).astype(int)
total_standard = (helpless + selfeff_reversed).astype(int)

print("\nPSS input:")
print(df[pss_cols].to_string())
print("\nCandidate scoring table (raw selfeff vs reversed selfeff):")
cand = pd.DataFrame({
    "subject": df.index.astype(str),
    "helpless": helpless,
    "selfeff_raw": selfeff_raw,
    "selfeff_reversed": selfeff_reversed,
    "total_standard": total_standard,
})
print(cand.to_string(index=False))

# Save likely required result: subscale score for perceived self-efficacy as reverse-coded contribution
# so subscales add to the total PSS score.
res = pd.DataFrame({
    "subject": df.index.astype(str),
    "perceived_helplessness": helpless,
    "perceived_self_efficacy": selfeff_reversed,
    "pss_total": total_standard,
})
os.makedirs("pred_results", exist_ok=True)
out_path = "pred_results/questionnaire_pred.csv"
res.to_csv(out_path, index=False, header=False)
print("\nSaved:", out_path)
print(open(out_path, "r", encoding="utf-8").read())