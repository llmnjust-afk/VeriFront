#!/usr/bin/env python3
import os
import pickle
import json
import pandas as pd
import numpy as np

DATA_PATH = "biopsykit_questionnaire_data/questionnaire_data.pkl"
OUT_PATH = "pred_results/questionnaire_pred.csv"

print(f"Loading data from {DATA_PATH}")
obj = pd.read_pickle(DATA_PATH)
print("Loaded object type:", type(obj))

if isinstance(obj, pd.DataFrame):
    df = obj.copy()
else:
    # fallback for unusual pickle contents
    df = pd.DataFrame(obj)

print("Data shape:", df.shape)
print("Columns:", list(df.columns)[:20], "... total", len(df.columns))
print("First rows:")
print(df.head().to_string())

# PSS-10 scoring:
# Items are coded 0..4 in this dataset.
# Positively stated/self-efficacy items (PSS_04, PSS_05, PSS_07, PSS_08) are reverse scored for total PSS.
# Perceived helplessness subscale: PSS_01, PSS_02, PSS_03, PSS_06, PSS_09, PSS_10.
# Perceived self-efficacy subscale: reverse-scored PSS_04, PSS_05, PSS_07, PSS_08.
subject_col = "subject"
helpless_items = ["PSS_01", "PSS_02", "PSS_03", "PSS_06", "PSS_09", "PSS_10"]
selfeff_items = ["PSS_04", "PSS_05", "PSS_07", "PSS_08"]
all_items = helpless_items + selfeff_items

missing = [c for c in [subject_col] + all_items if c not in df.columns]
if missing:
    raise ValueError(f"Missing required columns: {missing}")

pss = df[[subject_col] + all_items].copy()
for c in all_items:
    pss[c] = pd.to_numeric(pss[c], errors="raise")

print("PSS item min/max:")
print(pss[all_items].agg(["min", "max"]).to_string())

# Reverse score positive/self-efficacy items on 0-4 scale: new = 4 - old
helplessness = pss[helpless_items].sum(axis=1)
self_efficacy = (4 - pss[selfeff_items]).sum(axis=1)
total = helplessness + self_efficacy

res = pd.DataFrame({
    "subject": pss[subject_col],
    "perceived_helplessness": helplessness.astype(int),
    "perceived_self_efficacy": self_efficacy.astype(int),
    "total_pss_score": total.astype(int),
})

os.makedirs(os.path.dirname(OUT_PATH), exist_ok=True)
res.to_csv(OUT_PATH, index=False, header=False)

print(f"Saved {len(res)} rows to {OUT_PATH} (header=False).")
print("Result preview:")
print(res.head(10).to_string(index=False))
print("Score summaries:")
print(res[["perceived_helplessness", "perceived_self_efficacy", "total_pss_score"]].describe().to_string())