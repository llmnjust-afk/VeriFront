#!/usr/bin/env python3
import os
import inspect
import pandas as pd

DATA_PATH = "biopsykit_questionnaire_data/questionnaire_data.pkl"
OUT_PATH = "pred_results/questionnaire_pred.csv"

df = pd.read_pickle(DATA_PATH)

print("Inspecting BioPsyKit PSS implementation for scoring convention...")
try:
    from biopsykit.questionnaires import pss
    print("pss module/file:", getattr(pss, "__file__", None))
    public = [x for x in dir(pss) if not x.startswith("_")]
    print("public symbols:", public)
    for name in public:
        obj = getattr(pss, name)
        if callable(obj):
            print(f"\nCallable {name} signature:", end=" ")
            try:
                print(inspect.signature(obj))
            except Exception as e:
                print("signature unavailable", repr(e))
            try:
                src = inspect.getsource(obj)
                print(src[:4000])
            except Exception as e:
                print("source unavailable", repr(e))
except Exception as e:
    print("BioPsyKit inspection failed:", repr(e))

# Compute final output using the standard BioPsyKit/Cohen PSS-10 convention.
subjects = df.index.to_series(index=df.index).astype(str) if "subject" not in df.columns else df["subject"].astype(str)
pss_items = [f"PSS_{i:02d}" for i in range(1, 11)]
pss_df = df[pss_items].apply(pd.to_numeric, errors="raise")

helpless_items = ["PSS_01", "PSS_02", "PSS_03", "PSS_06", "PSS_09", "PSS_10"]
selfeff_items = ["PSS_04", "PSS_05", "PSS_07", "PSS_08"]

# In the scored PSS, self-efficacy/positive items are inverted (0<->4, 1<->3, 2 unchanged).
res = pd.DataFrame({
    "subject": subjects.to_numpy(),
    "perceived_helplessness": pss_df[helpless_items].sum(axis=1).astype(int).to_numpy(),
    "perceived_self_efficacy": (4 - pss_df[selfeff_items]).sum(axis=1).astype(int).to_numpy(),
})
res["total_pss_score"] = res["perceived_helplessness"] + res["perceived_self_efficacy"]

os.makedirs(os.path.dirname(OUT_PATH), exist_ok=True)
res.to_csv(OUT_PATH, index=False, header=False)

print("\nFinal output saved:", OUT_PATH)
print(res.to_string(index=False))
print("\nFile exists:", os.path.exists(OUT_PATH), "size:", os.path.getsize(OUT_PATH))