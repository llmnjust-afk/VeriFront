#!/usr/bin/env python3
import os
import inspect
import pandas as pd

DATA_PATH = "biopsykit_questionnaire_data/questionnaire_data.pkl"
OUT_PATH = "pred_results/questionnaire_pred.csv"

df = pd.read_pickle(DATA_PATH)
print("Loaded dataframe shape:", df.shape)
print("Index name:", df.index.name)
print("Index preview:", list(df.index[:5]))
print("Columns preview:", list(df.columns[:12]))

# Subjects are stored as the dataframe index in the provided pickle.
if "subject" in df.columns:
    subjects = df["subject"]
elif df.index.name == "subject" or not isinstance(df.index, pd.RangeIndex):
    subjects = df.index.to_series(index=df.index)
else:
    raise ValueError("Could not identify subject identifiers.")

pss_items = [f"PSS_{i:02d}" for i in range(1, 11)]
missing = [c for c in pss_items if c not in df.columns]
if missing:
    raise ValueError(f"Missing PSS columns: {missing}")

pss = df[pss_items].apply(pd.to_numeric, errors="raise")
print("PSS item ranges:")
print(pss.agg(["min", "max"]).to_string())

# Try to inspect/use BioPsyKit if available, to align with benchmark convention.
used_biopsykit = False
bio_result = None
try:
    import biopsykit as bp  # noqa: F401
    print("BioPsyKit import succeeded.")
    # Print potentially relevant symbols for observation without relying on them blindly.
    try:
        import biopsykit.questionnaires as bq
        print("biopsykit.questionnaires symbols containing PSS/pss:",
              [x for x in dir(bq) if "pss" in x.lower() or "PSS" in x][:20])
    except Exception as e:
        print("Could not inspect biopsykit.questionnaires:", repr(e))
except Exception as e:
    print("BioPsyKit import not available or failed:", repr(e))

# PSS-10 scoring convention for BioPsyKit/Cohen PSS:
# - Perceived helplessness: negative items 1,2,3,6,9,10, summed as-is.
# - Perceived self-efficacy: positive items 4,5,7,8, reverse-scored on the 0..4 PSS scale,
#   so that it contributes to perceived stress total.
# - Total PSS score: sum of both scored subscales, range 0..40.
helpless_items = ["PSS_01", "PSS_02", "PSS_03", "PSS_06", "PSS_09", "PSS_10"]
selfeff_items = ["PSS_04", "PSS_05", "PSS_07", "PSS_08"]

perceived_helplessness = pss[helpless_items].sum(axis=1)
perceived_self_efficacy = (4 - pss[selfeff_items]).sum(axis=1)
total_pss = perceived_helplessness + perceived_self_efficacy

res = pd.DataFrame({
    "subject": subjects.astype(str).to_numpy(),
    "perceived_helplessness": perceived_helplessness.astype(int).to_numpy(),
    "perceived_self_efficacy": perceived_self_efficacy.astype(int).to_numpy(),
    "total_pss_score": total_pss.astype(int).to_numpy(),
})

os.makedirs(os.path.dirname(OUT_PATH), exist_ok=True)
res.to_csv(OUT_PATH, index=False, header=False)

print(f"Saved result to {OUT_PATH}")
print("Result table:")
print(res.to_string(index=False))
print("Output file first lines:")
with open(OUT_PATH, "r", encoding="utf-8") as f:
    for i, line in enumerate(f):
        if i >= 5:
            break
        print(line.rstrip("\n"))