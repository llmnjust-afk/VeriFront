#!/usr/bin/env python3
import os
import pandas as pd
import numpy as np
import importlib
import pkgutil
import inspect

path = "biopsykit_questionnaire_data/questionnaire_data.pkl"
df = pd.read_pickle(path)

print("Shape:", df.shape)
print("Index name:", df.index.name)
print("Index type:", type(df.index))
print("Index values:", list(df.index))
print("Columns first/last:", list(df.columns[:12]), list(df.columns[-5:]))

pss_cols = [f"PSS_{i:02d}" for i in range(1, 11)]
print("PSS head with index:")
print(df[pss_cols].head(13).to_string())

# Inspect BioPsyKit availability/modules more robustly
try:
    import biopsykit
    print("biopsykit version:", getattr(biopsykit, "__version__", "unknown"))
    hits = []
    for modinfo in pkgutil.walk_packages(biopsykit.__path__, prefix="biopsykit."):
        name = modinfo.name
        if any(tok in name.lower() for tok in ["question", "pss", "score"]):
            hits.append(name)
    print("Potential modules:", hits[:100])
    for name in hits[:30]:
        try:
            mod = importlib.import_module(name)
            attrs = [a for a in dir(mod) if any(tok in a.lower() for tok in ["pss", "perceived", "stress", "questionnaire", "score"])]
            if attrs:
                print("Module", name, "attrs", attrs[:50])
        except Exception as e:
            print("Could not import", name, repr(e))
except Exception as e:
    print("BioPsyKit inspection failed:", repr(e))

# Compute likely PSS scores.
# PSS-10 has perceived helplessness items 1,2,3,6,9,10.
# Perceived self-efficacy items 4,5,7,8 are positively worded; subscale is commonly scored after reversing.
helpless_cols = ["PSS_01", "PSS_02", "PSS_03", "PSS_06", "PSS_09", "PSS_10"]
selfeff_cols = ["PSS_04", "PSS_05", "PSS_07", "PSS_08"]

subjects = df.index.to_series().astype(str)
helpless = df[helpless_cols].sum(axis=1)
selfeff_reversed = (4 - df[selfeff_cols]).sum(axis=1)
selfeff_raw = df[selfeff_cols].sum(axis=1)
total = helpless + selfeff_reversed

out_reversed = pd.DataFrame({
    "subject": subjects.values,
    "perceived_helplessness": helpless.values,
    "perceived_self_efficacy": selfeff_reversed.values,
    "total_pss": total.values,
})
out_raw = pd.DataFrame({
    "subject": subjects.values,
    "perceived_helplessness": helpless.values,
    "perceived_self_efficacy_raw": selfeff_raw.values,
    "total_pss_if_reversed": total.values,
})

print("\nScored candidate (self-efficacy reverse-coded as contribution to stress):")
print(out_reversed.to_string(index=False))
print("\nAlternative raw self-efficacy subscale shown for comparison:")
print(out_raw.to_string(index=False))
print("\nSummary candidate:")
print(out_reversed.iloc[:, 1:].describe().to_string())

# Save candidate output according to required no-header CSV.
os.makedirs("pred_results", exist_ok=True)
out_path = "pred_results/questionnaire_pred.csv"
out_reversed.to_csv(out_path, index=False, header=False)
print("\nSaved:", out_path)
print("File content:")
print(open(out_path, "r", encoding="utf-8").read())