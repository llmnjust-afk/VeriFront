#!/usr/bin/env python3
import os
import pickle
import pandas as pd
import numpy as np

path = "biopsykit_questionnaire_data/questionnaire_data.pkl"
print("CWD:", os.getcwd())
print("Exists:", os.path.exists(path), "size:", os.path.getsize(path) if os.path.exists(path) else None)

# Load the questionnaire data
obj = pd.read_pickle(path)
print("Loaded type:", type(obj))
if isinstance(obj, pd.DataFrame):
    df = obj
else:
    print("Object repr:", repr(obj)[:500])
    raise SystemExit("Expected a pandas DataFrame")

print("Shape:", df.shape)
print("Columns:", list(df.columns)[:20], "... total", len(df.columns))
print("Dtypes first 12:")
print(df.dtypes.head(12))
print("Head PSS:")
print(df[["subject"] + [f"PSS_{i:02d}" for i in range(1, 11)]].head().to_string(index=False))

# Check whether BioPsyKit is available and inspect likely PSS functionality
try:
    import biopsykit
    print("biopsykit available:", getattr(biopsykit, "__version__", "unknown version"))
    import biopsykit.questionnaires as bq
    print("biopsykit.questionnaires attrs containing PSS/Stress:")
    attrs = [a for a in dir(bq) if "PSS" in a.upper() or "STRESS" in a.upper() or "PERCEIVED" in a.upper()]
    print(attrs)
except Exception as e:
    print("BioPsyKit import/inspection failed:", repr(e))

# Compute standard PSS-10 candidate scores for sanity:
# Negative/helplessness items: 1,2,3,6,9,10.
# Positive/self-efficacy items: 4,5,7,8, reverse-scored for total PSS as 4-x.
pss_cols = [f"PSS_{i:02d}" for i in range(1, 11)]
helpless_cols = ["PSS_01", "PSS_02", "PSS_03", "PSS_06", "PSS_09", "PSS_10"]
selfeff_cols = ["PSS_04", "PSS_05", "PSS_07", "PSS_08"]
helpless = df[helpless_cols].sum(axis=1)
selfeff_reversed = (4 - df[selfeff_cols]).sum(axis=1)
total = helpless + selfeff_reversed
candidate = pd.DataFrame({
    "subject": df["subject"],
    "perceived_helplessness": helpless,
    "perceived_self_efficacy_reversed": selfeff_reversed,
    "pss_total": total,
})
print("Candidate scored head:")
print(candidate.head(10).to_string(index=False))
print("Candidate summary:")
print(candidate.iloc[:, 1:].describe().to_string())