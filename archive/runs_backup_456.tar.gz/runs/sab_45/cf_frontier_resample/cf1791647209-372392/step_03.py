#!/usr/bin/env python3
import os
import inspect
import pandas as pd

# Confirm BioPsyKit's exact PSS scoring convention, compare with saved file,
# and rewrite output if needed.
df = pd.read_pickle("biopsykit_questionnaire_data/questionnaire_data.pkl")

try:
    from biopsykit.questionnaires import pss
    print("BioPsyKit pss function:", pss)
    print("Signature:", inspect.signature(pss))
    src = inspect.getsource(pss)
    print("Source of biopsykit.questionnaires.pss:\n", src)
    bp = pss(df)
    print("BioPsyKit pss result type:", type(bp))
    print("BioPsyKit pss result:")
    print(bp.to_string())
except Exception as e:
    print("BioPsyKit pss call/source failed:", repr(e))
    bp = None

# Manual standard scoring:
# Perceived helplessness: PSS 1,2,3,6,9,10 (not reversed)
# Perceived self-efficacy: PSS 4,5,7,8 (positively worded; reverse-coded for stress/PSS total)
helpless_cols = ["PSS_01", "PSS_02", "PSS_03", "PSS_06", "PSS_09", "PSS_10"]
selfeff_cols = ["PSS_04", "PSS_05", "PSS_07", "PSS_08"]

manual = pd.DataFrame(index=df.index)
manual["Perceived Helplessness"] = df[helpless_cols].sum(axis=1)
manual["Perceived Self-Efficacy"] = (4 - df[selfeff_cols]).sum(axis=1)
manual["PSS"] = manual["Perceived Helplessness"] + manual["Perceived Self-Efficacy"]

print("\nManual result:")
print(manual.to_string())

if bp is not None:
    print("\nManual vs BioPsyKit equality checks:")
    # Align possible column names case-insensitively
    print("BioPsyKit columns:", list(bp.columns))
    for col in manual.columns:
        matches = [c for c in bp.columns if c.lower().replace("_", " ").replace("-", " ") == col.lower().replace("_", " ").replace("-", " ")]
        if matches:
            print(col, "matches", matches[0], bool((manual[col] == bp[matches[0]]).all()))
        else:
            print(col, "no direct name match")

# Build required CSV: columns are subject, perceived helplessness,
# perceived self-efficacy, total PSS score; no header.
out = pd.DataFrame({
    "subject": df.index.astype(str),
    "perceived_helplessness": manual["Perceived Helplessness"].astype(int).values,
    "perceived_self_efficacy": manual["Perceived Self-Efficacy"].astype(int).values,
    "total_pss": manual["PSS"].astype(int).values,
})

os.makedirs("pred_results", exist_ok=True)
out_path = "pred_results/questionnaire_pred.csv"
out.to_csv(out_path, index=False, header=False)

print("\nFinal output saved:", out_path)
print("Rows:", len(out), "Columns:", len(out.columns))
print("Final CSV content:")
print(open(out_path, "r", encoding="utf-8").read())