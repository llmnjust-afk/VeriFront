#!/usr/bin/env python3
import os
import pickle
import pandas as pd
import numpy as np

print("Working directory:", os.getcwd())
data_path = "biopsykit_questionnaire_data/questionnaire_data.pkl"
print("Data path exists:", os.path.exists(data_path))

# Load questionnaire data
df = pd.read_pickle(data_path)
print("Loaded type:", type(df))
print("Shape:", df.shape)
print("Columns:", list(df.columns[:15]), "...", list(df.columns[-5:]))
print("Head PSS data:")
print(df[["subject"] + [f"PSS_{i:02d}" for i in range(1, 11)]].head().to_string(index=False))

# Check whether BioPsyKit is available and inspect possible PSS functionality
try:
    import biopsykit
    print("biopsykit version:", getattr(biopsykit, "__version__", "unknown"))
    import biopsykit.questionnaires as bq
    print("biopsykit.questionnaires members containing 'PSS' or 'pss':")
    members = [m for m in dir(bq) if "pss" in m.lower()]
    print(members)
except Exception as e:
    print("Could not import/inspect biopsykit:", repr(e))

# Compute a first candidate using standard PSS-10 scoring:
# helplessness items: 1,2,3,6,9,10 (not reversed)
# self-efficacy items: 4,5,7,8 (positive items reverse-scored: 0<->4, 1<->3, 2 unchanged)
pss_cols = [f"PSS_{i:02d}" for i in range(1, 11)]
helpless_cols = ["PSS_01", "PSS_02", "PSS_03", "PSS_06", "PSS_09", "PSS_10"]
selfeff_cols = ["PSS_04", "PSS_05", "PSS_07", "PSS_08"]

pss = df[["subject"] + pss_cols].copy()
helpless = pss[helpless_cols].sum(axis=1)
selfeff_reversed = (4 - pss[selfeff_cols]).sum(axis=1)
total = helpless + selfeff_reversed

candidate = pd.DataFrame({
    "subject": pss["subject"],
    "perceived_helplessness": helpless,
    "perceived_self_efficacy": selfeff_reversed,
    "total_pss": total,
})
print("Candidate results head:")
print(candidate.head(10).to_string(index=False))
print("Candidate descriptive stats:")
print(candidate[["perceived_helplessness", "perceived_self_efficacy", "total_pss"]].describe().to_string())

# Save provisional result to required location
os.makedirs("pred_results", exist_ok=True)
out_path = "pred_results/questionnaire_pred.csv"
candidate.to_csv(out_path, index=False, header=False)
print("Saved provisional CSV:", out_path)
print("First 5 CSV lines:")
with open(out_path, "r", encoding="utf-8") as f:
    for _ in range(5):
        line = f.readline()
        if not line:
            break
        print(line.rstrip())