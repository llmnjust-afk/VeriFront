#!/usr/bin/env python3
import os
import pandas as pd
import numpy as np

print("Working directory:", os.getcwd())
data_path = "biopsykit_questionnaire_data/questionnaire_data.pkl"
print("Data path exists:", os.path.exists(data_path))

df = pd.read_pickle(data_path)
print("Loaded type:", type(df))
print("Shape:", df.shape)
print("Index name:", df.index.name)
print("Index preview:", list(df.index[:5]))
print("Columns preview:", list(df.columns[:12]), "...")

pss_cols = [f"PSS_{i:02d}" for i in range(1, 11)]
missing = [c for c in pss_cols if c not in df.columns]
print("Missing PSS columns:", missing)
print("PSS data head:")
print(df[pss_cols].head().to_string())

# Inspect BioPsyKit availability/function names, without relying on it.
try:
    import biopsykit
    print("biopsykit version:", getattr(biopsykit, "__version__", "unknown"))
    import biopsykit.questionnaires as bq
    print("biopsykit.questionnaires PSS-like members:", [m for m in dir(bq) if "pss" in m.lower()])
except Exception as e:
    print("BioPsyKit import/inspection failed:", repr(e))

# Standard PSS-10 scoring:
# - Negative/perceived helplessness items: 1, 2, 3, 6, 9, 10 are summed as-is.
# - Positive/perceived self-efficacy items: 4, 5, 7, 8 are reverse scored (0-4 scale -> 4-x) and summed.
# - Total PSS score is the sum of these two subscale scores.
helpless_cols = ["PSS_01", "PSS_02", "PSS_03", "PSS_06", "PSS_09", "PSS_10"]
selfeff_cols = ["PSS_04", "PSS_05", "PSS_07", "PSS_08"]

pss_df = df[pss_cols].apply(pd.to_numeric)
if pss_df.isna().any().any():
    print("WARNING: NaNs detected in PSS items:")
    print(pss_df.isna().sum())

perceived_helplessness = pss_df[helpless_cols].sum(axis=1)
perceived_self_efficacy = (4 - pss_df[selfeff_cols]).sum(axis=1)
total_pss = perceived_helplessness + perceived_self_efficacy

# Subject is stored in the DataFrame index in this dataset.
subjects = df.index.to_series().astype(str).reset_index(drop=True)
result = pd.DataFrame({
    "subject": subjects,
    "perceived_helplessness": perceived_helplessness.reset_index(drop=True).astype(int),
    "perceived_self_efficacy": perceived_self_efficacy.reset_index(drop=True).astype(int),
    "total_pss": total_pss.reset_index(drop=True).astype(int),
})

print("Computed result:")
print(result.to_string(index=False))
print("Summary stats:")
print(result[["perceived_helplessness", "perceived_self_efficacy", "total_pss"]].describe().to_string())

os.makedirs("pred_results", exist_ok=True)
out_path = "pred_results/questionnaire_pred.csv"
result.to_csv(out_path, index=False, header=False)

print("Saved:", out_path)
print("File exists:", os.path.exists(out_path), "size:", os.path.getsize(out_path))
print("CSV content:")
with open(out_path, "r", encoding="utf-8") as f:
    print(f.read())