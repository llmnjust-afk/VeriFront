#!/usr/bin/env python3
import os
import inspect
import pandas as pd

# Set matplotlib cache dir to avoid warnings if BioPsyKit imports matplotlib.
os.environ.setdefault("MPLCONFIGDIR", os.path.abspath(".mplconfig"))
os.makedirs(os.environ["MPLCONFIGDIR"], exist_ok=True)

data_path = "biopsykit_questionnaire_data/questionnaire_data.pkl"
df = pd.read_pickle(data_path)

print("Loaded data shape:", df.shape)
print("Index name:", df.index.name)
print("Subjects:", list(df.index))

# Inspect and run BioPsyKit's PSS implementation if possible to confirm exact subscale definitions.
try:
    from biopsykit.questionnaires import pss
    print("BioPsyKit pss object:", pss)
    print("BioPsyKit pss signature:", inspect.signature(pss))
    try:
        src = inspect.getsource(pss)
        print("BioPsyKit pss source (first 4000 chars):")
        print(src[:4000])
    except Exception as e:
        print("Could not get pss source:", repr(e))

    bp_result = pss(df)
    print("BioPsyKit pss(df) type:", type(bp_result))
    print("BioPsyKit pss(df) result:")
    print(bp_result.to_string() if hasattr(bp_result, "to_string") else bp_result)
except Exception as e:
    print("BioPsyKit pss call failed:", repr(e))
    bp_result = None

# Compute per documented BioPsyKit/PSS-10 convention:
# Perceived helplessness: PSS_01,02,03,06,09,10
# Perceived self-efficacy: reverse-scored PSS_04,05,07,08 (4 - item)
# Total score: sum of both subscales.
pss_cols = [f"PSS_{i:02d}" for i in range(1, 11)]
helpless_cols = ["PSS_01", "PSS_02", "PSS_03", "PSS_06", "PSS_09", "PSS_10"]
selfeff_cols = ["PSS_04", "PSS_05", "PSS_07", "PSS_08"]

pss_items = df[pss_cols].apply(pd.to_numeric)
result = pd.DataFrame(index=df.index)
result["perceived_helplessness"] = pss_items[helpless_cols].sum(axis=1).astype(int)
result["perceived_self_efficacy"] = (4 - pss_items[selfeff_cols]).sum(axis=1).astype(int)
result["total_pss"] = (result["perceived_helplessness"] + result["perceived_self_efficacy"]).astype(int)

print("Our final result:")
print(result.to_string())

# If BioPsyKit returned comparable result, print comparison info.
if bp_result is not None and isinstance(bp_result, pd.DataFrame):
    print("BioPsyKit columns:", list(bp_result.columns))
    print("BioPsyKit index equals data index:", bp_result.index.equals(df.index))
    common = [c for c in result.columns if c in bp_result.columns]
    print("Common columns with our chosen names:", common)
    if common:
        print("Differences on common columns:")
        print((result[common] - bp_result[common]).to_string())

# Save required no-header CSV: subject, perceived helplessness, perceived self-efficacy, total PSS.
out_df = result.reset_index()
# Ensure first column is called subject even if reset_index chooses another name.
out_df.columns = ["subject", "perceived_helplessness", "perceived_self_efficacy", "total_pss"]

os.makedirs("pred_results", exist_ok=True)
out_path = "pred_results/questionnaire_pred.csv"
out_df.to_csv(out_path, index=False, header=False)

print("Saved final output:", out_path)
print("Output file size:", os.path.getsize(out_path))
print("Output CSV:")
with open(out_path, "r", encoding="utf-8") as f:
    print(f.read())