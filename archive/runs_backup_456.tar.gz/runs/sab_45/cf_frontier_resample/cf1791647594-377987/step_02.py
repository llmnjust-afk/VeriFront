#!/usr/bin/env python3
import os
import pandas as pd

# Load data
input_path = "biopsykit_questionnaire_data/questionnaire_data.pkl"
df = pd.read_pickle(input_path)

# In this dataset, subject identifiers are stored as the DataFrame index.
subjects = df.index.to_series().astype(str)

# PSS-10 scoring:
# - Perceived helplessness: items 1, 2, 3, 6, 9, 10
# - Perceived self-efficacy: items 4, 5, 7, 8, reverse scored for stress contribution
# - Total PSS: perceived helplessness + reverse-scored perceived self-efficacy
helplessness_items = ["PSS_01", "PSS_02", "PSS_03", "PSS_06", "PSS_09", "PSS_10"]
selfeff_items = ["PSS_04", "PSS_05", "PSS_07", "PSS_08"]

missing = [c for c in helplessness_items + selfeff_items if c not in df.columns]
if missing:
    raise ValueError(f"Missing required PSS columns: {missing}")

helplessness = df[helplessness_items].sum(axis=1)
self_efficacy_reversed = (4 - df[selfeff_items]).sum(axis=1)
total_pss = helplessness + self_efficacy_reversed

results = pd.DataFrame({
    "subject": subjects.values,
    "perceived_helplessness": helplessness.astype(int).values,
    "perceived_self_efficacy": self_efficacy_reversed.astype(int).values,
    "total_pss": total_pss.astype(int).values,
})

# Save required CSV without header
out_dir = "pred_results"
out_path = os.path.join(out_dir, "questionnaire_pred.csv")
os.makedirs(out_dir, exist_ok=True)
results.to_csv(out_path, index=False, header=False)

print("Saved:", out_path)
print("Rows:", len(results))
print("Columns:", list(results.columns))
print("First rows:")
print(results.head(13).to_string(index=False))
print("Summary:")
print(results[["perceived_helplessness", "perceived_self_efficacy", "total_pss"]].describe().to_string())