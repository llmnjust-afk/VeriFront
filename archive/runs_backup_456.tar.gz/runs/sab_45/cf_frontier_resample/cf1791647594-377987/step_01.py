#!/usr/bin/env python3
import os
import pickle
import pandas as pd

path = "biopsykit_questionnaire_data/questionnaire_data.pkl"
print("cwd:", os.getcwd())
print("exists:", os.path.exists(path), "size:", os.path.getsize(path) if os.path.exists(path) else None)

obj = pd.read_pickle(path)
print("type:", type(obj))
if isinstance(obj, pd.DataFrame):
    df = obj
else:
    print("object repr:", repr(obj)[:1000])
    df = pd.DataFrame(obj)

print("shape:", df.shape)
print("columns:", list(df.columns)[:80])
print("dtypes first 15:", df.dtypes.head(15).to_dict())
print("head:")
print(df.head().to_string())

pss_cols = [f"PSS_{i:02d}" for i in range(1, 11)]
print("PSS cols present:", all(c in df.columns for c in pss_cols))
print("PSS unique values:")
for c in pss_cols:
    print(c, sorted(df[c].dropna().unique().tolist()))

# Compute candidate PSS scoring for inspection.
neg = ["PSS_01", "PSS_02", "PSS_03", "PSS_06", "PSS_09", "PSS_10"]
pos = ["PSS_04", "PSS_05", "PSS_07", "PSS_08"]
cand = pd.DataFrame({"subject": df["subject"]})
cand["helplessness_raw_neg"] = df[neg].sum(axis=1)
cand["selfeff_raw_pos"] = df[pos].sum(axis=1)
cand["selfeff_reversed_pos"] = (4 - df[pos]).sum(axis=1)
cand["total_rawneg_revpos"] = cand["helplessness_raw_neg"] + cand["selfeff_reversed_pos"]
cand["total_all_raw"] = df[pss_cols].sum(axis=1)
print("candidate head:")
print(cand.head(10).to_string(index=False))
print("candidate describe:")
print(cand.drop(columns=["subject"]).describe().to_string())