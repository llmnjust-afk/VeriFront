#!/usr/bin/env python3
import os
from pathlib import Path
import numpy as np
import pandas as pd
import netCDF4

infile = Path("polynomial_fit/A1B_north_america.nc")
outdir = Path("pred_results")
outfile = outdir / "polynomial_fit_pred.csv"
outdir.mkdir(parents=True, exist_ok=True)

with netCDF4.Dataset(infile, "r") as ds:
    temp_var = ds.variables["air_temperature"]
    temps = temp_var[:]
    temps = np.ma.filled(temps, np.nan).astype(float)

    # Extract a single temperature time series for North America by spatially
    # averaging the gridded air_temperature field at each time step.
    temp_ts = np.nanmean(temps, axis=(1, 2))

    time_var = ds.variables["time"]
    time_vals = time_var[:]
    units = getattr(time_var, "units", "hours since 1970-01-01 00:00:00")
    calendar = getattr(time_var, "calendar", "standard")
    dates = netCDF4.num2date(time_vals, units=units, calendar=calendar)
    years = np.array([int(d.year) for d in dates], dtype=int)

# In this file there is one time slice per year. If a future variant contains
# multiple slices in a year, aggregate to annual mean before fitting.
unique_years = np.array(sorted(np.unique(years)), dtype=int)
annual_temp = np.array([np.nanmean(temp_ts[years == y]) for y in unique_years], dtype=float)

valid = np.isfinite(annual_temp)
fit_years = unique_years[valid].astype(float)
fit_temp = annual_temp[valid]

# Use a numerically stable x coordinate for fitting, while predicting for every year.
year0 = float(fit_years[0])
x_fit = fit_years - year0
coeff = np.polyfit(x_fit, fit_temp, deg=2)
pred_temp = np.polyval(coeff, unique_years.astype(float) - year0)

df = pd.DataFrame({
    "year": unique_years,
    "temperature": annual_temp,
    "predicted_temperature": pred_temp,
})
df.to_csv(outfile, index=False)

print(f"Loaded: {infile}")
print(f"air_temperature spatial-mean annual series length: {len(unique_years)}")
print(f"Year range: {unique_years[0]}-{unique_years[-1]}")
print("Quadratic fit used x = year - %.0f" % year0)
print("Coefficients [a, b, c]:", coeff)
rmse = float(np.sqrt(np.nanmean((annual_temp - pred_temp) ** 2)))
print("Fit RMSE:", rmse)
print(f"Saved: {outfile}")
print("First 5 output rows:")
print(df.head().to_string(index=False))
print("Last 5 output rows:")
print(df.tail().to_string(index=False))