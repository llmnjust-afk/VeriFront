#!/usr/bin/env python3
import os
from pathlib import Path

print("Working directory:", os.getcwd())
path = Path("polynomial_fit/A1B_north_america.nc")
print("Dataset exists:", path.exists(), "size:", path.stat().st_size if path.exists() else None)

# Inspect available NetCDF readers and dataset structure.
try:
    import netCDF4
    print("netCDF4 available")
    ds = netCDF4.Dataset(path, "r")
    print("Dimensions:")
    for k, v in ds.dimensions.items():
        print(f"  {k}: size={len(v)} unlimited={v.isunlimited()}")
    print("Variables:")
    for k, v in ds.variables.items():
        attrs = {a: getattr(v, a) for a in v.ncattrs()}
        print(f"  {k}: dimensions={v.dimensions}, shape={v.shape}, dtype={v.dtype}")
        print(f"    attrs={attrs}")
        try:
            data = v[:]
            import numpy as np
            arr = np.asarray(data)
            print(f"    sample min/max/mean: {np.nanmin(arr):.6g} / {np.nanmax(arr):.6g} / {np.nanmean(arr):.6g}")
            print(f"    first values: {arr.ravel()[:10]}")
        except Exception as e:
            print(f"    could not read sample: {e}")
    ds.close()
except Exception as e:
    print("netCDF4 inspection failed:", repr(e))
    try:
        import scipy.io.netcdf as netcdf
        print("scipy.io.netcdf available")
        ds = netcdf.netcdf_file(str(path), "r", mmap=False)
        print("Dimensions:", ds.dimensions)
        print("Variables:")
        for k, v in ds.variables.items():
            print(f"  {k}: dimensions={v.dimensions}, shape={v.data.shape}, dtype={v.data.dtype}")
            print(f"    attrs={getattr(v, '_attributes', {})}")
            import numpy as np
            arr = np.asarray(v.data)
            print(f"    sample min/max/mean: {np.nanmin(arr):.6g} / {np.nanmax(arr):.6g} / {np.nanmean(arr):.6g}")
            print(f"    first values: {arr.ravel()[:10]}")
        ds.close()
    except Exception as e2:
        print("scipy inspection failed:", repr(e2))