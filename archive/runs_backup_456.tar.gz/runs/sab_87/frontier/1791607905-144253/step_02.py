#!/usr/bin/env python3
"""
Locate the provided NetCDF file in the working tree, then inspect its structure.
The task path says polynomial_fit/A1B_north_america.nc, but the first run
showed only benchmark/ and pred_results/, so we search known local folders.
"""
import os
import sys
import glob
import numpy as np

print(f"Working directory: {os.getcwd()}")

candidates = []
for pattern in [
    "polynomial_fit/A1B_north_america.nc",
    "benchmark/polynomial_fit/A1B_north_america.nc",
    "**/A1B_north_america.nc",
    "**/*.nc",
]:
    found = glob.glob(pattern, recursive=True)
    print(f"Pattern {pattern!r}: {found[:20]}{' ...' if len(found) > 20 else ''}")
    candidates.extend(found)

# preserve order, unique
seen = set()
candidates = [p for p in candidates if not (p in seen or seen.add(p))]
if not candidates:
    print("No NetCDF candidates found. Directory tree (limited):")
    for root, dirs, files in os.walk("."):
        level = root.count(os.sep)
        if level > 5:
            continue
        indent = "  " * level
        print(f"{indent}{os.path.basename(root)}/")
        for f in files[:20]:
            print(f"{indent}  {f}")
    sys.exit(1)

path = candidates[0]
print(f"\nUsing dataset: {path}")

reader_used = None
ds = None
try:
    import netCDF4
    ds = netCDF4.Dataset(path, "r")
    reader_used = "netCDF4"
except Exception as e:
    print(f"netCDF4 failed/unavailable: {repr(e)}")
    try:
        from scipy.io import netcdf_file
        ds = netcdf_file(path, "r", mmap=False)
        reader_used = "scipy.io.netcdf_file"
    except Exception as e2:
        print(f"scipy.io.netcdf_file failed/unavailable: {repr(e2)}")
        sys.exit(1)

print(f"Reader used: {reader_used}")

print("\nDimensions:")
for name, dim in ds.dimensions.items():
    try:
        size = len(dim)
    except TypeError:
        size = int(dim)
    try:
        unlimited = dim.isunlimited()
    except Exception:
        unlimited = False
    print(f"  {name}: size={size}, unlimited={unlimited}")

print("\nGlobal attributes:")
try:
    attrs = ds.ncattrs() if hasattr(ds, "ncattrs") else []
    for a in attrs:
        print(f"  {a}: {getattr(ds, a)}")
except Exception as e:
    print(f"  Could not list global attributes: {repr(e)}")

print("\nVariables:")
for name, var in ds.variables.items():
    print(f"  {name}:")
    print(f"    dimensions: {getattr(var, 'dimensions', None)}")
    print(f"    shape: {getattr(var, 'shape', None)}")
    print(f"    dtype: {getattr(var, 'dtype', None)}")
    try:
        vattrs = var.ncattrs() if hasattr(var, "ncattrs") else []
        for a in vattrs:
            print(f"    attr {a}: {getattr(var, a)}")
    except Exception as e:
        print(f"    attrs unavailable: {repr(e)}")
    try:
        arr = np.asarray(var[:])
        flat = arr.ravel()
        print(f"    sample first 8: {flat[:8]}")
        if np.issubdtype(arr.dtype, np.number):
            finite = flat[np.isfinite(flat)]
            if finite.size:
                print(f"    numeric min/mean/max: {np.nanmin(arr):.6g} / {np.nanmean(arr):.6g} / {np.nanmax(arr):.6g}")
    except Exception as e:
        print(f"    sample unavailable: {repr(e)}")

try:
    ds.close()
except Exception:
    pass

# Persist located path for next step.
with open("dataset_path.txt", "w", encoding="utf-8") as f:
    f.write(path + "\n")
print("\nInspection complete. Saved dataset_path.txt.")