#!/usr/bin/env python3
"""
First inspection pass: examine the NetCDF structure, dimensions, variables,
attributes, and a small sample of the temperature data so we can implement
the required quadratic polynomial fit correctly in the next step.
"""
import os
import sys
import json
import numpy as np

path = "polynomial_fit/A1B_north_america.nc"
print(f"Working directory: {os.getcwd()}")
print(f"Looking for dataset: {path}")
print(f"Exists: {os.path.exists(path)}")
if not os.path.exists(path):
    print("Dataset not found; listing current directory:")
    for root, dirs, files in os.walk("."):
        level = root.count(os.sep)
        if level > 3:
            continue
        indent = "  " * level
        print(f"{indent}{os.path.basename(root)}/")
        for f in files[:10]:
            print(f"{indent}  {f}")
    sys.exit(1)

# Try available NetCDF readers.
reader_used = None
ds = None
try:
    import netCDF4
    ds = netCDF4.Dataset(path, "r")
    reader_used = "netCDF4"
except Exception as e:
    print(f"netCDF4 failed/unavailable: {repr(e)}")
    try:
        from scipy.io import netcdf_file
        ds = netcdf_file(path, "r", mmap=False)
        reader_used = "scipy.io.netcdf_file"
    except Exception as e2:
        print(f"scipy.io.netcdf_file failed/unavailable: {repr(e2)}")
        sys.exit(1)

print(f"Reader used: {reader_used}")

print("\nDimensions:")
try:
    for name, dim in ds.dimensions.items():
        try:
            size = len(dim)
        except TypeError:
            size = int(dim)
        unlimited = getattr(dim, "isunlimited", lambda: False)()
        print(f"  {name}: size={size}, unlimited={unlimited}")
except Exception as e:
    print(f"  Could not list dimensions: {repr(e)}")

print("\nGlobal attributes:")
try:
    attrs = ds.ncattrs() if hasattr(ds, "ncattrs") else []
    for a in attrs:
        print(f"  {a}: {getattr(ds, a)}")
except Exception as e:
    print(f"  Could not list global attributes: {repr(e)}")

print("\nVariables:")
variables = ds.variables
for name, var in variables.items():
    print(f"  {name}:")
    print(f"    dimensions: {getattr(var, 'dimensions', None)}")
    print(f"    shape: {getattr(var, 'shape', None)}")
    print(f"    dtype: {getattr(var, 'dtype', None)}")
    # attrs
    try:
        vattrs = var.ncattrs() if hasattr(var, "ncattrs") else []
        for a in vattrs:
            print(f"    attr {a}: {getattr(var, a)}")
    except Exception as e:
        print(f"    attrs unavailable: {repr(e)}")
    # sample
    try:
        arr = var[:]
        arr_np = np.asarray(arr)
        flat = arr_np.ravel()
        sample = flat[:8]
        finite = flat[np.isfinite(flat)] if np.issubdtype(arr_np.dtype, np.number) else flat
        print(f"    sample first 8: {sample}")
        if np.issubdtype(arr_np.dtype, np.number) and finite.size:
            print(f"    numeric min/mean/max: {np.nanmin(arr_np):.6g} / {np.nanmean(arr_np):.6g} / {np.nanmax(arr_np):.6g}")
    except Exception as e:
        print(f"    sample unavailable: {repr(e)}")

try:
    ds.close()
except Exception:
    pass

print("\nInspection complete.")