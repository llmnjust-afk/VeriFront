#!/usr/bin/env python3
"""
Second pass: inspect time decoding and look for benchmark hints/examples, then
compute annual spatial-mean temperature and quadratic polynomial fit preview.
"""
import os
import glob
import json
import numpy as np
import pandas as pd

path = open("dataset_path.txt", "r", encoding="utf-8").read().strip()
print(f"Dataset path: {path}")

# Look for any task-specific files or prior examples that reveal expected CSV format.
print("\nNearby benchmark files:")
for p in glob.glob("benchmark/**/*polynomial*", recursive=True)[:50]:
    print(" ", p)
print("\nExisting pred_results:")
print(os.listdir("pred_results") if os.path.exists("pred_results") else "no pred_results")

import netCDF4
ds = netCDF4.Dataset(path, "r")
time_var = ds.variables["time"]
time = np.asarray(time_var[:], dtype=float)
units = getattr(time_var, "units", "")
calendar = getattr(time_var, "calendar", "standard")
print(f"\nTime units={units!r}, calendar={calendar!r}")
print("First/last time raw:", time[:5], time[-5:])

try:
    dates = netCDF4.num2date(time, units=units, calendar=calendar, only_use_cftime_datetimes=False, only_use_python_datetimes=False)
    print("Decoded first 8 dates:", [str(d) for d in dates[:8]])
    print("Decoded last 8 dates:", [str(d) for d in dates[-8:]])
    years = np.array([int(d.year) for d in dates], dtype=int)
except Exception as e:
    print("num2date failed:", repr(e))
    # 360-day calendar fallback: integer day count from 1970-01-01.
    days = np.floor(time / 24.0).astype(int)
    years = 1970 + np.floor_divide(days, 360)

temp = np.asarray(ds.variables["air_temperature"][:], dtype=float)
# Account for possible missing values/fill values.
var = ds.variables["air_temperature"]
for attr in ["_FillValue", "missing_value"]:
    if hasattr(var, attr):
        fill = float(getattr(var, attr))
        temp = np.where(temp == fill, np.nan, temp)
ds.close()

spatial_mean = np.nanmean(temp, axis=(1, 2))
print("\nSpatial monthly mean sample K:", spatial_mean[:8])
print("Spatial monthly mean min/mean/max K:", float(np.nanmin(spatial_mean)), float(np.nanmean(spatial_mean)), float(np.nanmax(spatial_mean)))
print("Year counts:", {int(y): int(np.sum(years == y)) for y in np.unique(years)[:10]}, "...", {int(y): int(np.sum(years == y)) for y in np.unique(years)[-5:]})

annual = pd.DataFrame({"year": years, "temperature": spatial_mean}).groupby("year", as_index=False)["temperature"].mean()
x = annual["year"].to_numpy(dtype=float)
y = annual["temperature"].to_numpy(dtype=float)
coef = np.polyfit(x, y, 2)
pred = np.polyval(coef, x)
annual["polyfit_temperature"] = pred
annual["residual"] = y - pred

print("\nAnnual rows:", len(annual))
print("Annual head:")
print(annual.head(10).to_string(index=False))
print("Annual tail:")
print(annual.tail(10).to_string(index=False))
print("Quadratic coefficients [a,b,c] for a*year^2+b*year+c:")
print(coef)
print("Fit RMSE:", float(np.sqrt(np.mean((y - pred) ** 2))))

# Save a preview artifact for transparency; final required file will be written next.
annual.to_csv("polynomial_fit_annual_preview.csv", index=False)
print("\nSaved preview: polynomial_fit_annual_preview.csv")