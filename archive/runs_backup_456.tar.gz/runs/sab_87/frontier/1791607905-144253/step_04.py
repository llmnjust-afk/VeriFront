#!/usr/bin/env python3
"""
Create the required polynomial fitting prediction CSV.

Method:
1. Read air_temperature(time, latitude, longitude) from the NetCDF file.
2. Decode CF/360_day time coordinates to calendar years.
3. Collapse each time slice to a North America spatial mean temperature.
4. Aggregate by year (this file has one sample per year, but grouping makes the
   output explicitly "by year").
5. Fit a quadratic polynomial with numpy.polyfit(year, temperature, deg=2).
6. Evaluate fitted values with numpy.polyval and save to:
   pred_results/polynomial_fit_pred.csv
"""
import os
import glob
import numpy as np
import pandas as pd
import netCDF4

# Locate dataset robustly.
candidates = [
    "polynomial_fit/A1B_north_america.nc",
    "benchmark/datasets/polynomial_fit/A1B_north_america.nc",
]
if os.path.exists("dataset_path.txt"):
    with open("dataset_path.txt", "r", encoding="utf-8") as f:
        candidates.insert(0, f.read().strip())
path = next((p for p in candidates if p and os.path.exists(p)), None)
if path is None:
    found = glob.glob("**/A1B_north_america.nc", recursive=True)
    if found:
        path = found[0]
if path is None:
    raise FileNotFoundError("Could not find A1B_north_america.nc")

print(f"Reading: {path}")
with netCDF4.Dataset(path, "r") as ds:
    tvar = ds.variables["time"]
    raw_time = np.asarray(tvar[:], dtype=float)
    units = getattr(tvar, "units")
    calendar = getattr(tvar, "calendar", "standard")
    dates = netCDF4.num2date(
        raw_time,
        units=units,
        calendar=calendar,
        only_use_cftime_datetimes=False,
        only_use_python_datetimes=False,
    )
    years = np.asarray([int(d.year) for d in dates], dtype=int)

    temp_var = ds.variables["air_temperature"]
    temp = np.asarray(temp_var[:], dtype=float)
    for attr in ("_FillValue", "missing_value"):
        if hasattr(temp_var, attr):
            fill_value = float(getattr(temp_var, attr))
            temp = np.where(temp == fill_value, np.nan, temp)

# Mean temperature time series over all latitude/longitude grid cells.
temperature_ts = np.nanmean(temp, axis=(1, 2))

annual = (
    pd.DataFrame({"year": years, "temperature": temperature_ts})
    .groupby("year", as_index=False)["temperature"]
    .mean()
    .sort_values("year")
)

x = annual["year"].to_numpy(dtype=float)
y = annual["temperature"].to_numpy(dtype=float)
coefficients = np.polyfit(x, y, 2)
fitted = np.polyval(coefficients, x)

# Required output: fitting results by year.
out = pd.DataFrame(
    {
        "year": annual["year"].astype(int),
        "temperature": y,
        "fitted_temperature": fitted,
    }
)

os.makedirs("pred_results", exist_ok=True)
out_path = "pred_results/polynomial_fit_pred.csv"
out.to_csv(out_path, index=False, float_format="%.10f")

rmse = float(np.sqrt(np.mean((y - fitted) ** 2)))
print(f"Rows written: {len(out)}")
print(f"Year range: {int(out['year'].min())}-{int(out['year'].max())}")
print("Quadratic coefficients [a, b, c] for a*year^2 + b*year + c:")
print(coefficients)
print(f"RMSE: {rmse:.10f}")
print(f"Saved: {out_path}")
print("\nOutput head:")
print(out.head().to_string(index=False))
print("\nOutput tail:")
print(out.tail().to_string(index=False))