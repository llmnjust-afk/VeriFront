#!/usr/bin/env python3
import os
from pathlib import Path

print("Working directory:", os.getcwd())
path = Path("polynomial_fit/A1B_north_america.nc")
print("Dataset exists:", path.exists(), "size:", path.stat().st_size if path.exists() else None)

# Try to inspect the NetCDF file with available libraries.
try:
    import xarray as xr
    print("xarray version:", xr.__version__)
    ds = xr.open_dataset(path)
    print("Dataset summary:")
    print(ds)
    print("\nVariables and attributes:")
    for name in ds.variables:
        var = ds[name]
        print(f"\n{name}: dims={var.dims}, shape={var.shape}, dtype={var.dtype}")
        print("attrs:", dict(var.attrs))
        try:
            vals = var.values
            import numpy as np
            flat = vals.ravel()
            finite = flat[np.isfinite(flat)] if np.issubdtype(vals.dtype, np.number) else flat[:10]
            print("first values:", flat[:10])
            if np.issubdtype(vals.dtype, np.number) and finite.size:
                print("min/max:", float(np.nanmin(vals)), float(np.nanmax(vals)))
        except Exception as e:
            print("Could not read values:", repr(e))
    ds.close()
except Exception as e:
    print("xarray inspection failed:", repr(e))
    try:
        from netCDF4 import Dataset
        print("netCDF4 available")
        nc = Dataset(path)
        print(nc)
        for name, var in nc.variables.items():
            print(f"\n{name}: dimensions={var.dimensions}, shape={var.shape}, dtype={var.dtype}")
            print("attrs:", {a: getattr(var, a) for a in var.ncattrs()})
            try:
                print("first values:", var[:].ravel()[:10])
            except Exception as ee:
                print("Could not read values:", repr(ee))
        nc.close()
    except Exception as e2:
        print("netCDF4 inspection failed:", repr(e2))