#!/usr/bin/env python3
"""
Load North America climate NetCDF, extract the spatially averaged air-temperature
time series, fit a quadratic polynomial versus year, and save yearly fitted
results to pred_results/polynomial_fit_pred.csv.
"""
from pathlib import Path
import numpy as np
import pandas as pd
import xarray as xr

input_path = Path("polynomial_fit/A1B_north_america.nc")
output_dir = Path("pred_results")
output_path = output_dir / "polynomial_fit_pred.csv"

if not input_path.exists():
    raise FileNotFoundError(f"Required input file not found: {input_path}")

# Open dataset and extract annual time coordinate and air-temperature series.
with xr.open_dataset(input_path) as ds:
    if "air_temperature" not in ds:
        raise KeyError("Variable 'air_temperature' not found in NetCDF file.")
    if "time" not in ds:
        raise KeyError("Coordinate 'time' not found in NetCDF file.")

    air = ds["air_temperature"]

    # Convert gridded temperature field into a single time series by averaging
    # over all non-time dimensions, ignoring missing values if present.
    non_time_dims = [dim for dim in air.dims if dim != "time"]
    temp_mean = air.mean(dim=non_time_dims, skipna=True).values.astype(float)

    # cftime objects expose .year; this is robust for the 360-day calendar here.
    times = ds["time"].values
    years = np.array([int(t.year) if hasattr(t, "year") else pd.Timestamp(t).year for t in times], dtype=float)

# Validate finite data for fitting.
mask = np.isfinite(years) & np.isfinite(temp_mean)
if mask.sum() < 3:
    raise ValueError(f"Need at least 3 finite points for quadratic fit; found {mask.sum()}.")

fit_years = years[mask]
fit_temps = temp_mean[mask]

# Quadratic polynomial fit: temperature = a*year^2 + b*year + c.
coefficients = np.polyfit(fit_years, fit_temps, deg=2)
predicted = np.polyval(coefficients, years)

# Save fitting results by year.
output_dir.mkdir(parents=True, exist_ok=True)
result = pd.DataFrame({
    "year": years.astype(int),
    "air_temperature_mean_K": temp_mean,
    "quadratic_fit_temperature_K": predicted,
})
result.to_csv(output_path, index=False)

# Print useful verification information.
print(f"Loaded: {input_path}")
print(f"Temperature variable reduced over dimensions: {non_time_dims}")
print(f"Number of yearly records: {len(result)}")
print(f"Year range: {int(np.nanmin(years))} to {int(np.nanmax(years))}")
print("Quadratic coefficients [a, b, c] for a*year^2 + b*year + c:")
print(coefficients)
rmse = float(np.sqrt(np.nanmean((temp_mean - predicted) ** 2)))
print(f"Fit RMSE (K): {rmse:.6f}")
print(f"Saved CSV: {output_path}")
print("First 5 rows:")
print(result.head().to_string(index=False))
print("Last 5 rows:")
print(result.tail().to_string(index=False))