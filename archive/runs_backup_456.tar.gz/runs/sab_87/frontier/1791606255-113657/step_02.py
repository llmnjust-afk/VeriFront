#!/usr/bin/env python3
import os
from pathlib import Path

print("Working directory:", os.getcwd())
print("Top-level entries:")
for p in sorted(Path(".").iterdir()):
    try:
        print(("DIR " if p.is_dir() else "FILE"), p, "size" if p.is_file() else "", p.stat().st_size if p.is_file() else "")
    except Exception as e:
        print("ERR", p, repr(e))

print("\nSearching for .nc files under working directory and nearby common roots...")
roots = [Path("."), Path("/data/lab/VeriFront"), Path("/data")]
seen = set()
for root in roots:
    if not root.exists() or str(root.resolve()) in seen:
        continue
    seen.add(str(root.resolve()))
    print(f"\nRoot: {root}")
    count = 0
    try:
        for p in root.rglob("*.nc"):
            count += 1
            try:
                print(" ", p, "size", p.stat().st_size)
            except Exception:
                print(" ", p)
            if count >= 50:
                print("  ... stopping at 50")
                break
    except Exception as e:
        print("  search failed:", repr(e))
    print("  count shown:", count)

print("\nSearching for polynomial_fit directories...")
for root in roots:
    if not root.exists():
        continue
    count = 0
    try:
        for p in root.rglob("polynomial_fit"):
            count += 1
            print(" ", p, "is_dir", p.is_dir())
            if p.is_dir():
                try:
                    print("   contents:", [str(x) for x in p.iterdir()])
                except Exception as e:
                    print("   contents failed:", repr(e))
            if count >= 20:
                break
    except Exception as e:
        print("  search failed in", root, repr(e))