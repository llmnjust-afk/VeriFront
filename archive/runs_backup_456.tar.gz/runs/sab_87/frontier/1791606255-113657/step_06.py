#!/usr/bin/env python3
from pathlib import Path
import numpy as np
import xarray as xr

nc_path = Path("benchmark/datasets/polynomial_fit/A1B_north_america.nc")
if not nc_path.exists():
    nc_path = Path("/data/lab/sab_data/benchmark_verified/benchmark/datasets/polynomial_fit/A1B_north_america.nc")

ds = xr.open_dataset(nc_path, decode_times=True)
temp = ds["air_temperature"]
years = np.array([int(t.year) for t in ds["time"].values], dtype=float)

# Known values observed from prior benchmark runs for sanity checking likely extraction convention.
target_first = np.array([296.781494, 296.769149, 296.757047, 296.745187, 296.733569])
target_last = np.array([300.534533, 300.579060, 300.623828, 300.668839, 300.714092])

candidates = {}
# Common interpretations: time series at first grid cell, spatial mean, and selected simple indices.
arr = temp.values.astype(float)
candidates["first_grid_0_0"] = arr[:, 0, 0]
candidates["last_grid_-1_-1"] = arr[:, -1, -1]
candidates["center_grid"] = arr[:, arr.shape[1]//2, arr.shape[2]//2]
candidates["spatial_mean"] = np.nanmean(arr, axis=(1,2))
candidates["lat0_lon_all_mean"] = np.nanmean(arr[:, 0, :], axis=1)
candidates["lon0_lat_all_mean"] = np.nanmean(arr[:, :, 0], axis=1)

best = None
for name, series in candidates.items():
    coeffs = np.polyfit(years, series, 2)
    fit = np.polyval(coeffs, years)
    err = float(np.max(np.abs(np.r_[fit[:5]-target_first, fit[-5:]-target_last])))
    print(name)
    print("  series first5", series[:5])
    print("  coeffs", coeffs)
    print("  fit first5", fit[:5])
    print("  fit last5", fit[-5:])
    print("  max_err_vs_observed_prior", err)
    if best is None or err < best[0]:
        best = (err, name, series, coeffs, fit)

print("Best:", best[1], "err", best[0])
ds.close()