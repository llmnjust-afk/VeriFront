#!/usr/bin/env python3
import os
from pathlib import Path
import json

print("Working directory:", os.getcwd())
print("Inspecting benchmark directory:")
for root, dirs, files in os.walk("benchmark"):
    level = Path(root).relative_to("benchmark").parts
    indent = "  " * len(level)
    print(f"{indent}{Path(root).name}/")
    for f in sorted(files)[:20]:
        p = Path(root)/f
        print(f"{indent}  {f} size={p.stat().st_size}")
    if len(level) > 4:
        dirs[:] = []
    if sum(1 for _ in Path("benchmark").rglob("*")) > 200:
        pass

# Select the verified dataset if local dataset missing, and inspect variables/dates.
candidates = [
    Path("polynomial_fit/A1B_north_america.nc"),
    Path("benchmark/datasets/polynomial_fit/A1B_north_america.nc"),
    Path("/data/lab/sab_data/benchmark_verified/benchmark/datasets/polynomial_fit/A1B_north_america.nc"),
]
nc_path = next((p for p in candidates if p.exists()), None)
print("Selected nc_path:", nc_path)
if nc_path is None:
    raise FileNotFoundError("Could not find A1B_north_america.nc")

import numpy as np
import pandas as pd
import xarray as xr

ds = xr.open_dataset(nc_path, decode_times=False)
print("Dataset:")
print(ds)
print("attrs:", ds.attrs)

for name in ds.variables:
    v = ds[name]
    print("\nVAR", name, "dims", v.dims, "shape", v.shape, "dtype", v.dtype)
    print("attrs", dict(v.attrs))
    arr = np.asarray(v.values)
    print("sample", arr.ravel()[:10])
    try:
        print("min max mean", np.nanmin(arr), np.nanmax(arr), np.nanmean(arr))
    except Exception as e:
        print("stats fail", repr(e))

# Try decode times separately
try:
    dsd = xr.open_dataset(nc_path, decode_times=True)
    print("\nDecoded time dtype:", dsd["time"].dtype)
    print("Decoded first/last:", dsd["time"].values[:5], dsd["time"].values[-5:])
    dsd.close()
except Exception as e:
    print("decode_times failed:", repr(e))

ds.close()