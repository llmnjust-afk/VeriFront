#!/usr/bin/env python3
import os
import sys
import json
from pathlib import Path

print("Working directory:", os.getcwd())
nc_path = Path("polynomial_fit/A1B_north_america.nc")
print("NetCDF exists:", nc_path.exists(), "path:", nc_path)
if nc_path.exists():
    print("File size bytes:", nc_path.stat().st_size)

# Try available libraries and inspect dataset structure.
errors = {}
try:
    import xarray as xr
    print("xarray version:", xr.__version__)
    ds = xr.open_dataset(nc_path)
    print("Opened with xarray.")
    print("Dataset summary:")
    print(ds)
    print("Variables:", list(ds.variables))
    for name in ds.variables:
        var = ds[name]
        print(f"\nVariable: {name}")
        print("  dims:", var.dims)
        print("  shape:", var.shape)
        print("  dtype:", var.dtype)
        print("  attrs:", dict(var.attrs))
        try:
            vals = var.values
            import numpy as np
            flat = np.asarray(vals).ravel()
            print("  first values:", flat[:8])
            print("  finite min/max:", np.nanmin(flat), np.nanmax(flat))
        except Exception as e:
            print("  value preview failed:", repr(e))
    ds.close()
except Exception as e:
    errors["xarray"] = repr(e)
    print("xarray inspection failed:", repr(e))

try:
    import netCDF4
    print("netCDF4 version:", netCDF4.__version__)
    nc = netCDF4.Dataset(str(nc_path), "r")
    print("Opened with netCDF4.")
    print("Dimensions:")
    for k, v in nc.dimensions.items():
        print(" ", k, len(v), "unlimited=", v.isunlimited())
    print("Variables:")
    for k, v in nc.variables.items():
        print(" ", k, "dims=", v.dimensions, "shape=", v.shape, "dtype=", v.dtype)
        print("    attrs=", {a: getattr(v, a) for a in v.ncattrs()})
    nc.close()
except Exception as e:
    errors["netCDF4"] = repr(e)
    print("netCDF4 inspection failed:", repr(e))

print("Errors:", json.dumps(errors, indent=2))