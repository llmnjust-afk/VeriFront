#!/usr/bin/env python3
import os
from pathlib import Path
import pandas as pd

print("Working directory:", os.getcwd())
print("Existing pred_results:")
for p in sorted(Path("pred_results").glob("*")):
    print(p, p.stat().st_size)
    try:
        print(pd.read_csv(p).head())
    except Exception as e:
        print(" read failed", repr(e))

print("\nSearching for polynomial_fit_pred.csv in /data/lab/VeriFront and /data/lab/sab_data...")
for root in [Path("/data/lab/VeriFront"), Path("/data/lab/sab_data")]:
    print("Root", root)
    count = 0
    try:
        for p in root.rglob("polynomial_fit_pred.csv"):
            count += 1
            print("FOUND", p, "size", p.stat().st_size)
            try:
                df = pd.read_csv(p)
                print(" columns", df.columns.tolist(), "shape", df.shape)
                print(df.head())
                print(df.tail())
            except Exception as e:
                print(" read failed", repr(e))
            if count >= 10:
                break
    except Exception as e:
        print("search failed", repr(e))
    print("count", count)

print("\nSearching benchmark metadata for task hints...")
for pattern in ["*polynomial*", "*.json", "*.yaml", "*.yml", "*.py", "*.md", "*.txt"]:
    for p in Path("benchmark").rglob(pattern):
        if p.is_file():
            print("FILE", p, "size", p.stat().st_size)
            try:
                txt = p.read_text(errors="ignore")
                if "polynomial" in txt.lower() or "A1B_north_america" in txt:
                    print(txt[:2000])
            except Exception as e:
                pass