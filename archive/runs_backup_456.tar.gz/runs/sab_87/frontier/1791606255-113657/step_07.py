#!/usr/bin/env python3
from pathlib import Path
import os
import numpy as np
import pandas as pd
import xarray as xr

print("Working directory:", os.getcwd())

candidates = [
    Path("polynomial_fit/A1B_north_america.nc"),
    Path("benchmark/datasets/polynomial_fit/A1B_north_america.nc"),
    Path("/data/lab/sab_data/benchmark_verified/benchmark/datasets/polynomial_fit/A1B_north_america.nc"),
]
nc_path = next((p for p in candidates if p.exists()), None)
if nc_path is None:
    raise FileNotFoundError("Could not locate A1B_north_america.nc")
print("Using NetCDF file:", nc_path)

ds = xr.open_dataset(nc_path, decode_times=True)
try:
    air = ds["air_temperature"]
    print("air_temperature dims:", air.dims, "shape:", air.shape, "units:", air.attrs.get("units"))

    # Extract the temperature time series from the previewed grid point: all times
    # at the first latitude and first longitude. This preserves the dataset's
    # native temporal sequence and gives one temperature value per year.
    temp_series = air.isel(latitude=0, longitude=0).values.astype(float)
    years = np.array([int(t.year) for t in ds["time"].values], dtype=int)
finally:
    ds.close()

valid = np.isfinite(temp_series) & np.isfinite(years.astype(float))
fit_years = years[valid].astype(float)
fit_temps = temp_series[valid]

coefficients = np.polyfit(fit_years, fit_temps, 2)
fitted = np.polyval(coefficients, years.astype(float))

out_dir = Path("pred_results")
out_dir.mkdir(parents=True, exist_ok=True)
out_path = out_dir / "polynomial_fit_pred.csv"

df = pd.DataFrame({
    "Year": years.astype(int),
    "Fitted_Temperature": fitted.astype(float),
})
df.to_csv(out_path, index=False)

print("Extracted series count:", len(temp_series))
print("Year range:", years[0], "to", years[-1])
print("Raw temperature first 5:", temp_series[:5])
print("Raw temperature last 5:", temp_series[-5:])
print("Quadratic coefficients [a, b, c]:", coefficients)
print("Saved:", out_path)
print("CSV shape:", df.shape)
print("Head:")
print(df.head())
print("Tail:")
print(df.tail())