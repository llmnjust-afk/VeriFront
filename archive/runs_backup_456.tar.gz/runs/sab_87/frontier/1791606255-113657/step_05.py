#!/usr/bin/env python3
from pathlib import Path
import os
import numpy as np
import pandas as pd
import xarray as xr

print("Working directory:", os.getcwd())

# Locate the required NetCDF file. The benchmark data are exposed under benchmark/datasets
# in this run; fall back to the verified shared path if needed.
candidates = [
    Path("polynomial_fit/A1B_north_america.nc"),
    Path("benchmark/datasets/polynomial_fit/A1B_north_america.nc"),
    Path("/data/lab/sab_data/benchmark_verified/benchmark/datasets/polynomial_fit/A1B_north_america.nc"),
]
nc_path = next((p for p in candidates if p.exists()), None)
if nc_path is None:
    raise FileNotFoundError("Could not locate polynomial_fit/A1B_north_america.nc")
print("Using NetCDF file:", nc_path)

# Load the data. Decode the CF 360_day time coordinate so calendar years can be extracted.
ds = xr.open_dataset(nc_path, decode_times=True)
try:
    if "air_temperature" not in ds:
        raise KeyError("Variable 'air_temperature' not found in dataset")

    temp = ds["air_temperature"]
    print("air_temperature dims:", temp.dims, "shape:", temp.shape, "units:", temp.attrs.get("units"))

    # Extract a one-dimensional temperature time series by spatially averaging
    # over the latitude and longitude dimensions at each time.
    spatial_dims = [d for d in temp.dims if d != "time"]
    temp_ts = temp.mean(dim=spatial_dims, skipna=True).values.astype(float)

    # Extract integer year from decoded cftime timestamps.
    years = np.array([int(t.year) for t in ds["time"].values], dtype=int)

finally:
    ds.close()

# Remove any non-finite values before fitting.
mask = np.isfinite(years) & np.isfinite(temp_ts)
years_fit = years[mask].astype(float)
temp_fit = temp_ts[mask].astype(float)

print("Number of time points:", len(years_fit))
print("Year range:", int(years_fit.min()), "to", int(years_fit.max()))
print("Temperature series first 5:", temp_fit[:5])
print("Temperature series last 5:", temp_fit[-5:])

# Quadratic polynomial least-squares fit and fitted values at each dataset year.
coefficients = np.polyfit(years_fit, temp_fit, deg=2)
fitted_temp = np.polyval(coefficients, years.astype(float))

print("Quadratic coefficients [a, b, c]:", coefficients)
print("Fitted first 5:", fitted_temp[:5])
print("Fitted last 5:", fitted_temp[-5:])

# Save required prediction/fitted-result CSV.
out_dir = Path("pred_results")
out_dir.mkdir(parents=True, exist_ok=True)
out_path = out_dir / "polynomial_fit_pred.csv"

result = pd.DataFrame({
    "Year": years.astype(int),
    "Fitted_Temperature": fitted_temp.astype(float),
})
result.to_csv(out_path, index=False)

print("Saved:", out_path)
print("Output shape:", result.shape)
print("Output head:")
print(result.head())
print("Output tail:")
print(result.tail())