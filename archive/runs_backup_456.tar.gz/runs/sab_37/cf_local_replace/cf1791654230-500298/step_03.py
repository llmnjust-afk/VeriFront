from pathlib import Path
import inspect
import biopsykit.protocols.cft as cft

print("members:")
for name, obj in inspect.getmembers(cft):
    if not name.startswith("_"):
        print(name, type(obj))

print("\nSOURCE:")
print(inspect.getsource(cft))