import inspect
from biopsykit.protocols.cft import CFT

for name in ["baseline_hr", "onset", "extract_cft_interval", "peak_bradycardia", "mean_bradycardia", "poly_fit"]:
    print("\n###", name)
    print(inspect.getsource(getattr(CFT, name)))