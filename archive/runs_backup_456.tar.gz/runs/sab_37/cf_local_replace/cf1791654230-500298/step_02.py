import importlib, pkgutil, os, sys

try:
    import biopsykit
    print("biopsykit", biopsykit.__version__, biopsykit.__file__)
    p = os.path.dirname(biopsykit.__file__)
    for root, dirs, files in os.walk(p):
        dirs[:] = [d for d in dirs if d != "__pycache__"]
        rel = os.path.relpath(root, p)
        for f in files:
            if f.endswith(".py"):
                print(os.path.join(rel, f))
except Exception as e:
    print("no biopsykit:", repr(e))

print("=== grep for cft ===")
import subprocess
try:
    out = subprocess.run(["grep","-ril","cft", p if 'p' in dir() else "."], capture_output=True, text=True)
    print(out.stdout)
except Exception as e:
    print(e)