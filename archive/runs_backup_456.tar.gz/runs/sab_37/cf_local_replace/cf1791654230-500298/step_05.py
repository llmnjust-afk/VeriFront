import inspect
from biopsykit.protocols.cft import CFT

for name in ["compute_cft_parameter", "cft_parameter", "cft_plot"]:
    if hasattr(CFT, name):
        obj = getattr(CFT, name)
        print("\n###", name)
        print(inspect.getsource(obj))

# print any methods with compute/parameter
print("\nRelevant methods:")
for name, obj in inspect.getmembers(CFT):
    if inspect.isfunction(obj) and any(s in name.lower() for s in ["compute", "param", "baseline", "onset"]):
        print(name)