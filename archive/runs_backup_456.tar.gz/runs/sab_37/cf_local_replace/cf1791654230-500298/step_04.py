import inspect
from biopsykit.protocols.cft import CFT

print("CFT methods:")
for name, obj in inspect.getmembers(CFT):
    if inspect.isfunction(obj) and not name.startswith("__"):
        print("\n###", name)
        src = inspect.getsource(obj)
        lines = src.splitlines()
        print("\n".join(lines[:120]))
        if len(lines) > 120:
            print(f"... [{len(lines)-120} more lines]")