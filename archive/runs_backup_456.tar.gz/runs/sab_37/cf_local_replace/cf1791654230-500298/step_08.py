from pathlib import Path
import json
import math

import pandas as pd
import numpy as np
from biopsykit.protocols import CFT

# Load MIST3 heart-rate data
xlsx_path = Path("mist_hr/hr_sample_mist.xlsx")
df = pd.read_excel(xlsx_path, sheet_name="MIST3")

print("Loaded rows:", len(df))
print("Columns:", list(df.columns))
print("Time range:", df["time"].iloc[0], "to", df["time"].iloc[-1])
print("HR summary:")
print(df["Heart_Rate"].describe().to_string())

# Prepare data in the format expected by BioPsyKit's CFT protocol:
# DatetimeIndex, one HR column.
hr_data = df[["time", "Heart_Rate"]].copy()
hr_data["time"] = pd.to_datetime(hr_data["time"])
hr_data = hr_data.set_index("time")
hr_data = hr_data.astype(float)

# CFT default structure: 60 s baseline, 120 s cold-face-test interval, 60 s recovery.
# The requested parameters are baseline_hr, onset_hr, onset_hr_percent.
cft = CFT()

baseline_hr = cft.baseline_hr(hr_data)
cft_interval = cft.extract_cft_interval(hr_data)
onset_params = cft.onset(
    data=cft_interval,
    is_cft_interval=True,
    compute_baseline=False,
    hr_baseline=baseline_hr,
)

results = {
    "baseline_hr": float(baseline_hr),
    "onset_hr": float(np.squeeze(onset_params["onset_hr"])),
    "onset_hr_percent": float(np.squeeze(onset_params["onset_hr_percent"])),
}

print("Computed requested CFT parameters:")
print(json.dumps(results, indent=2))

# Save JSON output
out_path = Path("pred_results/cft_pred_results.json")
out_path.parent.mkdir(parents=True, exist_ok=True)
with out_path.open("w", encoding="utf-8") as f:
    json.dump(results, f, indent=2)

print("Saved:", out_path)
print("Saved file content:")
print(out_path.read_text(encoding="utf-8"))