import inspect
from biopsykit.protocols.cft import CFT

obj = CFT.onset
print(inspect.signature(obj))
src = inspect.getsource(obj)
lines = src.splitlines()
for i, line in enumerate(lines, 1):
    print(f"{i:03d}: {line}")