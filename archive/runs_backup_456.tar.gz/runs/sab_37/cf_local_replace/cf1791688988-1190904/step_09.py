import json
import os
from pathlib import Path

import numpy as np
import pandas as pd
from biopsykit.protocols.cft import CFT

# Load heart-rate data from the requested sheet.
xlsx_path = Path("mist_hr/hr_sample_mist.xlsx")
sheet_name = "MIST3"
df = pd.read_excel(xlsx_path, sheet_name=sheet_name)

print("Loaded", sheet_name, "shape:", df.shape)
print("Columns:", list(df.columns))
print("First rows:")
print(df.head().to_string(index=False))
print("Last rows:")
print(df.tail().to_string(index=False))

# BioPsyKit CFT expects a time-indexed dataframe containing heart-rate values.
hr = df[["time", "Heart_Rate"]].copy()
hr["time"] = pd.to_datetime(hr["time"])
hr = hr.set_index("time")
hr = hr.rename(columns={"Heart_Rate": "Heart_Rate"})
hr = hr.sort_index()

print("Time span:", hr.index[0], "to", hr.index[-1], "duration_s:", (hr.index[-1] - hr.index[0]).total_seconds())
print("HR summary:")
print(hr["Heart_Rate"].describe().to_string())

# Use standard CFT structure: 60 s baseline, 120 s cold-face exposure, remaining data as recovery.
cft = CFT(structure={"Baseline": 60, "CFT": 120, "Recovery": 60})
params = cft.compute_cft_parameter(hr, return_dict=True)

print("Computed CFT parameters:")
for k, v in params.items():
    print(k, "=", repr(v))

# Convert BioPsyKit/Pandas/Numpy objects to JSON-safe values.
def json_safe(x):
    if isinstance(x, (pd.Timestamp,)):
        return x.isoformat()
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (np.floating,)):
        return float(x)
    if isinstance(x, np.ndarray):
        return x.tolist()
    if hasattr(x, "item") and not isinstance(x, (str, bytes)):
        try:
            return x.item()
        except Exception:
            pass
    return x

out = {k: json_safe(v) for k, v in params.items()}

# Ensure the required benchmark keys are present and JSON numeric where expected.
required = ["baseline_hr", "onset_hr", "onset_hr_percent"]
missing = [k for k in required if k not in out]
if missing:
    raise KeyError(f"Missing required CFT parameters: {missing}")

out_dir = Path("pred_results")
out_dir.mkdir(parents=True, exist_ok=True)
out_path = out_dir / "cft_pred_results.json"
with out_path.open("w") as f:
    json.dump(out, f, indent=2, sort_keys=True)

print("Saved JSON to:", out_path)
print("Required output values:")
for k in required:
    print(k, "=", out[k])
print("JSON file content:")
print(out_path.read_text())