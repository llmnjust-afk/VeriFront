import inspect
from biopsykit.protocols.cft import CFT

print("CFT signature:", inspect.signature(CFT))
print("CFT MRO:", CFT.mro())

print("\nCFT methods/properties:")
for name, obj in inspect.getmembers(CFT):
    if not name.startswith("_"):
        if inspect.isfunction(obj) or isinstance(obj, property):
            print(name, type(obj), end="")
            if inspect.isfunction(obj):
                try:
                    print(" sig", inspect.signature(obj))
                except Exception as e:
                    print(" sig error", e)
            else:
                print()

print("\nFull CFT source:")
src = inspect.getsource(CFT)
print(src)