import inspect
from biopsykit.protocols.cft import CFT

for meth in ["extract_cft_interval", "onset", "peak_bradycardia", "mean_bradycardia", "poly_fit"]:
    obj = getattr(CFT, meth)
    src = inspect.getsource(obj)
    lines = src.splitlines()
    print("\n" + "="*80)
    print(meth, "signature:", inspect.signature(obj), "num_lines", len(lines))
    for i, line in enumerate(lines, 1):
        print(f"{i:03d}: {line}")