import json
from pathlib import Path

import numpy as np
import pandas as pd

xlsx = Path("mist_hr/hr_sample_mist.xlsx")
outpath = Path("pred_results/cft_pred_results.json")
outpath.parent.mkdir(parents=True, exist_ok=True)

df = pd.read_excel(xlsx, sheet_name="MIST3")
df["time"] = pd.to_datetime(df["time"])
df = df.sort_values("time").reset_index(drop=True)

# Heuristic CFT parameter estimation for MIST3:
# baseline HR: average heart rate over the first 30 seconds of the segment
# onset HR: average heart rate over a short window near the initial response peak,
#           using the first 20 seconds after the detected onset of cooling response.
# onset HR percent: onset HR relative to baseline HR.
t0 = df["time"].iloc[0]
sec = (df["time"] - t0).dt.total_seconds().to_numpy()
hr = df["Heart_Rate"].astype(float).to_numpy()

baseline_mask = sec <= 30
baseline_hr = float(np.mean(hr[baseline_mask]))

# Detect the first local sustained increase above baseline by >2 bpm for at least 3 samples,
# then define onset as the first sample of that run.
diff = hr - baseline_hr
cand = np.where(diff > 2.0)[0]
onset_idx = None
if len(cand):
    for idx in cand:
        if idx + 2 < len(hr) and np.all(diff[idx:idx+3] > 2.0):
            onset_idx = idx
            break
if onset_idx is None:
    onset_idx = int(np.argmax(hr))

# Onset HR: mean over 20 s window from onset
onset_end = sec[onset_idx] + 20.0
onset_mask = (sec >= sec[onset_idx]) & (sec <= onset_end)
onset_hr = float(np.mean(hr[onset_mask]))

onset_hr_percent = float(100.0 * onset_hr / baseline_hr)

results = {
    "baseline_hr": baseline_hr,
    "onset_hr": onset_hr,
    "onset_hr_percent": onset_hr_percent,
}

with outpath.open("w", encoding="utf-8") as f:
    json.dump(results, f, indent=2)

print("Saved:", outpath)
print(json.dumps(results, indent=2))