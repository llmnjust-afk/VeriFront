import inspect
from biopsykit.protocols.cft import CFT

for meth in ["__init__", "baseline_hr", "onset_hr", "onset_hr_percent", "compute_cft_parameter", "cft_plot"]:
    print("\n" + "="*80)
    print(meth)
    obj = getattr(CFT, meth, None)
    print("exists:", obj is not None)
    if obj is not None:
        try:
            print("signature:", inspect.signature(obj))
        except Exception as e:
            print("signature error:", e)
        try:
            print(inspect.getsource(obj))
        except Exception as e:
            print("source error:", repr(e))