import inspect
import biopsykit.protocols.cft as cft
import biopsykit.protocols.mist as mist

print("cft module members:")
for name, obj in inspect.getmembers(cft):
    if not name.startswith("_"):
        print(name, type(obj))

print("\nSource snippets/classes:")
for name, obj in inspect.getmembers(cft):
    if inspect.isclass(obj) or inspect.isfunction(obj):
        print("\n---", name, "---")
        try:
            print(inspect.signature(obj))
        except Exception as e:
            print("no signature", e)
        try:
            src = inspect.getsource(obj)
            print(src[:4000])
        except Exception as e:
            print("no source", e)