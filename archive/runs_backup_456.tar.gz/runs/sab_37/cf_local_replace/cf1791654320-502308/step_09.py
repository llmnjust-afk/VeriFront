import inspect
from biopsykit.protocols.cft import CFT

for meth in ["compute_cft_parameter", "cft_plot"]:
    obj = getattr(CFT, meth)
    src = inspect.getsource(obj)
    lines = src.splitlines()
    print("\n" + "="*80)
    print(meth, "num_lines", len(lines))
    for i, line in enumerate(lines, 1):
        print(f"{i:03d}: {line}")

print("\nAttributes containing hr/percent/onset:")
for name in dir(CFT):
    lname = name.lower()
    if any(x in lname for x in ["hr", "percent", "onset", "baseline", "cft"]):
        print(name)