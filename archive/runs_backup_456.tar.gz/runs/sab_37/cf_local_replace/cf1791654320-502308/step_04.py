import importlib.util
import sys
from pathlib import Path

mods = ["biopsykit", "neurokit2", "pingouin"]
for m in mods:
    spec = importlib.util.find_spec(m)
    print(m, "available:", spec is not None, "origin:", spec.origin if spec else None)

if importlib.util.find_spec("biopsykit"):
    import biopsykit
    print("biopsykit version:", getattr(biopsykit, "__version__", "unknown"))
    # list potentially relevant modules/classes
    import pkgutil
    names = []
    for modinfo in pkgutil.walk_packages(biopsykit.__path__, biopsykit.__name__ + "."):
        lname = modinfo.name.lower()
        if "cft" in lname or "cold" in lname or "heart" in lname or "mist" in lname:
            names.append(modinfo.name)
    print("relevant modules:")
    for n in names[:200]:
        print(" ", n)
    print("count", len(names))