import json
from pathlib import Path

import pandas as pd
from biopsykit.protocols.cft import CFT

xlsx = Path("mist_hr/hr_sample_mist.xlsx")
outpath = Path("pred_results/cft_pred_results.json")
outpath.parent.mkdir(parents=True, exist_ok=True)

# Load MIST3 heart-rate data. BioPsyKit's CFT implementation expects a
# one-column heart-rate DataFrame indexed by time (DatetimeIndex or seconds).
df = pd.read_excel(xlsx, sheet_name="MIST3")
df["time"] = pd.to_datetime(df["time"])
hr_data = (
    df.sort_values("time")
      .set_index("time")[["Heart_Rate"]]
      .rename(columns={"Heart_Rate": "Heart_Rate"})
)

# Use BioPsyKit's default CFT structure:
# Baseline: first 60 s; CFT exposure: following 120 s; Recovery: following 60 s.
# The required baseline/onset parameters are computed from baseline + CFT interval,
# so the slightly shorter recovery part of this recording does not affect them.
protocol = CFT()
params = protocol.compute_cft_parameter(hr_data, return_dict=True)

print("All BioPsyKit CFT parameters:")
for key, value in params.items():
    print(f"{key}: {value}")

# BioPsyKit returns "onset_hr_brady_percent", defined as relative bradycardic
# HR change at onset compared with baseline. Save it under the requested key.
results = {
    "baseline_hr": float(params["baseline_hr"]),
    "onset_hr": float(params["onset_hr"]),
    "onset_hr_percent": float(params["onset_hr_brady_percent"]),
}

with outpath.open("w", encoding="utf-8") as f:
    json.dump(results, f, indent=2)

print("\nSaved required parameters to", outpath)
print(json.dumps(results, indent=2))