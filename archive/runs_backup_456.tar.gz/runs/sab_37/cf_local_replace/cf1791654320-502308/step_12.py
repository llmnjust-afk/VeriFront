import json
from pathlib import Path

import pandas as pd
from biopsykit.protocols.cft import CFT

xlsx = Path("mist_hr/hr_sample_mist.xlsx")
outpath = Path("pred_results/cft_pred_results.json")
outpath.parent.mkdir(parents=True, exist_ok=True)

df = pd.read_excel(xlsx, sheet_name="MIST3")
df["time"] = pd.to_datetime(df["time"])
hr_data = df.sort_values("time").set_index("time")[["Heart_Rate"]]

protocol = CFT()  # default: Baseline 60 s, CFT 120 s, Recovery 60 s
params = protocol.compute_cft_parameter(hr_data, return_dict=True)

results = {
    "baseline_hr": float(params["baseline_hr"]),
    "onset_hr": float(params["onset_hr"]),
    "onset_hr_percent": float(params["onset_hr_percent"]),
}

with outpath.open("w", encoding="utf-8") as f:
    json.dump(results, f, indent=2)

print("Saved:", outpath)
print(json.dumps(results, indent=2))