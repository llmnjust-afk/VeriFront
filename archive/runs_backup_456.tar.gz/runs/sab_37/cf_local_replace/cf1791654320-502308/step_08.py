import inspect
from biopsykit.protocols.cft import CFT

for meth in ["baseline_hr", "onset_hr", "onset_hr_percent", "compute_cft_parameter"]:
    obj = getattr(CFT, meth)
    src = inspect.getsource(obj)
    lines = src.splitlines()
    print("\n" + "="*60)
    print(meth, "num_lines", len(lines))
    for i, line in enumerate(lines, 1):
        print(f"{i:03d}: {line}")