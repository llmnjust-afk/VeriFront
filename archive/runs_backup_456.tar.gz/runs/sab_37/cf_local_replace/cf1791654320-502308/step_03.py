from pathlib import Path
import pandas as pd
import numpy as np

xlsx = Path("mist_hr/hr_sample_mist.xlsx")
df = pd.read_excel(xlsx, sheet_name="MIST3")
df["time"] = pd.to_datetime(df["time"])
df = df.sort_values("time").reset_index(drop=True)
t0 = df["time"].iloc[0]
df["sec"] = (df["time"] - t0).dt.total_seconds()
hr = df["Heart_Rate"].astype(float)

print("duration", df["sec"].iloc[-1], "n", len(df))
print("overall mean median min max", hr.mean(), hr.median(), hr.min(), hr.max())
print("first time", df["time"].iloc[0], "last", df["time"].iloc[-1])
print("\nFirst/last 20 rows:")
print(df.head(20).to_string(index=True))
print(df.tail(20).to_string(index=True))

print("\n10-sec bin statistics:")
bins = np.arange(0, np.ceil(df["sec"].max()/10)*10 + 10, 10)
df["bin10"] = pd.cut(df["sec"], bins=bins, right=False)
stats = df.groupby("bin10", observed=False)["Heart_Rate"].agg(["count","mean","median","min","max"])
print(stats.to_string())

print("\n30-sec bin statistics:")
bins30 = np.arange(0, np.ceil(df["sec"].max()/30)*30 + 30, 30)
df["bin30"] = pd.cut(df["sec"], bins=bins30, right=False)
stats30 = df.groupby("bin30", observed=False)["Heart_Rate"].agg(["count","mean","median","min","max"])
print(stats30.to_string())

# rolling means, extrema
for window_s in [5, 10, 15, 20, 30, 60]:
    vals = []
    secs = df["sec"].to_numpy()
    hrs = hr.to_numpy()
    for i, s in enumerate(secs):
        m = (secs >= s) & (secs <= s + window_s)
        if m.sum() >= 3:
            vals.append((hrs[m].mean(), s, secs[m][-1], m.sum()))
    minv = min(vals, key=lambda x:x[0])
    maxv = max(vals, key=lambda x:x[0])
    print(f"window {window_s}s min_mean={minv} max_mean={maxv}")