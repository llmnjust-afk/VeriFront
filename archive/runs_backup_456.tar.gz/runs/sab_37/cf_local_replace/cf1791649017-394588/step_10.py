from pathlib import Path
import json

import numpy as np
import pandas as pd
from biopsykit.protocols import CFT

# Load heart-rate data from the required sheet.
xlsx_path = Path("mist_hr/hr_sample_mist.xlsx")
sheet_name = "MIST3"
df = pd.read_excel(xlsx_path, sheet_name=sheet_name)

print("Loaded:", xlsx_path, "sheet:", sheet_name)
print("Shape:", df.shape)
print("Columns:", list(df.columns))
print(df.head().to_string(index=False))
print(df.tail().to_string(index=False))

# Prepare dataframe expected by BioPsyKit's CFT implementation:
# DatetimeIndex + single heart-rate column.
hr = df.copy()
hr["time"] = pd.to_datetime(hr["time"])
hr = hr.set_index("time")[["Heart_Rate"]].sort_index()
hr = hr.dropna()

print("\nPrepared HR data:")
print("Shape:", hr.shape)
print("Index type:", type(hr.index).__name__)
print("Start:", hr.index[0], "End:", hr.index[-1])
print("Duration seconds:", (hr.index[-1] - hr.index[0]).total_seconds())
print("HR min/mean/max:", float(hr["Heart_Rate"].min()),
      float(hr["Heart_Rate"].mean()), float(hr["Heart_Rate"].max()))

# Standard CFT structure: 60 s Baseline, 120 s CFT exposure, 60 s Recovery.
cft = CFT()
params_all = cft.compute_cft_parameter(hr, return_dict=True)

print("\nAll computed CFT parameters:")
for key, value in params_all.items():
    print(f"{key}: {value} ({type(value).__name__})")

required_keys = ["baseline_hr", "onset_hr", "onset_hr_percent"]
missing = [k for k in required_keys if k not in params_all]
if missing:
    raise KeyError(f"Missing required computed keys: {missing}")

results = {}
for key in required_keys:
    value = params_all[key]
    if hasattr(value, "item"):
        value = value.item()
    results[key] = float(value)

out_path = Path("pred_results/cft_pred_results.json")
out_path.parent.mkdir(parents=True, exist_ok=True)
with out_path.open("w", encoding="utf-8") as f:
    json.dump(results, f, indent=2, sort_keys=True)

print("\nSaved required results to:", out_path)
print(json.dumps(results, indent=2, sort_keys=True))