import json
from pathlib import Path

import pandas as pd
from biopsykit.protocols import CFT

# Paths
input_path = Path("mist_hr/hr_sample_mist.xlsx")
output_path = Path("pred_results/cft_pred_results.json")
output_path.parent.mkdir(parents=True, exist_ok=True)

# Load heart-rate data from sheet "MIST3"
df = pd.read_excel(input_path, sheet_name="MIST3")
print("Loaded data shape:", df.shape)
print("Columns:", list(df.columns))
print("First rows:")
print(df.head().to_string(index=False))
print("Last rows:")
print(df.tail().to_string(index=False))

# Prepare data for BioPsyKit CFT analysis:
# CFT expects a DataFrame indexed by time/datetime and containing heart-rate values.
hr = df[["time", "Heart_Rate"]].copy()
hr["time"] = pd.to_datetime(hr["time"])
hr = hr.set_index("time")
hr = hr[["Heart_Rate"]].sort_index()

duration_s = (hr.index[-1] - hr.index[0]).total_seconds()
print("MIST3 start:", hr.index[0])
print("MIST3 end:", hr.index[-1])
print("MIST3 duration seconds:", duration_s)

# Compute CFT parameters using the default CFT structure:
# Baseline = first 60 s, CFT = following 120 s, Recovery = following 60 s.
cft = CFT()
params = cft.compute_cft_parameter(hr, return_dict=True)

print("All computed CFT parameters:")
for k, v in params.items():
    print(f"{k}: {v} ({type(v)})")

# Required output keys
results = {
    "baseline_hr": float(params["baseline_hr"]),
    "onset_hr": float(params["onset_hr"]),
    "onset_hr_percent": float(params["onset_hr_percent"]),
}

with output_path.open("w", encoding="utf-8") as f:
    json.dump(results, f, indent=2, sort_keys=True)

print("Saved required JSON to:", output_path)
print("Saved JSON contents:")
print(json.dumps(results, indent=2, sort_keys=True))