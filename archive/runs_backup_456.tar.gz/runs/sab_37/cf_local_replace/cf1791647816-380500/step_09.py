# inspect_and_manual_compute.py
from pathlib import Path
import json
import inspect
import re

import numpy as np
import pandas as pd
from biopsykit.protocols.cft import CFT

# Print the full onset implementation and then reproduce the relevant parts manually.
src = inspect.getsource(CFT.onset)
print("CFT.onset source:\n", src)

df = pd.read_excel("mist_hr/hr_sample_mist.xlsx", sheet_name="MIST3")
df["t"] = (df["time"] - df["time"].iloc[0]).dt.total_seconds()
hr = df.set_index("t")["Heart_Rate"].astype(float)

# Benchmark/domain default for CFT in BioPsyKit: 60 s baseline followed by 120 s CFT.
cft_start = 60.0
cft_duration = 120.0

baseline_segment = hr.loc[hr.index[0] : hr.index[0] + cft_start]
baseline_hr = float(baseline_segment.mean())
cft_segment = hr.loc[hr.index[0] + cft_start : hr.index[0] + cft_start + cft_duration]

print("\nData duration:", float(hr.index[-1]), "s, n=", len(hr))
print("Baseline n:", len(baseline_segment), "start/end:", baseline_segment.index[0], baseline_segment.index[-1])
print("CFT n:", len(cft_segment), "start/end:", cft_segment.index[0], cft_segment.index[-1])
print("Baseline HR:", baseline_hr)

# Reproduce BioPsyKit's documented CFT onset: first time point in CFT where three consecutive heart-rate
# samples are below the baseline HR.
below = cft_segment < baseline_hr
onset_pos = None
for i in range(0, len(cft_segment) - 2):
    if bool(below.iloc[i]) and bool(below.iloc[i + 1]) and bool(below.iloc[i + 2]):
        onset_pos = i
        break

if onset_pos is None:
    raise RuntimeError("No CFT onset found (three consecutive samples below baseline).")

onset_time = float(cft_segment.index[onset_pos])
onset_latency = onset_time - float(cft_segment.index[0])
onset_hr = float(cft_segment.iloc[onset_pos])

# BioPsyKit calls this onset_hr_brady_percent and defines it as relative change from baseline in percent.
onset_hr_percent_relative_change = float((onset_hr - baseline_hr) / baseline_hr * 100.0)
# Some tasks use "heart rate percentage" as HR expressed relative to baseline; print both candidates.
onset_hr_percent_of_baseline = float(onset_hr / baseline_hr * 100.0)

print("\nOnset position in CFT segment:", onset_pos)
print("Onset absolute relative time:", onset_time, "s")
print("Onset latency:", onset_latency, "s")
print("Onset HR:", onset_hr)
print("onset_hr_percent relative change:", onset_hr_percent_relative_change)
print("onset_hr_percent of baseline:", onset_hr_percent_of_baseline)
print("\nSamples around CFT start/onset:")
around = hr.loc[cft_start - 5 : onset_time + 5].to_frame("Heart_Rate")
around["below_baseline"] = around["Heart_Rate"] < baseline_hr
print(around.to_string())

# Save required JSON. Use the parameter name requested by task:
# "onset_hr_percent" corresponds to BioPsyKit's relative percent bradycardia/change from baseline.
out = {
    "baseline_hr": baseline_hr,
    "onset_hr": onset_hr,
    "onset_hr_percent": onset_hr_percent_relative_change,
}
out_path = Path("pred_results/cft_pred_results.json")
out_path.parent.mkdir(parents=True, exist_ok=True)
out_path.write_text(json.dumps(out, indent=2))
print("\nSaved:", out_path)
print(out_path.read_text())