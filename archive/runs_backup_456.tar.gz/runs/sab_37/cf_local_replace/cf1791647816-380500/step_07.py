# compute_with_biopsykit_probe.py
from pathlib import Path
import json
import pandas as pd
from biopsykit.protocols.cft import CFT

df = pd.read_excel("mist_hr/hr_sample_mist.xlsx", sheet_name="MIST3")
hr = df.set_index("time")["Heart_Rate"]
print("Series name:", hr.name, "index type:", type(hr.index), "len", len(hr), "duration_s", (hr.index[-1]-hr.index[0]).total_seconds())
for structure in [
    {"Baseline": 60, "CFT": 120, "Recovery": 60},
    {"Baseline": 60, "CFT": 120},
    {"Baseline": 0, "CFT": 120, "Recovery": 60},
]:
    print("\nTrying structure:", structure)
    try:
        cft = CFT(structure=structure)
        res = cft.compute_cft_parameter(hr, return_dict=True)
        for k, v in res.items():
            print(k, repr(v), type(v))
        if "onset_hr_brady_percent" in res:
            print("onset_hr / baseline *100 =", res["onset_hr"] / res["baseline_hr"] * 100)
            print("(onset-baseline)/baseline*100 =", (res["onset_hr"] - res["baseline_hr"]) / res["baseline_hr"] * 100)
    except Exception as e:
        print("ERROR:", type(e).__name__, str(e))