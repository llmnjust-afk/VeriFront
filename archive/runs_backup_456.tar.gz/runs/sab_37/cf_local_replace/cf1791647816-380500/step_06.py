# inspect_key_methods.py
import inspect
from biopsykit.protocols.cft import CFT

for name in ["baseline_hr", "onset", "extract_cft_interval", "peak_bradycardia", "mean_bradycardia", "poly_fit"]:
    print("\n" + "="*90)
    print("METHOD:", name)
    print("="*90)
    print(inspect.getsource(getattr(CFT, name)))