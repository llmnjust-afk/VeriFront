# correct_cft_results.py
from pathlib import Path
import json

import numpy as np
import pandas as pd

df = pd.read_excel("mist_hr/hr_sample_mist.xlsx", sheet_name="MIST3")
df["t"] = (df["time"] - df["time"].iloc[0]).dt.total_seconds()
hr = df.set_index("t")["Heart_Rate"].astype(float)

# BioPsyKit CFT defaults: 60 s baseline and 120 s CFT exposure.
cft_start = 60.0
cft_duration = 120.0

baseline_segment = hr.loc[hr.index[0] : hr.index[0] + cft_start]
cft_segment = hr.loc[hr.index[0] + cft_start : hr.index[0] + cft_start + cft_duration]

baseline_hr = float(baseline_segment.mean())

# Reproduce BioPsyKit CFT.onset implementation:
# - mask samples below baseline
# - keep bradycardia phases with at least 3 HR values below baseline
# - CFT onset is the third beat/sample of the first qualifying bradycardia sequence.
hr_brady = cft_segment < baseline_hr
brady_border = np.abs(np.ediff1d(hr_brady.astype(int), to_begin=0))
brady_phases = cft_segment[hr_brady].groupby(np.cumsum(brady_border)[hr_brady]).filter(lambda s: s.sum() >= 3)

# The upstream implementation's filter is applied to the boolean series; reproduce more directly/clearly:
brady_bool_phases = hr_brady.groupby(np.cumsum(brady_border)).filter(lambda s: s.sum() >= 3)
onset_time = float(brady_bool_phases.index[2])
onset_hr = float(cft_segment.loc[onset_time])

# BioPsyKit returns this key as "onset_hr_percent": (1 - onset_hr / baseline_hr) * 100.
onset_hr_percent = float((1.0 - onset_hr / baseline_hr) * 100.0)

results = {
    "baseline_hr": baseline_hr,
    "onset_hr": onset_hr,
    "onset_hr_percent": onset_hr_percent,
}

out_path = Path("pred_results/cft_pred_results.json")
out_path.parent.mkdir(parents=True, exist_ok=True)
out_path.write_text(json.dumps(results, indent=2))

print("Baseline segment n/start/end:", len(baseline_segment), baseline_segment.index[0], baseline_segment.index[-1])
print("CFT segment n/start/end:", len(cft_segment), cft_segment.index[0], cft_segment.index[-1])
print("baseline_hr:", baseline_hr)
print("onset_time:", onset_time)
print("onset_hr:", onset_hr)
print("onset_hr_percent:", onset_hr_percent)
print("First CFT samples:")
tmp = cft_segment.head(10).to_frame("Heart_Rate")
tmp["below_baseline"] = tmp["Heart_Rate"] < baseline_hr
print(tmp.to_string())
print("Saved JSON:", out_path)
print(out_path.read_text())