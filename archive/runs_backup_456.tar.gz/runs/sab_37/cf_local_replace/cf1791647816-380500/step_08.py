# compute_with_relative_index_probe.py
import pandas as pd
from biopsykit.protocols.cft import CFT
import traceback

df = pd.read_excel("mist_hr/hr_sample_mist.xlsx", sheet_name="MIST3")
df["t"] = (df["time"] - df["time"].iloc[0]).dt.total_seconds()
hr = df.set_index("t")["Heart_Rate"]
print("index first/last", hr.index[0], hr.index[-1], "len", len(hr))
for structure in [
    {"Baseline": 60, "CFT": 120, "Recovery": 38},
    {"Baseline": 60, "CFT": 120, "Recovery": 60},
    {"Baseline": 0, "CFT": 120, "Recovery": 60},
]:
    print("\nTrying structure:", structure)
    try:
        cft = CFT(structure=structure)
        res = cft.compute_cft_parameter(hr, return_dict=True)
        for k, v in res.items():
            print(k, repr(v), type(v))
        print("computed onset_hr_percent candidates:")
        print("onset_hr / baseline_hr * 100 =", float(res["onset_hr"] / res["baseline_hr"] * 100))
        print("onset_hr_brady_percent =", res.get("onset_hr_brady_percent"))
    except Exception as e:
        print("ERROR:", type(e).__name__, str(e))
        traceback.print_exc(limit=3)