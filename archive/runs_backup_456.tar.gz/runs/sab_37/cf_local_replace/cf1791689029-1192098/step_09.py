import json
import os
from pathlib import Path

import numpy as np
import pandas as pd
from biopsykit.protocols import CFT

# Paths
input_path = Path("mist_hr/hr_sample_mist.xlsx")
output_path = Path("pred_results/cft_pred_results.json")
output_path.parent.mkdir(parents=True, exist_ok=True)

# Load heart-rate data from the requested sheet
df = pd.read_excel(input_path, sheet_name="MIST3")
print("Loaded MIST3:", df.shape)
print(df.head().to_string(index=False))
print(df.tail().to_string(index=False))

# Prepare data for BioPsyKit CFT: DatetimeIndex and single HR column
df["time"] = pd.to_datetime(df["time"])
hr = df.set_index("time")[["Heart_Rate"]].sort_index()
hr = hr.dropna()
print("Prepared HR:", hr.shape, "start:", hr.index[0], "end:", hr.index[-1])
print("Duration seconds:", (hr.index[-1] - hr.index[0]).total_seconds())

# Compute CFT parameters using the standard CFT structure:
# Baseline = first 60 s; CFT interval = following 120 s; Recovery = remaining.
cft = CFT(structure={"Baseline": 60, "CFT": 120, "Recovery": 60})
params = cft.compute_cft_parameter(hr, return_dict=True)

print("Computed CFT parameter keys:", sorted(params.keys()))
for key in ["baseline_hr", "onset_hr", "onset_hr_percent", "onset", "onset_latency", "onset_idx"]:
    print(key, "=", params.get(key))

# Convert numpy/pandas scalar values to JSON-serializable Python floats
def as_float(x):
    if isinstance(x, (pd.Series, pd.DataFrame)):
        x = np.squeeze(x.to_numpy())
    if isinstance(x, np.ndarray):
        x = np.squeeze(x)
    return float(x)

required = {
    "baseline_hr": as_float(params["baseline_hr"]),
    "onset_hr": as_float(params["onset_hr"]),
    "onset_hr_percent": as_float(params["onset_hr_percent"]),
}

with output_path.open("w", encoding="utf-8") as f:
    json.dump(required, f, indent=2, sort_keys=True)

print("Saved:", output_path)
print(output_path.read_text())