import inspect
from biopsykit.protocols.cft import CFT

src = inspect.getsource(CFT.onset)
lines = src.splitlines()
start = None
for i, line in enumerate(lines):
    if 'is_cft_interval is False' in line or 'if is_cft_interval' in line or 'if not is_cft_interval' in line:
        start = i
        break
# print the whole body after the docstring
in_doc = False
printed = 0
for i, line in enumerate(lines, 1):
    print(f"{i:03d}: {line}")