from pathlib import Path
import json
import pandas as pd
import numpy as np
from biopsykit.protocols import CFT

path = Path("mist_hr/hr_sample_mist.xlsx")
df = pd.read_excel(path, sheet_name="MIST3")
print("raw shape:", df.shape)
print(df.head().to_string(index=False))
print(df.tail().to_string(index=False))
print("columns:", df.columns.tolist())

# Prepare heart-rate dataframe for BioPsyKit CFT analysis.
hr = df[["time", "Heart_Rate"]].copy()
hr["time"] = pd.to_datetime(hr["time"])
hr = hr.set_index("time")
print("prepared shape:", hr.shape)
print("index start/end:", hr.index[0], hr.index[-1], "duration_s:", (hr.index[-1] - hr.index[0]).total_seconds())
print("HR descriptive stats:")
print(hr["Heart_Rate"].describe().to_string())

# Try the standard CFT structure used by BioPsyKit: 60 s baseline, 120 s CFT, 60 s recovery.
# The recording is slightly shorter than the nominal 240 s full procedure but contains sufficient baseline+CFT.
cft = CFT()
print("CFT start/duration:", cft.cft_start, cft.cft_duration)
try:
    params = cft.compute_cft_parameter(hr, return_dict=True)
    print("BioPsyKit CFT parameters:")
    for k, v in params.items():
        print(k, repr(v), type(v))
except Exception as e:
    print("BioPsyKit compute_cft_parameter failed:", type(e).__name__, repr(e))
    raise

required = {
    "baseline_hr": float(params["baseline_hr"]),
    "onset_hr": float(params["onset_hr"]),
    "onset_hr_percent": float(params["onset_hr_percent"]),
}
print("required parameters:", required)

out_dir = Path("pred_results")
out_dir.mkdir(parents=True, exist_ok=True)
out_path = out_dir / "cft_pred_results.json"
with out_path.open("w") as f:
    json.dump(required, f, indent=2)
print("saved:", out_path)
print(out_path.read_text())