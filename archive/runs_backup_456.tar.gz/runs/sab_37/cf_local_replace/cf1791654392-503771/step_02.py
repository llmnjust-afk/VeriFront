import importlib, pkgutil, inspect
import biopsykit as bp
print("biopsykit version:", getattr(bp, "__version__", "?"))
print("path:", bp.__file__)

# list submodules
import biopsykit
mods = [m.name for m in pkgutil.walk_packages(biopsykit.__path__, prefix="biopsykit.")]
for m in mods:
    print(m)