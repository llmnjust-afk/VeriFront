import inspect, re
from biopsykit.protocols.cft import CFT

src = inspect.getsource(CFT)
# Print method signatures and full source for key methods names
for name in ["compute_cft_parameter", "baseline_hr", "onset", "peak_bradycardia", "bradycardia"]:
    print("\n" + "="*80)
    print("METHOD", name)
    obj = getattr(CFT, name, None)
    print("obj", obj)
    if obj:
        print("signature", inspect.signature(obj))
        print(inspect.getsource(obj))