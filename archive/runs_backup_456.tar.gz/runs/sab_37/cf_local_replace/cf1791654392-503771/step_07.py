import inspect
from biopsykit.protocols.cft import CFT
src = inspect.getsource(CFT.onset)
for i, line in enumerate(src.splitlines(), 1):
    print(f"{i:03d}: {line}")
print("\nextract")
src2 = inspect.getsource(CFT.extract_cft_interval)
for i, line in enumerate(src2.splitlines(), 1):
    print(f"{i:03d}: {line}")