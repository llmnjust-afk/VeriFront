import inspect
from biopsykit.protocols.cft import CFT
print(inspect.getsource(CFT))