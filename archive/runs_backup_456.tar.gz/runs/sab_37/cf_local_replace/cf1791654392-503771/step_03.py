import inspect
import biopsykit.protocols.cft as cft
print("module:", cft)
print("members:")
for name, obj in inspect.getmembers(cft):
    if not name.startswith("_"):
        print(name, type(obj))
        if inspect.isclass(obj) or inspect.isfunction(obj):
            try:
                print(inspect.signature(obj))
            except Exception as e:
                print("sig err", e)
            doc = inspect.getdoc(obj)
            if doc:
                print(doc[:1000].replace("\n", "\n  "))
            print("---")