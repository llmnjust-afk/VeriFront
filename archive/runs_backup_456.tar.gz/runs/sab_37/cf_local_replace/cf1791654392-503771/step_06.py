import inspect
from biopsykit.protocols.cft import CFT

for name in ["baseline_hr", "onset", "extract_cft_interval"]:
    obj = getattr(CFT, name)
    src = inspect.getsource(obj)
    print("\n" + "="*60 + f"\n{name} signature: {inspect.signature(obj)}\n" + "="*60)
    print(src)