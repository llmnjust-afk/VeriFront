# inspect_full_onset.py
import inspect
from biopsykit.protocols.cft import CFT

print(inspect.getsource(CFT.onset))
print("\n" + "=" * 80)
print(inspect.getsource(CFT.extract_cft_interval))