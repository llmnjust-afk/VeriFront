# compute_cft_results.py
import json
from pathlib import Path

import numpy as np
import pandas as pd
from biopsykit.protocols.cft import CFT

input_path = Path("mist_hr/hr_sample_mist.xlsx")
output_path = Path("pred_results/cft_pred_results.json")
output_path.parent.mkdir(parents=True, exist_ok=True)

# Load the heart-rate data from sheet "MIST3".
df = pd.read_excel(input_path, sheet_name="MIST3")
print("Loaded MIST3:", df.shape)
print("Columns:", list(df.columns))
print(df.head().to_string(index=False))

# BioPsyKit's CFT implementation expects a datetime index and a single heart-rate column.
hr = df[["time", "Heart_Rate"]].copy()
hr["time"] = pd.to_datetime(hr["time"])
hr = hr.set_index("time")
hr = hr.rename(columns={"Heart_Rate": "Heart_Rate"})
hr = hr.astype(float)

print("Time span:", hr.index[0], "to", hr.index[-1])
print("Duration seconds:", (hr.index[-1] - hr.index[0]).total_seconds())
print("N samples:", len(hr))

# Use the standard CFT protocol structure documented in BioPsyKit:
# 60 s baseline, 120 s cold face exposure, 60 s recovery.
cft = CFT(structure={"Baseline": 60, "CFT": 120, "Recovery": 60})
params = cft.compute_cft_parameter(hr, return_dict=True)

print("All computed CFT parameters:")
for key, value in params.items():
    print(f"  {key}: {value}")

results = {
    "baseline_hr": float(np.asarray(params["baseline_hr"]).squeeze()),
    "onset_hr": float(np.asarray(params["onset_hr"]).squeeze()),
    "onset_hr_percent": float(np.asarray(params["onset_hr_percent"]).squeeze()),
}

with output_path.open("w", encoding="utf-8") as f:
    json.dump(results, f, indent=2, sort_keys=True)

print("Saved required parameters to:", output_path)
print(json.dumps(results, indent=2, sort_keys=True))