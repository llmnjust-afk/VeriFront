from pathlib import Path
import json

import pandas as pd
from biopsykit.protocols import CFT

# Load data
xlsx_path = Path("mist_hr/hr_sample_mist.xlsx")
sheet_name = "MIST3"
df = pd.read_excel(xlsx_path, sheet_name=sheet_name)

print("Loaded:", xlsx_path, "sheet:", sheet_name)
print("Shape:", df.shape)
print("Columns:", list(df.columns))
print(df.head().to_string(index=False))

# Prepare input for CFT
hr = df.copy()
hr["time"] = pd.to_datetime(hr["time"])
hr = hr.set_index("time")[["Heart_Rate"]].sort_index().dropna()

print("\nPrepared HR dataframe")
print("Shape:", hr.shape)
print("Index type:", type(hr.index).__name__)
print("Start:", hr.index[0], "End:", hr.index[-1])
print("Duration (s):", (hr.index[-1] - hr.index[0]).total_seconds())

# Compute CFT parameters
cft = CFT()
params_all = cft.compute_cft_parameter(hr, return_dict=True)

print("\nComputed parameters:")
for k in ["baseline_hr", "onset_hr", "onset_hr_percent", "onset_latency", "onset_idx", "onset_slope"]:
    print(k, "=", params_all.get(k))

required_keys = ["baseline_hr", "onset_hr", "onset_hr_percent"]
results = {}
missing = []
for key in required_keys:
    if key not in params_all:
        missing.append(key)
    else:
        val = params_all[key]
        if hasattr(val, "item"):
            val = val.item()
        results[key] = float(val)

if missing:
    raise KeyError(f"Missing required keys: {missing}")

out_path = Path("pred_results/cft_pred_results.json")
out_path.parent.mkdir(parents=True, exist_ok=True)
with out_path.open("w", encoding="utf-8") as f:
    json.dump(results, f, indent=2, sort_keys=True)

print("\nSaved:", out_path)
print(json.dumps(results, indent=2, sort_keys=True))