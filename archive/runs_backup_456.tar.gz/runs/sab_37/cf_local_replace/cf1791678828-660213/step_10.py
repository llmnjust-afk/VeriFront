import os
import json
from pathlib import Path

import pandas as pd
from biopsykit.protocols import CFT

xlsx = Path("mist_hr/hr_sample_mist.xlsx")
df = pd.read_excel(xlsx, sheet_name="MIST3")
print("raw shape:", df.shape)
print(df.head().to_string(index=False))
print(df.tail().to_string(index=False))
print("dtypes:", df.dtypes.to_dict())

# Prepare BioPsyKit input: DatetimeIndex and only heart-rate column.
hr = df.copy()
hr["time"] = pd.to_datetime(hr["time"])
hr = hr.set_index("time")[["Heart_Rate"]].sort_index()
print("prepared shape:", hr.shape)
print("time span seconds:", (hr.index[-1] - hr.index[0]).total_seconds())
print("first index:", hr.index[0], "last index:", hr.index[-1])
print("HR summary:\n", hr["Heart_Rate"].describe().to_string())

# Default CFT structure is Baseline=60s, CFT=120s, Recovery=60s.
cft = CFT()
params = cft.compute_cft_parameter(hr, return_dict=True)
print("\nBioPsyKit CFT params:")
for k, v in params.items():
    print(k, repr(v), type(v))

selected = {
    "baseline_hr": float(params["baseline_hr"]),
    "onset_hr": float(params["onset_hr"]),
    "onset_hr_percent": float(params["onset_hr_percent"]),
}
print("\nselected:", selected)

out_dir = Path("pred_results")
out_dir.mkdir(parents=True, exist_ok=True)
out_path = out_dir / "cft_pred_results.json"
with out_path.open("w") as f:
    json.dump(selected, f, indent=2)
print("saved:", out_path)
print(out_path.read_text())