# compute_cft_parameters.py
from pathlib import Path
import json
import math

import numpy as np
import pandas as pd
from biopsykit.protocols.cft import CFT

xlsx_path = Path("mist_hr/hr_sample_mist.xlsx")
out_path = Path("pred_results/cft_pred_results.json")
out_path.parent.mkdir(parents=True, exist_ok=True)

# Load heart-rate data from required sheet.
raw = pd.read_excel(xlsx_path, sheet_name="MIST3")
raw = raw[["time", "Heart_Rate"]].dropna().copy()
raw["time"] = pd.to_datetime(raw["time"])
raw["elapsed_s"] = (raw["time"] - raw["time"].iloc[0]).dt.total_seconds()

print("Loaded MIST3:", raw.shape)
print("Time range:", raw["time"].iloc[0], "to", raw["time"].iloc[-1])
print("Elapsed duration (s):", raw["elapsed_s"].iloc[-1])

# Use the standard CFT structure documented in BioPsyKit:
# 60 s baseline, 120 s cold-face exposure, remaining samples recovery.
structure = {"Baseline": 60, "CFT": 120, "Recovery": 60}
cft_start_s = structure["Baseline"]
cft_end_s = cft_start_s + structure["CFT"]

# Compute baseline exactly following BioPsyKit's baseline interval convention:
# interval [recording start, recording start + cft_start].
baseline_mask = (raw["elapsed_s"] >= 0) & (raw["elapsed_s"] <= cft_start_s)
baseline_hr = float(raw.loc[baseline_mask, "Heart_Rate"].mean())

# Compute CFT onset following BioPsyKit CFT.onset:
# The onset is the third heart-rate value in the first CFT bradycardia phase
# with at least 3 consecutive values below baseline HR.
cft_df = raw[(raw["elapsed_s"] >= cft_start_s) & (raw["elapsed_s"] <= cft_end_s)].copy()
below = (cft_df["Heart_Rate"] < baseline_hr).to_numpy()

onset_pos = None
run_start = None
run_len = 0
for i, is_below in enumerate(below):
    if is_below:
        if run_len == 0:
            run_start = i
        run_len += 1
        if run_len == 3:
            onset_pos = run_start + 2  # third beat/value of the bradycardia phase
            break
    else:
        run_start = None
        run_len = 0

if onset_pos is None:
    raise RuntimeError("No CFT onset found: no run of three consecutive HR values below baseline.")

onset_row = cft_df.iloc[onset_pos]
onset_hr = float(onset_row["Heart_Rate"])
onset_hr_percent = float((1.0 - onset_hr / baseline_hr) * 100.0)

# Cross-check the required three values against BioPsyKit's own baseline_hr/onset methods
# where possible (passing only the extracted CFT interval to avoid unrelated package issues).
hr_series_dt = raw.set_index("time")["Heart_Rate"]
cft_series_dt = cft_df.set_index("time")["Heart_Rate"]
bp = CFT(structure=structure)
bp_baseline = bp.baseline_hr(hr_series_dt)
bp_onset = bp.onset(
    cft_series_dt,
    is_cft_interval=True,
    compute_baseline=False,
    hr_baseline=bp_baseline,
)
print("Manual baseline_hr:", baseline_hr)
print("BioPsyKit baseline_hr:", bp_baseline)
print("Manual onset time:", onset_row["time"], "elapsed_s:", onset_row["elapsed_s"], "cft_latency_s:", onset_row["elapsed_s"] - cft_start_s)
print("BioPsyKit onset summary:", {k: str(v) for k, v in bp_onset.items() if k in ["onset", "onset_latency", "onset_idx", "onset_hr", "onset_hr_percent"]})
print("Manual onset_hr:", onset_hr)
print("Manual onset_hr_percent:", onset_hr_percent)

if not math.isclose(baseline_hr, float(bp_baseline), rel_tol=0, abs_tol=1e-12):
    raise RuntimeError("Baseline cross-check failed.")
if not math.isclose(onset_hr, float(bp_onset["onset_hr"]), rel_tol=0, abs_tol=1e-12):
    raise RuntimeError("Onset HR cross-check failed.")
if not math.isclose(onset_hr_percent, float(bp_onset["onset_hr_percent"]), rel_tol=0, abs_tol=1e-12):
    raise RuntimeError("Onset percent cross-check failed.")

results = {
    "baseline_hr": baseline_hr,
    "onset_hr": onset_hr,
    "onset_hr_percent": onset_hr_percent,
}

with out_path.open("w", encoding="utf-8") as f:
    json.dump(results, f, indent=2)

print("Saved:", out_path)
print(json.dumps(results, indent=2))