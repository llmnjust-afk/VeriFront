# inspect_full_methods_and_manual.py
import inspect
from biopsykit.protocols.cft import CFT

for meth in ["onset", "extract_cft_interval", "peak_bradycardia", "mean_bradycardia", "poly_fit"]:
    print("\n" + "="*120)
    print("METHOD", meth)
    print(inspect.getsource(getattr(CFT, meth)))