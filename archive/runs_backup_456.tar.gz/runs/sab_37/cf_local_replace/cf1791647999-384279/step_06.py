# run_biopsykit_cft_default.py
from pathlib import Path
import json
import pandas as pd
import numpy as np
from biopsykit.protocols.cft import CFT

df = pd.read_excel("mist_hr/hr_sample_mist.xlsx", sheet_name="MIST3")
hr = df[["Heart_Rate"]].copy()
# BioPsyKit expects the index to encode elapsed seconds or DatetimeIndex; keep absolute datetime index.
hr.index = pd.DatetimeIndex(df["time"])
hr = hr["Heart_Rate"]  # many methods use float(data.loc[idx]) and mean(); Series works best

for structure in [
    {"Baseline": 60, "CFT": 120, "Recovery": 60},
    {"Baseline": 0, "CFT": 120, "Recovery": 60},
    {"Baseline": 30, "CFT": 120, "Recovery": 60},
]:
    print("\nStructure", structure)
    cft = CFT(structure=structure)
    try:
        params = cft.compute_cft_parameter(hr, return_dict=True)
        for k, v in params.items():
            if isinstance(v, (np.integer, np.floating)):
                v = float(v)
            print(k, repr(v))
    except Exception as e:
        print("ERROR", type(e).__name__, str(e))

# Also try elapsed-seconds numeric index because DatetimeIndex extraction can have edge cases with dates.
hr2 = df[["Heart_Rate"]].copy()
hr2.index = (df["time"] - df["time"].iloc[0]).dt.total_seconds()
hr2 = hr2["Heart_Rate"]
for structure in [
    {"Baseline": 60, "CFT": 120, "Recovery": 60},
    {"Baseline": 0, "CFT": 120, "Recovery": 60},
    {"Baseline": 30, "CFT": 120, "Recovery": 60},
]:
    print("\nNumeric index structure", structure)
    cft = CFT(structure=structure)
    try:
        params = cft.compute_cft_parameter(hr2, return_dict=True)
        for k, v in params.items():
            if isinstance(v, (np.integer, np.floating)):
                v = float(v)
            print(k, repr(v))
    except Exception as e:
        print("ERROR", type(e).__name__, str(e))