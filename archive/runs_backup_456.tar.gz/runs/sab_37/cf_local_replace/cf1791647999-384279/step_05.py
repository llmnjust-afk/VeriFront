# inspect_onset_and_baseline.py
import inspect
from biopsykit.protocols.cft import CFT
from biopsykit.protocols import BaseProtocol

for meth in ["baseline_hr", "onset", "extract_cft_interval", "peak_bradycardia"]:
    print("\n" + "="*100)
    print("METHOD", meth)
    try:
        print(inspect.getsource(getattr(CFT, meth)))
    except Exception as e:
        print("err", e)

print("\n\n=== BaseProtocol members ===")
print([x for x in dir(BaseProtocol) if not x.startswith("__")])