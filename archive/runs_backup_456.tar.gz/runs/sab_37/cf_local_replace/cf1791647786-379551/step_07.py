# compute_cft_results.py
import json
from pathlib import Path

import pandas as pd
from biopsykit.protocols import CFT

# Paths
input_path = Path("mist_hr/hr_sample_mist.xlsx")
output_path = Path("pred_results/cft_pred_results.json")
output_path.parent.mkdir(parents=True, exist_ok=True)

# Load heart-rate data from the required sheet.
df = pd.read_excel(input_path, sheet_name="MIST3")
hr = df[["time", "Heart_Rate"]].dropna().copy()
hr["time"] = pd.to_datetime(hr["time"])
hr = hr.set_index("time")
# BioPsyKit CFT functions expect a single-column HR dataframe/series indexed by time.
hr = hr.rename(columns={"Heart_Rate": "Heart_Rate"})

print("Loaded MIST3 HR data")
print("Shape:", hr.shape)
print("Start:", hr.index[0], "End:", hr.index[-1])
print("Duration seconds:", (hr.index[-1] - hr.index[0]).total_seconds())

# Use BioPsyKit's default CFT structure:
# Baseline = first 60 s, CFT exposure = next 120 s, Recovery = remaining/nominal 60 s.
# Required parameters are computed according to BioPsyKit definitions:
# baseline_hr: mean HR during baseline interval
# onset_hr: HR at the CFT onset (third consecutive HR sample below baseline during CFT)
# onset_hr_percent: relative bradycardia at onset = (1 - onset_hr / baseline_hr) * 100
cft = CFT()
params = cft.compute_cft_parameter(hr, return_dict=True)

# Convert any pandas/numpy scalar values to regular JSON-serializable floats.
results = {
    "baseline_hr": float(params["baseline_hr"]),
    "onset_hr": float(params["onset_hr"]),
    "onset_hr_percent": float(params["onset_hr_percent"]),
}

with output_path.open("w", encoding="utf-8") as f:
    json.dump(results, f, indent=2, sort_keys=True)

print("Computed required CFT parameters:")
print(json.dumps(results, indent=2, sort_keys=True))
print(f"Saved JSON to: {output_path}")