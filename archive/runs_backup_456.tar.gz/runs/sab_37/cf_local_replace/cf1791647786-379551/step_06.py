# inspect_onset_full.py
import inspect
from biopsykit.protocols.cft import CFT

src = inspect.getsource(CFT.onset)
print(src)