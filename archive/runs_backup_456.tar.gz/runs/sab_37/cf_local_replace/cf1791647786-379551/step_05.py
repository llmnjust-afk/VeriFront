# inspect_baseline_onset_methods.py
import inspect
from biopsykit.protocols.cft import CFT

for name in ["baseline_hr", "onset", "extract_cft_interval"]:
    fn = getattr(CFT, name)
    print("\n" + "="*80)
    print(name, inspect.signature(fn))
    print(inspect.getsource(fn))