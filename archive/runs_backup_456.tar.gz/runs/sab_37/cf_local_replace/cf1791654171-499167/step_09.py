import json
from pathlib import Path

import pandas as pd
from biopsykit.protocols import CFT

# Paths
xlsx_path = Path("mist_hr/hr_sample_mist.xlsx")
out_path = Path("pred_results/cft_pred_results.json")
out_path.parent.mkdir(parents=True, exist_ok=True)

# Load heart-rate data from sheet MIST3.
df = pd.read_excel(xlsx_path, sheet_name="MIST3")
df["time"] = pd.to_datetime(df["time"])
df = df.sort_values("time").set_index("time")

print("Loaded MIST3")
print("Rows:", len(df))
print("Columns:", list(df.columns))
print("Start:", df.index[0])
print("End:", df.index[-1])
print("Duration seconds:", (df.index[-1] - df.index[0]).total_seconds())

# Compute CFT parameters with BioPsyKit's default CFT structure:
# Baseline: first 60 s, CFT: next 120 s, Recovery: 60 s.
cft = CFT()
cft_params = cft.compute_cft_parameter(df, return_dict=True)

# Required output keys only.
results = {
    "baseline_hr": float(cft_params["baseline_hr"]),
    "onset_hr": float(cft_params["onset_hr"]),
    "onset_hr_percent": float(cft_params["onset_hr_percent"]),
}

print("Computed required CFT parameters:")
for key, value in results.items():
    print(f"{key}: {value}")

with out_path.open("w", encoding="utf-8") as f:
    json.dump(results, f, indent=2)

print("Saved:", out_path)
print("JSON content:")
print(json.dumps(results, indent=2))