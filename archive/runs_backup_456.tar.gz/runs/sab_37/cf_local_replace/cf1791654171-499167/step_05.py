import inspect
from biopsykit.protocols.cft import CFT
import biopsykit.protocols.cft as cftmod

print("CFT methods/properties containing compute/param/hr/onset/baseline:")
for name, obj in inspect.getmembers(CFT):
    if any(t in name.lower() for t in ["compute", "param", "hr", "onset", "baseline", "feature", "data"]):
        print(name, type(obj))
        try:
            print(" signature:", inspect.signature(obj))
        except Exception:
            pass

print("\nFull source for public CFT methods (first 250 lines chunks around parameter methods):")
src = inspect.getsource(CFT)
lines = src.splitlines()
for i, line in enumerate(lines):
    if any(t in line.lower() for t in ["def compute", "parameter", "baseline", "onset", "heart", "hr"]):
        start = max(0, i-8)
        end = min(len(lines), i+80)
        print("\n--- lines", start+1, "to", end, "---")
        print("\n".join(f"{j+1:04d}: {lines[j]}" for j in range(start, end)))

print("\nModule-level funcs/classes:")
for name, obj in inspect.getmembers(cftmod):
    if inspect.isfunction(obj) or inspect.isclass(obj):
        print(name, type(obj))
        if name.startswith("_") or any(t in name.lower() for t in ["hr", "param", "onset", "baseline", "cft"]):
            try:
                print(inspect.signature(obj))
            except Exception:
                pass
            try:
                s = inspect.getsource(obj)
                print("\n".join(s.splitlines()[:80]))
            except Exception as e:
                print("no source", e)