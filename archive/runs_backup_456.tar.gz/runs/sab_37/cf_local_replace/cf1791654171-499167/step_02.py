import json
from pathlib import Path

import numpy as np
import pandas as pd

xlsx = Path("mist_hr/hr_sample_mist.xlsx")
out_path = Path("pred_results/cft_pred_results.json")
out_path.parent.mkdir(parents=True, exist_ok=True)

df = pd.read_excel(xlsx, sheet_name="MIST3")
df["time"] = pd.to_datetime(df["time"])
df = df.sort_values("time").reset_index(drop=True)

# Robustly estimate the baseline as the pre-test resting HR in the MIST3 sheet:
# use the first 60 seconds (or all data if shorter), which is before the onset of
# the cold face response in this segment.
t0 = df["time"].iloc[0]
baseline_window = df[df["time"] <= t0 + pd.Timedelta(seconds=60)]
if len(baseline_window) < 5:
    baseline_window = df.iloc[:min(60, len(df))]
baseline_hr = float(baseline_window["Heart_Rate"].mean())

# Detect the onset as the first sustained decrease below baseline by at least 3 bpm
# for 3 consecutive samples, using a short centered rolling mean for stability.
hr_smooth = df["Heart_Rate"].rolling(window=5, center=True, min_periods=1).mean()
below = hr_smooth <= (baseline_hr - 3.0)

onset_idx = None
for i in range(2, len(df)):
    if bool(below.iloc[i-2]) and bool(below.iloc[i-1]) and bool(below.iloc[i]):
        onset_idx = i - 2
        break

if onset_idx is None:
    # fallback: strongest drop point relative to baseline
    onset_idx = int((baseline_hr - hr_smooth).idxmax())

onset_hr = float(df.loc[onset_idx, "Heart_Rate"])
onset_hr_percent = float((onset_hr / baseline_hr) * 100.0)

results = {
    "baseline_hr": baseline_hr,
    "onset_hr": onset_hr,
    "onset_hr_percent": onset_hr_percent,
}

print("baseline_hr:", baseline_hr)
print("onset_idx:", onset_idx)
print("onset_hr:", onset_hr)
print("onset_hr_percent:", onset_hr_percent)

with open(out_path, "w", encoding="utf-8") as f:
    json.dump(results, f, indent=2)

print("saved to:", out_path)