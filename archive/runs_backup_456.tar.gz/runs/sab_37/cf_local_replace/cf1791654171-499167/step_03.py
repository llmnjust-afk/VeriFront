from pathlib import Path
import json
import numpy as np
import pandas as pd

print("checking BioPsyKit availability and data characteristics")
try:
    import biopsykit as bp
    print("biopsykit version:", getattr(bp, "__version__", "unknown"))
    print("biopsykit module:", bp)
except Exception as e:
    print("biopsykit import failed:", repr(e))

xlsx = Path("mist_hr/hr_sample_mist.xlsx")
df = pd.read_excel(xlsx, sheet_name="MIST3")
df["time"] = pd.to_datetime(df["time"])
df = df.sort_values("time").reset_index(drop=True)
df["sec"] = (df["time"] - df["time"].iloc[0]).dt.total_seconds()

print("rows", len(df), "duration_s", df["sec"].iloc[-1])
print("HR describe:")
print(df["Heart_Rate"].describe().to_string())

# Print coarser temporal summaries to infer phases/onset.
bins = np.arange(0, df["sec"].iloc[-1] + 30, 30)
df["bin30"] = pd.cut(df["sec"], bins=bins, right=False)
summary = df.groupby("bin30", observed=False)["Heart_Rate"].agg(["count", "mean", "median", "min", "max"])
print("\n30s bins:")
print(summary.to_string())

# Rolling minima/maxima in early period
for win in [10, 20, 30, 60]:
    sub = df[df["sec"] < win]
    print(f"first {win}s: n={len(sub)} mean={sub['Heart_Rate'].mean():.6f} median={sub['Heart_Rate'].median():.6f} min={sub['Heart_Rate'].min():.6f} max={sub['Heart_Rate'].max():.6f}")

print("\nfirst 100 rows:")
print(df[["sec", "time", "Heart_Rate"]].head(100).to_string(index=True))
print("\nlast 40 rows:")
print(df[["sec", "time", "Heart_Rate"]].tail(40).to_string(index=True))