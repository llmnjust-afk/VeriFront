import inspect
import pkgutil
import biopsykit

print("biopsykit", biopsykit.__version__)

# Search for CFT-related modules/classes/functions in biopsykit
matches = []
for modinfo in pkgutil.walk_packages(biopsykit.__path__, biopsykit.__name__ + "."):
    name = modinfo.name
    if any(term in name.lower() for term in ["cft", "cold", "face"]):
        matches.append(name)
print("module name matches:", matches)

# Broader search by importing selected likely namespaces and listing cft names
candidate_modules = [
    "biopsykit.protocols",
    "biopsykit.protocols.cft",
    "biopsykit.protocols.cft.cft",
    "biopsykit.protocols.cft.cft_parameter",
    "biopsykit.utils",
    "biopsykit.signals",
]
for mname in candidate_modules:
    try:
        mod = __import__(mname, fromlist=["*"])
        print("\nMODULE", mname, "loaded")
        attrs = [a for a in dir(mod) if any(t in a.lower() for t in ["cft", "cold", "face", "onset", "baseline"])]
        print("attrs:", attrs)
        for a in attrs:
            obj = getattr(mod, a)
            print(" ", a, type(obj))
            try:
                sig = inspect.signature(obj)
                print("   sig", sig)
            except Exception:
                pass
            try:
                src = inspect.getsource(obj)
                print("   source first lines:")
                print("\n".join(src.splitlines()[:40]))
            except Exception as e:
                print("   no source", repr(e)[:120])
    except Exception as e:
        print("\nMODULE", mname, "failed:", repr(e))