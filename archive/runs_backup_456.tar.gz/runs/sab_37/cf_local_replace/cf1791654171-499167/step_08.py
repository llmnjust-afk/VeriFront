from pathlib import Path
import json
import pandas as pd
from biopsykit.protocols import CFT

xlsx = Path("mist_hr/hr_sample_mist.xlsx")
df = pd.read_excel(xlsx, sheet_name="MIST3")
df["time"] = pd.to_datetime(df["time"])
df = df.sort_values("time").set_index("time")
print("input head:")
print(df.head().to_string())
print("index type:", type(df.index), "columns:", list(df.columns), "duration:", (df.index[-1]-df.index[0]).total_seconds())

for structure in [
    {"Baseline": 60, "CFT": 120, "Recovery": 60},
    {"Baseline": 30, "CFT": 120, "Recovery": 60},
    {"Baseline": 0, "CFT": 120, "Recovery": 60},
]:
    print("\nTrying structure", structure)
    cft = CFT(structure=structure)
    try:
        res_dict = cft.compute_cft_parameter(df, return_dict=True)
        print("result dict:")
        for k, v in res_dict.items():
            print(" ", k, repr(v))
        res_df = cft.compute_cft_parameter(df, index="MIST3", return_dict=False)
        print("result dataframe:")
        print(res_df.to_string())
    except Exception as e:
        print("failed:", type(e).__name__, repr(e))