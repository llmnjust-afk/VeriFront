import inspect
from biopsykit.protocols.cft import CFT

for method_name in ["__init__", "compute_cft_parameter", "baseline_hr", "min_hr", "max_hr", "onset_hr", "onset_time", "hr_diff", "hr_percent"]:
    if hasattr(CFT, method_name):
        obj = getattr(CFT, method_name)
        print("\n###", method_name, "###")
        try:
            print("signature:", inspect.signature(obj))
        except Exception as e:
            print("no sig", e)
        try:
            src = inspect.getsource(obj)
            print(src[:8000])
        except Exception as e:
            print("no source:", repr(e))

# print all methods in vicinity of compute_cft_parameter only
src = inspect.getsource(CFT)
lines = src.splitlines()
for idx, line in enumerate(lines):
    if "def compute_cft_parameter" in line:
        start = idx
        end = min(len(lines), idx+220)
        print("\n### compute_cft_parameter vicinity numbered ###")
        print("\n".join(f"{j+1:04d}: {lines[j]}" for j in range(start, end)))
        break