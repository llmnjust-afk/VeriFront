import inspect
from biopsykit.protocols.cft import CFT

src = inspect.getsource(CFT.compute_cft_parameter)
print("compute_cft_parameter source:")
print(src)

for method_name in ["baseline_hr", "onset_hr", "onset_time", "min_hr", "max_hr", "hr_diff", "hr_percent"]:
    if hasattr(CFT, method_name):
        print("\n---", method_name, "---")
        print(inspect.getsource(getattr(CFT, method_name)))