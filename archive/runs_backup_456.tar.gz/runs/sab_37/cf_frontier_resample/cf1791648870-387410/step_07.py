import inspect
from biopsykit.protocols.cft import CFT

for name in ["baseline_hr", "extract_cft_interval", "onset"]:
    obj = getattr(CFT, name)
    print("\n" + "="*60)
    print(name, inspect.signature(obj))
    src = inspect.getsource(obj)
    lines = src.splitlines()
    for i, line in enumerate(lines, 1):
        print(f"{i:03d}: {line}")