import importlib.util
import pkgutil
import inspect
from pathlib import Path

mods = ["biopsykit", "neurokit2", "heartpy"]
for m in mods:
    spec = importlib.util.find_spec(m)
    print(m, "installed:", spec is not None, "origin:", spec.origin if spec else None)

if importlib.util.find_spec("biopsykit"):
    import biopsykit
    print("biopsykit version:", getattr(biopsykit, "__version__", "unknown"))
    print("biopsykit path:", biopsykit.__path__)
    names = []
    for mod in pkgutil.walk_packages(biopsykit.__path__, biopsykit.__name__ + "."):
        if any(k in mod.name.lower() for k in ["cft", "cold", "mist", "hr"]):
            names.append(mod.name)
    print("candidate modules:", names[:200])
    for name in names:
        try:
            module = importlib.import_module(name)
            print("\nMODULE", name)
            for obj_name in dir(module):
                if any(k in obj_name.lower() for k in ["cft", "cold", "hr", "heart", "onset", "baseline"]):
                    obj = getattr(module, obj_name)
                    print(" ", obj_name, type(obj))
                    if inspect.isfunction(obj) or inspect.isclass(obj):
                        try:
                            print("   sig:", inspect.signature(obj))
                        except Exception:
                            pass
                        doc = inspect.getdoc(obj)
                        if doc:
                            print("   doc:", doc[:500].replace("\n", " "))
        except Exception as e:
            print("FAILED import", name, repr(e))