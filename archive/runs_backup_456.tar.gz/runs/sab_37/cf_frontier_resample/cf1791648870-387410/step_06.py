import inspect
from biopsykit.protocols.cft import CFT

names = ["compute_cft_parameter", "baseline_hr", "onset", "peak_bradycardia", "mean_bradycardia", "poly_fit"]
for name in names:
    obj = getattr(CFT, name)
    print("\n" + "="*60)
    print(name, inspect.signature(obj))
    src = inspect.getsource(obj)
    lines = src.splitlines()
    for i, line in enumerate(lines, 1):
        print(f"{i:03d}: {line}")