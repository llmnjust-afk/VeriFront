import inspect
from biopsykit.protocols.cft import CFT

for name in ["__init__", "compute_cft_parameter", "baseline_hr", "onset", "peak_bradycardia", "mean_bradycardia", "poly_fit", "_get_times", "_get_cft_data"]:
    if hasattr(CFT, name):
        obj = getattr(CFT, name)
        print("\n" + "="*80)
        print("METHOD", name, "signature", inspect.signature(obj))
        src = inspect.getsource(obj)
        print(src[:6000])
        if len(src) > 6000:
            print("...TRUNCATED len", len(src))