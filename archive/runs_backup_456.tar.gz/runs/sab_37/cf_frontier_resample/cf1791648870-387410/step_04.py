import inspect
import re
from pathlib import Path
from biopsykit.protocols.cft import CFT

src_path = Path(inspect.getsourcefile(CFT))
print("source path:", src_path)
text = src_path.read_text()

for pat in ["def cft", "def .*param", "onset", "baseline_hr", "onset_hr", "bradycardia", "compute_cft"]:
    print("\n=== matches for", pat, "===")
    for m in re.finditer(pat, text, flags=re.IGNORECASE):
        start = max(0, m.start() - 300)
        end = min(len(text), m.start() + 1200)
        print(text[start:end])
        print("---")

# print all def names in file
print("\nALL DEFS:")
for m in re.finditer(r"^\s*def\s+([A-Za-z0-9_]+)\s*\(", text, flags=re.MULTILINE):
    print(m.group(1), "at", m.start())

# Show full source of selected methods likely useful
selected = [
    "cft_parameter", "cft_params", "compute_cft_parameter", "compute_cft_params",
    "cft_plot", "_compute_cft_params", "_cft_plot_add_baseline",
    "_cft_plot_add_onset", "_cft_plot_add_peak_bradycardia", "_cft_plot_add_mean_bradycardia"
]
for name in selected:
    if hasattr(CFT, name):
        print("\n\n### SOURCE", name, "###")
        print(inspect.getsource(getattr(CFT, name)))