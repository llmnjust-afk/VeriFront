import os
import json
from pathlib import Path

import pandas as pd

xlsx = Path("mist_hr/hr_sample_mist.xlsx")
print("exists", xlsx.exists(), "size", xlsx.stat().st_size if xlsx.exists() else None)

if not xlsx.exists():
    raise FileNotFoundError(xlsx)

xl = pd.ExcelFile(xlsx)
print("sheets:", xl.sheet_names)

for sheet in xl.sheet_names:
    df_head = pd.read_excel(xlsx, sheet_name=sheet, nrows=10)
    df_info = pd.read_excel(xlsx, sheet_name=sheet, nrows=0)
    print("\nSHEET", sheet)
    print("columns:", list(df_info.columns))
    print(df_head.to_string(index=False))
    try:
        # read only first column to get approximate row count efficiently
        col0 = pd.read_excel(xlsx, sheet_name=sheet, usecols=[0])
        print("rows:", len(col0), "first/last first-col:", col0.iloc[0,0], col0.iloc[-1,0])
    except Exception as e:
        print("row count failed:", repr(e))