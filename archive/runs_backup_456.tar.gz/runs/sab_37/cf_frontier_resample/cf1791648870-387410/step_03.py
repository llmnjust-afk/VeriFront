import inspect
from pathlib import Path
import biopsykit.protocols.cft as cft

print("CFT class:", cft.CFT)
print("signature:", inspect.signature(cft.CFT))
print("source file:", inspect.getsourcefile(cft.CFT))
print("\nCFT doc:\n", inspect.getdoc(cft.CFT))

print("\nMethods/attrs containing param/result/hr/base/onset:")
for name, obj in inspect.getmembers(cft.CFT):
    if any(k in name.lower() for k in ["param", "result", "hr", "heart", "base", "onset", "process", "compute", "analy", "add"]):
        print(name, type(obj))
        if inspect.isfunction(obj) or inspect.ismethoddescriptor(obj) or isinstance(obj, property):
            try:
                target = obj.fget if isinstance(obj, property) else obj
                print(" sig:", inspect.signature(target))
            except Exception as e:
                print(" sig err", e)
            try:
                target = obj.fget if isinstance(obj, property) else obj
                doc = inspect.getdoc(target)
                if doc:
                    print(" doc:", doc[:1000].replace("\n", " "))
            except Exception:
                pass

src = inspect.getsource(cft.CFT)
print("\nSOURCE SNIPPET START")
print(src[:12000])
print("SOURCE SNIPPET END")