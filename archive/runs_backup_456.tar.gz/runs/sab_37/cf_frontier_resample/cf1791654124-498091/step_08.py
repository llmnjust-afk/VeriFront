import json
from pathlib import Path

import pandas as pd
import numpy as np
from biopsykit.protocols import CFT

input_path = Path("mist_hr/hr_sample_mist.xlsx")
sheet = "MIST3"

df = pd.read_excel(input_path, sheet_name=sheet)
print("Loaded shape:", df.shape)
print("Columns:", list(df.columns))
print("Head:")
print(df.head().to_string(index=False))
print("Tail:")
print(df.tail().to_string(index=False))

# Prepare heart-rate dataframe for BioPsyKit CFT: DatetimeIndex + one HR column.
hr = df[["time", "Heart_Rate"]].copy()
hr["time"] = pd.to_datetime(hr["time"])
hr = hr.set_index("time").sort_index()
hr = hr.rename(columns={"Heart_Rate": "Heart_Rate"})
hr = hr.dropna()
print("Prepared shape:", hr.shape)
print("Time span seconds:", (hr.index[-1] - hr.index[0]).total_seconds())
print("First/last:", hr.index[0], hr.index[-1])

# Typical CFT structure: 60 s baseline, 120 s cold-face exposure, 60 s recovery.
# This sheet is long enough for the first two phases needed by the requested parameters.
protocol = CFT(structure={"Baseline": 60, "CFT": 120, "Recovery": 60})
results = protocol.compute_cft_parameter(hr, return_dict=True)

print("Full BioPsyKit CFT results:")
for k, v in results.items():
    print(k, repr(v), type(v))

selected = {
    "baseline_hr": float(np.asarray(results["baseline_hr"]).squeeze()),
    "onset_hr": float(np.asarray(results["onset_hr"]).squeeze()),
    "onset_hr_percent": float(np.asarray(results["onset_hr_percent"]).squeeze()),
}

out_dir = Path("pred_results")
out_dir.mkdir(parents=True, exist_ok=True)
out_path = out_dir / "cft_pred_results.json"
with out_path.open("w", encoding="utf-8") as f:
    json.dump(selected, f, indent=2, sort_keys=True)

print("Selected results:")
print(json.dumps(selected, indent=2, sort_keys=True))
print("Saved to:", out_path)