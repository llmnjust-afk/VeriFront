import inspect
from pathlib import Path
from biopsykit.protocols.cft import CFT

src = inspect.getsource(CFT.onset)
print(src)
print("source file:", inspect.getsourcefile(CFT.onset), "line:", inspect.getsourcelines(CFT.onset)[1])