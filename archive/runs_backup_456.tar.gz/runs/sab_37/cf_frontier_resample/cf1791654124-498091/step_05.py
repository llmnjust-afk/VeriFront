import inspect
from biopsykit.protocols.cft import CFT

for name in ["compute_cft_parameter", "baseline_hr", "onset", "bradycardia", "max_hr", "cft_plot"]:
    obj = getattr(CFT, name, None)
    print("\n" + "="*80)
    print(name, obj)
    if obj:
        print("signature", inspect.signature(obj))
        print(inspect.getsource(obj))