import importlib.util
import sys
import pkgutil

mods = ["biopsykit", "neurokit2", "pingouin", "openpyxl", "scipy", "numpy", "pandas"]
for m in mods:
    spec = importlib.util.find_spec(m)
    print(m, "FOUND" if spec else "not found", spec.origin if spec else "")

if importlib.util.find_spec("biopsykit"):
    import biopsykit
    print("biopsykit version", getattr(biopsykit, "__version__", "unknown"))
    print("biopsykit path", biopsykit.__file__)
    # list potentially relevant modules
    names = []
    for mod in pkgutil.walk_packages(biopsykit.__path__, biopsykit.__name__ + "."):
        if any(k in mod.name.lower() for k in ["cft", "cold", "heart", "hr", "cardio", "feature"]):
            names.append(mod.name)
    print("relevant modules count", len(names))
    for n in names[:200]:
        print(n)