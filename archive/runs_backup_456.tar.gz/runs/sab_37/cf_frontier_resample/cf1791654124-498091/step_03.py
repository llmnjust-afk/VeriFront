import inspect
import biopsykit.protocols.cft as cft

print("module", cft)
print("members:")
for name, obj in inspect.getmembers(cft):
    if not name.startswith("_"):
        print(name, type(obj))

for name, obj in inspect.getmembers(cft):
    if inspect.isclass(obj) or inspect.isfunction(obj):
        print("\n===", name, "===")
        try:
            print(inspect.signature(obj))
        except Exception as e:
            print("sig err", e)
        try:
            src = inspect.getsource(obj)
            print(src[:6000])
        except Exception as e:
            print("src err", e)