import inspect
from biopsykit.protocols.cft import CFT

print("CFT signature:", inspect.signature(CFT))
src = inspect.getsource(CFT)
print(src)