import inspect
from biopsykit.protocols.cft import CFT

for name in ["baseline_hr", "onset", "peak_bradycardia", "mean_bradycardia", "poly_fit", "extract_cft_interval"]:
    obj = getattr(CFT, name, None)
    print("\n" + "="*60 + "\n" + name)
    src = inspect.getsource(obj)
    print(src)