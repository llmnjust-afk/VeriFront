# inspect_compute_cft_parameter.py
import inspect
from biopsykit.protocols.cft import CFT

src = inspect.getsource(CFT.compute_cft_parameter)
print(src)