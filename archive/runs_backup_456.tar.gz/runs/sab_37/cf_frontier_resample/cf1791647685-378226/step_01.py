# inspect_dataset.py
import os
import json
from pathlib import Path

import pandas as pd

xlsx_path = Path("mist_hr/hr_sample_mist.xlsx")
print(f"Exists: {xlsx_path.exists()} size={xlsx_path.stat().st_size if xlsx_path.exists() else 'NA'}")

if xlsx_path.exists():
    xl = pd.ExcelFile(xlsx_path)
    print("Sheets:", xl.sheet_names)
    for sheet in xl.sheet_names:
        df_head = pd.read_excel(xlsx_path, sheet_name=sheet, nrows=5)
        print(f"\nSheet {sheet!r} head shape {df_head.shape}")
        print(df_head.to_string())
        df_info = pd.read_excel(xlsx_path, sheet_name=sheet, usecols=None)
        print(f"Sheet {sheet!r} full shape {df_info.shape}")
        print("Columns:", list(df_info.columns))
        print("Dtypes:", df_info.dtypes.astype(str).to_dict())
        print("Describe numeric:")
        print(df_info.describe().to_string())