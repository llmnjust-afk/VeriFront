# inspect_onset_full.py
import inspect
from biopsykit.protocols.cft import CFT

src = inspect.getsource(CFT.onset)
print(src)

# Also test possible structures on MIST3 with BioPsyKit
import pandas as pd
from pathlib import Path

df = pd.read_excel("mist_hr/hr_sample_mist.xlsx", sheet_name="MIST3")
s = df.set_index("time")["Heart_Rate"]
print("\nData start/end/duration:", s.index[0], s.index[-1], (s.index[-1]-s.index[0]).total_seconds(), "n", len(s))

structures = [
    {"Baseline": 60, "CFT": 120, "Recovery": 60},
    {"Baseline": 0, "CFT": 120, "Recovery": 60},
    {"Baseline": 30, "CFT": 120, "Recovery": 60},
    {"Baseline": 60, "CFT": 120},
    {"Baseline": 60, "CFT": 158},
]
for st in structures:
    try:
        cft = CFT(structure=st)
        res = cft.compute_cft_parameter(s, return_dict=True)
        print("\nSTRUCT", st)
        for k,v in res.items():
            print(k, repr(v))
    except Exception as e:
        print("\nSTRUCT", st, "ERROR", type(e).__name__, str(e))