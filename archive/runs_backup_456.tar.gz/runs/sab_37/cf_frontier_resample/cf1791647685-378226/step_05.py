# inspect_cft_param_methods.py
import inspect
from biopsykit.protocols.cft import CFT

for name in ["extract_cft_interval", "baseline_hr", "onset", "peak_bradycardia", "mean_bradycardia", "poly_fit"]:
    print("\n" + "="*100)
    print(name, inspect.signature(getattr(CFT, name)))
    print(inspect.getsource(getattr(CFT, name)))