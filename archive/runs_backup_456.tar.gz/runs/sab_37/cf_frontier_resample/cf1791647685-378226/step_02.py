# explore_biopsykit_and_data.py
from pathlib import Path
import importlib.util
import inspect
import pkgutil
import pandas as pd
import numpy as np

print("biopsykit installed?", importlib.util.find_spec("biopsykit") is not None)
if importlib.util.find_spec("biopsykit") is not None:
    import biopsykit
    print("biopsykit version:", getattr(biopsykit, "__version__", "unknown"))
    names = []
    for mod in pkgutil.walk_packages(biopsykit.__path__, biopsykit.__name__ + "."):
        if "cft" in mod.name.lower() or "cold" in mod.name.lower():
            names.append(mod.name)
    print("modules containing cft/cold:", names)
    for name in names:
        try:
            m = __import__(name, fromlist=["*"])
            print("\nMODULE", name)
            print("members:", [x for x in dir(m) if "cft" in x.lower() or "cold" in x.lower() or "Cft" in x])
            src = inspect.getsource(m)
            print(src[:4000])
        except Exception as e:
            print("could not inspect", name, e)

df = pd.read_excel("mist_hr/hr_sample_mist.xlsx", sheet_name="MIST3")
df = df.rename(columns={"time": "time", "Heart_Rate": "hr"})
df["t"] = (df["time"] - df["time"].iloc[0]).dt.total_seconds()
print("MIST3 duration", df["t"].iloc[-1], "n", len(df))
# window summaries to understand transitions
for win in [5,10,15,20,30,45,60]:
    print(f"mean first {win}s", df.loc[df.t <= win, "hr"].mean(),
          f"median", df.loc[df.t <= win, "hr"].median(),
          f"n", (df.t <= win).sum())
print("last 10s mean", df.loc[df.t >= df.t.max()-10, "hr"].mean())
# Print 10 s binned HR statistics
bins = np.arange(0, df["t"].max()+10, 10)
df["bin"] = pd.cut(df["t"], bins=bins, right=False, include_lowest=True)
summ = df.groupby("bin", observed=True)["hr"].agg(["count","mean","median","min","max"]).reset_index()
print("\n10-s bin summary:")
print(summ.to_string(index=False))
# Extremes with times
print("\nLowest 10 points:")
print(df.nsmallest(10, "hr")[["time","t","hr"]].to_string(index=False))
print("\nHighest 10 points:")
print(df.nlargest(10, "hr")[["time","t","hr"]].to_string(index=False))