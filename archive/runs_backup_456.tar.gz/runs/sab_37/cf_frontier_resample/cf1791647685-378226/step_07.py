# compute_cft_results.py
from pathlib import Path
import json
import pandas as pd
import numpy as np

input_path = Path("mist_hr/hr_sample_mist.xlsx")
sheet = "MIST3"
out_path = Path("pred_results/cft_pred_results.json")
out_path.parent.mkdir(parents=True, exist_ok=True)

# Load heart-rate data from the required sheet
df = pd.read_excel(input_path, sheet_name=sheet)
print("Loaded", input_path, "sheet", sheet, "shape", df.shape)
print("Columns:", list(df.columns))

# Normalize to a simple HR Series with a DatetimeIndex.
time_col = "time" if "time" in df.columns else "timestamps"
hr_col = "Heart_Rate" if "Heart_Rate" in df.columns else None
if hr_col is None:
    # Fallback for raw samples is not expected here; fail clearly if no HR column exists.
    numeric_cols = [c for c in df.columns if c != time_col and pd.api.types.is_numeric_dtype(df[c])]
    raise ValueError(f"No Heart_Rate column found. Numeric columns available: {numeric_cols}")

df[time_col] = pd.to_datetime(df[time_col])
hr = pd.Series(df[hr_col].astype(float).to_numpy(), index=pd.DatetimeIndex(df[time_col]), name=hr_col).sort_index()

# BioPsyKit's default CFT protocol structure is Baseline=60 s, CFT=120 s, Recovery=60 s.
# The benchmark asks for CFT parameters; compute the core definitions directly for robustness:
# - baseline_hr: mean HR over [recording_start, recording_start + 60 s]
# - onset: during the CFT interval, the third consecutive HR value below baseline
# - onset_hr_percent: (1 - onset_hr / baseline_hr) * 100
baseline_duration_s = 60.0
cft_duration_s = 120.0

start = hr.index[0]
baseline_end = start + pd.Timedelta(seconds=baseline_duration_s)
cft_start = baseline_end
cft_end = cft_start + pd.Timedelta(seconds=cft_duration_s)

baseline_hr_series = hr.loc[(hr.index >= start) & (hr.index <= baseline_end)]
cft_hr_series = hr.loc[(hr.index >= cft_start) & (hr.index <= cft_end)]

if baseline_hr_series.empty:
    raise ValueError("Baseline interval is empty.")
if cft_hr_series.empty:
    raise ValueError("CFT interval is empty.")

baseline_hr = float(baseline_hr_series.mean())

below = cft_hr_series < baseline_hr
# Find the first run with at least three consecutive values below baseline; onset is its third sample.
run_len = 0
onset_time = None
onset_hr = None
for ts, is_below in below.items():
    if bool(is_below):
        run_len += 1
        if run_len == 3:
            onset_time = ts
            onset_hr = float(cft_hr_series.loc[ts])
            break
    else:
        run_len = 0

if onset_time is None:
    raise ValueError("No CFT onset found: no run of three consecutive HR values below baseline in CFT interval.")

onset_latency_s = (onset_time - cft_start).total_seconds()
onset_hr_percent = float((1.0 - onset_hr / baseline_hr) * 100.0)

results = {
    "baseline_hr": baseline_hr,
    "onset_hr": onset_hr,
    "onset_hr_percent": onset_hr_percent,
}

with out_path.open("w", encoding="utf-8") as f:
    json.dump(results, f, indent=2)

print("Recording start:", start)
print("Recording end:", hr.index[-1], "duration_s:", (hr.index[-1] - start).total_seconds())
print("Baseline interval:", start, "to", baseline_end, "n:", len(baseline_hr_series))
print("CFT interval:", cft_start, "to", cft_end, "n:", len(cft_hr_series))
print("Onset time:", onset_time, "onset_latency_s:", onset_latency_s)
print("Results:", json.dumps(results, indent=2))
print("Saved to:", out_path)