# inspect_cft_methods.py
import inspect
from biopsykit.protocols.cft import CFT

print("CFT class source relevant methods:\n")
for name in dir(CFT):
    if "compute" in name.lower() or "parameter" in name.lower() or "onset" in name.lower() or "baseline" in name.lower():
        attr = getattr(CFT, name)
        if callable(attr):
            print("\n" + "="*80)
            print(name)
            try:
                print(inspect.signature(attr))
            except Exception as e:
                print("signature err", e)
            try:
                print(inspect.getsource(attr))
            except Exception as e:
                print("source err", e)