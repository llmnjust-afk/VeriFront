from pathlib import Path
import inspect
from biopsykit.protocols.cft import CFT

src = inspect.getsource(CFT.onset)
Path("onset_source.txt").write_text(src)
print(src)
print("wrote onset_source.txt lines", len(src.splitlines()))