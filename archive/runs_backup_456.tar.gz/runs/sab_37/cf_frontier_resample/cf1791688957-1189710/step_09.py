import os
import json
from pathlib import Path

import pandas as pd
import numpy as np
from biopsykit.protocols import CFT

xlsx = Path("mist_hr/hr_sample_mist.xlsx")
df = pd.read_excel(xlsx, sheet_name="MIST3")
print("raw shape:", df.shape)
print("raw columns:", list(df.columns))
print("raw head:\n", df.head().to_string(index=False))

# Prepare BioPsyKit CFT heart-rate dataframe: DatetimeIndex and one Heart_Rate column.
df["time"] = pd.to_datetime(df["time"])
hr = df.set_index("time")[["Heart_Rate"]].sort_index()
hr = hr.dropna()
print("prepared shape:", hr.shape)
print("index type:", type(hr.index), "start:", hr.index[0], "end:", hr.index[-1])
print("duration seconds:", (hr.index[-1] - hr.index[0]).total_seconds())
print("HR summary:\n", hr["Heart_Rate"].describe().to_string())

# Use the standard CFT structure from BioPsyKit: 60 s baseline, 120 s CFT exposure, 60 s recovery.
# The available MIST3 data spans the full baseline and CFT exposure needed for these parameters.
cft = CFT(structure={"Baseline": 60, "CFT": 120, "Recovery": 60})
params = cft.compute_cft_parameter(hr, return_dict=True)
print("BioPsyKit CFT parameters:")
for k, v in params.items():
    print(k, repr(v), type(v))

# Required parameters only.
required = {}
for key in ["baseline_hr", "onset_hr", "onset_hr_percent"]:
    val = params[key]
    if isinstance(val, (pd.Timestamp,)):
        val = val.isoformat()
    elif isinstance(val, np.generic):
        val = val.item()
    elif isinstance(val, np.ndarray):
        val = val.item() if val.size == 1 else val.tolist()
    required[key] = float(val) if isinstance(val, (int, float, np.number)) else val

out_dir = Path("pred_results")
out_dir.mkdir(parents=True, exist_ok=True)
out_path = out_dir / "cft_pred_results.json"
with out_path.open("w") as f:
    json.dump(required, f, indent=2, sort_keys=True)

print("saved:", out_path)
print("json:", json.dumps(required, indent=2, sort_keys=True))