import json
from pathlib import Path

import pandas as pd
from biopsykit.protocols import CFT

xlsx = Path("mist_hr/hr_sample_mist.xlsx")
df = pd.read_excel(xlsx, sheet_name="MIST3")
print("raw shape:", df.shape)
print(df.head().to_string(index=False))
print(df.tail().to_string(index=False))
print("dtypes:", df.dtypes.to_dict())

# Prepare BioPsyKit input: DatetimeIndex and a heart-rate column.
df["time"] = pd.to_datetime(df["time"])
data = df.set_index("time")[["Heart_Rate"]].sort_index()
print("prepared index type:", type(data.index).__name__)
print("duration seconds:", (data.index[-1] - data.index[0]).total_seconds())
print("columns:", list(data.columns))
print("sampling intervals seconds summary:")
print(data.index.to_series().diff().dt.total_seconds().describe().to_string())

cft = CFT()
print("CFT defaults: cft_start", cft.cft_start, "cft_duration", cft.cft_duration, "structure", cft.structure)

try:
    params = cft.compute_cft_parameter(data, return_dict=True)
    print("computed params:")
    for k, v in params.items():
        print(k, repr(v))
except Exception as e:
    print("compute_cft_parameter failed:", type(e).__name__, str(e))
    raise