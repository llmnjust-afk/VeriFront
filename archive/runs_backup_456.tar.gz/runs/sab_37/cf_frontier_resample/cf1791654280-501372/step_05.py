import inspect
from biopsykit.protocols.cft import CFT

for name in ["compute_cft_parameter", "baseline_hr", "onset", "onset_hr", "onset_hr_percent"]:
    if hasattr(CFT, name):
        obj = getattr(CFT, name)
        print("\n==", name, "signature", inspect.signature(obj), "==")
        print(inspect.getsource(obj))
    else:
        print("missing", name)

print("All CFT methods containing hr/onset/baseline/param:")
for name, obj in inspect.getmembers(CFT):
    if (inspect.isfunction(obj) or inspect.ismethod(obj)) and any(s in name.lower() for s in ["hr", "onset", "baseline", "param", "brad"]):
        print(name, inspect.signature(obj))