import importlib.util
import pkgutil
import sys
from pathlib import Path

mods = ["biopsykit", "BioPsyKit", "numpy", "pandas", "scipy"]
for m in mods:
    spec = importlib.util.find_spec(m)
    print(m, "available:", spec is not None, "origin:", spec.origin if spec else None)

if importlib.util.find_spec("biopsykit"):
    import biopsykit
    print("biopsykit version:", getattr(biopsykit, "__version__", "unknown"))
    print("biopsykit file:", biopsykit.__file__)
    names = []
    for mod in pkgutil.walk_packages(biopsykit.__path__, biopsykit.__name__ + "."):
        if any(s in mod.name.lower() for s in ["cft", "cold", "heart", "hr"]):
            names.append(mod.name)
    print("candidate modules:")
    for n in names[:100]:
        print(" ", n)