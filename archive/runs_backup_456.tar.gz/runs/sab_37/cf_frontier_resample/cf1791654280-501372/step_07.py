import json
from pathlib import Path

import pandas as pd
from biopsykit.protocols import CFT

# Load the heart-rate data from the requested sheet.
xlsx = Path("mist_hr/hr_sample_mist.xlsx")
df = pd.read_excel(xlsx, sheet_name="MIST3")

# BioPsyKit's CFT routines expect a DatetimeIndex and a heart-rate column.
df["time"] = pd.to_datetime(df["time"])
data = df.set_index("time")[["Heart_Rate"]].sort_index()

# Compute CFT parameters using the standard CFT structure:
# 60 s baseline, 120 s CFT exposure, 60 s recovery.
cft = CFT()
params = cft.compute_cft_parameter(data, return_dict=True)

# Save the required parameters with the specified keys.
results = {
    "baseline_hr": float(params["baseline_hr"]),
    "onset_hr": float(params["onset_hr"]),
    "onset_hr_percent": float(params["onset_hr_percent"]),
}

out_dir = Path("pred_results")
out_dir.mkdir(parents=True, exist_ok=True)
out_path = out_dir / "cft_pred_results.json"
with out_path.open("w", encoding="utf-8") as f:
    json.dump(results, f, indent=2, sort_keys=True)

print("Saved:", out_path)
print(json.dumps(results, indent=2, sort_keys=True))