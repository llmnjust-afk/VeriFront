# inspect_cft_parameter_sources.py
import inspect
from biopsykit.protocols.cft import CFT

for name in ["baseline_hr", "extract_cft_interval", "onset", "peak_bradycardia", "mean_bradycardia", "poly_fit"]:
    print("\n" + "="*100)
    print(name)
    attr = getattr(CFT, name)
    print(inspect.signature(attr))
    print(inspect.getsource(attr))