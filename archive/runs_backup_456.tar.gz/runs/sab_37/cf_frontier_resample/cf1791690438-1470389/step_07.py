# compute_cft_params_trial.py
from pathlib import Path
import json

import pandas as pd
import numpy as np
from biopsykit.protocols import CFT

xlsx_path = Path("mist_hr/hr_sample_mist.xlsx")
df_raw = pd.read_excel(xlsx_path, sheet_name="MIST3")
print("Raw shape:", df_raw.shape)
print(df_raw.head().to_string(index=False))
print(df_raw.tail().to_string(index=False))

# BioPsyKit CFT expects a DataFrame/Series indexed by time.
hr = df_raw.set_index("time")[["Heart_Rate"]].sort_index()
print("Indexed shape:", hr.shape, "start:", hr.index[0], "end:", hr.index[-1])
print("Duration s:", (hr.index[-1] - hr.index[0]).total_seconds())

cft = CFT()  # default structure: Baseline=60 s, CFT=120 s, Recovery=60 s
print("CFT structure:", cft.structure, "cft_start:", cft.cft_start, "cft_duration:", cft.cft_duration)

baseline = cft.baseline_hr(hr)
cft_interval = cft.extract_cft_interval(hr)
print("Baseline HR:", baseline)
print("CFT interval shape:", cft_interval.shape, "start:", cft_interval.index[0], "end:", cft_interval.index[-1])
print("CFT interval duration:", (cft_interval.index[-1] - cft_interval.index[0]).total_seconds())

onset = cft.onset(cft_interval, is_cft_interval=True, compute_baseline=False, hr_baseline=baseline)
print("Onset dict:")
for k, v in onset.items():
    if hasattr(v, "item"):
        try:
            v = v.item()
        except Exception:
            pass
    print(f"  {k}: {v!r} ({type(v)})")

# Also try full compute_cft_parameter to verify BioPsyKit's combined output.
try:
    params = cft.compute_cft_parameter(hr, return_dict=True)
    print("Full compute_cft_parameter keys:", sorted(params.keys()))
    for k in ["baseline_hr", "onset_hr", "onset_hr_percent"]:
        print("full", k, params.get(k), type(params.get(k)))
except Exception as e:
    print("Full compute_cft_parameter failed:", repr(e))