# compute_and_save_cft_results.py
from pathlib import Path
import json

import pandas as pd
from biopsykit.protocols import CFT

input_path = Path("mist_hr/hr_sample_mist.xlsx")
output_path = Path("pred_results/cft_pred_results.json")
output_path.parent.mkdir(parents=True, exist_ok=True)

# Load heart-rate data from the requested sheet.
df = pd.read_excel(input_path, sheet_name="MIST3")
if "time" not in df.columns or "Heart_Rate" not in df.columns:
    raise ValueError(f"Expected columns ['time', 'Heart_Rate'], found {list(df.columns)}")

# BioPsyKit CFT methods expect heart-rate data indexed by timestamps.
hr_data = df.set_index("time")[["Heart_Rate"]].sort_index()

# Use the standard BioPsyKit CFT structure:
# 60 s baseline, 120 s cold-face-test interval, 60 s recovery.
cft = CFT()
baseline_hr = cft.baseline_hr(hr_data)
cft_interval = cft.extract_cft_interval(hr_data)
onset_params = cft.onset(
    data=cft_interval,
    is_cft_interval=True,
    compute_baseline=False,
    hr_baseline=baseline_hr,
)

results = {
    "baseline_hr": float(baseline_hr),
    "onset_hr": float(onset_params["onset_hr"]),
    "onset_hr_percent": float(onset_params["onset_hr_percent"]),
}

with output_path.open("w", encoding="utf-8") as f:
    json.dump(results, f, indent=2, sort_keys=True)

print(f"Loaded {len(hr_data)} MIST3 heart-rate samples from {input_path}")
print(f"CFT structure used: {cft.structure}")
print(f"Recording start: {hr_data.index[0]}")
print(f"Recording end: {hr_data.index[-1]}")
print(f"CFT interval start: {cft_interval.index[0]}")
print(f"CFT interval end: {cft_interval.index[-1]}")
print("Computed required CFT parameters:")
print(json.dumps(results, indent=2, sort_keys=True))
print(f"Saved JSON to: {output_path}")
print(f"Output file exists: {output_path.exists()}, size: {output_path.stat().st_size if output_path.exists() else 'NA'} bytes")