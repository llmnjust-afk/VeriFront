# inspect_onset_full.py
import inspect
from biopsykit.protocols.cft import CFT

for name in ["onset", "peak_bradycardia", "mean_bradycardia", "poly_fit"]:
    src = inspect.getsource(getattr(CFT, name))
    print("\n" + "="*80)
    print(name, "source length", len(src))
    print(src)