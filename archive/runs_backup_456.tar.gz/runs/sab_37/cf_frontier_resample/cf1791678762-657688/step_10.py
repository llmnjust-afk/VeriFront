import json
import os
from pathlib import Path

import numpy as np
import pandas as pd
from biopsykit.protocols import CFT

# Load MIST3 heart-rate sheet
input_path = Path("mist_hr/hr_sample_mist.xlsx")
df = pd.read_excel(input_path, sheet_name="MIST3")

# Prepare data for BioPsyKit CFT routines: DatetimeIndex + one HR column
df["time"] = pd.to_datetime(df["time"])
hr = df.set_index("time")[["Heart_Rate"]].sort_index()
hr = hr.dropna()

print("Loaded rows:", len(hr))
print("Start:", hr.index[0], "End:", hr.index[-1])
print("Duration seconds:", (hr.index[-1] - hr.index[0]).total_seconds())
print("First rows:")
print(hr.head().to_string())
print("Last rows:")
print(hr.tail().to_string())

# CFT default structure: 60 s baseline, 120 s cold-face exposure, 60 s recovery.
# This sheet contains enough data for the required baseline and CFT exposure intervals.
cft = CFT()
print("CFT structure:", cft.structure)
print("cft_start:", cft.cft_start, "cft_duration:", cft.cft_duration)

baseline_hr = cft.baseline_hr(hr)
onset_params = cft.onset(hr)

results = {
    "baseline_hr": float(baseline_hr),
    "onset_hr": float(np.asarray(onset_params["onset_hr"]).squeeze()),
    "onset_hr_percent": float(np.asarray(onset_params["onset_hr_percent"]).squeeze()),
}

print("Onset params:")
for k, v in onset_params.items():
    print(k, repr(v))
print("Required results:")
print(json.dumps(results, indent=2))

# Save JSON to required path
out_dir = Path("pred_results")
out_dir.mkdir(parents=True, exist_ok=True)
out_path = out_dir / "cft_pred_results.json"
with out_path.open("w", encoding="utf-8") as f:
    json.dump(results, f, indent=2)

print("Saved:", out_path.resolve())
print("File content:")
print(out_path.read_text())