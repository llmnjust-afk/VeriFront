import inspect
from biopsykit.protocols.cft import CFT

obj = CFT.onset
print("onset", inspect.signature(obj))
src = inspect.getsource(obj)
for i, line in enumerate(src.splitlines(), 1):
    print(f"{i:03d}: {line}")