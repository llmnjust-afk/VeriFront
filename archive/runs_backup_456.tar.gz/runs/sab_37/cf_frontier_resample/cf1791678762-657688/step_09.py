import inspect
from biopsykit.protocols.cft import CFT
src = inspect.getsource(CFT.onset)
print(src)
print("repr tail:", repr(src[-300:]))