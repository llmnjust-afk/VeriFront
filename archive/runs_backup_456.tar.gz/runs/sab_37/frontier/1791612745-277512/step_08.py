# compute_required_cft_results.py
import json
from pathlib import Path

import pandas as pd
from biopsykit.protocols import CFT

input_path = Path("mist_hr/hr_sample_mist.xlsx")
output_path = Path("pred_results/cft_pred_results.json")
output_path.parent.mkdir(parents=True, exist_ok=True)

# Load the required heart-rate data sheet.
df = pd.read_excel(input_path, sheet_name="MIST3")
hr = df[["time", "Heart_Rate"]].dropna().copy()
hr["time"] = pd.to_datetime(hr["time"])
hr = hr.set_index("time")["Heart_Rate"].sort_index()

print("Loaded MIST3 heart-rate data")
print("rows:", len(hr))
print("start:", hr.index[0])
print("end:", hr.index[-1])
print("duration_s:", (hr.index[-1] - hr.index[0]).total_seconds())
print("first rows:")
print(hr.head().to_string())

# Standard CFT structure: 60 s baseline followed by 120 s cold-face exposure.
# Only the requested parameters are computed to avoid unrelated BioPsyKit peak-fit
# routines that are not required for this benchmark output.
cft = CFT(structure={"Baseline": 60, "CFT": 120, "Recovery": 60})

baseline_hr = cft.baseline_hr(hr)
onset_params = cft.onset(
    data=cft.extract_cft_interval(hr),
    is_cft_interval=True,
    compute_baseline=False,
    hr_baseline=baseline_hr,
)

results = {
    "baseline_hr": float(baseline_hr),
    "onset_hr": float(onset_params["onset_hr"]),
    "onset_hr_percent": float(onset_params["onset_hr_percent"]),
}

print("Computed requested CFT parameters:")
print(json.dumps(results, indent=2))
print("Additional onset diagnostics:")
for key in ["onset", "onset_latency", "onset_idx", "onset_slope"]:
    print(f"{key}: {onset_params[key]}")

with output_path.open("w", encoding="utf-8") as f:
    json.dump(results, f, indent=2)

print("Saved:", output_path)