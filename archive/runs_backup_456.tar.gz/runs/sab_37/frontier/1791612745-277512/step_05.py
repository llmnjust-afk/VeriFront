# inspect_cft_formulas.py
import inspect
from biopsykit.protocols.cft import CFT

for method in ["baseline_hr", "extract_cft_interval", "onset", "peak_bradycardia", "mean_bradycardia", "poly_fit"]:
    print("\n" + "="*100)
    print(method, inspect.signature(getattr(CFT, method)))
    print(inspect.getsource(getattr(CFT, method)))