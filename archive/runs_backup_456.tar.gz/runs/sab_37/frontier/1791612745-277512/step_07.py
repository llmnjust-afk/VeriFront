# compute_cft_results.py
import json
from pathlib import Path

import pandas as pd
from biopsykit.protocols import CFT

input_path = Path("mist_hr/hr_sample_mist.xlsx")
output_path = Path("pred_results/cft_pred_results.json")
output_path.parent.mkdir(parents=True, exist_ok=True)

# Load heart rate data from required sheet
df = pd.read_excel(input_path, sheet_name="MIST3")
print("Loaded MIST3:", df.shape)
print(df.head().to_string(index=False))

# BioPsyKit CFT expects HR data indexed by time/datetime, ideally a single-column DataFrame/Series.
hr = df[["time", "Heart_Rate"]].dropna().copy()
hr["time"] = pd.to_datetime(hr["time"])
hr = hr.set_index("time")["Heart_Rate"]

print("HR series length:", len(hr))
print("Start:", hr.index[0], "End:", hr.index[-1], "Duration_s:", (hr.index[-1] - hr.index[0]).total_seconds())

# Use standard CFT structure from BioPsyKit/domain docs:
# 60 s baseline, 120 s CFT exposure, 60 s recovery.
# The required baseline/onset parameters only require baseline + CFT interval.
cft = CFT(structure={"Baseline": 60, "CFT": 120, "Recovery": 60})

params = cft.compute_cft_parameter(hr, return_dict=True)
print("Computed CFT parameters:")
for k, v in params.items():
    print(f"{k}: {v}")

required = {
    "baseline_hr": float(params["baseline_hr"]),
    "onset_hr": float(params["onset_hr"]),
    "onset_hr_percent": float(params["onset_hr_percent"]),
}

with output_path.open("w", encoding="utf-8") as f:
    json.dump(required, f, indent=2)

print("Saved required parameters to", output_path)
print(json.dumps(required, indent=2))