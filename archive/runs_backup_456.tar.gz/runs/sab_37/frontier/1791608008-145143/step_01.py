import os
import json
from pathlib import Path

import pandas as pd

xlsx = Path("mist_hr/hr_sample_mist.xlsx")
print("exists", xlsx.exists(), "size", xlsx.stat().st_size if xlsx.exists() else None)

try:
    xl = pd.ExcelFile(xlsx)
    print("sheets:", xl.sheet_names)
    for sh in xl.sheet_names:
        df = pd.read_excel(xlsx, sheet_name=sh, nrows=10)
        print("\nSHEET", sh)
        print("shape first10", df.shape)
        print("columns", list(df.columns))
        print(df.head(10).to_string())
except Exception as e:
    print("ERROR reading workbook:", repr(e))

# Check relevant installed packages
for mod in ["biopsykit", "neurokit2", "biosppy", "heartpy", "openpyxl", "scipy", "numpy", "pandas"]:
    try:
        m = __import__(mod)
        print("package", mod, "OK", getattr(m, "__version__", "no_version"))
    except Exception as e:
        print("package", mod, "NOT available", repr(e))