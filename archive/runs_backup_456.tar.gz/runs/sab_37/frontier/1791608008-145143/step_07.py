from pathlib import Path
import inspect, re
import biopsykit.protocols.cft as cft

txt = Path(inspect.getfile(cft.CFT)).read_text()
# Print compute_cft_parameter and helper functions in chunks
for pattern in ["def compute_cft_parameter", "def cft_plot", "def _"]:
    pass
start = txt.find("    def compute_cft_parameter")
end = txt.find("    def cft_plot", start)
print(txt[start:end])
print("\n--- remaining helper defs names ---")
for m in re.finditer(r"^(def|    def) ([A-Za-z_][A-Za-z0-9_]*)", txt, flags=re.M):
    print(m.group(0), "at", m.start())