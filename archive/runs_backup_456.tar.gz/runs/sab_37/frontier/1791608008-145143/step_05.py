import biopsykit, pkgutil, importlib, inspect
from pathlib import Path

# Print only relevant BioPsyKit analysis modules/classes/functions for CFT
terms = ["cft", "cold", "face", "onset", "baseline"]
hits = []
for modinfo in pkgutil.walk_packages(biopsykit.__path__, biopsykit.__name__ + "."):
    lname = modinfo.name.lower()
    if any(t in lname for t in terms) or "protocols" in lname or "mist" in lname:
        hits.append(modinfo.name)
print("module hits count", len(hits))
for h in hits:
    print(h)

print("\nImport selected modules and inspect names/docs:")
for modname in hits:
    try:
        mod = importlib.import_module(modname)
    except Exception as e:
        print("IMPORT_ERR", modname, repr(e))
        continue
    names = [n for n in dir(mod) if any(t in n.lower() for t in terms + ["hr", "heart", "parameter", "feature"])]
    if names:
        print("\nMOD", modname)
        for n in names:
            obj = getattr(mod, n)
            line = ""
            if inspect.isclass(obj) or inspect.isfunction(obj):
                try:
                    line += str(inspect.signature(obj))
                except Exception:
                    pass
                doc = inspect.getdoc(obj)
                if doc:
                    line += " DOC: " + doc.split("\n")[0][:160]
            else:
                line = repr(obj)[:160]
            print(" ", n, line)

# Try locate installed package files containing cft or onset_hr
pkg_path = Path(biopsykit.__file__).parent
print("\nPackage path:", pkg_path)
patterns = ["cft", "onset_hr", "baseline_hr", "cold face", "Cold"]
for pat in patterns:
    print("\nGREP", pat)
    count=0
    for py in pkg_path.rglob("*.py"):
        try:
            txt = py.read_text(errors="ignore")
        except:
            continue
        if pat.lower() in txt.lower():
            print(" ", py.relative_to(pkg_path))
            count += 1
            if count >= 20:
                break
    print("count", count)