import json
from pathlib import Path

import numpy as np
import pandas as pd
from biopsykit.protocols import CFT

# Locate input workbook. The task path is preferred; in this execution environment
# the dataset is mounted in the benchmark_verified dataset directory.
candidate_paths = [
    Path("mist_hr/hr_sample_mist.xlsx"),
    Path("benchmark/datasets/mist_hr/hr_sample_mist.xlsx"),
    Path("/data/lab/sab_data/benchmark_verified/benchmark/datasets/mist_hr/hr_sample_mist.xlsx"),
]
xlsx_path = next((p for p in candidate_paths if p.exists()), None)
if xlsx_path is None:
    raise FileNotFoundError("Could not find hr_sample_mist.xlsx in expected locations.")

print("Using workbook:", xlsx_path)

# Load heart-rate data from sheet MIST3.
raw = pd.read_excel(xlsx_path, sheet_name="MIST3")
print("Loaded MIST3 shape:", raw.shape)
print(raw.head().to_string())
print(raw.tail().to_string())

# Prepare for BioPsyKit CFT: single HR column indexed by datetime.
df = raw.copy()
df["time"] = pd.to_datetime(df["time"])
df = df.set_index("time")[["Heart_Rate"]].sort_index()
df = df.rename(columns={"Heart_Rate": "Heart_Rate"})
print("Prepared HR interval:", df.index[0], "to", df.index[-1], "duration_s", (df.index[-1] - df.index[0]).total_seconds())

# Compute CFT parameters using BioPsyKit defaults:
# Baseline = first 60 s, CFT exposure = following 120 s, Recovery = 60 s.
cft = CFT()
params = cft.compute_cft_parameter(df, return_dict=True)

print("All computed CFT parameters:")
for k, v in params.items():
    print(k, repr(v))

# Extract required keys and convert numpy/pandas scalar types to plain JSON numbers.
required = {
    "baseline_hr": float(np.asarray(params["baseline_hr"]).squeeze()),
    "onset_hr": float(np.asarray(params["onset_hr"]).squeeze()),
    "onset_hr_percent": float(np.asarray(params["onset_hr_percent"]).squeeze()),
}

# Save required output.
out_dir = Path("pred_results")
out_dir.mkdir(parents=True, exist_ok=True)
out_path = out_dir / "cft_pred_results.json"
with out_path.open("w", encoding="utf-8") as f:
    json.dump(required, f, indent=2, sort_keys=True)

print("Saved:", out_path)
print(json.dumps(required, indent=2, sort_keys=True))