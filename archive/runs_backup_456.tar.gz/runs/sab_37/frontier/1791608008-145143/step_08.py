from pathlib import Path
import inspect
import biopsykit.protocols.cft as cft

txt = Path(inspect.getfile(cft.CFT)).read_text()
# save relevant full cft source copy for line-numbered inspection chunks
lines = txt.splitlines()
for i, line in enumerate(lines, start=1):
    if 90 <= i <= 360:
        print(f"{i:04d}: {line}")