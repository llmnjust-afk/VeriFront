from pathlib import Path
import os

def list_tree(base, max_depth=6):
    base = Path(base)
    print(f"Tree for {base.resolve() if base.exists() else base}: exists={base.exists()}")
    if not base.exists():
        return
    for root, dirs, files in os.walk(base):
        rel = Path(root).relative_to(base)
        depth = len(rel.parts)
        if depth > max_depth:
            dirs[:] = []
            continue
        indent = "  " * depth
        print(f"{indent}{Path(root).name}/")
        for f in sorted(files)[:50]:
            p = Path(root)/f
            print(f"{indent}  {f} ({p.stat().st_size} bytes)")
        if len(files) > 50:
            print(f"{indent}  ... {len(files)-50} more files")

list_tree("benchmark", 8)
print("\nAbsolute search in /data/lab/VeriFront for hr_sample_mist.xlsx or mist_hr (depth constrained by find via os.walk):")
targets = []
for base in [Path.cwd(), Path("/data/lab/VeriFront"), Path("/data/lab"), Path("/tmp")]:
    if not base.exists():
        continue
    print("search base", base)
    count = 0
    for root, dirs, files in os.walk(base):
        # prune hidden/cache-ish large dirs
        dirs[:] = [d for d in dirs if d not in {".git", "__pycache__", "node_modules"}]
        for d in dirs:
            if d == "mist_hr":
                print("found dir", Path(root)/d)
        for f in files:
            if f == "hr_sample_mist.xlsx" or f.lower().endswith((".xlsx",".xls")):
                p = Path(root)/f
                print("found excel", p, p.stat().st_size)
                targets.append(p)
                count += 1
                if count > 20:
                    break
        if count > 20:
            break
    print("done base", base, "found excel count printed <=", count)
print("targets:", targets[:10])