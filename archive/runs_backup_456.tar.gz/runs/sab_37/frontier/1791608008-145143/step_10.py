from pathlib import Path
import inspect
import biopsykit.protocols.cft as cft

lines = Path(inspect.getfile(cft.CFT)).read_text().splitlines()
for lo, hi in [(243,330),(331,390)]:
    print(f"\n--- lines {lo}-{hi} ---")
    for i in range(lo, min(hi, len(lines))+1):
        print(f"{i:04d}: {lines[i-1]}")