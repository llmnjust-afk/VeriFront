from pathlib import Path
import inspect
import biopsykit.protocols.cft as cft

path = Path(inspect.getfile(cft.CFT))
print("CFT file:", path)
txt = path.read_text()
print(txt[:20000])