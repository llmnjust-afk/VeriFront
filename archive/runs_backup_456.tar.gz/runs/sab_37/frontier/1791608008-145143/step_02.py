from pathlib import Path
import os

print("cwd:", Path.cwd())
print("top-level entries:")
for p in sorted(Path(".").iterdir()):
    print(" ", p, "dir" if p.is_dir() else f"file {p.stat().st_size}")

print("\nSearching for .xlsx/.xls/.csv files up to depth 5:")
matches = []
for root, dirs, files in os.walk("."):
    depth = Path(root).relative_to(".").parts
    if len(depth) > 5:
        dirs[:] = []
        continue
    for f in files:
        if f.lower().endswith((".xlsx", ".xls", ".csv", ".json")):
            path = Path(root) / f
            matches.append(path)
            print(path, path.stat().st_size)
print("num matches", len(matches))