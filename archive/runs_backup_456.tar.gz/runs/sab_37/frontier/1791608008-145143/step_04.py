from pathlib import Path
import pandas as pd
import numpy as np
import inspect
import biopsykit

src = Path("/data/lab/sab_data/benchmark_verified/benchmark/datasets/mist_hr/hr_sample_mist.xlsx")
print("source exists", src.exists(), src, src.stat().st_size if src.exists() else None)

xl = pd.ExcelFile(src)
print("sheets:", xl.sheet_names)
for sh in xl.sheet_names:
    df = pd.read_excel(src, sheet_name=sh)
    print("\nSHEET", sh, "shape", df.shape)
    print("cols", list(df.columns))
    print(df.head(3).to_string())
    print(df.tail(3).to_string())
    print(df.describe(include='all').to_string())

print("\nbiopsykit version", biopsykit.__version__)
print("biopsykit attrs", [a for a in dir(biopsykit) if not a.startswith("_")][:100])

# Search BioPsyKit for CFT/ColdFace/heart related APIs
import pkgutil, importlib
names = []
for modinfo in pkgutil.walk_packages(biopsykit.__path__, biopsykit.__name__ + "."):
    lname = modinfo.name.lower()
    if any(k in lname for k in ["cft", "cold", "heart", "hr", "ecg"]):
        names.append(modinfo.name)
print("candidate modules", names[:200], "count", len(names))

for modname in names[:100]:
    try:
        mod = importlib.import_module(modname)
        members = [n for n in dir(mod) if any(k in n.lower() for k in ["cft","cold","heart","hr","ecg","onset","baseline"])]
        print("\nMOD", modname, "members", members[:50])
        for n in members[:20]:
            obj = getattr(mod, n)
            if inspect.isfunction(obj) or inspect.isclass(obj):
                try:
                    print(" ", n, inspect.signature(obj))
                except Exception as e:
                    print(" ", n, "sig err", e)
    except Exception as e:
        print("IMPORT ERR", modname, repr(e))