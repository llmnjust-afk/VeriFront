from pathlib import Path
import biopsykit.protocols.cft as cft

lines = Path(cft.__file__).read_text().splitlines()
for a,b in [(243, 345), (345, 430)]:
    print(f"\n===== LINES {a}-{b} =====")
    for i in range(a-1, min(b, len(lines))):
        print(f"{i+1:04d}: {lines[i]}")