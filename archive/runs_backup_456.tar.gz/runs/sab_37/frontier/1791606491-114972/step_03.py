import os
from pathlib import Path

def list_tree(root, max_depth=6):
    root = Path(root)
    print(f"\nTree under {root}:")
    for dirpath, dirnames, filenames in os.walk(root):
        p = Path(dirpath)
        depth = len(p.relative_to(root).parts)
        if depth > max_depth:
            dirnames[:] = []
            continue
        indent = "  " * depth
        print(f"{indent}{p.name}/")
        for fn in sorted(filenames):
            fp = p / fn
            try:
                size = fp.stat().st_size
            except Exception:
                size = "?"
            print(f"{indent}  {fn} ({size})")

list_tree("benchmark", max_depth=8)
list_tree("pred_results", max_depth=2)

print("\nSearching all files under current directory:")
for p in sorted(Path(".").glob("**/*")):
    if p.is_file():
        print(p, p.stat().st_size)