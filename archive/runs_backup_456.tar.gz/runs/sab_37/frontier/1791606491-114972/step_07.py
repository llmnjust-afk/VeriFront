from pathlib import Path
import inspect
import biopsykit.protocols.cft as cft

print("Module file:", cft.__file__)
print("Dir:")
for name in dir(cft):
    if not name.startswith("_"):
        obj = getattr(cft, name)
        print(" ", name, type(obj))

print("\nSource:")
src = Path(cft.__file__).read_text()
print(src)