from pathlib import Path
import re
import biopsykit.protocols.cft as cft

src = Path(cft.__file__).read_text().splitlines()

# Print relevant method bodies by line ranges.
ranges = [(80, 180), (180, 330), (330, 520)]
for a,b in ranges:
    print(f"\n===== LINES {a}-{b} =====")
    for i in range(a-1, min(b, len(src))):
        print(f"{i+1:04d}: {src[i]}")