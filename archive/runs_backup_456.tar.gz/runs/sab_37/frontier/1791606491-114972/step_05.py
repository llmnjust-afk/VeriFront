import json
from pathlib import Path

import numpy as np
import pandas as pd

xlsx_path = Path("/data/lab/sab_data/benchmark_verified/benchmark/datasets/mist_hr/hr_sample_mist.xlsx")
print("Using:", xlsx_path, "exists", xlsx_path.exists(), "size", xlsx_path.stat().st_size if xlsx_path.exists() else None)

xl = pd.ExcelFile(xlsx_path)
print("Sheets:", xl.sheet_names)

# Load all sheets with dimensions and columns to infer where HR / protocol metadata live.
for sheet in xl.sheet_names:
    try:
        df0 = pd.read_excel(xlsx_path, sheet_name=sheet)
        print("\nSHEET", repr(sheet), "shape", df0.shape)
        print("columns:", list(df0.columns))
        print(df0.head(8).to_string())
        print("tail:")
        print(df0.tail(3).to_string())
    except Exception as e:
        print("Error reading", sheet, repr(e))

# Focus on MIST3
df = pd.read_excel(xlsx_path, sheet_name="MIST3")
print("\nMIST3 dtypes:")
print(df.dtypes.to_string())
print("time min/max/duration:", df["timestamps"].min(), df["timestamps"].max(), df["timestamps"].max() - df["timestamps"].min())
print("sampling interval median:", np.median(np.diff(df["timestamps"].to_numpy())))
print("rows:", len(df))