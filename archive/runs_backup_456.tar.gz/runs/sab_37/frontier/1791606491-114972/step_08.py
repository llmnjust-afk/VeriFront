from pathlib import Path
import re
import biopsykit.protocols.cft as cft

src = Path(cft.__file__).read_text()
# Print class method names and the sections around parameter computation.
for pat in ["baseline_hr", "onset_hr", "onset_hr_percent", "compute", "parameter", "extract"]:
    print(f"\n=== occurrences of {pat!r} ===")
    for m in re.finditer(pat, src):
        start = max(0, m.start()-900)
        end = min(len(src), m.end()+1600)
        print(src[start:end])
        print("\n---")
        break

# list function definitions with line numbers
print("\nDefinitions:")
for i, line in enumerate(src.splitlines(), 1):
    if re.match(r"\s+def |\s*class ", line):
        print(f"{i}: {line}")