import json
from pathlib import Path

import numpy as np
import pandas as pd
from biopsykit.protocols import CFT

xlsx_path = Path("/data/lab/sab_data/benchmark_verified/benchmark/datasets/mist_hr/hr_sample_mist.xlsx")
out_path = Path("pred_results/cft_pred_results.json")
out_path.parent.mkdir(parents=True, exist_ok=True)

df = pd.read_excel(xlsx_path, sheet_name="MIST3")
print("Loaded MIST3:", df.shape, df.dtypes.to_dict())
print(df.head().to_string())

# BioPsyKit CFT expects a one-column HR dataframe indexed by time.
hr = df[["time", "Heart_Rate"]].copy()
hr["time"] = pd.to_datetime(hr["time"])
hr = hr.set_index("time").sort_index()
hr = hr.rename(columns={"Heart_Rate": "Heart_Rate"})
print("HR index range:", hr.index[0], "to", hr.index[-1], "duration_s", (hr.index[-1] - hr.index[0]).total_seconds())

# Default CFT protocol: Baseline=60s, CFT=120s, Recovery=60s.
cft = CFT()
params = cft.compute_cft_parameter(hr, return_dict=True)
print("Computed full CFT params:")
for k, v in params.items():
    print(k, repr(v), type(v))

result = {
    "baseline_hr": float(params["baseline_hr"]),
    "onset_hr": float(params["onset_hr"]),
    "onset_hr_percent": float(params["onset_hr_percent"]),
}

with out_path.open("w") as f:
    json.dump(result, f, indent=2, sort_keys=True)

print("Saved:", out_path)
print(json.dumps(result, indent=2, sort_keys=True))