import os
import json
from pathlib import Path

import pandas as pd

xlsx_path = Path("mist_hr/hr_sample_mist.xlsx")
print("Exists:", xlsx_path.exists(), "Path:", xlsx_path)

if xlsx_path.exists():
    xl = pd.ExcelFile(xlsx_path)
    print("Sheets:", xl.sheet_names)
    for sheet in xl.sheet_names:
        if sheet == "MIST3":
            df = pd.read_excel(xlsx_path, sheet_name=sheet)
            print("MIST3 shape:", df.shape)
            print("MIST3 columns:", list(df.columns))
            print("MIST3 head:")
            print(df.head(10).to_string())
            print("MIST3 tail:")
            print(df.tail(10).to_string())
            print("MIST3 describe:")
            print(df.describe(include='all').to_string())
        else:
            # print minimal sheet metadata to understand workbook structure
            try:
                tmp = pd.read_excel(xlsx_path, sheet_name=sheet, nrows=3)
                print(f"Sheet {sheet!r} shape preview:", tmp.shape, "columns:", list(tmp.columns))
                print(tmp.head(3).to_string())
            except Exception as e:
                print(f"Could not preview sheet {sheet!r}:", repr(e))