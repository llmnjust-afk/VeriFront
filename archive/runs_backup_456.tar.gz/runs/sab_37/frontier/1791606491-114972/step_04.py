import os
from pathlib import Path

print("CWD:", os.getcwd())

# Search likely parent locations for the stated dataset file/folder.
roots = [Path("."), Path(".."), Path("../.."), Path("../../.."), Path("/data/lab/VeriFront"), Path("/data"), Path("/mnt/data")]
seen = set()
for root in roots:
    try:
        root = root.resolve()
    except Exception:
        continue
    if root in seen or not root.exists():
        continue
    seen.add(root)
    print(f"\nSearching under {root} (limited patterns)...")
    matches = []
    for pat in ["**/hr_sample_mist.xlsx", "**/mist_hr", "**/*mist*.xlsx", "**/*.xlsx"]:
        try:
            for p in root.glob(pat):
                matches.append(p)
        except Exception as e:
            print(" glob error", pat, e)
    for p in sorted(set(matches))[:200]:
        try:
            print(" ", p, "dir" if p.is_dir() else f"file {p.stat().st_size}")
        except Exception as e:
            print(" ", p, "stat error", e)
    if len(set(matches)) > 200:
        print(" ... truncated", len(set(matches)))