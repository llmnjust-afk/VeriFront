import importlib
import inspect
import pkgutil
import sys
from pathlib import Path

print("Python", sys.version)
mods = ["biopsykit", "BioPsyKit", "neurokit2"]
for m in mods:
    try:
        mod = importlib.import_module(m)
        print(m, "imported", getattr(mod, "__version__", "no version"), "file", getattr(mod, "__file__", None))
    except Exception as e:
        print(m, "not importable:", repr(e))

try:
    import biopsykit
    print("\nSearching biopsykit modules containing cft/cold...")
    names = []
    for mi in pkgutil.walk_packages(biopsykit.__path__, biopsykit.__name__ + "."):
        low = mi.name.lower()
        if "cft" in low or "cold" in low or "hr" in low or "heart" in low:
            names.append(mi.name)
    for name in names[:200]:
        print(" ", name)
    print("count", len(names))
except Exception as e:
    print("walk error", repr(e))

# Try grep source for CFT terms
try:
    import biopsykit
    root = Path(biopsykit.__file__).parent
    print("\nbiopsykit root", root)
    for term in ["CFT", "Cold Face", "cold face", "onset_hr", "baseline_hr"]:
        print(f"\nGREP {term!r}")
        hits = []
        for py in root.rglob("*.py"):
            try:
                txt = py.read_text(errors="ignore")
            except Exception:
                continue
            if term in txt:
                hits.append(py)
        for h in hits[:30]:
            print(" ", h)
        print(" hits", len(hits))
except Exception as e:
    print("grep error", repr(e))