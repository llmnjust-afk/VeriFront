import os
from pathlib import Path

print("Current working directory:", os.getcwd())
print("Top-level entries:")
for p in sorted(Path(".").iterdir()):
    print(" -", p, "dir" if p.is_dir() else "file", p.stat().st_size if p.is_file() else "")

print("\nSearching for Excel/data files up to depth 5:")
patterns = ["*.xlsx", "*.xls", "*.csv", "*.json", "*.txt"]
found = []
for pattern in patterns:
    found.extend(Path(".").glob(f"**/{pattern}"))
for p in sorted(set(found)):
    try:
        print(p, "size", p.stat().st_size)
    except Exception as e:
        print(p, "stat error", e)